﻿function Download_Orders(startDate, starttime, enddate, endtime, report) {
    
 
    var url = '/Report/Downloads_Order?'
         + 'datestart=' + document.getElementById(startDate).value
         + '&timestart=' + document.getElementById(starttime).value
         + '&dateend=' + document.getElementById(enddate).value
         + '&timeend=' + document.getElementById(endtime).value
         + '&reporttype=' + report;

    
      
            var a = document.createElement('a');
            a.href = url;
            a.download = 'Report' + (new Date()).getFullYear().toString()
                + (new Date()).getMonth().toString()
                + (new Date()).getDate().toString()
                + (new Date()).getTime().toString()
                + '.pdf';

   window.location.href = a.href;

            window.URL.revokeObjectURL(url);
        

};