﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Customers
{
    public class MCustomerController : MasterController
    {
        // GET: MCustomer
        private M_CustomerModel SetOldParametr()
        {
            M_CustomerModel obj = new M_CustomerModel(CurrentUser, "CUSTOMER");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.txtFullName = FieldFullName;
                    obj.txtBirthDate = FieldDATEAZ;
                    obj.cboSelectVisitor = FieldUSERSELECT;
                    obj.txtMobile = FieldMobileNumber;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_CustomerModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            FieldFullName = obj.txtFullName.Trim();
            FieldMobileNumber = obj.txtMobile.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            FieldDATEAZ = obj.txtBirthDate;
            FieldUSERSELECT = obj.cboSelectVisitor;
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult Customer()
        {
            M_CustomerModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Customer", obj);
        }
        [HttpPost]
        public ActionResult Customer(FormCollection frm, string btn)
        {
            M_CustomerModel obj = new M_CustomerModel(frm, CurrentUser, "CUSTOMER");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("CustomerSpec", "MCustomer");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("CustomerSpec", "MCustomer", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Customer", obj);
        }

        // GET: CustomerSPEC
        public ActionResult CustomerSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_CustomerSpecModel obj = new M_CustomerSpecModel(ID, CurrentUser, "CUSTOMERSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("CustomerSpec", obj);
        }
        [HttpPost]
        public ActionResult CustomerSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_CustomerSpecModel obj = new M_CustomerSpecModel(ID, frm, CurrentUser, "CUSTOMERSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Customer", "MCustomer", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Customer", "MCustomer", "index=old");
            }
            return View("CustomerSpec", obj);
        }

    }
}