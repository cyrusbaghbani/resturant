﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator
{
    public class MApplicationController : MasterController
    {
        // GET: MApplication
        public ActionResult MainPage()
        {
            M_MainPageModel obj = new M_MainPageModel(CurrentUser, "MAINPAGE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("MainPage",obj);
        }
        [HttpPost]
        public ActionResult MainPage(FormCollection frm, string btn)
        {
            M_MainPageModel obj = new M_MainPageModel(frm, CurrentUser, "MAINPAGE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("MainPage",obj);
        }



    }
}