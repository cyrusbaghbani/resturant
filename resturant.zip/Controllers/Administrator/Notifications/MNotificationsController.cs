﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Notifications
{
    public class MNotificationsController : MasterController
    {
        // GET: MNotifications

        private M_NotificationModel SetOldParametr()
        {
            M_NotificationModel obj = new M_NotificationModel(CurrentUser, "NOTIFICATION");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtDateAz = FieldDATEAZ;
                    obj.txtDateTa = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_NotificationModel obj)
        {
            FieldDATEAZ= obj.txtDateAz.Trim();
            FieldDATETA = obj.txtDateTa.Trim();

            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        // GET: MPersonel
        public ActionResult Notifications()
        {
            M_NotificationModel obj = new M_NotificationModel(CurrentUser, "NOTIFICATION");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Notifications", obj);
        }
        [HttpPost]
        public ActionResult Notifications(FormCollection frm, string btn)
        {
            M_NotificationModel obj = new M_NotificationModel(frm, CurrentUser, "NOTIFICATION");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("NotificationSpec", "MNotifications");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("NotificationSpec", "MNotifications", "id=" + obj.hf_SelectValueID+"&"+"type=" + obj.hf_SelectValueReciveMsg);
            }
           
            Search(obj);
            return View("Notifications", obj);
        }

        // GET: PersonelSPEC
        public ActionResult NotificationSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            string type = EmoNetUtility.GetQueryString("type", (string)RouteData.Values["id"]);
            M_NotificationSpecModel obj = new M_NotificationSpecModel(ID, type, CurrentUser, "NOTIFICATIONSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("NotificationSpec", obj);
        }
        [HttpPost]
        public ActionResult NotificationSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            string type = EmoNetUtility.GetQueryString("type", (string)RouteData.Values["id"]);
            M_NotificationSpecModel obj = new M_NotificationSpecModel(ID, type, frm, CurrentUser, "NOTIFICATIONSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Notifications", "MNotifications", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Notifications", "MNotifications", "index=old");
            }
            return View("NotificationSpec", obj);
        }


    }
}