﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Reports
{
    public class MReportsController : MasterController
    {
        // GET: MReports
        public ActionResult FactorReports()
        {
            M_FactorReportsModel obj = new M_FactorReportsModel( CurrentUser, "FACTORREPORTS_M");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("FactorReports", obj);
        }
        [HttpPost]
        public ActionResult FactorReports(FormCollection frm, string btn)
        {
            M_FactorReportsModel obj = new M_FactorReportsModel(frm, CurrentUser, "FACTORREPORTS_M");
            if (!obj.security.IsDisplay)
                return GOLOGIN();


            obj.Search();

            return View("FactorReports", obj);
        }
        public ActionResult Orders()
        {
            M_OrdersReportsModel obj = new M_OrdersReportsModel(CurrentUser, "ORDERREPORTS_M");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
      
            return View("OrderReports", obj);
        }


    }
}