﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Profiles
{

    public class MProfileController : MasterController
    {
        // GET: Profiles
        public ActionResult Profiles()
        {
            M_ProfileModel obj = new M_ProfileModel(CurrentUser, "PROFILES");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("Profiles", obj);
        }
        [HttpPost]
        public ActionResult Profiles(FormCollection frm, string btn)
        {
            M_ProfileModel obj = new M_ProfileModel(frm, CurrentUser, "PROFILES");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    obj.FullName_Master = obj.txtName + " " + obj.txtFamily;
                }
            }
            return View("Profiles", obj);
        }


        // GET: ChangePassword
        public ActionResult ChangePassword()
        {
            M_ChangePasswordModel obj = new M_ChangePasswordModel(CurrentUser, "CHANGEPASSWORD");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("ChangePassword", obj);
        }
        [HttpPost]
        public ActionResult ChangePassword(FormCollection frm, string btn)
        {
            M_ChangePasswordModel obj = new M_ChangePasswordModel(frm, CurrentUser, "CHANGEPASSWORD");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }


            return View("ChangePassword", obj);
        }
    }
}