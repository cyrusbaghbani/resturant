﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Systems
{
    public class MSystemController : MasterController
    {
        // GET: Events
        public ActionResult Events()
        {
            M_EventsModel obj = new M_EventsModel(CurrentUser, "EVENTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("Events", obj);
        }
        [HttpPost]
        public ActionResult Events(FormCollection frm, string btn)
        {
            M_EventsModel obj = new M_EventsModel(frm, CurrentUser, "EVENTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();



            obj.Search();
            return View("Events", obj);
        }

        // GET: Transactions
        public ActionResult Transactions()
        {
            M_TransactionsModel obj = new M_TransactionsModel(CurrentUser, "TRANSACTIONS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();


            obj.Search();
            return View("Transactions", obj);
        }
        [HttpPost]
        public ActionResult Transactions(FormCollection frm, string btn)
        {
            M_TransactionsModel obj = new M_TransactionsModel(frm, CurrentUser, "TRANSACTIONS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();



            obj.Search();
            return View("Transactions", obj);
        }


        // GET: BRAND
        public ActionResult Reserve_Products()
        {
            M_Reserve_ProductsModel obj = new M_Reserve_ProductsModel(CurrentUser, "RESERVE_PRODUCTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();


            obj.Search();
            return View("Reserve_Products", obj);
        }
        [HttpPost]
        public ActionResult Reserve_Products(FormCollection frm, string btn)
        {
            M_Reserve_ProductsModel obj = new M_Reserve_ProductsModel(frm, CurrentUser, "RESERVE_PRODUCTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }

            obj.Search();
            return View("Reserve_Products", obj);
        }

        public ActionResult Edit_SabadKharid()
        {
            M_Edit_SabadKharidModel obj = new M_Edit_SabadKharidModel(CurrentUser, "EDIT_SABADKHARID");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("Edit_SabadKharid", obj);
        }
        [HttpPost]
        public ActionResult Edit_SabadKharid(FormCollection frm, string btn)
        {
            M_Edit_SabadKharidModel obj = new M_Edit_SabadKharidModel(frm, CurrentUser, "EDIT_SABADKHARID");
            if (!obj.security.IsDisplay)
                return GOLOGIN();


            obj.Search();
            return View("Edit_SabadKharid", obj);
        }
    }
}