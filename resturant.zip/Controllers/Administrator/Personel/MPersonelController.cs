﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator
{
    public class MPersonelController : MasterController
    {


        private M_PersonelModel SetOldParametr()
        {
            M_PersonelModel obj = new M_PersonelModel(CurrentUser, "PERSONEL");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtFullName = FieldFullName;
                    obj.txtMobile = FieldMobileNumber;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_PersonelModel obj)
        {
            FieldFullName = obj.txtFullName.Trim();
            FieldMobileNumber = obj.txtMobile.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        // GET: MPersonel
        public ActionResult Personel()
        {
            M_PersonelModel obj = new M_PersonelModel(CurrentUser, "PERSONEL");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Personel", obj);
        }
        [HttpPost]
        public ActionResult Personel(FormCollection frm, string btn)
        {
            M_PersonelModel obj = new M_PersonelModel(frm, CurrentUser, "PERSONEL");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("PersonelSpec", "MPersonel");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("PersonelSpec", "MPersonel", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Personel", obj);
        }

        // GET: PersonelSPEC
        public ActionResult PersonelSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_PersonelSpecModel obj = new M_PersonelSpecModel(ID, CurrentUser, "PERSONELSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PersonelSpec", obj);
        }
        [HttpPost]
        public ActionResult PersonelSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_PersonelSpecModel obj = new M_PersonelSpecModel(ID, frm, CurrentUser, "PERSONELSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Personel", "MPersonel", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Personel", "MPersonel", "index=old");
            }
            return View("PersonelSpec", obj);
        }
    }
}