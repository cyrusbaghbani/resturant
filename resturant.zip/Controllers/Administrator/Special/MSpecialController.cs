﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace restauran.Controllers.Administrator.Special
{
    public class MSpecialController : MasterController
    {
        // GET: Special
        private M_SpecialModel SetOldParametr()
        {
            M_SpecialModel obj = new M_SpecialModel(CurrentUser, "SPECIAL");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.cboBrandID = FieldCboBrandValue;
                    obj.cboProductTypeGroupID = FieldCboProductType;
                    obj.txtStartDate = FieldDATEAZ;
                    obj.txtEndDate = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_SpecialModel obj)
        {
            FieldCboBrandValue = obj.cboBrandID;
            FieldCboProductType = obj.cboProductTypeGroupID;
            FieldDATEAZ = obj.txtStartDate;
            FieldDATETA = obj.txtEndDate;
            Fieldhfvalue = obj.hfContent;

            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }


        public ActionResult Specials()
        {
            M_SpecialModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Specials", obj);

        }
        [HttpPost]
        public ActionResult Specials(FormCollection frm, string btn)
        {
            M_SpecialModel obj = new M_SpecialModel(frm, CurrentUser, "SPECIAL");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("SpecialSpec", "MSpecial");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("SpecialSpec", "MSpecial", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Specials", obj);
        }

        public ActionResult SpecialSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_SpecialSpecModel obj = new M_SpecialSpecModel(ID, CurrentUser, "SPECIALSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("SpecialSpec", obj);
        }
        [HttpPost]
        public ActionResult SpecialSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_SpecialSpecModel obj = new M_SpecialSpecModel(ID, frm, CurrentUser, "FESTIVALPRIVATESPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Specials", "MSpecial", "index=old");
                }
            }
            if (btn == "BARGASHTMOJODIBANBAR")
            {
                if (obj.CheckValidateBargashtMojodi())
                {
                    obj.BargashtMojodiBeAnbar();
                    return GoToPage("Specials", "MSpecial", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Specials", "MSpecial", "index=old");
            }
            return View("SpecialSpec", obj);
        }
    }
}