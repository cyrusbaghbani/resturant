﻿using restauran.Models.Access.Tables;
using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator
{
    public class MBaseInfoController : MasterController
    {
        // GET: Post
        public ActionResult Post()
        {
            M_PostModel obj = new M_PostModel(CurrentUser, "POST");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.BindTable();
            return View("Post", obj);
        }
        [HttpPost]
        public ActionResult Post(FormCollection frm, string btn)
        {
            M_PostModel obj = new M_PostModel(frm, CurrentUser, "POST");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if(btn=="REMOVE")
            {
                obj.DeleteRows();
            }
            else if(btn=="SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.BindTable();
            return View("Post", obj);
        }

        // GET: BRAND
        public ActionResult Brand()
        {
            M_BrandModel obj = new M_BrandModel(CurrentUser, "BRAND");
            if (!obj.security.IsDisplay)
                return GOLOGIN();


            obj.BindTable();
            return View("Brand", obj);
        }
        [HttpPost]
        public ActionResult Brand(FormCollection frm, string btn)
        {
            M_BrandModel obj = new M_BrandModel(frm, CurrentUser, "BRAND");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }
            else if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.BindTable();
            return View("Brand", obj);
        }

        // GET: ProductType
        public ActionResult ProductType()
        {
            M_ProductTypeModel obj = new M_ProductTypeModel(CurrentUser, "PRODUCTTYPE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.BindTable();
            return View("ProductType", obj);
        }
        [HttpPost]
        public ActionResult ProductType(FormCollection frm, string btn)
        {
            M_ProductTypeModel obj = new M_ProductTypeModel(frm, CurrentUser, "PRODUCTTYPE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }
            else if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.BindTable();
            return View("ProductType", obj);
        }

        // GET: UnitType
        public ActionResult UnitType()
        {
            M_UnitType obj = new M_UnitType(CurrentUser, "UNITTYPE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.BindTable();
            return View("UnitType", obj);
        }
        [HttpPost]
        public ActionResult UnitType(FormCollection frm, string btn)
        {
            M_UnitType obj = new M_UnitType(frm, CurrentUser, "UNITTYPE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }
            else if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.BindTable();
            return View("UnitType", obj);
        }

        // GET: UnitType
        public ActionResult Districts()
        {
            M_Districts obj = new M_Districts(CurrentUser, "DISTRICTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.BindTable();
            return View("Districts", obj);
        }
        [HttpPost]
        public ActionResult Districts(FormCollection frm, string btn)
        {
            M_Districts obj = new M_Districts(frm, CurrentUser, "DISTRICTS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }
            else if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.BindTable();
            return View("Districts", obj);
        }

        ////دسته محصولات
        [HttpPost]
        public ContentResult UploadFiles()
        {
            var r = new List<UploadFilesResult>();

            foreach (string file in Request.Files)
            {
                HttpPostedFileBase hpf = Request.Files[file] as HttpPostedFileBase;
                int ContentLength = hpf.ContentLength;
                WebImage img = new WebImage(hpf.InputStream);

                string error = Validation.ValidationImage(hpf.ContentType, hpf.FileName, ContentLength, 307200, img.Height, img.Width, 250, 250, 250, 250);
                if (error != "")
                {
                    r.Add(new UploadFilesResult()
                    {
                        Name = hpf.FileName,
                        Length = ContentLength,
                        Type = hpf.ContentType,
                        ERRORINFO = error,

                    });
                    break;
                }
                if (ContentLength == 0)
                    continue;


                string savedFileName = Path.Combine(Server.MapPath("~/Attachment/Temp/"), "TEMP_" + Guid.NewGuid().ToString() + Path.GetExtension(hpf.FileName));
                //img.Resize(300, 300);
                img.Save(savedFileName);


                string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
                Guid temp = Guid.Empty;
                Guid? UIDITEms = Guid.Empty;
                UIDITEms = Guid.TryParse(ID, out temp) ? temp : (Guid?)null;
                //Delete Temp Files

                string SessionID = this.Session.SessionID.ToString();

                ///Add New temp Files
                var obj = new Temp();
                obj.UID = Guid.NewGuid();
                obj.UserID = CurrentUser.UID;
                obj.src = "/Attachment/Temp/" + Path.GetFileName(savedFileName);
                obj.SessionID = SessionID;
                obj.UIDItems = UIDITEms;
                obj.PAGENAME = "PRODUCTGROUPTYPESPEC";
                obj.DateTimeSabt = DateTime.Now;
                dc.Temps.InsertOnSubmit(obj);
                dc.SubmitChanges();

                r.Add(new UploadFilesResult()
                {
                    Name = hpf.FileName,
                    Length = ContentLength,
                    Type = hpf.ContentType,
                    ERRORINFO = "",
                    SRC = obj.src /*"/Attachment/Temp/" + Path.GetFileName(savedFileName)*/,
                    ID = Utility.EncryptedQueryString.Encrypt(obj.UID.ToString())
                });
            }
            return Content("{\"name\":\"" + r[0].Name + "\",\"ID\":\"" + r[0].ID + "\",\"SRC\":\"" + r[0].SRC + "\",\"ERRORINFO\":\"" + r[0].ERRORINFO + "\",\"type\":\"" + r[0].Type + "\",\"size\":\"" + string.Format("{0} bytes", r[0].Length) + "\"}", "application/json");
        }
        [HttpPost]

        // GET: MGroupProduct
        private M_GroupProductTypeModel SetOldParametr()
        {
            M_GroupProductTypeModel obj = new M_GroupProductTypeModel(CurrentUser, "PRODUCTGROUPTYPE");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {

                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                    obj.txtOnvan = FieldtxtOnvan;
                }
            }
            return obj;
        }
        private void Search(M_GroupProductTypeModel obj)
        {

            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            FieldtxtOnvan = obj.txtOnvan;
            obj.Search();
        }
        // GET: MPersonel
        public ActionResult ProductGroupType()
        {
            M_GroupProductTypeModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            Search(obj);
            return View("ProductGroupType", obj);
        }
        [HttpPost]
        public ActionResult ProductGroupType(FormCollection frm, string btn)
        {
            M_GroupProductTypeModel obj = new M_GroupProductTypeModel(frm, CurrentUser, "PRODUCTGROUPTYPE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("ProductGroupTypeSpec", "MBaseInfo");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("ProductGroupTypeSpec", "MBaseInfo", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("ProductGroupType", obj);
        }

        // GET: PersonelSPEC
        public ActionResult ProductGroupTypeSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_GroupProductTypeSpecModel obj = new M_GroupProductTypeSpecModel(ID, CurrentUser, "PRODUCTGROUPTYPESPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("ProductGroupTypeSpec", obj);
        }
        [HttpPost]
        public ActionResult ProductGroupTypeSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_GroupProductTypeSpecModel obj = new M_GroupProductTypeSpecModel(ID, frm, CurrentUser, "PRODUCTGROUPTYPESPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("ProductGroupType", "MBaseInfo", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("ProductGroupType", "MBaseInfo", "index=old");
            }
            else if (btn == "DELETEIMAGE")
            {
                RemoveImage(obj);
                obj.DisplayMessage.ShowSeccessMessage("عکس به صورت موقت حذف گردید.");
            }
            return View("ProductGroupTypeSpec", obj);
        }

        private void RemoveImage(M_GroupProductTypeSpecModel obj)
        {
            string id = Utility.EncryptedQueryString.Decrypt(obj.hfIDimgDisplay);
            var q = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);
            if (q != null)
            {
                try
                {
                    string path = Server.MapPath(q.src);
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);

                    dc.Temps.DeleteOnSubmit(q);
                    dc.SubmitChanges();
                }
                catch { }
            }
            obj.hfIDimgDisplay = "REMOVE";
            obj.hfimgDisplay = obj.ImageEmpty;


        }
    }
}