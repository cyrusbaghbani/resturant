﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Account
{
    public class MAccountController : MasterController
    {
        // GET: MAccount
        public ActionResult TurnOvers()
        {
            M_TurnOversModel obj = new M_TurnOversModel(CurrentUser, "TURNOVERS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("TurnOvers", obj);
        }
        [HttpPost]
        public ActionResult TurnOvers(FormCollection frm, string btn)
        {
            M_TurnOversModel obj = new M_TurnOversModel(frm, CurrentUser, "TURNOVERS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRows();
            }
            else if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }

            obj.Search();
            return View("TurnOvers", obj);
        }
    }
}