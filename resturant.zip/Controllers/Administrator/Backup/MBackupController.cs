﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Backup
{
    public class MBackupController : MasterController
    {
        public FileResult DownloadBackup(string filename)
        {
            string BackupPath = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];
            var FileVirtualPath = BackupPath + filename;
            return File(FileVirtualPath, "application/force-download", Path.GetFileName(filename));
        }
        // GET: MBackup
        public ActionResult Backup()
        {
            
            M_BackupModel obj = new M_BackupModel(CurrentUser, "M_BACKUP");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("Backup", obj);
        }
        [HttpPost]
        public ActionResult Backup(FormCollection frm, string btn)
        {
            M_BackupModel obj = new M_BackupModel(frm, CurrentUser, "M_BACKUP");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "BACKUPDATABASE")
            {
                obj.GetbackupDB();
            }
            if(btn=="BACKUPATTACHMENT")
            {
                obj.GetBackupAttachment(Server);
            }
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            obj.Search();

            return View("Backup", obj);
        }
    }
}