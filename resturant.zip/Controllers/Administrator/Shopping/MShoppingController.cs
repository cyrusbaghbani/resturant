﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Shopping
{
    public class MShoppingController : MasterController
    {
        // GET: MShopping
        private M_BarrasiNashodeModel SetOldParametr()
        {
            M_BarrasiNashodeModel obj = new M_BarrasiNashodeModel(CurrentUser, "SHOPPING_BARRASINASHODE");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_BarrasiNashodeModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult BarrasiNashode()
        {
            M_BarrasiNashodeModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("BarrasiNashode", obj);
        }
        [HttpPost]
        public ActionResult BarrasiNashode(FormCollection frm, string btn)
        {
            M_BarrasiNashodeModel obj = new M_BarrasiNashodeModel(frm, CurrentUser, "SHOPPING_BARRASINASHODE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "SAVE_TOZIEKONANDE_FACTOR")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                }
            }
            obj = new M_BarrasiNashodeModel(frm, CurrentUser, "SHOPPING_BARRASINASHODE");
            Search(obj);
           
            return View("BarrasiNashode", obj);
        }


        private M_TahvilShodeModel SetOldParametr_TahvilSHode()
        {
            M_TahvilShodeModel obj = new M_TahvilShodeModel(CurrentUser, "SHOPPING_TAHVILSHODE");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_TahvilShodeModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult TahvilShode()
        {
            M_TahvilShodeModel obj = SetOldParametr_TahvilSHode();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("TahvilShode", obj);
        }
        [HttpPost]
        public ActionResult TahvilShode(FormCollection frm, string btn)
        {
            M_TahvilShodeModel obj = new M_TahvilShodeModel(frm, CurrentUser, "SHOPPING_TAHVILSHODE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

         
            Search(obj);
            return View("TahvilShode", obj);
        }




        private M_DARHALTOZIEE_Model SetOldParametrDArHalToziee()
        {
            M_DARHALTOZIEE_Model obj = new M_DARHALTOZIEE_Model(CurrentUser, "SHOPPING_DARHALTOZIEE");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search_DARHALTOZIEE(M_DARHALTOZIEE_Model obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult DarHalToziee()
        {
            M_DARHALTOZIEE_Model obj = SetOldParametrDArHalToziee();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search_DARHALTOZIEE(obj);
            return View("DarHalToziee", obj);
        }
        [HttpPost]
        public ActionResult DarHalToziee(FormCollection frm, string btn)
        {
            M_DARHALTOZIEE_Model obj = new M_DARHALTOZIEE_Model(frm, CurrentUser, "SHOPPING_DARHALTOZIEE");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "TAHVIL_BE_MOSHTARI")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }
            obj = new M_DARHALTOZIEE_Model(frm, CurrentUser, "SHOPPING_DARHALTOZIEE");
            Search_DARHALTOZIEE(obj);
            return View("DarHalToziee", obj);
        }
    }
}