﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Festival
{
    public class MFestivalController : MasterController
    {
        // GET: MFestival
        // GET: Festivali Omomi
        private M_FestivalPublicModel SetOldParametr_Public()
        {
            M_FestivalPublicModel obj = new M_FestivalPublicModel(CurrentUser, "FESTIVALPUBLIC");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.cboBrandID = FieldCboBrandValue;
                    obj.cboProductTypeGroupID = FieldCboProductType;
                    obj.txtStartDate = FieldDATEAZ;
                    obj.txtEndDate = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search_Public(M_FestivalPublicModel obj)
        {
            FieldCboBrandValue = obj.cboBrandID;
            FieldCboProductType = obj.cboProductTypeGroupID;
            FieldDATEAZ = obj.txtStartDate;
            FieldDATETA = obj.txtEndDate;
            Fieldhfvalue = obj.hfContent;

            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }


        public ActionResult Publics()
        {
            M_FestivalPublicModel obj = SetOldParametr_Public();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search_Public(obj);
            return View("Publics", obj);

        }
        [HttpPost]
        public ActionResult Publics(FormCollection frm, string btn)
        {
            M_FestivalPublicModel obj = new M_FestivalPublicModel(frm, CurrentUser, "FESTIVALPUBLIC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("PublicSpec", "MFestival");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("PublicSpec", "MFestival", "id=" + obj.hf_SelectValueID);
            }

            Search_Public(obj);
            return View("Publics", obj);
        }

        public ActionResult PublicSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_FestivalPublicSpecModel obj = new M_FestivalPublicSpecModel(ID, CurrentUser, "FESTIVALPUBLICSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PublicSpec", obj);
        }
        [HttpPost]
        public ActionResult PublicSpec(FormCollection frm,string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_FestivalPublicSpecModel obj = new M_FestivalPublicSpecModel(ID, frm, CurrentUser, "FESTIVALPUBLICSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Publics", "MFestival", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Publics", "MFestival", "index=old");
            }
            return View("PublicSpec", obj);
        }

        // GET: Fesitival Ekhtesasi

        private M_FestivalPrivateModel SetOldParametr_Privates()
        {
            M_FestivalPrivateModel obj = new M_FestivalPrivateModel(CurrentUser, "FESTIVALPRIVETS");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.cboBrandID = FieldCboBrandValue;
                    obj.cboProductTypeGroupID = FieldCboProductType;
                    obj.txtStartDate = FieldDATEAZ;
                    obj.txtEndDate = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search_Privates(M_FestivalPrivateModel obj)
        {
            FieldCboBrandValue = obj.cboBrandID;
            FieldCboProductType = obj.cboProductTypeGroupID;
            FieldDATEAZ = obj.txtStartDate;
            FieldDATETA = obj.txtEndDate;
            Fieldhfvalue = obj.hfContent;

            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult Privates()
        {
            M_FestivalPrivateModel obj = SetOldParametr_Privates();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search_Privates(obj);
            return View("Privates", obj);
        }
        [HttpPost]
        public ActionResult Privates(FormCollection frm,string btn)
        {
            M_FestivalPrivateModel obj = new M_FestivalPrivateModel(frm, CurrentUser, "FESTIVALPRIVETS");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("PrivateSpec", "MFestival");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("PrivateSpec", "MFestival", "id=" + obj.hf_SelectValueID);
            }

            Search_Privates(obj);
            return View("Privates", obj);
        }

        public ActionResult PrivateSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_FestivalPrivateSpecModel obj = new M_FestivalPrivateSpecModel(ID, CurrentUser, "FESTIVALPRIVATESPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("PrivateSpec",obj);
        }
        [HttpPost]
        public ActionResult PrivateSpec(FormCollection frm,string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_FestivalPrivateSpecModel obj = new M_FestivalPrivateSpecModel(ID, frm, CurrentUser, "FESTIVALPRIVATESPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("Privates", "MFestival", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Privates", "MFestival", "index=old");
            }
            return View("PrivateSpec", obj);
           
        }
    }
}