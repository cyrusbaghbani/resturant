﻿using restauran.Models.Access.Tables;
using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Advertising
{
    public class MAdvertisingController : MasterController
    {
        [HttpPost]
        public ContentResult UploadFiles()
        {
            var r = new List<UploadFilesResult>();

            foreach (string file in Request.Files)
            {
                HttpPostedFileBase hpf = Request.Files[file] as HttpPostedFileBase;
                int ContentLength = hpf.ContentLength;
                WebImage img = new WebImage(hpf.InputStream);

                string error = Validation.ValidationImage(hpf.ContentType, hpf.FileName, ContentLength, 1048576, img.Height, img.Width, 450, 1920, 450, 1920);
                if (error != "")
                {
                    r.Add(new UploadFilesResult()
                    {
                        Name = hpf.FileName,
                        Length = ContentLength,
                        Type = hpf.ContentType,
                        ERRORINFO = error,

                    });
                    break;
                }
                if (ContentLength == 0)
                    continue;


                string savedFileName = Path.Combine(Server.MapPath("~/Attachment/Temp/"), "TEMP_ADVERTISING" + Guid.NewGuid().ToString() + Path.GetExtension(hpf.FileName));
                //img.Resize(300, 300);
                img.Save(savedFileName);


                string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
                Guid temp = Guid.Empty;
                Guid? UIDITEms = Guid.Empty;
                UIDITEms = Guid.TryParse(ID, out temp) ? temp : (Guid?)null;
                //Delete Temp Files

                string SessionID = this.Session.SessionID.ToString();

                ///Add New temp Files
                var obj = new Temp();
                obj.UID = Guid.NewGuid();
                obj.UserID = CurrentUser.UID;
                obj.src = "/Attachment/Temp/" + Path.GetFileName(savedFileName);
                obj.SessionID = SessionID;
                obj.UIDItems = UIDITEms;
                obj.PAGENAME = "ADVERTISINGSPEC";
                obj.DateTimeSabt = DateTime.Now;
                dc.Temps.InsertOnSubmit(obj);
                dc.SubmitChanges();

                r.Add(new UploadFilesResult()
                {
                    Name = hpf.FileName,
                    Length = ContentLength,
                    Type = hpf.ContentType,
                    ERRORINFO = "",
                    SRC = obj.src /*"/Attachment/Temp/" + Path.GetFileName(savedFileName)*/,
                    ID = Utility.EncryptedQueryString.Encrypt(obj.UID.ToString())
                });
            }
            return Content("{\"name\":\"" + r[0].Name + "\",\"ID\":\"" + r[0].ID + "\",\"SRC\":\"" + r[0].SRC + "\",\"ERRORINFO\":\"" + r[0].ERRORINFO + "\",\"type\":\"" + r[0].Type + "\",\"size\":\"" + string.Format("{0} bytes", r[0].Length) + "\"}", "application/json");
        }
        [HttpPost]
        public ContentResult UploadFiles800_600()
        {
            var r = new List<UploadFilesResult>();

            foreach (string file in Request.Files)
            {
                HttpPostedFileBase hpf = Request.Files[file] as HttpPostedFileBase;
                int ContentLength = hpf.ContentLength;
                WebImage img = new WebImage(hpf.InputStream);

                string error = Validation.ValidationImage(hpf.ContentType, hpf.FileName, ContentLength, 1048576, img.Height, img.Width, 600, 800, 600, 800);
                if (error != "")
                {
                    r.Add(new UploadFilesResult()
                    {
                        Name = hpf.FileName,
                        Length = ContentLength,
                        Type = hpf.ContentType,
                        ERRORINFO = error,

                    });
                    break;
                }
                if (ContentLength == 0)
                    continue;


                string savedFileName = Path.Combine(Server.MapPath("~/Attachment/Temp/"), "TEMP_ADVERTISING800_600" + Guid.NewGuid().ToString() + Path.GetExtension(hpf.FileName));
                //img.Resize(300, 300);
                img.Save(savedFileName);


                string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
                Guid temp = Guid.Empty;
                Guid? UIDITEms = Guid.Empty;
                UIDITEms = Guid.TryParse(ID, out temp) ? temp : (Guid?)null;
                //Delete Temp Files

                string SessionID = this.Session.SessionID.ToString();

                ///Add New temp Files
                var obj = new Temp();
                obj.UID = Guid.NewGuid();
                obj.UserID = CurrentUser.UID;
                obj.src = "/Attachment/Temp/" + Path.GetFileName(savedFileName);
                obj.SessionID = SessionID;
                obj.UIDItems = UIDITEms;
                obj.PAGENAME = "ADVERTISINGSPEC";
                obj.DateTimeSabt = DateTime.Now;
                dc.Temps.InsertOnSubmit(obj);
                dc.SubmitChanges();

                r.Add(new UploadFilesResult()
                {
                    Name = hpf.FileName,
                    Length = ContentLength,
                    Type = hpf.ContentType,
                    ERRORINFO = "",
                    SRC = obj.src /*"/Attachment/Temp/" + Path.GetFileName(savedFileName)*/,
                    ID = Utility.EncryptedQueryString.Encrypt(obj.UID.ToString())
                });
            }
            return Content("{\"name\":\"" + r[0].Name + "\",\"ID\":\"" + r[0].ID + "\",\"SRC\":\"" + r[0].SRC + "\",\"ERRORINFO\":\"" + r[0].ERRORINFO + "\",\"type\":\"" + r[0].Type + "\",\"size\":\"" + string.Format("{0} bytes", r[0].Length) + "\"}", "application/json");
        }
        // GET: MAdvertising
        private M_AdvertisingModel SetOldParametr()
        {
            M_AdvertisingModel obj = new M_AdvertisingModel(CurrentUser, "ADVERTISING");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_AdvertisingModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult Advertising()
        {
            M_AdvertisingModel obj = new M_AdvertisingModel(CurrentUser, "ADVERTISING");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Advertising", obj);
        }
        [HttpPost]
        public ActionResult Advertising(FormCollection frm, string btn)
        {
            M_AdvertisingModel obj = new M_AdvertisingModel(frm, CurrentUser, "ADVERTISING");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("AdvertisingSpec", "MAdvertising");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("AdvertisingSpec", "MAdvertising", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Advertising", obj);
        }

        // GET: AdvertisingSpec
        public ActionResult AdvertisingSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_AdvertisingSpecModel obj = new M_AdvertisingSpecModel(ID, CurrentUser, "ADVERTISINGSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("AdvertisingSpec", obj);
        }
        [HttpPost]
        public ActionResult AdvertisingSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_AdvertisingSpecModel obj = new M_AdvertisingSpecModel(ID, frm, CurrentUser, "ADVERTISINGSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Advertising", "MAdvertising", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("Advertising", "MAdvertising", "index=old");
            }
            else if (btn == "DELETEIMAGE")
            {
                RemoveImage(obj);
                obj.DisplayMessage.ShowSeccessMessage("عکس به صورت موقت حذف گردید.");
            }
            else if (btn == "DELETEIMAGE800_600")
            {
                RemoveImage(obj, true);
                obj.DisplayMessage.ShowSeccessMessage("عکس به صورت موقت حذف گردید.");
            }
            return View("AdvertisingSpec", obj);
        }

        private void RemoveImage(M_AdvertisingSpecModel obj, bool IsImage800_600 = false)
        {

            if (IsImage800_600 == false)
            {
                string id = Utility.EncryptedQueryString.Decrypt(obj.hfUploadID);
                var q = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);
                if (q != null)
                {
                    try
                    {
                        string path = Server.MapPath(q.src);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);

                        dc.Temps.DeleteOnSubmit(q);
                        dc.SubmitChanges();
                    }
                    catch { }
                }
                obj.hfUploadID = "REMOVE";
                obj.hfUploadDisplay = "";
            }
            else
            {
                string id = Utility.EncryptedQueryString.Decrypt(obj.hfUploadID800_600);
                var q = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);
                if (q != null)
                {
                    try
                    {
                        string path = Server.MapPath(q.src);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);

                        dc.Temps.DeleteOnSubmit(q);
                        dc.SubmitChanges();
                    }
                    catch { }
                }
                obj.hfUploadID800_600 = "REMOVE";
                obj.hfUploadDisplay800_600 = "";
            }


        }
    }
}