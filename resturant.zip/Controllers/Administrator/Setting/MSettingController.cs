﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Administrator.Setting
{
    public class MSettingController : MasterController
    {
        // GET: MSetting
        private M_SettingModel SetOldParametr()
        {
            M_SettingModel obj = new M_SettingModel(CurrentUser, "LOYALTY");
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtStartDate = FieldDATEAZ;
                    obj.txtEndDate = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(M_SettingModel obj)
        {

            FieldDATEAZ = obj.txtStartDate;
            FieldDATETA = obj.txtEndDate;
            Fieldhfvalue = obj.hfContent;

            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }


        public ActionResult LoyaltyGift()
        {
            M_SettingModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("LoyaltyGift", obj);

        }
        [HttpPost]
        public ActionResult LoyaltyGift(FormCollection frm, string btn)
        {
            M_SettingModel obj = new M_SettingModel(frm, CurrentUser, "LOYALTY");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "NEW")
            {
                return GoToPage("LoyaltyGiftSpec", "MSetting");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("LoyaltyGiftSpec", "MSetting", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("LoyaltyGift", obj);
        }

        public ActionResult LoyaltyGiftSpec()
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_SettingSpecModel obj = new M_SettingSpecModel(ID, CurrentUser, "LOYALTYSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("LoyaltyGiftSpec", obj);
        }
        [HttpPost]
        public ActionResult LoyaltyGiftSpec(FormCollection frm, string btn)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)RouteData.Values["id"]);
            M_SettingSpecModel obj = new M_SettingSpecModel(ID, frm, CurrentUser, "LOYALTYSPEC");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("LoyaltyGift", "MSetting", "index=old");
                }
            }
            else if (btn == "CANCEL")
            {
                return GoToPage("LoyaltyGift", "MSetting", "index=old");
            }
            return View("LoyaltyGiftSpec", obj);
        }
    }
}