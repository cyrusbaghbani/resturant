﻿using restauran.Models;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Report
{

    public class ReportController : CommonMasterController
    {


        // GET: Report
        public FileResult DownloadFactor(string imageurl)
        {
            if (!Security_IsUser())
            {
                return null;
            }
            var obj = Reports.Factor(imageurl, Server);
            return File(obj.MS.ToArray(), "application/force-download", obj.ONVAN);
        }
        public FileResult Downloads_Order(string datestart, string timestart, string dateend, string timeend, string reporttype)
        {
            if (!Security_IsManagment())
            {
                return null;
            }
            Security sec = new Security(CurrentUser, "ORDERREPORTS_M");

            if (sec.IsDisplay)
            {
                STRUCT_REPORT obj = new STRUCT_REPORT();
                if (reporttype == "REPORT_KOL_SEFARESHAT")
                {
                    obj = Reports.REPORT_KOL_SEFARESHAT(datestart, timestart, dateend, timeend, Server);
                }
                else if (reporttype == "REPORT_SEFARESHAT_HAR_VISITOR")
                {
                    obj = Reports.REPORT_SEFARESHAT_HAR_VISITOR(datestart, timestart, dateend, timeend, Server);
                }
                else if (reporttype == "REPORT_SEFARESHAT_HAR_TOZIEKONANDE")
                {
                    obj = Reports.REPORT_SEFARESHAT_HAR_TOZIEKONANDE(datestart, timestart, dateend, timeend, Server);
                }

                return File(obj.MS.ToArray(), "application/force-download", obj.ONVAN);
            }
            return null;

        }
    }
}