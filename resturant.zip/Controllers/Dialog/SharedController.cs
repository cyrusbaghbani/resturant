﻿using App_Start.Utility;
using Models.Controll;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Controllers.Dialog
{
    public class SharedController : DialogController
    {
        #region EDIT Factor
        [HttpPost]
        public ActionResult GETDISPLAYFACTOR_ManegmrntFOR_EDIT(string Value)
        {
            string str = "<center><div style=\"text-align:center\">سبد خرید مورد نظر یافت نشد</div></center>";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                str = "";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span>کد پیگیری  : " + sabadkharid.CodeRahgiri + " </label> ";
                str += "           </div>       ";
                str += "   </div>            ";

                str += "   <div class=\"col-lg-6\"> ";
                str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "               </span>" + ((sabadkharid.IsKharid == false) ? "تاریخ آخرین تغییر  : " : "تاریخ سفارش  : ")
                    + ((sabadkharid.IsKharid == false) ? (DateShamsi.ConvertMiladiDateToPersionDate(sabadkharid.DateTimeAkharinTaghirat) + " [" + sabadkharid.DateTimeAkharinTaghirat.Hour.ToString("00") + ":" + sabadkharid.DateTimeAkharinTaghirat.Minute.ToString("00") + ":" + sabadkharid.DateTimeAkharinTaghirat.Second.ToString("00") + "] ")
                    : (sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] "));
                str += "           </label> ";
                str += "       </div> ";
                str += "   </div> ";
                str += "   <div class=\"breakdiv_1\"></div> ";
                if (sabadkharid.IsKharid == true)
                {
                    str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                    str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "                   </span> وضعیت : " + (sabadkharid.UserTahvilDahandeID == null ? "در حال بررسی" : (sabadkharid.IsTahvilBeMoshtari == true ? "تحویل شد" : "در حال توزیع")) + " </label> ";
                    str += "           </div>       ";
                    str += "   </div>      ";

                    if (sabadkharid.UserTahvilDahandeID != null)
                    {

                        str += "   <div class=\"col-lg-6\"> ";
                        str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                        str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                        str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                        str += "               </span>توزیع کننده : " + sabadkharid.userTahvilDahande.FullName;
                        str += "           </label> ";
                        str += "       </div> ";
                        str += "   </div> ";
                        str += "   <div class=\"breakdiv_1\"></div> ";
                    }
                    if (sabadkharid.IsTahvilBeMoshtari)
                    {
                        str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                        str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                        str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                        str += "                   </span> تحویل گیرنده : " + sabadkharid.FullNameTahvilGirande + " </label> ";
                        str += "           </div>       ";
                        str += "   </div>            ";
                        str += "   <div class=\"col-lg-6\"> ";
                        str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                        str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                        str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                        str += "               </span>تاریخ تحویل  : " + sabadkharid.DateTahvilBeMoshtari_Fa + " [" + sabadkharid.TimeTahvilBeMoshtari_Fa + "] ";
                        str += "           </label> ";
                        str += "       </div> ";
                        str += "   </div> ";
                        str += "   <div class=\"breakdiv_1\"></div> ";
                    }
                }

                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";
                str += "    <div id=\"no-more-tables\"> ";
                str += "       <table id=\"Table_SHOW_FACTOR\" class=\"table table-bordered table-striped table-condensed cf\"> ";
                GridPageNumber gr = new GridPageNumber();

                gr.lst_headerName.AddRange(new List<string>() { "عنوان", "تعداد", "قیمت واحد", "قیمت کل", "تحویل از انبار", "حذف" });

                str += gr.GetHtmlHeader();
                str += " <tbody> ";
                int line = 0;
                foreach (var q in sabadkharid.SabadKharidItems)
                {

                    str += " <tr> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++line) + " </td> ";
                    str += " <td data-title=\"عنوان\" align=\"center\"> " + q.Product.ProductType.Parent.Name + " " + q.Product.ProductType.Name + " " + q.Product.Brand.Name + (q.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (q.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : (q.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : ""))) + "  </td> ";
                    str += " <td data-title=\"تعداد\" align=\"center\"> " + q.Count.ToString("###,##0") + " " + q.Product.Unit.Name + "  </td> ";
                    str += " <td data-title=\"قیمت واحد\" align=\"center\"> " + (q.PriceVahed.ToString("###,##0") + " ریال") + "  </td> ";
                    str += " <td data-title=\"قیمت کل\" align=\"center\"> " + (q.Count * q.PriceVahed).ToString("###,##0") + " ریال" + "  </td> ";
                    str += " <td data-title=\" تحویل از انبار\" align=\"center\"> " + (q.IsTahvilAzAnbar != true ? "-" : (q.DateTahvilAzAnbar_Fa + " [" + q.TimeTahvilAzAnbar_Fa + "] ")) + "  </td> ";

                    str += "  <td data-title=\"\"> ";
                    str += "      <button  onclick=\"ConfirmMessage(this,'آیا مایل به حذف کالا می باشید؟');DeleteSabadkharidItem('" + (Utility.EncryptedQueryString.Encrypt(q.UID.ToString())) + "'); return false;\" class=\"fa fa-trash-o fa-edit-Grid-Emonet\" > ";
                    str += "      </button> ";
                    str += "  </td> ";

                    str += " </tr> ";



                }

                str += " </tbody> ";

                str += "  <tbody> ";

                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مجموع قیمت :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مجموع قیمت\"> " + (sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed).ToString("###,##0")) + " ریال </td> ";
                str += " <td style=\"background-color:#695959\" colspan=\"2\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مالیات بر ارزش افزوده :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مالیات\"> " + (sabadkharid.MablaghPardakhtMaliat).ToString("###,##0") +" ریال </td> ";
                str += " <td style=\"background-color:#695959\" colspan=\"2\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\">  ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">حمل نقل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"حمل نقل\"> " + (sabadkharid.MablaghPardakhtTransport).ToString("###,##0") + " ریال </td> ";
                str += " <td style=\"background-color:#695959\" colspan=\"2\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\"> مبلغ کل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\" مبلغ کل\"> " + ((sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed) + sabadkharid.MablaghPardakhtTransport + sabadkharid.MablaghPardakhtMaliat).ToString("###,##0")) + " ریال </td> ";
                str += " <td style=\"background-color:#695959\" colspan=\"2\"></td> ";
                str += " </tr> ";

                str += " </tbody> ";


                str += " </table> ";
                str += "    </div> ";
            }
            return Json(str);

        }
        [HttpPost]
        public ActionResult GETDISPLAYFACTOR_ManegmrntFOR_EDIT_DeleteSabadkharidItem(string Value)
        {

            string Vaziat = "";
            Value = EncryptedQueryString.Decrypt(Value);

            var obj = dc.SabadKharidItems.Where(s => s.UID.ToString() == Value).FirstOrDefault();
            string ID = obj == null ? "" : obj.SabadKharidID.ToString();
            if (obj != null)
            {
                if (obj.SabadKharid.IsKharid == false)
                {


                    string Dsc = " کالای \'" + (obj.Product.ProductType.Parent.IsShowName ? obj.Product.ProductType.Parent.Name : "") + " " + obj.Product.ProductType.Name + " " + obj.Product.Brand.Name + " [" + (obj.Price.IsDarhalEngheza ? "فروش ویژه" : (obj.Price.IsTakhfifOmomi ? "جشنواره عمومی" : (obj.Price.IsTakhfifEkhtesasi ? "جشنواره اختصاصی" : (obj.Price.IsPriceAsli ? "اصلی" : "")))) + "]\' در سبد خرید با کد رهگیری '" + obj.SabadKharid.CodeRahgiri + "' به تعداد '" + obj.Count + " " + obj.Product.Unit.Name + "' قیمت '" + obj.PriceVahed.ToString("###,##0") + " ریال' مربوط به مشتری '" + obj.SabadKharid.userMoshtari.FullName + " [" + obj.SabadKharid.userMoshtari.OnvaneSherkat + "] " + "' حذف گردید ";
                    obj.SabadKharid.DSC += Dsc + "</br>";
                    dc.SubmitChanges();
                    dc.SabadKharidItems.DeleteOnSubmit(obj);
                    dc.SubmitChanges();
                    // DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
                    Vaziat = "secsess";
                    EventLog.Loging(Dsc, EventTypeIds.DELETE, "EDIT_SABADKHARID_M", CurrentUser.UID);
                }
                else
                {

                }
            }
            return GETDISPLAYFACTOR_ManegmrntFOR_EDIT(EncryptedQueryString.Encrypt(ID));

        }

        #endregion

        [HttpPost]
        public ActionResult loadSabadkharidDarHalTozi()
        {


            var countj = (from p in dc.SabadKharids
                          where
                          p.IsDeleted == false
                          &&
                          p.IsKharid == true
                          &&
                          p.IsTahvilBeMoshtari == false
                          &&
                          p.IsTaiedBarrasi == true
                          &&
                          p.UserTahvilDahandeID != null
                          &&
                          p.UserTahvilDahandeID != Guid.Empty
                           &&
                          (
                          (p.UserMoshtariID != null && p.userMoshtari.VisitorUserID != null && CurrentUser.RoleId == RoleIds.M_Visitor && CurrentUser.UID == p.userMoshtari.VisitorUserID)
                          ||
                          (p.UserMoshtariID != null && p.UserTahvilDahandeID != null && CurrentUser.RoleId == RoleIds.M_ToziKonande && CurrentUser.UID == p.UserTahvilDahandeID)
                          ||
                          (CurrentUser.RoleId != RoleIds.M_Visitor && CurrentUser.RoleId != RoleIds.M_ToziKonande)
                          )
                          select p.UID).Count().ToString();


            System.Drawing.Image img = new System.Drawing.Bitmap(320, 320);



            img = System.Drawing.Image.FromFile(Server.MapPath("~/Images/Img/" + "shopping-cart-Dar-Hale-Tozee" + ".png"));
            Bitmap bmp = new Bitmap(img);

            //for (int x = 0; x < bmp.Width; x++)
            //{
            //    for (int y = 0; y < bmp.Height; y++)
            //    {
            //        Color gotColor = bmp.GetPixel(x, y);
            //        if (gotColor != Color.FromArgb(0, 0, 0, 0))
            //        {
            //            if (!(y > 37 && (x > 21 && x < 31)))
            //                gotColor = Color.FromArgb(gotColor.A, 0, 0, 0);
            //        }

            //        bmp.SetPixel(x, y, gotColor);
            //    }
            //}

            img = bmp;
            System.Drawing.Graphics graphics = System.Drawing.Graphics.FromImage(img);
            // Create font
            System.Drawing.Font font = new System.Drawing.Font("Tahoma", 20f);
            font = new Font(font, FontStyle.Bold);

            // Create text position
            System.Drawing.PointF point = new System.Drawing.PointF(350, 290);
            // Draw text



            Color customColor = Color.FromArgb(0, 0, 0);

            SolidBrush shadowBrush = new SolidBrush(customColor);



            //['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            countj = countj == "0" ? "   0" : countj;
            countj = countj.Replace("0", "۰").Replace("1", "۱").Replace("2", "۲").Replace("3", "۳").Replace("4", "۴").Replace("5", "۵").Replace("6", "۶").Replace("7", "۷").Replace("8", "۸").Replace("9", "۹");
            graphics.DrawString(countj, font, shadowBrush, point);


            string savepath = Server.MapPath("~/Images/Img/") + "DarhalTozih" + ".png";
            img.Save(savepath, System.Drawing.Imaging.ImageFormat.Png);



            return Json("/Images/Img/" + "DarhalTozih" + ".png?t=" + DateTime.Now.Ticks + "" + Guid.NewGuid(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult loadSabadkharidBarrasiNashode()
        {


            var countj = (from p in dc.SabadKharids
                          where
                          p.IsDeleted == false
                          &&
                          p.IsKharid == true
                          &&
                          p.IsTahvilBeMoshtari == false
                          &&
                          p.IsTaiedBarrasi == false

                           &&
                          (
                          (p.UserMoshtariID != null && p.userMoshtari.VisitorUserID != null && CurrentUser.RoleId == RoleIds.M_Visitor && CurrentUser.UID == p.userMoshtari.VisitorUserID)
                          ||
                          (CurrentUser.RoleId != RoleIds.M_Visitor && CurrentUser.RoleId != RoleIds.M_ToziKonande)
                          )
                          select p.UID).Count().ToString();


            System.Drawing.Image img = new System.Drawing.Bitmap(320, 320);



            img = System.Drawing.Image.FromFile(Server.MapPath("~/Images/Img/" + "shopping-cart-barresi-nashode" + ".png"));
            Bitmap bmp = new Bitmap(img);

            //for (int x = 0; x < bmp.Width; x++)
            //{
            //    for (int y = 0; y < bmp.Height; y++)
            //    {
            //        Color gotColor = bmp.GetPixel(x, y);
            //        if (gotColor != Color.FromArgb(0, 0, 0, 0))
            //        {
            //            if (!(y > 37 && (x > 21 && x < 31)))
            //                gotColor = Color.FromArgb(gotColor.A, 0, 0, 0);
            //        }

            //        bmp.SetPixel(x, y, gotColor);
            //    }
            //}

            img = bmp;
            System.Drawing.Graphics graphics = System.Drawing.Graphics.FromImage(img);
            // Create font
            System.Drawing.Font font = new System.Drawing.Font("Tahoma", 20f);
            font = new Font(font, FontStyle.Bold);

            // Create text position
            System.Drawing.PointF point = new System.Drawing.PointF(350, 290);
            // Draw text



            Color customColor = Color.FromArgb(0, 0, 0);

            SolidBrush shadowBrush = new SolidBrush(customColor);



            //['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            countj = countj == "0" ? "   0" : countj;
            countj = countj.Replace("0", "۰").Replace("1", "۱").Replace("2", "۲").Replace("3", "۳").Replace("4", "۴").Replace("5", "۵").Replace("6", "۶").Replace("7", "۷").Replace("8", "۸").Replace("9", "۹");
            graphics.DrawString(countj, font, shadowBrush, point);


            string savepath = Server.MapPath("~/Images/Img/") + "BarrasiNashode" + ".png";
            img.Save(savepath, System.Drawing.Imaging.ImageFormat.Png);



            return Json("/Images/Img/" + "BarrasiNashode" + ".png?t=" + DateTime.Now.Ticks + "" + Guid.NewGuid(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult loadSabadkharidTahvilShode()
        {

            string currentdate = DateShamsi.GetCurrentDate();
            var countj = (from p in dc.SabadKharids
                          where
                          p.IsDeleted == false
                          &&
                          p.IsKharid == true
                          &&
                          p.IsTahvilBeMoshtari == true

                          &&
                          p.DateTahvilBeMoshtari_Fa == currentdate
                          &&
                          (
                          (p.UserMoshtariID != null && p.userMoshtari.VisitorUserID != null && CurrentUser.RoleId == RoleIds.M_Visitor && CurrentUser.UID == p.userMoshtari.VisitorUserID)
                          ||
                          (p.UserMoshtariID != null && p.UserTahvilDahandeID != null && CurrentUser.RoleId == RoleIds.M_ToziKonande && CurrentUser.UID == p.UserTahvilDahandeID)
                          ||
                          (CurrentUser.RoleId != RoleIds.M_Visitor && CurrentUser.RoleId != RoleIds.M_ToziKonande)
                          )
                          select p.UID).Count().ToString();


            System.Drawing.Image img = new System.Drawing.Bitmap(320, 320);



            img = System.Drawing.Image.FromFile(Server.MapPath("~/Images/Img/" + "shopping-cart-tahvil-shode" + ".png"));
            Bitmap bmp = new Bitmap(img);

            //for (int x = 0; x < bmp.Width; x++)
            //{
            //    for (int y = 0; y < bmp.Height; y++)
            //    {
            //        Color gotColor = bmp.GetPixel(x, y);
            //        if (gotColor != Color.FromArgb(0, 0, 0, 0))
            //        {
            //            if (!(y > 37 && (x > 21 && x < 31)))
            //                gotColor = Color.FromArgb(gotColor.A, 0, 0, 0);
            //        }

            //        bmp.SetPixel(x, y, gotColor);
            //    }
            //}

            img = bmp;
            System.Drawing.Graphics graphics = System.Drawing.Graphics.FromImage(img);
            // Create font
            System.Drawing.Font font = new System.Drawing.Font("Tahoma", 20f);
            font = new Font(font, FontStyle.Bold);

            // Create text position
            System.Drawing.PointF point = new System.Drawing.PointF(350, 290);
            // Draw text



            Color customColor = Color.FromArgb(0, 0, 0);

            SolidBrush shadowBrush = new SolidBrush(customColor);



            //['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            countj = countj == "0" ? "   0" : countj;
            countj = countj.Replace("0", "۰").Replace("1", "۱").Replace("2", "۲").Replace("3", "۳").Replace("4", "۴").Replace("5", "۵").Replace("6", "۶").Replace("7", "۷").Replace("8", "۸").Replace("9", "۹");
            graphics.DrawString(countj, font, shadowBrush, point);


            string savepath = Server.MapPath("~/Images/Img/") + "TahvilShode" + ".png";
            img.Save(savepath, System.Drawing.Imaging.ImageFormat.Png);



            return Json("/Images/Img/" + "TahvilShode" + ".png?t=" + DateTime.Now.Ticks + "" + Guid.NewGuid(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SelectCustomersDialog(string Value)
        {

            List<CheckboxListItems> list_checkbox = new List<CheckboxListItems>();
            var q = (from p in dc.users
                     where
                     p.IsDeleted == false
                     &&
                     p.Role.IsShow == true
                     &&
                     p.Role.IsDeleted == false
                     &&
                     p.Role.IsMenagment == false
                     &&
                    (
                    Value == ""
                    ||
                    p.FullName.Contains(Value)
                    ||
                    (p.OnvaneSherkat != null && p.OnvaneSherkat.Contains(Value))

                    )
                     select new item_CheckboxListItems
                     {
                         id = (EncryptedQueryString.Encrypt(p.UID.ToString())),
                         label = p.FullName + ((p.OnvaneSherkat == null || p.OnvaneSherkat == "") ? "" : (" [ " + p.OnvaneSherkat + " ] ")),
                         checked_ = false,
                         parentID = p.UserTypeID.ToString(),
                     });



            var list_ParentName = dc.UserTypes.Where(s => s.IsDeleted == false).ToList();
            foreach (var item in list_ParentName)
            {
                if (q.Any(s => s.parentID.ToString() == item.Id.ToString()))
                {
                    CheckboxListItems root = new CheckboxListItems() { id = EncryptedQueryString.Encrypt(item.Id.ToString()), label = item.name, checked_ = false };

                    root.children.AddRange(q.Where(s => s.parentID == item.Id.ToString()).Distinct().OrderBy(s => s.label));
                    list_checkbox.Add(root);
                }
            }


            return Json(list_checkbox);
        }
        [HttpPost]
        public JsonResult SearchProductsDialog(string Value, string PageIndex)
        {

            var q = (from p in dc.Products
                     where
                     p.IsDeleted == false
                     &&
                    (
                    (Value == "" || Value == null)
                    ||
                    (p.ProductTypeId != null && p.ProductType.ParentId != null && p.BrandId != null && ((p.ProductType.Parent.IsShowName ? p.ProductType.Parent.Name : "") + " " + p.ProductType.Name + " " + p.Brand.Name).Contains(Value))
                    ||
                    (p.BrandId != null && p.Brand.Name.Contains(Value))
                    ||
                    (p.ProductTypeId != null && p.ProductType.Name.Contains(Value))
                    ||
                    (p.ProductType.ParentId != null && p.ProductType.Parent.Name.Contains(Value))
                    )
                     select new
                     {
                         p.UID,
                         FullName = ((p.ProductType.Parent.IsShowName ? p.ProductType.Parent.Name : "") + " " + p.ProductType.Name + " " + p.Brand.Name),
                         p.MojodiCount,
                         UnitName = p.Unit.Name,
                     }).OrderBy(s => s.FullName);



            GridPageNumber GridPaging = new GridPageNumber("PRODUCT_DIALOG_GRID");
            GridPaging.lst_headerName.Add("نام کالا");
            GridPaging.lst_headerName.Add("موجودی");
            GridPaging.lst_headerName.Add("قیمت");

            GridPaging.pageIndex = PageIndex;
            GridPaging.Columns = 4;
            GridPaging.RowRecord = 7;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q.ToList();

            string str = GridPaging.GetHtmlHeader() + " <tbody> <tr> <td data-title=\"\" style=\"font-size:20px\"  colspan=\"" + GridPaging.Columns + "\" > هیچ رکوردی یافت نشد. </td>  </tr> </tbody> ";

            if (list.Any())
            {
                str = GridPaging.GetHtmlHeader() + " <tbody> ";
                int linnumbere = GridPaging.StartLineNumber - 1;
                foreach (var p in list)
                {
                    decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(p.UID);
                    string mojodi = p.MojodiCount.ToString("###,##0") + ((TedadReservMojodiKol == null || TedadReservMojodiKol == 0) ? "" : (" (" + TedadReservMojodiKol.Value.ToString("###,##0") + " )")) + " " + p.UnitName;

                    var price_ = dc.Prices.Where(s => s.IsPriceAsli == true && s.IsDeleted == false && s.ProductId == p.UID && s.DateShoro.CompareTo(CurrentDate) <= 0 && (s.DatePayan == null || s.DatePayan.Trim() == "" || s.DatePayan.CompareTo(CurrentDate) >= 0)).OrderByDescending(s => s.DateSabt).FirstOrDefault();

                    str += " <tr style=\"cursor:pointer;\" onclick=\"SelectProductSelect('" + EncryptedQueryString.Encrypt(p.UID.ToString()) + "','" + p.FullName + "','" + mojodi + "'); return false;\" > "
                        + " <td  data-title=\"ردیف\" align=\"center\"> " + (++linnumbere).ToString() + " </td> "
                             + " <td align=\"center\" data-title=\"نام کالا\"> " + p.FullName + " </td> "
                             + " <td align=\"center\" class=\"numeric\" data-title=\"موجودی\"> " + (mojodi) + " </td> "
                             + " <td align=\"center\" class=\"numeric\" data-title=\"قیمت\"> " + (price_ == null ? "-" : (price_.Price_.ToString("###,##0") + " ريال")) + " </td> "
                             + " </tr> ";
                }
                str += " </tbody> ";

                str += GridPaging.GetHtmlFooter("SearchProduct");
            }

            return Json(str);
        }
        [HttpPost]
        public JsonResult SearchNotification(string PageIndex)
        {

            var q = (from p in dc.Notifications
                     where
                     p.IsDeleted_Customer == false
                     &&
                    (
                   p.UserId == CurrentUser.UID
                    )
                     select p).OrderByDescending(s => s.DateCreate).ThenByDescending(s => s.TimeCreate).ToList();

            string PageNotificationUrl = CurrentUser.Role.IsMenagment == false ? "/CNotification/Notifications/" : "/MNotifications/Notifications/";
            GridPageNumber GridPaging = new GridPageNumber("NOTIFICATION");
            GridPaging.Columns = 7;
            GridPaging.RowRecord = 3;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.pageIndex = PageIndex;
            GridPaging.GridLoad();
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q.ToList();

            string str = " <div class=\"notify-arrow notify-arrow-green\"></div> ";

            string TedadUnread = "";
            if (list.Any())
            {
                if (q.Any(s => s.IsRead == false))
                {
                    TedadUnread = q.Count(s => s.IsRead == false).ToString("###,##0");

                    str += ""
                      + "  <li style=\"cursor:default;\"> "
                      // + "  <p class=\"green\">"  + ("شما " + q.Count(s => s.IsRead == false).ToString("###,##0") + " پیام خوانده نشده دارید") + "</p> "
                      + "  <p class=\"green\">" + "<a href=\"" + PageNotificationUrl + "\" style=\"color:#565353\">" + ("شما " + q.Count(s => s.IsRead == false).ToString("###,##0") + " پیام خوانده نشده دارید") + "</a>" + "</p> "
                      + "  </li> ";
                }
                else
                {
                    str += ""
                     + "  <li style=\"cursor:default;\"> "
                      // + "  <p class=\"green\">"  + ("شما " + q.Count(s => s.IsRead == false).ToString("###,##0") + " پیام خوانده نشده دارید") + "</p> "
                      + "  <p class=\"green\">" + "<a href=\"" + PageNotificationUrl + "\" style=\"color:#565353\">" + ("لیست پیام ها") + "</a>" + "</p> "
                      + "  </li> ";
                }
                int linnumbere = GridPaging.StartLineNumber - 1;
                foreach (var p in list)
                {
                    string time = p.DateCreate;
                    DateTime? dt = DateShamsi.GetMiladiDate(p.DateCreate);
                    if (dt != null)
                    {
                        try
                        {
                            int hour = 0;
                            int min = 0;
                            int sec = 0;
                            hour = int.TryParse(p.TimeCreate.Split(':')[0], out hour) ? hour : 0;
                            min = int.TryParse(p.TimeCreate.Split(':')[1], out min) ? min : 0;
                            sec = int.TryParse(p.TimeCreate.Split(':')[2], out sec) ? sec : 0;
                            dt = dt.Value.AddHours(hour).AddMinutes(min).AddSeconds(sec);
                            TimeSpan timesubtract = DateTime.Now.Subtract(dt.Value);
                            if (timesubtract.TotalHours < 1)
                            {
                                if (timesubtract.TotalMinutes < 1)
                                {
                                    time = timesubtract.TotalSeconds.ToString("0") + " ثانیه";
                                }
                                else
                                    time = timesubtract.TotalMinutes.ToString("0") + " دقیقه";
                            }
                            else if (timesubtract.TotalHours < 24)
                            {
                                time = timesubtract.TotalHours.ToString("0") + " ساعت";
                            }
                        }
                        catch { }

                    }
                    str += "  <li style=\"cursor:default;\"> "
                        + "      <div href=\"#\" style=\"cursor:default;\"> "
                        + "          <span class=\"subject\" style=\"cursor:default;\"> "
                        + "              <span class=\"from\" style=\"cursor:default;\">" + (p.NotificationTypeId != NotificationTypeIDs.Customid ? p.NotificationType.Name : p.Subject) + "</span> "
                        + "              <span class=\"time\" style=\"cursor:default;\">" + time + "</span> "
                        + "          </span> "
                        + "          <span class=\"message\" style=\"cursor:default;\"> "
                        + ((p.NotificationTypeId == ((int)NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + p.NotificationType.Name + " از محصول " + (p.Price.Product.ProductType.Parent.IsShowName ? p.Price.Product.ProductType.Parent.Name : "") + " " + p.Price.Product.ProductType.Name + " " + p.Price.Product.Brand.Name + " به مقدار " + (p.Price.MojodiProduct == null ? "" : p.Price.MojodiProduct.Value.ToString("###,##0")) + " " + p.Price.Product.Unit.Name + " با قیمت " + p.Price.Price_.ToString("###,##0") + " ريال از تاریخ " + p.Price.DatetimeShoro_Persian + " تا " + p.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            ((p.NotificationTypeId == ((int)NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((p.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (p.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + p.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((p.NotificationTypeId == ((int)NotificationTypeIDs.MojodiAnbar)) ? (p.Dsc.Replace(Environment.NewLine, "</br>"))
                            :
                            ((p.NotificationTypeId == ((int)NotificationTypeIDs.TahvilSabadKharid)) ? (p.Dsc.Replace(Environment.NewLine, "</br>"))
                            :
                            ((p.NotificationTypeId == ((int)NotificationTypeIDs.Customid)) ? (p.Dsc.Replace(Environment.NewLine, "</br>")) : ""))

                            )

                            )
                            )
                            )
                        + "          </span> "
                        + "      </div> "
                        + "  </li> ";
                }

                ////Footer
                string UseJavascriptFunctionName = "GetNotifications";
                string strhtml = "";
                if (GridPaging.IsShowPageNumbering)
                {

                    strhtml += " <li> ";

                    if (GridPaging.currentPage >= GridPaging.PageNumber)
                    {

                        strhtml += " <div name=\"notification_pageindex_topmen\" onclick=\"" + UseJavascriptFunctionName + "('" + (GridPaging.StartPageNumber - 1) + "')" + "; return false;\"  class=\"Paging_notification\">" + (GridPaging.Prview) + "</div> ";

                    }

                    for (int i = GridPaging.StartPageNumber; i < (GridPaging.EndPageNumber); i++)
                    {

                        if (i == GridPaging.currentPage)
                        {
                            strhtml += " <div name=\"notification_pageindex_topmen\" style=\"font-weight:bold;background-color: #ffd411\" onclick=\"" + UseJavascriptFunctionName + "('" + (i) + "')" + "; return false;\"  class=\"Paging_notification green\">" + (i + 1) + "</div> ";
                        }
                        else
                        {
                            strhtml += " <div name=\"notification_pageindex_topmen\"  onclick=\"" + UseJavascriptFunctionName + "('" + (i) + "')" + "; return false;\"  class=\"Paging_notification\">" + (i + 1) + "</div> ";

                        }
                    }

                    if (((GridPaging.maxPageNumber - 1) / GridPaging.PageNumber) > ((GridPaging.currentPage) / GridPaging.PageNumber))
                    {

                        strhtml += " <div name=\"notification_pageindex_topmen\" onclick=\"" + UseJavascriptFunctionName + "('" + (GridPaging.EndPageNumber) + "')" + "; return false;\"  class=\"Paging_notification\">" + GridPaging.Next + "</div> ";

                    }

                    strhtml += " </li> ";

                }
                strhtml += " <input type = \"hidden\" id=\"hfCurrentPageIndex" + GridPaging.name + "\" name=\"hfCurrentPageIndex" + GridPaging.name + "\" value=\"" + GridPaging.currentPage + "\" /> ";
                str += strhtml;

            }
            else
            {
                str += ""
                     + "  <li style=\"cursor:default;\"> "
                      // + "  <p class=\"green\">"  + ("شما " + q.Count(s => s.IsRead == false).ToString("###,##0") + " پیام خوانده نشده دارید") + "</p> "
                      + "  <p class=\"green\">" + "<a href=\"" + PageNotificationUrl + "\" style=\"color:#565353\">" + ("لیست پیام ها") + "</a>" + "</p> "
                      + "  </li> "
                + "  <li> "
              + "  <p>در حال حاضر پیامی یافت نشد</p> "
              + "  </li> "
              + " <input type = \"hidden\" id=\"hfCurrentPageIndex" + GridPaging.name + "\" name=\"hfCurrentPageIndex" + GridPaging.name + "\" value=\"" + GridPaging.currentPage + "\" /> ";
            }
            CCheckbox obj = new CCheckbox();
            obj.Name = str;
            obj.ParrentName = TedadUnread;
            return Json(obj);
        }
        [HttpPost]
        public JsonResult ReadAllNotification()
        {
            var q = (from p in dc.Notifications
                     where
                     p.IsDeleted_Customer == false
                     &&
                    (
                   p.UserId == CurrentUser.UID
                    )
                    &&
                    p.IsRead == false
                     select p);
            int i = 0;
            foreach (var p in q)
            {
                p.IsRead = true;
                p.TimeRead = DateShamsi.GetCurrentHour();
                p.DateRead = DateShamsi.GetCurrentDate();
                p.UserRead_Id = CurrentUser.UID;
                i++;
                if (i > 100)
                {
                    i = 0;
                    dc.SubmitChanges();
                }

            }
            dc.SubmitChanges();

            return Json("");
        }

        public JsonResult GETInformationProducts(string Value)
        {
            string ValueDecriptId = Value;
            string str = "";
            Value = EncryptedQueryString.Decrypt(Value);
            var obj = dc.Products.FirstOrDefault(s => s.UID.ToString() == Value);

            var point = dc.Points.FirstOrDefault(s => s.UserID == CurrentUser.UID && s.ProductID.ToString() == Value);
            decimal pointvalue = point == null ? 0 : point.Point1;

            decimal Allpointvalue = obj.Point_Fake == null ? 0 : obj.Point_Fake.Value;
            if (obj.Point_Fake == null)
            {


                var allpoints = dc.Points.Where(s => s.ProductID.ToString() == Value);
                Allpointvalue = allpoints.Any() == true ? ((allpoints).Sum(s => s.Point1) / (allpoints).Count()) : 0;

            }

            if (obj == null)
                str = "<center><div style=\"text-align:center\">کالای مورد نظر یافت نشد</div></center>";
            else
            {

                str += " <div class=\"col-lg-3 col-md-3 Put-md-Right\"> "
                   + "     <center> "
                   + " <img src=\"" + ((obj.ImageUrl == null || obj.ImageUrl.Trim() == "") ? obj.ProductType.Parent.ImageUrl : obj.ImageUrl) + "\" class=\"img-responsive Image_Information\"  /> "

                    + " <div class=\"breakdiv_1\" style=\"height:10px\"></div> "
                    + " <div class=\"stars\">  امتیاز کل : <span id=\"lbl_star_Point\">" + Allpointvalue.ToString("0.0") + "</span>"
                    + " <div class=\"breakdiv_1\"></div> "
                    + " <input class=\"star star-5\" id=\"star-5\" " + (pointvalue == 5 ? "checked" : "") + " type=\"radio\"  name=\"star\" /> "
                    + " <label class=\"star star-5\" onclick=\"SetPoint('" + ValueDecriptId + "','5')\" for=\"star-5\"></label> "
                    + " <input class=\"star star-4\" id=\"star-4\" " + (pointvalue == 4 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                    + " <label class=\"star star-4\"  onclick=\"SetPoint('" + ValueDecriptId + "','4')\"  for=\"star-4\"></label> "
                    + " <input class=\"star star-3\" id=\"star-3\" " + (pointvalue == 3 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                    + " <label class=\"star star-3\" onclick=\"SetPoint('" + ValueDecriptId + "','3')\"  for=\"star-3\"></label> "
                    + " <input class=\"star star-2\" id=\"star-2\" " + (pointvalue == 2 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                    + " <label class=\"star star-2\" onclick=\"SetPoint('" + ValueDecriptId + "','2')\"  for=\"star-2\"></label>  "
                    + " <input class=\"star star-1\"  id=\"star-1\"  " + (pointvalue == 1 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                    + " <label class=\"star star-1\" onclick=\"SetPoint('" + ValueDecriptId + "','1')\"  for=\"star-1\"></label>   "
                    + " </div> "

                   + "    </center> "
                   + " </div> "
                   + " <div class=\"col-lg-9 col-md-9 Put-md-Right\" style\"text-align:right\"> "
                   + "    <div class=\"Farsi_\" style=\"padding:10px;text-align:justify\"> "
                   + (obj.Information == null ? "" : obj.Information.Replace(Environment.NewLine, "</br>"));

                #region محاسبه برای اینکه ببیند تخفیف دارد یا نه

                string CurrentDateTime = DateShamsi.GetMixShamsiDateTimeString(CurrentDate, DateShamsi.GetCurrentHour().Substring(0, 5));


                FunctionMojodi.SETMOJODI(Value);
                dc = new Models.Access.DBDataContext();
                var LstPrices = dc.Prices.Where(s => s.ProductId.ToString() == Value && s.IsDeleted == false &&
                         s.Product.IsShowInSite == true
                &&
                (
                    (
                    (

                        s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.Trim() != "" && s.DatetimeShoro_Persian.CompareTo(CurrentDateTime) <= 0
                        &&
                        (s.DatetimePayan_Persian.Trim() != "" && s.DatetimePayan_Persian.CompareTo(CurrentDateTime) >= 0)
                        &&
                        (
                          (s.IsTakhfifOmomi == true || s.IsDarhalEngheza == true) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0))
                          ||
                          (s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0))
                        )
                    //(s.IsTakhfifEkhtesasi == true || s.IsDarhalEngheza == true || s.IsTakhfifOmomi == true)

                    )
                )

                );

                decimal? tedadreservhayKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(Guid.Parse(Value));
                tedadreservhayKol = tedadreservhayKol == null ? 0 : tedadreservhayKol;
                var sabadkharidjariItemsproduct = dc.SabadKharidItems.Where(s => s.ProductId.ToString() == Value && s.SabadKharidID == CurrentSabadKharidID);

                var ekhtesasi = LstPrices.Where(s => s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID)).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                if (ekhtesasi != null)
                {

                    ////خریدهای اختصاصی رزرو و ثبت شده توسط این کاربر
                    var sabadkharidItems = ekhtesasi.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID);
                    //// تعداد رزرو از کالای اختصاصی توسط این کاربر
                    decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false).Sum(s => s.Count)) : 0;
                    //// تعداد خریداری شده از این کالا توسط این کاربر
                    decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                    ////تعدادی که کاربر اجازه خرید دارد 
                    decimal TedadiKMitavanKharid = (decimal)ekhtesasi.MojodiProduct - TedadKharid;


                    if (TedadiKMitavanKharid > 0)
                    {

                        str += "</br> <span style=\"color:#ca5a55\" class=\"fa fa-gift\">   </span><span style=\"color:#ca5a55\"> جشنواره اختصاصی تا تاریخ " + ekhtesasi.DatetimePayan_Persian + " ادامه دارد. </span>";


                    }
                }
                var omomi = LstPrices.Where(s => s.IsTakhfifOmomi == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                if (omomi != null)
                {



                    ////خریدهای عمومی رزرو و ثبت شده 
                    var sabadkharidItems = omomi.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                    //// تعداد رزرو از کالای عمومی توسط این کاربر
                    decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(s => s.Count)) : 0;
                    //// تعداد خریداری شده از این کالا 
                    decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                    ////تعدادی که کاربر اجازه خرید دارد 
                    decimal TedadiKMitavanKharid = (decimal)omomi.MojodiProduct - TedadKharid;


                    if (TedadiKMitavanKharid > 0)
                    {
                        str += "</br> <span style=\"color:#ca5a55\" class=\"fa fa-gift\">   </span><span style=\"color:#ca5a55\"> جشنواره عمومی تا تاریخ " + omomi.DatetimePayan_Persian + " ادامه دارد. </span>";


                    }
                }
                var vizhe = LstPrices.Where(s => s.IsDarhalEngheza == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                if (vizhe != null)
                {

                    ////خریدهای ویژه رزرو و خریداری شده 
                    var sabadkharidItems = vizhe.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                    //// تعداد رزرو از کالای ویژه توسط این کاربر
                    decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(s => s.Count)) : 0;
                    //// تعداد خریداری شده از این کالا 
                    decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                    ////تعدادی که کاربر اجازه خرید دارد 
                    decimal TedadiKMitavanKharid = (decimal)vizhe.MojodiProduct - TedadKharid;


                    if (TedadiKMitavanKharid > 0)
                    {


                        str += "</br> <span style=\"color:#ca5a55\" class=\"fa fa-gift\">   </span><span style=\"color:#ca5a55\"> فروش ویژه تا تاریخ " + vizhe.DatetimePayan_Persian + " ادامه دارد. </span>";

                    }
                }
                #endregion

                str += "  </div> ";
                str += "   </div>     ";

            }








            return Json(str);
        }
        [HttpPost]
        public JsonResult GETSefareshnProducts(string Value)
        {



            string str = "";
            string CurrentDateTime = DateShamsi.GetMixShamsiDateTimeString(CurrentDate, DateShamsi.GetCurrentHour().Substring(0, 5));
            Value = EncryptedQueryString.Decrypt(Value);

            FunctionMojodi.SETMOJODI(Value);
            dc = new Models.Access.DBDataContext();
            var LstPrices = dc.Prices.Where(s => s.ProductId.ToString() == Value && s.IsDeleted == false &&
                     s.Product.IsShowInSite == true
            &&
            (
                (
                    s.IsPriceAsli == true

                    &&
                    s.DateShoro != null && s.DateShoro.Trim() != "" && s.DateShoro.CompareTo(CurrentDate) <= 0
                    &&
                    (s.DatePayan == null || s.DatePayan.Trim() == "" || s.DatePayan.CompareTo(CurrentDate) >= 0)
                )
                ||
                (
                (

                    s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.Trim() != "" && s.DatetimeShoro_Persian.CompareTo(CurrentDateTime) <= 0
                    &&
                    (s.DatetimePayan_Persian.Trim() != "" && s.DatetimePayan_Persian.CompareTo(CurrentDateTime) >= 0)
                    &&
                    (
                      (s.IsTakhfifOmomi == true || s.IsDarhalEngheza == true) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0))
                      ||
                      (s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0))
                    )
                //(s.IsTakhfifEkhtesasi == true || s.IsDarhalEngheza == true || s.IsTakhfifOmomi == true)

                )
            )

            );

            decimal? tedadreservhayKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(Guid.Parse(Value));
            tedadreservhayKol = tedadreservhayKol == null ? 0 : tedadreservhayKol;
            var sabadkharidjariItemsproduct = dc.SabadKharidItems.Where(s => s.ProductId.ToString() == Value && s.SabadKharidID == CurrentSabadKharidID);


            GridPageNumber gr = new GridPageNumber();
            gr.lst_headerName.AddRange(new List<string>() { "نوع سفارش", "قیمت واحد", "موجودی", "تعداد سفارش", "واحد" });
            str += gr.GetHtmlHeader(false);
            str += " <tbody> ";



            var ekhtesasi = LstPrices.Where(s => s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID)).OrderByDescending(s => s.DateSabt).FirstOrDefault();
            if (ekhtesasi != null)
            {

                ////خریدهای اختصاصی رزرو و ثبت شده توسط این کاربر
                var sabadkharidItems = ekhtesasi.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID);
                //// تعداد رزرو از کالای اختصاصی توسط این کاربر
                decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false).Sum(s => s.Count)) : 0;
                //// تعداد خریداری شده از این کالا توسط این کاربر
                decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                ////تعدادی که کاربر اجازه خرید دارد 
                decimal TedadiKMitavanKharid = (decimal)ekhtesasi.MojodiProduct - TedadKharid;


                if (TedadiKMitavanKharid > 0)
                {
                    decimal anbar_jari = ekhtesasi.Product.MojodiCount - (decimal)tedadreservhayKol + TedadReservSabadKharid;


                    string Mojodi = (anbar_jari < TedadiKMitavanKharid) ?
                        (anbar_jari <= 0 ? (TedadReservSabadKharid <= 0 ? "ناموجود" : (TedadReservSabadKharid.ToString("###,##0") + " " + ekhtesasi.Product.Unit.Name))
                        : (anbar_jari.ToString("###,##0") + " " + ekhtesasi.Product.Unit.Name))
                        : ((TedadiKMitavanKharid.ToString("###,##0") + " " + ekhtesasi.Product.Unit.Name));

                    str += AddRecordFromTableSefareshProducts("جشنواره اختصاصی", ekhtesasi.Price_.ToString("###,##0") + " ریال", Mojodi, "PRIVATE", TedadReservSabadKharid <= 0 ? "" : TedadReservSabadKharid.ToString(), ekhtesasi.Product.Unit.Name, ekhtesasi.UID.ToString());


                }
            }
            var omomi = LstPrices.Where(s => s.IsTakhfifOmomi == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
            if (omomi != null)
            {



                ////خریدهای عمومی رزرو و ثبت شده 
                var sabadkharidItems = omomi.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                //// تعداد رزرو از کالای عمومی توسط این کاربر
                decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(s => s.Count)) : 0;
                //// تعداد خریداری شده از این کالا 
                decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                ////تعدادی که کاربر اجازه خرید دارد 
                decimal TedadiKMitavanKharid = (decimal)omomi.MojodiProduct - TedadKharid;


                if (TedadiKMitavanKharid > 0)
                {
                    decimal anbar_jari = omomi.Product.MojodiCount - (decimal)tedadreservhayKol + TedadReservSabadKharid;


                    string Mojodi = (anbar_jari < TedadiKMitavanKharid) ?
                        (anbar_jari <= 0 ? (TedadReservSabadKharid <= 0 ? "ناموجود" : (TedadReservSabadKharid.ToString("###,##0") + " " + omomi.Product.Unit.Name))
                        : (anbar_jari.ToString("###,##0") + " " + omomi.Product.Unit.Name))
                        : ((TedadiKMitavanKharid.ToString("###,##0") + " " + omomi.Product.Unit.Name));

                    str += AddRecordFromTableSefareshProducts("جشنواره عمومی", omomi.Price_.ToString("###,##0") + " ریال", Mojodi, "PUBLIC", TedadReservSabadKharid <= 0 ? "" : TedadReservSabadKharid.ToString(), omomi.Product.Unit.Name, omomi.UID.ToString());


                }
            }
            var vizhe = LstPrices.Where(s => s.IsDarhalEngheza == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
            if (vizhe != null)
            {

                ////خریدهای ویژه رزرو و خریداری شده 
                var sabadkharidItems = vizhe.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                //// تعداد رزرو از کالای ویژه توسط این کاربر
                decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(s => s.Count)) : 0;
                //// تعداد خریداری شده از این کالا 
                decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                ////تعدادی که کاربر اجازه خرید دارد 
                decimal TedadiKMitavanKharid = (decimal)vizhe.MojodiProduct - TedadKharid;


                if (TedadiKMitavanKharid > 0)
                {
                    decimal? tedadrezervKol = FunctionMojodi.MojodiReservHay_TedadDarHaleEngheza(vizhe.ProductId);
                    tedadrezervKol = tedadrezervKol == null ? 0 : tedadrezervKol;
                    decimal anbar_jari = TedadiKMitavanKharid - (decimal)tedadrezervKol + TedadReservSabadKharid;


                    string Mojodi = (anbar_jari < TedadiKMitavanKharid) ?
                        (anbar_jari <= 0 ? (TedadReservSabadKharid <= 0 ? "ناموجود" : (TedadReservSabadKharid.ToString("###,##0") + " " + vizhe.Product.Unit.Name))
                        : (anbar_jari.ToString("###,##0") + " " + vizhe.Product.Unit.Name))
                        : ((TedadiKMitavanKharid.ToString("###,##0") + " " + vizhe.Product.Unit.Name));

                    str += AddRecordFromTableSefareshProducts("فروش ویژه", vizhe.Price_.ToString("###,##0") + " ریال", Mojodi, "SPECIAL", TedadReservSabadKharid <= 0 ? "" : TedadReservSabadKharid.ToString(), vizhe.Product.Unit.Name, vizhe.UID.ToString());


                }
            }

            var asli = LstPrices.Where(s => s.IsPriceAsli == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
            if (asli != null)
            {
                ////خریدهای رزرو  
                var sabadkharidItems = asli.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false);
                //// تعداد رزرو از کالا توسط این کاربر
                decimal TedadReservSabadKharid = sabadkharidItems.Any(s => s.SabadKharid.UserMoshtariID == CurrentUser.UID) ? (sabadkharidItems.Where(s => s.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(s => s.Count)) : 0;


                if (asli.Product.MojodiCount > 0)
                {
                    decimal anbar_jari = asli.Product.MojodiCount - (decimal)tedadreservhayKol + TedadReservSabadKharid;


                    string Mojodi = (anbar_jari <= 0) ? "ناموجود" : "موجود";


                    str += AddRecordFromTableSefareshProducts(" عمومی", asli.Price_.ToString("###,##0") + " ریال", Mojodi, "ASLI", TedadReservSabadKharid <= 0 ? "" : TedadReservSabadKharid.ToString(), asli.Product.Unit.Name, asli.UID.ToString());


                }
            }

            str += "    <input type=\"hidden\" id=\"hfproductSefareshID\" name=\"hfproductSefareshID\" value=\"" + Value + "\" /> ";
            str += " <tbody> ";
            return Json(str);
        }

        private string AddRecordFromTableSefareshProducts(string NoeSefaresh, string ghymat, string mojodi, string idInput, string meghdarJari, string vahed, string PriceID)
        {
            string str = "";

            str = " <tr> "
            + "    <td data-title=\"نوع سفارش\"> " + NoeSefaresh + " </td> "
            + "    <td data-title=\"قیمت واحد\"> " + ghymat + " </td> "
            + "    <td data-title=\"موجودی\"> " + mojodi + " </td> "
            + "    <td data-title=\"تعداد سفارش\"> <input ID=\"txt" + idInput + "\"  name=\"txt" + idInput + "\" type=\"text\" value=\"" + meghdarJari + "\" maxlength=\"12\"  onkeypress=\"IsNumeric(event)\" style=\"direction: rtl;\" class=\"form-control Farsi_\" /> </td> "
            + "    <td data-title=\"واحد\"> " + vahed + " </td> "
            + "    <input type=\"hidden\" id=\"hf" + idInput + "\" name=\"hf" + idInput + "\" value=\"" + EncryptedQueryString.Encrypt(PriceID) + "\" /> "
            + " </tr> ";




            return str;
        }




        [HttpPost]
        public ActionResult GETDISPLAYFACTOR(string Value)
        {
            string str = "<center><div style=\"text-align:center\">سبد خرید مورد نظر یافت نشد</div></center>";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                string ValueDecriptId = Utility.EncryptedQueryString.Encrypt(sabadkharid.UID.ToString());
                str = "";



                str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span>کد پیگیری  : " + sabadkharid.CodeRahgiri + " </label> ";
                str += "           </div>       ";
                str += "   </div>            ";
                str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\"> ";
                str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "               </span>تاریخ سفارش  : " + sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] ";
                str += "           </label> ";
                str += "       </div> ";
                str += "   </div> ";
                str += "   <div class=\"breakdiv_1\"></div> ";

                str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span> وضعیت : " + (sabadkharid.IsTaiedBarrasi == false ? "در حال بررسی" : (sabadkharid.IsTahvilBeMoshtari == true ? "تحویل شد" : "در حال توزیع")) + " </label> ";
                str += "           </div>       ";
                str += "   </div>      ";

                if (sabadkharid.IsTaiedBarrasi)
                {

                    str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\"> ";
                    str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                    str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "               </span>توزیع کننده : " + sabadkharid.userTahvilDahande.FullName;
                    str += "           </label> ";
                    str += "       </div> ";
                    str += "   </div> ";
                    str += "   <div class=\"breakdiv_1\"></div> ";
                }
                if (sabadkharid.IsTahvilBeMoshtari)
                {
                    str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12 Put-lg-Right \"> ";
                    str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "                   </span> تحویل گیرنده : " + sabadkharid.FullNameTahvilGirande + " </label> ";
                    str += "           </div>       ";
                    str += "   </div>            ";
                    str += "   <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\"> ";
                    str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                    str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "               </span>تاریخ تحویل  : " + sabadkharid.DateTahvilBeMoshtari_Fa + " [" + sabadkharid.TimeTahvilBeMoshtari_Fa + "] ";
                    str += "           </label> ";
                    str += "       </div> ";
                    str += "   </div> ";
                    str += "   <div class=\"breakdiv_1\"></div> ";
                }


                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";
                str += "    <div id=\"no-more-tables\"> ";
                str += "       <table id=\"Table_SHOW_FACTOR\" class=\"table table-bordered table-striped table-condensed cf\"> ";
                GridPageNumber gr = new GridPageNumber();
                gr.lst_headerName.AddRange(new List<string>() { "عنوان", "تعداد", "قیمت واحد", "قیمت کل" });
                str += gr.GetHtmlHeader();
                str += " <tbody> ";
                int line = 0;
                foreach (var q in sabadkharid.SabadKharidItems)
                {

                    str += " <tr> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++line) + " </td> ";
                    str += " <td data-title=\"عنوان\" align=\"center\"> " + q.Product.ProductType.Parent.Name + " " + q.Product.ProductType.Name + " " + q.Product.Brand.Name + (q.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (q.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : (q.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : ""))) + "  </td> ";
                    str += " <td data-title=\"تعداد\" align=\"center\"> " + q.Count.ToString("###,##0") + " " + q.Product.Unit.Name + "  </td> ";
                    str += " <td data-title=\"قیمت واحد\" align=\"center\"> " + (q.PriceVahed.ToString("###,##0") + " ریال") + "  </td> ";
                    str += " <td data-title=\"قیمت کل\" align=\"center\"> " + (q.Count * q.PriceVahed).ToString("###,##0") + " ریال" + "  </td> ";
                    str += " </tr> ";



                }

                str += " </tbody> ";

                str += "  <tbody> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مجموع قیمت :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مجموع قیمت\"> " + (sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed)).ToString("###,##0") + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مالیات بر ارزش افزوده :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مالیات\"> " + (sabadkharid.MablaghPardakhtMaliat).ToString("###,##0") +" ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">حمل نقل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"حمل نقل\"> " + (sabadkharid.MablaghPardakhtTransport).ToString("###,##0") + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\"> مبلغ کل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\" مبلغ کل\"> " + ((sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed) + sabadkharid.MablaghPardakhtTransport + sabadkharid.MablaghPardakhtMaliat).ToString("###,##0")) + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += " </tbody> ";


                str += " </table> ";
                str += "    </div> "
                + " <div class=\"breakdiv_1\" style=\"height:1px\"></div> "
                + " <div class=\"stars\" style=\"float:right;width:auto\">   <span id=\"lbl_star_Point\">" + "" + "</span>"
                + " <div style=\"float:right;padding-top: 11px;\">امتیاز دهی به خدمات :</div>"
                //+ " <div class=\"breakdiv_1\"></div> "
                + " <div style=\"float:right\"> "
                + " <input class=\"star star-5\" id=\"star-5\" " + (sabadkharid.PointService == 5 ? "checked" : "") + " type=\"radio\"  name=\"star\" /> "
                + " <label class=\"star star-5\" onclick=\"SetPointService('" + ValueDecriptId + "','5')\" for=\"star-5\"></label> "
                + " <input class=\"star star-4\" id=\"star-4\" " + (sabadkharid.PointService == 4 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                + " <label class=\"star star-4\"  onclick=\"SetPointService('" + ValueDecriptId + "','4')\"  for=\"star-4\"></label> "
                + " <input class=\"star star-3\" id=\"star-3\" " + (sabadkharid.PointService == 3 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                + " <label class=\"star star-3\" onclick=\"SetPointService('" + ValueDecriptId + "','3')\"  for=\"star-3\"></label> "
                + " <input class=\"star star-2\" id=\"star-2\" " + (sabadkharid.PointService == 2 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                + " <label class=\"star star-2\" onclick=\"SetPointService('" + ValueDecriptId + "','2')\"  for=\"star-2\"></label>  "
                + " <input class=\"star star-1\"  id=\"star-1\"  " + (sabadkharid.PointService == 1 ? "checked" : "") + "  type=\"radio\" name=\"star\" /> "
                + " <label class=\"star star-1\" onclick=\"SetPointService('" + ValueDecriptId + "','1')\"  for=\"star-1\"></label>   "
                + " </div> "
                + " </div> ";




                str += " <div style=\"float: left;margin-top:10px\"> ";
                str += "  <button ID=\"btnEnserafSHOW_FACTORProduct\" Class=\"btn btn_Costom\" onclick=\"ClickCloseModelDialog_SHOWFACTOR(); return false;\" style=\"width:90px\"><div class=\"fa fa-close\" style=\"font-size: 20px; font-weight: bold;float:right;padding-top:-6px\"></div>    انصراف</button> ";
                str += " </div> ";



                str += " <div class=\"breakdiv_1\" style=\"height:10px\"></div> ";
            }
            return Json(str);

        }
        [HttpPost]
        public ActionResult GETDISPLAYFACTOR_Manegmrnt(string Value)
        {
            string str = "<center><div style=\"text-align:center\">سبد خرید مورد نظر یافت نشد</div></center>";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                str = "";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span>کد پیگیری  : " + sabadkharid.CodeRahgiri + " </label> ";
                str += "           </div>       ";
                str += "   </div>            ";
                str += "   <div class=\"col-lg-6\"> ";
                str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "               </span>تاریخ سفارش  : " + sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] ";
                str += "           </label> ";
                str += "       </div> ";
                str += "   </div> ";
                str += "   <div class=\"breakdiv_1\"></div> ";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span> وضعیت : " + (sabadkharid.IsTaiedBarrasi == false ? "در حال بررسی" : (sabadkharid.IsTahvilBeMoshtari == true ? "تحویل شد" : "در حال توزیع")) + " </label> ";
                str += "           </div>       ";
                str += "   </div>      ";

                if (sabadkharid.IsTaiedBarrasi)
                {

                    str += "   <div class=\"col-lg-6\"> ";
                    str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                    str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "               </span>توزیع کننده : " + sabadkharid.userTahvilDahande.FullName;
                    str += "           </label> ";
                    str += "       </div> ";
                    str += "   </div> ";
                    str += "   <div class=\"breakdiv_1\"></div> ";
                }
                if (sabadkharid.IsTahvilBeMoshtari)
                {
                    str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                    str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "                   </span> تحویل گیرنده : " + sabadkharid.FullNameTahvilGirande + " </label> ";
                    str += "           </div>       ";
                    str += "   </div>            ";
                    str += "   <div class=\"col-lg-6\"> ";
                    str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                    str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                    str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                    str += "               </span>تاریخ تحویل  : " + sabadkharid.DateTahvilBeMoshtari_Fa + " [" + sabadkharid.TimeTahvilBeMoshtari_Fa + "] ";
                    str += "           </label> ";
                    str += "       </div> ";
                    str += "   </div> ";
                    str += "   <div class=\"breakdiv_1\"></div> ";
                }


                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";
                str += "    <div id=\"no-more-tables\"> ";
                str += "       <table id=\"Table_SHOW_FACTOR\" class=\"table table-bordered table-striped table-condensed cf\"> ";
                GridPageNumber gr = new GridPageNumber();
                gr.lst_headerName.AddRange(new List<string>() { "عنوان", "تعداد", "قیمت واحد", "قیمت کل", "تحویل از انبار" });
                str += gr.GetHtmlHeader();
                str += " <tbody> ";
                int line = 0;
                foreach (var q in sabadkharid.SabadKharidItems)
                {

                    str += " <tr> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++line) + " </td> ";
                    str += " <td data-title=\"عنوان\" align=\"center\"> " + q.Product.ProductType.Parent.Name + " " + q.Product.ProductType.Name + " " + q.Product.Brand.Name + (q.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (q.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : (q.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : ""))) + "  </td> ";
                    str += " <td data-title=\"تعداد\" align=\"center\"> " + q.Count.ToString("###,##0") + " " + q.Product.Unit.Name + "  </td> ";
                    str += " <td data-title=\"قیمت واحد\" align=\"center\"> " + (q.PriceVahed.ToString("###,##0") + " ریال") + "  </td> ";
                    str += " <td data-title=\"قیمت کل\" align=\"center\"> " + (q.Count * q.PriceVahed).ToString("###,##0") + " ریال" + "  </td> ";
                    str += " <td data-title=\" تحویل از انبار\" align=\"center\"> " + (q.IsTahvilAzAnbar != true ? "-" : (q.DateTahvilAzAnbar_Fa + " [" + q.TimeTahvilAzAnbar_Fa + "] ")) + "  </td> ";
                    str += " </tr> ";



                }

                str += " </tbody> ";

                str += "  <tbody> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مجموع قیمت :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مجموع قیمت\"> " + (sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed)).ToString("###,##0") + " ریال </td> ";
                str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مالیات بر ارزش افزوده :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مالیات\"> " + (sabadkharid.MablaghPardakhtMaliat).ToString("###,##0") +" ریال </td> ";
                str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">حمل نقل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"حمل نقل\"> " + (sabadkharid.MablaghPardakhtTransport).ToString("###,##0") + " ریال </td> ";
                str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\"> مبلغ کل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\" مبلغ کل\"> " + ((sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed) + sabadkharid.MablaghPardakhtTransport + sabadkharid.MablaghPardakhtMaliat).ToString("###,##0")) + " ریال </td> ";
                str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += " </tbody> ";


                str += " </table> ";
                str += "    </div> ";
            }
            return Json(str);

        }
        [HttpPost]
        public ActionResult GETDISPLAYFACTOR_BARRASINASHODE(string Value)
        {
            string str = "<center><div style=\"text-align:center\">سبد خرید مورد نظر یافت نشد</div></center>";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                str = "";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span>کد پیگیری  : " + sabadkharid.CodeRahgiri + " </label> ";
                str += "           </div>       ";
                str += "   </div>            ";
                str += "   <div class=\"col-lg-6\"> ";
                str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "               </span>تاریخ سفارش  : " + sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] ";
                str += "           </label> ";
                str += "       </div> ";
                str += "   </div> ";
                str += "   <div class=\"breakdiv_1\"></div> ";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span> درخواست کننده : " + (sabadkharid.UserMoshtariID == null ? "-" : (sabadkharid.userMoshtari.FullName + " [ " + sabadkharid.userMoshtari.OnvaneSherkat + " ]")) + " </label> ";
                str += "           </div>       ";
                str += "   </div>      ";

                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";
                str += "    <div id=\"no-more-tables\"> ";
                str += "       <table id=\"Table_SHOW_FACTOR\" class=\"table table-bordered table-striped table-condensed cf\"> ";
                GridPageNumber gr = new GridPageNumber();
                gr.lst_headerName.AddRange(new List<string>() { "عنوان", "تعداد", "قیمت واحد", "قیمت کل" });
                str += gr.GetHtmlHeader();
                str += " <tbody> ";
                int line = 0;
                foreach (var q in sabadkharid.SabadKharidItems)
                {

                    str += " <tr> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++line) + " </td> ";
                    str += " <td data-title=\"عنوان\" align=\"center\"> " + q.Product.ProductType.Parent.Name + " " + q.Product.ProductType.Name + " " + q.Product.Brand.Name + (q.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (q.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : (q.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : ""))) + "  </td> ";
                    str += " <td data-title=\"تعداد\" align=\"center\"> " + q.Count.ToString("###,##0") + " " + q.Product.Unit.Name + "  </td> ";
                    str += " <td data-title=\"قیمت واحد\" align=\"center\"> " + (q.PriceVahed.ToString("###,##0") + " ریال") + "  </td> ";
                    str += " <td data-title=\"قیمت کل\" align=\"center\"> " + (q.Count * q.PriceVahed).ToString("###,##0") + " ریال" + "  </td> ";
                    str += " </tr> ";



                }

                str += " </tbody> ";

                str += "  <tbody> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مجموع قیمت :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مجموع قیمت\"> " + (sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed)).ToString("###,##0") + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">مالیات بر ارزش افزوده :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"مالیات\"> " + (sabadkharid.MablaghPardakhtMaliat).ToString("###,##0") + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\">حمل نقل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\"حمل نقل\"> " + (sabadkharid.MablaghPardakhtTransport).ToString("###,##0") + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += "      <tr style=\"border: 1px solid #ccc;color:white !important\"> ";
                str += " <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"4\"><span class=\"DisplayWhenTableXs_sm\"> مبلغ کل :</span></td> ";
                str += " <td style=\"background-color:#695959;border-bottom-color:transparent\" data-title=\" مبلغ کل\"> " + ((sabadkharid.SabadKharidItems.Sum(s => s.Count * s.PriceVahed) + sabadkharid.MablaghPardakhtTransport + sabadkharid.MablaghPardakhtMaliat).ToString("###,##0")) + " ریال </td> ";
                // str += " <td style=\"background-color:#695959\"></td> ";
                str += " </tr> ";
                str += " </tbody> ";


                str += " </table> ";
                str += "    </div> ";
                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";


                var tozikonande = dc.users.Where(s => s.RoleId == (int)RoleIds.M_ToziKonande && s.IsDeleted == false);


                str += "    <div class=\"form-group\"> ";
                str += "      <div class=\"col-lg-2 col-md-4\" style=\"float: right;text-align: left\"> ";
                str += "          <label class=\"control-label Farsi_\" style=\"text-align: left;\">توزیع کننده  :</label> ";
                str += "      </div> ";
                str += "      <div class=\"col-lg-10 col-md-8\" style=\"padding: 0px;\"> ";
                str += "          <select id=\"cboSelectTozieKonande\" name=\"cboSelectTozieKonande\" style=\"float: right; padding-top: 0px\" class=\"form-control Farsi_\"> ";
                str += "    <option " + ((sabadkharid.UserTahvilDahandeID == null || sabadkharid.UserTahvilDahandeID == Guid.Empty) ? "selected=\"selected\"" : "") + " value = \"\" > " + "کاربر توزیع کننده را انتخاب نمایید" + " </ option > ";
                foreach (var item in tozikonande)
                {
                    str += "    <option " + (sabadkharid.UserTahvilDahandeID == item.UID ? "selected=\"selected\"" : "") + " value = \"" + Utility.EncryptedQueryString.Encrypt(item.UID.ToString()) + "\" > " + item.FullName + " </ option > ";
                }
                str += "          </select> ";
                str += "      </div> ";


            }
            return Json(str);

        }

        [HttpPost]
        public ActionResult GETDISPLAYFACTOR_DARHALTOZIE(string Value)
        {
            string str = "<center><div style=\"text-align:center\">سبد خرید مورد نظر یافت نشد</div></center>";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                str = "";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span>کد پیگیری  : " + sabadkharid.CodeRahgiri + " </label> ";
                str += "           </div>       ";
                str += "   </div>            ";
                str += "   <div class=\"col-lg-6\"> ";
                str += "       <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "           <label class=\"control-label Farsi_\" style=\"text-align: right;\"> ";
                str += "               <span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "               </span>تاریخ سفارش  : " + sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] ";
                str += "           </label> ";
                str += "       </div> ";
                str += "   </div> ";
                str += "   <div class=\"breakdiv_1\"></div> ";

                str += "   <div class=\"col-lg-6 Put-lg-Right\"> ";
                str += "           <div class=\"col-lg-12 \" style=\"float: right;\"> ";
                str += "               <label class=\"control-label Farsi_\" style=\"text-align: right;\"><span class=\"Farsi_\" style=\"color: red;\"> ";
                str += "                   </span> درخواست کننده : " + (sabadkharid.UserMoshtariID == null ? "-" : (sabadkharid.userMoshtari.FullName + " [ " + sabadkharid.userMoshtari.OnvaneSherkat + " ]")) + " </label> ";
                str += "           </div>       ";
                str += "   </div>      ";

                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";
                str += "    <div id=\"no-more-tables\"> ";
                str += "       <table id=\"Table_SHOW_FACTOR\" class=\"table table-bordered table-striped table-condensed cf\"> ";
                GridPageNumber gr = new GridPageNumber();
                gr.lst_headerName.AddRange(new List<string>() { "عنوان", "تعداد", "تحویل از انبار" });
                str += gr.GetHtmlHeader();
                str += " <tbody> ";
                int line = 0;
                foreach (var q in sabadkharid.SabadKharidItems)
                {

                    str += " <tr> ";
                    str += " <td data-title=\"ردیف\" align=\"center\"> " + (++line) + " </td> ";
                    str += " <td data-title=\"عنوان\" align=\"center\"> " + q.Product.ProductType.Parent.Name + " " + q.Product.ProductType.Name + " " + q.Product.Brand.Name + (q.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (q.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : (q.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : ""))) + "  </td> ";
                    str += " <td data-title=\"تعداد\" align=\"center\"> " + q.Count.ToString("###,##0") + " " + q.Product.Unit.Name + "  </td> ";
                    str += " <td data-title=\"تحویل از انبار\" align=\"center\"> " +
                   (q.IsTahvilAzAnbar == true ? (q.DateTahvilAzAnbar_Fa + " [" + q.TimeTahvilAzAnbar_Fa + "] ")

                   :
                        (

                     "   <div Id=\"DIVTAHVILAZANBAR" + line + "\" style=\"font-size:24px;\"> " +
                     "    <button onclick=\"SetTahvilAzAnbar('DIVTAHVILAZANBAR" + line + "','" + Utility.EncryptedQueryString.Encrypt(q.UID.ToString()) + "');return false;\"  class=\"btn  btn_Costom Farsi_\" Style=\"width:90px\"> " +
                     "     <div class=\"\" style=\"font-size: 20px; font-weight: bold;float:right;padding-top:-6px\"></div>  تحویل " +
                     "    </button> " +
                     "   </div> "

                        )
                   )


                    + "  </td> ";

                    str += " </tr> ";



                }

                str += " <tbody> ";


                str += " </table> ";
                str += "    </div> ";
                str += "     <div class=\"breakdiv_1\" style=\"height: 10px\"></div> ";



            }
            return Json(str);

        }

        [HttpPost]
        public ActionResult SetTahvilAzAnbar_FACTOR(string Value)
        {
            string str = "خطا";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharidItems.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {

                sabadkharid.IsTahvilAzAnbar = true;
                sabadkharid.DateTahvilAzAnbar_Fa = DateShamsi.GetCurrentDate();
                sabadkharid.TimeTahvilAzAnbar_Fa = DateShamsi.GetCurrentHour();
                sabadkharid.DateTimeTahvilAzAnbar = DateTime.Now;
                dc.SubmitChanges();
                str = sabadkharid.DateTahvilAzAnbar_Fa + " [" + sabadkharid.TimeTahvilAzAnbar_Fa + "]";
                EventLog.Loging("کالای " + sabadkharid.Product.ProductType.Parent.Name + " " + sabadkharid.Product.ProductType.Name + " " + sabadkharid.Product.Brand.Name + (sabadkharid.Price.IsDarhalEngheza == true ? " [فروش ویژه] " : (sabadkharid.Price.IsTakhfifOmomi == true ? " [جشنواره عمومی] " : (sabadkharid.Price.IsTakhfifEkhtesasi == true ? " [جشنواره اختصاصی] " : ""))) + " به تعداد " + sabadkharid.Count + " " + sabadkharid.Product.Unit.Name + " " + " با شماره پیگیری " + sabadkharid.SabadKharid.CodeRahgiri + " از انبار دریافت گردید.", EventTypeIds.SAVE, "TOZIEKALA_M", CurrentUser.UID);
            }
            return Json(str);

        }

        [HttpPost]
        public ActionResult IS_SABAD_KHARID_TAHVIL_GREFTE_SHODEAST(string Value)
        {
            string str = "false";

            Value = EncryptedQueryString.Decrypt(Value);

            var sabadkharid = dc.SabadKharids.Where(s => s.UID.ToString() == Value).FirstOrDefault();

            if (sabadkharid != null)
            {
                bool is_ = sabadkharid.SabadKharidItems.Any(s => s.IsTahvilAzAnbar == false || s.IsTahvilAzAnbar == null);
                str = is_ ? "false" : "true";
            }
            return Json(str);

        }

        [HttpPost]
        public JsonResult SetPoint(string Value, string idproduct)
        {
            decimal tmp = 0;
            string str = decimal.TryParse("0" + Value, out tmp) ? tmp.ToString("0.0") : tmp.ToString("0.0");
            idproduct = EncryptedQueryString.Decrypt(idproduct);
            try
            {
                var point = dc.Points.FirstOrDefault(s => s.UserID == CurrentUser.UID && s.ProductID.ToString() == idproduct);
                if (point == null)
                {
                    point = new restauran.Models.Access.Tables.Point();
                    point.UID = Guid.NewGuid();
                    point.ProductID = Guid.Parse(idproduct);
                    point.UserID = CurrentUser.UID;
                    point.Point1 = tmp;
                    dc.Points.InsertOnSubmit(point);
                }
                point.Point1 = tmp;
                dc.SubmitChanges();
            }
            catch { }

            var allpoints = dc.Points.Where(s => s.ProductID.ToString() == idproduct);
            decimal Allpointvalue = allpoints.Any() == true ? ((allpoints).Sum(s => s.Point1) / (allpoints).Count()) : 0;

            return Json(Allpointvalue.ToString("0.0"));
        }

        [HttpPost]
        public JsonResult SetPointService(string Value, string idsabadkharid)
        {
            int tmp = 0;
            string str = int.TryParse("0" + Value, out tmp) ? tmp.ToString("0") : tmp.ToString("0");
            idsabadkharid = EncryptedQueryString.Decrypt(idsabadkharid);
            try
            {
                var sabadkharid = dc.SabadKharids.FirstOrDefault(s => s.UID.ToString() == idsabadkharid);
                if (sabadkharid != null)
                {
                    sabadkharid.PointService = tmp;
                    dc.SubmitChanges();
                }

                dc.SubmitChanges();
            }
            catch { }

            return Json("");
        }

    }
}
