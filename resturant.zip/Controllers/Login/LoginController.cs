﻿using restauran.Models.Access;
using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Controllers.Login
{
    public class LoginController : Controller
    {
        public ActionResult generateCaptcha()
        {
            System.Drawing.FontFamily family = new System.Drawing.FontFamily("Arial");
            CaptchaImage img = new CaptchaImage(100, 40, family);
            string text = img.CreateRandomText(4);
            img.SetText(text);
            img.GenerateImage();
            img.Image.Save(Server.MapPath("~/Images/Captcha/") + this.Session.SessionID.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
            Session["captchaText"] = text.ToUpper();
            return Json("/Images/Captcha/" + this.Session.SessionID.ToString() + ".png?t=" + DateTime.Now.Ticks, JsonRequestBehavior.AllowGet);
        }

        public string GetgenerateCaptcha()
        {
            System.Drawing.FontFamily family = new System.Drawing.FontFamily("Arial");
            CaptchaImage img = new CaptchaImage(100, 40, family);
            string text = img.CreateRandomText(4);
            img.SetText(text);
            img.GenerateImage();
            img.Image.Save(Server.MapPath("~/Images/Captcha/") + this.Session.SessionID.ToString() + ".png", System.Drawing.Imaging.ImageFormat.Png);
            Session["captchaText"] = text.ToUpper();
            return ("/Images/Captcha/" + this.Session.SessionID.ToString() + ".png?t=" + DateTime.Now.Ticks);
        }
        // GET: Login
        public ActionResult Login()
        {
           
            Session.RemoveAll();
            var obj = new LoginModel();
            obj.SRCCaptcha = GetgenerateCaptcha();
            return View("Login",obj );
        }
        [HttpPost]
        public ActionResult Login(FormCollection frm, string btn)
        {
            LoginModel obj = new LoginModel(frm, (string)Session["captchaText"]);
            Session.RemoveAll();
            if (btn == "LOGIN")
            {
                if (obj.CheckValidate())
                {
                    EmoNetUtility.DeleteFiels_Al(frm["txtUserName"], frm["txtPassword"], Server);
                    DeleteExpireTemp();
                    Response.Redirect(obj.Login());
                    return null;
                }

            }
            else if (btn == "FORGOTPASSWORD")
            {
                if (obj.CheckValidateEmail())
                    obj.ChangePassword();
            }
            obj.SRCCaptcha = GetgenerateCaptcha();
            return View("Login", obj);
        }
        private void DeleteExpireTemp()
        {
            DBDataContext dc = new DBDataContext();
            var q = from p in dc.Temps.ToList()
                    where
                    p.DateTimeSabt == null
                    ||
                    DateTime.Now.Subtract(p.DateTimeSabt.Value).TotalMinutes > 60
                    select p;

            foreach (var p in q)
            {
                try
                {
                    string path = Server.MapPath(p.src);
                    if (System.IO.File.Exists(path))
                    {
                        System.IO.File.Delete(path);
                    }
                    dc.Temps.DeleteOnSubmit(p);
                }
                catch { }
            }
            dc.SubmitChanges();
        }


    }
}