﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.CPaymentResult
{
    public class CPaymentResultController : CMasterPaymentResultController
    {
        // GET: CPaymentResult
        public ActionResult PaymentResult()
        {
            C_PaymentResultModel obj = new C_PaymentResultModel(CurrentUser, "C_PAYMENTRESULT", "PaymentResult", "CPaymentResult", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.SetFreePayment();
            dc = new Models.Access.DBDataContext();
            CurrentUser = dc.users.SingleOrDefault(s => s.UID == CurrentUser.UID);
            obj.LoadValueOfMaster(CurrentUser);
            return View("PaymentResult", obj);
        }
        [HttpPost]
        public ActionResult PaymentResult(FormCollection frm, string btn)
        {
            C_PaymentResultModel obj = new C_PaymentResultModel(frm, CurrentUser, "C_PAYMENTRESULT", "PaymentResult", "CPaymentResult", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAFHEASLI")
            {
               return GoToPage("MainPage", "CMainPage");
                
            }

     
            obj.SetFreePayment();
            CurrentUser = dc.users.SingleOrDefault(s => s.UID == CurrentUser.UID);
            obj.LoadValueOfMaster(CurrentUser);
            return View("PaymentResult", obj);
        }
    }
}