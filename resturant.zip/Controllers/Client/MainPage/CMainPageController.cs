﻿using restauran.Models;
using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Controllers.Client.MainPage
{
    public class CMainPageController : CMasterController
    {
       
        public FileResult DownloadFileLottory(string imageurl)
        {
            var FileVirtualPath = imageurl;
            return File(FileVirtualPath, "application/force-download", Path.GetFileName(imageurl));
        }
        // GET: CMainPage
        public ActionResult MainPage()
        {
            C_MainPageModel obj = new C_MainPageModel(CurrentUser, "C_MAINPAGE", "MainPage", "CMainPage", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("MainPage", obj);
        }
        [HttpPost]
        public ActionResult MainPage(FormCollection frm, string btn)
        {
            C_MainPageModel obj = new C_MainPageModel(frm, CurrentUser, "C_MAINPAGE", "MainPage", "CMainPage", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SEARCH")
            {
                return GoToPage("Search", "CSearch", obj.GetSearchParametrAsID());
            }
            return View("MainPage", obj);
        }
    }
}