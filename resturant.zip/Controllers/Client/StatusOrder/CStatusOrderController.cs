﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.StatusOrder
{
    public class CStatusOrderController : CMasterController
    {
        // GET: CStatusOrder
        private C_DaryaftNashodeModel SetOldParametrDaryaftnashode()
        {
            C_DaryaftNashodeModel obj = new C_DaryaftNashodeModel(CurrentUser, "C_DARYAFTNASHODE", "DaryaftNashode", "CStatusOrder", RouteData, CurrentSabadKharidID);
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void SearchDaryaftNashode(C_DaryaftNashodeModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult DaryaftNashode()
        {
            C_DaryaftNashodeModel obj = SetOldParametrDaryaftnashode();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            SearchDaryaftNashode(obj);
            return View("DaryaftNashode", obj);
        }
        [HttpPost]
        public ActionResult DaryaftNashode(FormCollection frm, string btn)
        {
            C_DaryaftNashodeModel obj = new C_DaryaftNashodeModel(CurrentUser, "C_DARYAFTNASHODE", "DaryaftNashode", "CStatusOrder", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            SearchDaryaftNashode(obj);
            return View("DaryaftNashode", obj);
        }



        private C_DaryaftshodeModel SetOldParametrDaryaftshode()
        {
            C_DaryaftshodeModel obj = new C_DaryaftshodeModel(CurrentUser, "C_DARYAFTSHODE", "Daryaftshode", "CStatusOrder", RouteData, CurrentSabadKharidID);
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtOnvan = FieldtxtOnvan;
                    obj.hfContent = Fieldhfvalue;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void SearchDaryaftshode(C_DaryaftshodeModel obj)
        {
            FieldtxtOnvan = obj.txtOnvan.Trim();
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        public ActionResult DaryaftShode()
        {
            C_DaryaftshodeModel obj = SetOldParametrDaryaftshode();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            SearchDaryaftshode(obj);
            return View("DaryaftShode", obj);
        }
        [HttpPost]
        public ActionResult DaryaftShode(FormCollection frm, string btn)
        {
            C_DaryaftshodeModel obj = new C_DaryaftshodeModel(CurrentUser, "C_DARYAFTSHODE", "Daryaftshode", "CStatusOrder", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            SearchDaryaftshode(obj);
            return View("DaryaftShode", obj);
        }
    }
}