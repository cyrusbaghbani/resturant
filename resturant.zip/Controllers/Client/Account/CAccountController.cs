﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Account
{
    public class CAccountController : CMasterController
    {
        // GET: CAccount
        public ActionResult TurnOvers()
        {
            C_TurnOversModel obj = new C_TurnOversModel(CurrentUser, "C_TURNOVERS", "TurnOvers", "CAccount", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("TurnOvers", obj);
        }
        [HttpPost]
        public ActionResult TurnOvers(FormCollection frm, string btn)
        {
            C_TurnOversModel obj = new C_TurnOversModel(frm, CurrentUser, "C_TURNOVERS", "TurnOvers", "CAccount", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("TurnOvers", obj);
        }
    }
}