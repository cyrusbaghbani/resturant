﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Pages;

namespace restauran.Controllers.Client.SabadKharid
{
    public class CSabadKharidController : CMasterController
    {
        // GET: CSabadKharid
        public ActionResult History()
        {
            C_HistoryModel obj = new C_HistoryModel(CurrentUser, "C_HISTORY", "History", "CSabadKharid", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("History", obj);
        }
        [HttpPost]
        public ActionResult History(FormCollection frm, string btn)
        {
            C_HistoryModel obj = new C_HistoryModel(frm, CurrentUser, "C_HISTORY", "History", "CSabadKharid", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("History", obj);
        }

        public ActionResult CurrentShoping()
        {
            C_CurrentShopingModel obj = new C_CurrentShopingModel(CurrentUser, "C_CURRENTSHOPING", "CurrentShoping", "CSabadKharid", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("CurrentShoping", obj);
        }
        [HttpPost]
        public ActionResult CurrentShoping(FormCollection frm, string btn)
        {
            C_CurrentShopingModel obj = new C_CurrentShopingModel(frm, CurrentUser, "C_CURRENTSHOPING", "CurrentShoping", "CSabadKharid", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            if (btn == "TAIEDNAHAIE")
            {
                if (obj.CheckValidate())
                {
                    obj.SabtCodeMoaref();
                    return GoToPage("Finish", "CPayment");
                }
            }

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("CurrentShoping", obj);
        }

    }
}