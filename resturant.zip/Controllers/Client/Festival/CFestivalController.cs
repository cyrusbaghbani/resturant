﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Festival
{
    public class CFestivalController : CMasterController
    {
        // GET: CFestival
        public ActionResult Publics()
        {
            C_FestivalPublicModel obj = new C_FestivalPublicModel(CurrentUser, "C_FESTIVALPUBLIC", "Publics", "CFestival", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.Search();
            return View("Publics", obj);
        }
        [HttpPost]
        public ActionResult Publics(FormCollection frm, string btn)
        {
            C_FestivalPublicModel obj = new C_FestivalPublicModel(frm, CurrentUser, "C_FESTIVALPUBLIC", "Publics", "CFestival", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("Publics", obj);
        }

        public ActionResult Privates()
        {
            C_FestivalPrivateModel obj = new C_FestivalPrivateModel(CurrentUser, "C_FESTIVALPRIVATE", "Privates", "CFestival", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("Privates", obj);
        }
        [HttpPost]
        public ActionResult Privates(FormCollection frm, string btn)
        {
            C_FestivalPrivateModel obj = new C_FestivalPrivateModel(frm, CurrentUser, "C_FESTIVALPRIVATE", "Privates", "CFestival", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("Privates", obj);
        }

        public ActionResult Specials()
        {
            C_FestivalSpecialModel obj = new C_FestivalSpecialModel(CurrentUser, "C_FESTIVALSPECIALS", "Specials", "CFestival", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("Specials", obj);
        }
        [HttpPost]
        public ActionResult Specials(FormCollection frm, string btn)
        {
            C_FestivalSpecialModel obj = new C_FestivalSpecialModel(frm, CurrentUser, "C_FESTIVALSPECIALS", "Specials", "CFestival", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm,Response);
            obj.Search();
            return View("Specials", obj);
        }
    }
}