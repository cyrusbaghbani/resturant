﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Notification
{
    public class CNotificationController : CMasterController
    {
        private C_NotificationModel SetOldParametr()
        {
            C_NotificationModel obj = new C_NotificationModel(CurrentUser, "CNotification", "Notifications", "CNotification", RouteData, CurrentSabadKharidID); ;
            string index = EmoNetUtility.GetQueryString("index", (string)RouteData.Values["id"]);
            if (!string.IsNullOrEmpty(index))
            {
                if (index == "old")
                {
                    obj.txtDateAz = FieldDATEAZ;
                    obj.txtDateTa = FieldDATETA;
                    obj.hfContent = Fieldhfvalue;
                    obj.cboRead = FieldCboProductType;
                    obj.GridPaging.pageIndex = OldPageIndex;
                }
            }
            return obj;
        }
        private void Search(C_NotificationModel obj)
        {
            FieldDATEAZ = obj.txtDateAz.Trim();
            FieldDATETA = obj.txtDateTa.Trim();
            FieldCboProductType = obj.cboRead;
            Fieldhfvalue = obj.hfContent.Trim();
            OldPageIndex = obj.GridPaging.pageIndex;
            obj.Search();
        }
        // GET: CNotification
        public ActionResult Notifications()
        {
            C_NotificationModel obj = SetOldParametr();
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            Search(obj);
            return View("Notifications", obj);
        }
        [HttpPost]
        public ActionResult Notifications(FormCollection frm, string btn)
        {
            C_NotificationModel obj = new C_NotificationModel(frm, CurrentUser, "CNotification", "Notifications", "CNotification", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow();
            }
            else if (btn == "EDIT")
            {
                obj.Read();
                return GoToPage("NotificationSpec", "CNotification", "id=" + obj.hf_SelectValueID);
            }

            Search(obj);
            return View("Notifications", obj);
        }

        // GET: NotificationSpec
        public ActionResult NotificationSpec()
        {
            C_NotificatioSpecModel obj = new C_NotificatioSpecModel(CurrentUser, "CNotification", "NotificationSpec", "CNotification", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("NotificationSpec", obj);
        }
        [HttpPost]
        public ActionResult NotificationSpec(FormCollection frm, string btn)
        {
            C_NotificatioSpecModel obj = new C_NotificatioSpecModel(CurrentUser, "CNotification", "NotificationSpec", "CNotification", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            else if (btn == "CANCEL")
            {

                return GoToPage("Notifications", "CNotification", "index=old");
            }


            return View("NotificationSpec", obj);
        }


    }
}