﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Search
{
    public class CSearchController : CMasterController
    {
        // GET: CSearch
        public ActionResult Search()
        {
            C_SearchModel obj = new C_SearchModel(CurrentUser, "C_SEARCH", "Search", "CSearch", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("Search", obj);
        }

        [HttpPost]
        public ActionResult Search(FormCollection frm, string btn)
        {
            C_SearchModel obj = new C_SearchModel(frm, CurrentUser, "C_SEARCH", "Search", "CSearch", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("Search", obj);
        }
    }
}