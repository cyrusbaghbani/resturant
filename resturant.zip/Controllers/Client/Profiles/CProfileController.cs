﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Profiles
{
    public class CProfileController : CMasterController
    {
        // GET: CProfile
        public ActionResult Profiles()
        {
            C_ProfileModel obj = new C_ProfileModel(CurrentUser, "C_PROFILES", "Profiles", "CProfile", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("Profiles", obj);
        }
        [HttpPost]
        public ActionResult Profiles(FormCollection frm, string btn)
        {
            C_ProfileModel obj = new C_ProfileModel(frm, CurrentUser, "C_PROFILES", "Profiles", "CProfile", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SEARCH")
            {
                return GoToPage("Search", "CSearch", obj.GetSearchParametrAsID());
            }
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save();
                    obj.FullName_Master = obj.txtName + " " + obj.txtFamily;
                }
            }
            return View("Profiles", obj);
        }


        // GET: ChangePassword
        public ActionResult ChangePassword()
        {
            C_ChangePasswordModel obj = new C_ChangePasswordModel(CurrentUser, "C_CHANGEPASSWORD", "ChangePassword", "CProfile", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            return View("ChangePassword", obj);
        }
        [HttpPost]
        public ActionResult ChangePassword(FormCollection frm, string btn)
        {
            C_ChangePasswordModel obj = new C_ChangePasswordModel(frm, CurrentUser, "C_CHANGEPASSWORD", "ChangePassword", "CProfile", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SEARCH")
            {
                return GoToPage("Search", "CSearch", obj.GetSearchParametrAsID());
            }
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                    obj.Save();
            }


            return View("ChangePassword", obj);
        }
    }
}