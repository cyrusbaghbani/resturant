﻿using restauran.Models.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Controllers.Client.Payment
{
    public class CPaymentController : CMasterController
    {
        // GET: CPayment
        public ActionResult Finish()
        {
            C_PaymentFinishModel obj = new C_PaymentFinishModel(CurrentUser, "C_FINISH", "Finish", "CPayment", RouteData, CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            obj.Search();
            return View("Finish", obj);
        }
        [HttpPost]
        public ActionResult Finish(FormCollection frm, string btn)
        {
            C_PaymentFinishModel obj = new C_PaymentFinishModel(frm, CurrentUser, "C_FINISH", "Finish", "CPayment", CurrentSabadKharidID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if(btn== "PAYFREE")
            {
                if(obj.CheckValidate())
                {
                    obj.Save();
                    return GoToPage("PaymentResult", "CPaymentResult");
                }
            }

            obj.CheckBtnPublic(frm, Response);
            obj.Search();
            return View("Finish", obj);
        }


    }
}