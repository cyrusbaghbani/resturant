﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace restauran.Models
{
    public class Banners
    {
        public bool isAdvertisment = false;
        public bool isLottory = false;
        public int? priority = null;
        public string Onvan = "";
        public string UrlImage = "";
        public string UrlImage800_600 = "";
        public string link = "";
    }
}