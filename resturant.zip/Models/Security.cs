﻿using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Security
{
    public bool Is_SHOW_Munu_TURNOVERS = false;
    public bool Is_SHOW_Munu_ADVERTISING = false;
    public bool Is_SHOW_Munu_M_BACKUP = false;
    public bool Is_SHOW_Munu_POST = false;
    public bool Is_SHOW_Munu_BRAND = false;
    public bool Is_SHOW_Munu_PRODUCTTYPE = false;
    public bool Is_SHOW_Munu_DISTRICTS = false;
    public bool Is_SHOW_Munu_UNITTYPE = false;
    public bool Is_SHOW_Munu_PRODUCTGROUPTYPE = false;
    public bool Is_SHOW_Munu_CUSTOMER = false;
    public bool Is_SHOW_Munu_FESTIVALPUBLIC = false;
    public bool Is_SHOW_Munu_FESTIVALPRIVETS = false;
    public bool Is_SHOW_Munu_LOTTERY = false;
    public bool Is_SHOW_Munu_NOTIFICATION = false;
    public bool Is_SHOW_Munu_PERSONEL = false;
    public bool Is_SHOW_Munu_PRODUCT = false;
    public bool Is_SHOW_Munu_PROFILES = false;
    public bool Is_SHOW_Munu_CHANGEPASSWORD = false;
    public bool Is_SHOW_Munu_MAINPAGE = false;
    public bool Is_SHOW_Munu_LOYALTY = false;
    public bool Is_SHOW_Munu_SHOPPING_BARRASINASHODE = false;
    public bool Is_SHOW_Munu_SHOPPING_TAHVILSHODE = false;
    public bool Is_SHOW_Munu_SHOPPING_DARHALTOZIEE = false;
    public bool Is_SHOW_Munu_SPECIAL = false;
  


    public bool Is_SHOW_Munu_SYSTEM_EVENTS = false;
    public bool Is_SHOW_Munu_SYSTEM_TRANSACTION = false;
    public bool Is_SHOW_Munu_SYSTEM_RESERVPRODUCTS = false;
    public bool Is_SHOW_Munu_SYSTEM_EDITSABADKHARID = false;

    public bool Is_SHOW_Munu_Reports = false;


    public bool IsEdit = false;
    public bool IsNew = false;
    public bool IsSave = false;
    public bool IsDelete = false;
    public bool IsDisplay = false;
    public bool Is_ShowForVisitor =true;
    public bool IsAllowToSendMsg = false;
    public int RoleId = -1;
    public Security(user currentuser, string PageName)
    {

        SetMenu(currentuser);
        SetPageAccess(currentuser, PageName);

    }

    private void SetMenu(user currentuser)
    {
        if (currentuser == null || currentuser.IsActive == false || currentuser.IsDeleted == true)
            return;
        RoleId = currentuser.RoleId;

        Is_SHOW_Munu_TURNOVERS = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;
        Is_SHOW_Munu_ADVERTISING = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId;
        Is_SHOW_Munu_M_BACKUP = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;

        Is_SHOW_Munu_POST = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_BRAND = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_PRODUCTTYPE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_DISTRICTS = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_UNITTYPE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_PRODUCTGROUPTYPE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;

        Is_SHOW_Munu_CUSTOMER = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId || RoleId == RoleIds.M_Visitor;
        Is_SHOW_Munu_FESTIVALPUBLIC = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;
        Is_SHOW_Munu_FESTIVALPRIVETS = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;
        Is_SHOW_Munu_LOTTERY = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;
        Is_SHOW_Munu_NOTIFICATION = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande; ;
        Is_SHOW_Munu_PERSONEL = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId;
        Is_SHOW_Munu_PRODUCT = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;

        Is_SHOW_Munu_PROFILES = true;
        Is_SHOW_Munu_CHANGEPASSWORD = true;
        Is_SHOW_Munu_MAINPAGE = true;

        Is_SHOW_Munu_LOYALTY = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;
        Is_SHOW_Munu_SHOPPING_BARRASINASHODE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId || RoleIds.M_Visitor == RoleId;
        Is_SHOW_Munu_SHOPPING_TAHVILSHODE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId || RoleIds.M_Visitor == RoleId || RoleIds.M_ToziKonande == RoleId;
        Is_SHOW_Munu_SHOPPING_DARHALTOZIEE = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId || RoleIds.M_Visitor == RoleId || RoleIds.M_ToziKonande == RoleId;
        Is_SHOW_Munu_SPECIAL = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId;

        Is_SHOW_Munu_SYSTEM_EVENTS = RoleIds.M_Administrator == RoleId;
        Is_SHOW_Munu_SYSTEM_TRANSACTION = RoleIds.M_Administrator == RoleId;
        Is_SHOW_Munu_SYSTEM_RESERVPRODUCTS = RoleIds.M_Administrator == RoleId;
        Is_SHOW_Munu_SYSTEM_EDITSABADKHARID = RoleIds.M_Administrator == RoleId;

        Is_SHOW_Munu_Reports = RoleIds.M_Administrator == RoleId || RoleIds.M_AdminWebSiteIds == RoleId || RoleIds.M_OPERATOR_2 == RoleId || RoleIds.M_OPERATOR_1 == RoleId ;
     
    }

    private void SetPageAccess(user currentuser, string pageName)
    {
        if (currentuser == null || currentuser.IsActive == false || currentuser.IsDeleted == true)
            return;
        pageName = pageName == null ? "" : pageName.ToUpper();

        Is_ShowForVisitor = true;

        if (RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator)
        {
            IsDisplay = RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator;
            IsEdit = RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator;
            IsSave = RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator;
            IsDelete = RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator;
            IsNew = RoleId == RoleIds.C_MoshtariIds || RoleId == RoleIds.C_Administrator;
        }

        if (pageName == "TURNOVERS")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }

        else if (pageName == "FACTORREPORTS_M")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
        }
        else if (pageName == "ORDERREPORTS_M")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 ;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 ;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 ;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1  ;
        }
        
        else if (pageName == "ADVERTISING" || pageName == "ADVERTISINGSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
        }
        else if (pageName == "M_BACKUP")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
        //اطلاعات پایه
        else if (pageName == "POST" || pageName == "BRAND" || pageName == "PRODUCTTYPE" || pageName == "UNITTYPE"
            || pageName == "DISTRICTS" || pageName == "PRODUCTGROUPTYPESPEC" | pageName == "PRODUCTGROUPTYPE")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
        }
        //اطلاعات سیستمی
        else if (pageName == "EVENTS" || pageName == "TRANSACTIONS" || pageName == "RESERVE_PRODUCTS" || pageName == "EDIT_SABADKHARID")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator;
            IsEdit = RoleId == RoleIds.M_Administrator;
            IsSave = RoleId == RoleIds.M_Administrator;
            IsDelete = RoleId == RoleIds.M_Administrator;
            IsNew = RoleId == RoleIds.M_Administrator;
        }
        else if (pageName == "CUSTOMERSPEC" || pageName == "CUSTOMER")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            if (pageName == "CUSTOMERSPEC")
                Is_ShowForVisitor = (RoleId != RoleIds.M_Visitor);
        }
        else if (pageName == "FESTIVALPUBLIC" || pageName == "FESTIVALPUBLICSPEC"
            || pageName == "FESTIVALPRIVETS" || pageName == "FESTIVALPRIVATESPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
        else if (pageName == "LOTTERY" || pageName == "LOTTERYSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
        else if (pageName == "NOTIFICATION" || pageName == "NOTIFICATIONSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
            IsAllowToSendMsg= IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2;
        }
        else if (pageName == "PERSONELSPEC" || pageName == "PERSONEL")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds ;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1;
        }
        else if (pageName == "PRODUCT" || pageName == "PRODUCTSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
        else if (pageName == "PROFILES" || pageName == "CHANGEPASSWORD" || pageName == "MAINPAGE")
        {
            IsDisplay = true;
            IsEdit = true;
            IsSave = true;
            IsDelete = true;
            IsNew = true;
        }
        else if (pageName == "LOYALTY" || pageName == "LOYALTYSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
        else if (pageName == "SHOPPING_BARRASINASHODE")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 ;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor;
        }
        else if (pageName == "SHOPPING_TAHVILSHODE"
            || pageName == "SHOPPING_DARHALTOZIEE")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds || RoleId == RoleIds.M_OPERATOR_2 || RoleId == RoleIds.M_OPERATOR_1 || RoleId == RoleIds.M_Visitor || RoleId == RoleIds.M_ToziKonande;
        }
        else if (pageName == "SPECIAL" || pageName == "SPECIALSPEC")
        {
            IsDisplay = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsEdit = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsSave = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsDelete = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
            IsNew = RoleId == RoleIds.M_Administrator || RoleId == RoleIds.M_AdminWebSiteIds;
        }
    }
}
