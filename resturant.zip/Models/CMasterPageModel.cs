﻿using App_Start.Utility;
using Models.Controll;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Utility;

namespace restauran.Models
{
    public class CMasterPageModel
    {
        protected DBDataContext dc;
        protected user CurrentUser;
        public Messaging DisplayMessage;
        public Security security;
        public string FullName_Master;
        public string TodayDate_Master;
        public string LotteryPath = "/Attachment/Lottary/";
        public string LotteryImagePath = "/Attachment/Lottary/Lottory.jpg";
        public string LotteryImagePath800_600 = "/Attachment/Lottary/Lottory800_600.jpg";

        protected string AdvertisingPath = "/Attachment/Advertising/";
        public string Action = "";
        public string Controll = "";
        public string hf_id_delete_sabadkharid_topmenuItem = "";


        public string cboMoratabSazi = "";
        public string cboBrandSearch = "";
        public string cboProductGroupSearch = "";
        public List<Brand> lstBrandSearch = new List<Brand>();
        public List<ProductType> lstProductTypeSearch = new List<ProductType>();


        public decimal MablaghEtebarAsl = 0;
        public decimal MablaghEtebarHadie_AllMonth = 0;
        public decimal MablaghEtebarHadie_EndMonth = 0;
        public decimal MablaghKolEtebarkarbar = 0;

        public int FestivalOmomiCount = 0;
        public int FestivalEkhtesasiCount = 0;
        public int FestivalSpecialCount = 0;

        public int TedadKharidTahvilNashode = 0;

        public Guid CurrentSabadKharidID = Guid.Empty;
        public int CurrentSabadKharidItems = 0;
        public decimal CurrentSabadKharidPrice = 0;
        public List<SabadKharidItem> lstSabadKharid = new List<SabadKharidItem>();

        public List<CCheckbox> lstLottory = new List<CCheckbox>();

        public void Intialize(user currentUser, string pageNum, Guid CurrentSabadKharidID_, RouteData routeData)
        {
            security = new Security(currentUser, pageNum);
            DisplayMessage = new Messaging();
            CurrentUser = currentUser;
            CurrentSabadKharidID = CurrentSabadKharidID_;
            LoadValueOfMaster(currentUser);


            string brandsearch = EmoNetUtility.GetQueryString("brandsearch", (string)routeData.Values["id"]);
            string productsearch = EmoNetUtility.GetQueryString("productsearch", (string)routeData.Values["id"]);
            cboMoratabSazi = EmoNetUtility.GetQueryString("moratabsazi", (string)routeData.Values["id"]);

            cboBrandSearch = brandsearch;
            cboProductGroupSearch = productsearch;
        }
        public void Intialize(user currentUser, string pageNum, Guid CurrentSabadKharidID_, FormCollection frm)
        {
            security = new Security(currentUser, pageNum);
            DisplayMessage = new Messaging();
            CurrentUser = currentUser;
            CurrentSabadKharidID = CurrentSabadKharidID_;

            LoadValueOfMaster(currentUser);


            cboBrandSearch = Utility.EncryptedQueryString.Decrypt(frm["cboBrandSearch"] == null ? "" : frm["cboBrandSearch"].Trim());
            cboProductGroupSearch = Utility.EncryptedQueryString.Decrypt(frm["cboProductGroupSearch"] == null ? "" : frm["cboProductGroupSearch"].Trim());
            cboMoratabSazi = frm["cboMoratabSazi"].Trim();
            hf_id_delete_sabadkharid_topmenuItem = Utility.EncryptedQueryString.Decrypt(frm["hf_id_delete_sabadkharid_topmenuItem"] == null ? "" : frm["hf_id_delete_sabadkharid_topmenuItem"].Trim());
        }

        private void BindCambo()
        {
            lstBrandSearch = dc.Brands.Where(s => s.IsDeleted == false).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstBrandSearch.Insert(0, new Brand() { Id = -1, Name = "همه ی برند ها" });

            lstProductTypeSearch = dc.ProductTypes.Where(s => s.IsDeleted == false && s.ParentId == null).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lstProductTypeSearch.Insert(0, new ProductType() { Id = -1, Name = "همه ی گروه های کالا" });
        }
        public void LoadValueOfMaster(user currentUser)
        {
            dc = new DBDataContext();
            if (currentUser != null)
            {
                FullName_Master = currentUser.FullName;
                MablaghEtebarAsl = currentUser.MablaghAccountKol;
                MablaghEtebarHadie_AllMonth = currentUser.MablaghGiftsKol;
                MablaghEtebarHadie_EndMonth = currentUser.MablaghGifts_EndMonth_KOL;

                string Datetimstring_ = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
                if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring_) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring_) >= 0))
                    MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol + CurrentUser.MablaghGifts_EndMonth_KOL;
                else
                    MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol;
            }
            TodayDate_Master = DateShamsi.GetCurrentDate();





            SabadKharidBind();
            LottoryBind();
            BindCambo();
            FestivalCalculate();
            SabadKharidTahvilDadeNashode();
        }

        private void SabadKharidBind()
        {
            lstSabadKharid = dc.SabadKharidItems.Where(s => s.SabadKharidID == CurrentSabadKharidID && s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false).ToList();

            CurrentSabadKharidItems = lstSabadKharid.Count();
            CurrentSabadKharidPrice = lstSabadKharid.Any() ? (lstSabadKharid.Sum(s => s.PriceVahed * s.Count)) : 0;
        }

        private void FestivalCalculate()
        {
            string curentdatetime = DateShamsi.GetMixShamsiDateTimeString(TodayDate_Master, DateShamsi.GetCurrentHour().Substring(0, 5));
            dc = new DBDataContext();
            var q = (from p in dc.Prices
                     where
                     p.IsPriceAsli == false
                     &&
                     p.Product.IsShowInSite == true
                     &&
                     p.Product.IsDeleted == false
                     &&
                     p.IsDeleted == false
                     &&
                     p.MojodiProduct != null

                     &&
                     p.DatetimeShoro_Persian.CompareTo(curentdatetime) <= 0 && p.DatetimePayan_Persian.CompareTo(curentdatetime) >= 0
                     &&
                     (
                       ((p.IsTakhfifOmomi == true || p.IsDarhalEngheza == true) && (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0))
                       ||
                       (p.IsTakhfifEkhtesasi == true && p.USER_PRICEs.Any(s => s.UserID == CurrentUser.UID) && (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0))
                     )

                     select p);

            FestivalOmomiCount = q.Any() ? q.Count(s => s.IsTakhfifOmomi == true) : 0;
            FestivalEkhtesasiCount = q.Any() ? q.Count(s => s.IsTakhfifEkhtesasi == true) : 0;
            FestivalSpecialCount = q.Any() ? q.Count(s => s.IsDarhalEngheza == true) : 0;

        }

        private void LottoryBind()
        {
            lstLottory = dc.Lotteries.OrderByDescending(s => s.DateShoro).Take(5).Select(a => new CCheckbox { Name = a.DateShoro, url = a.url }).ToList();
        }

        private void SabadKharidTahvilDadeNashode()
        {
            var lst = dc.SabadKharids.Where(s => s.IsKharid == true && s.IsDeleted == false && s.IsTahvilBeMoshtari == false && s.UserMoshtariID == CurrentUser.UID);
            TedadKharidTahvilNashode = lst.Any() ? lst.Count() : 0;
        }

        public string GetSearchParametrAsID()
        {
            return "brandsearch=" + cboBrandSearch + "&" + "productsearch=" + cboProductGroupSearch + "&" + "moratabsazi=" + cboMoratabSazi;
        }

        public void SaveInSabadKharidAndCheckValidate(FormCollection frm)
        {
            string hfproductSefareshID = (frm["hfproductSefareshID"] == null ? "" : frm["hfproductSefareshID"].ToString().Trim());
            FunctionMojodi.SETMOJODI(hfproductSefareshID);
            dc = new Models.Access.DBDataContext();

            bool ResultHasSecsess = false;
            bool ResultHasError = false;
            List<int> lstroleIds = new List<int> { RoleIds.M_Administrator, RoleIds.M_AdminWebSiteIds };
            List<CCheckbox> lstmsg = new List<CCheckbox>();

            ///// سبد خرید را درست می کنیم
            ///// اگر وجود نداشت ایجاد کرده و اگر وجود داشت ویرایش می کنیم
            ///// 
            var sabadkharid = dc.SabadKharids.SingleOrDefault(s => s.UID == CurrentSabadKharidID && s.IsDeleted == false && s.IsKharid == false);
            if (sabadkharid == null)
            {
                ///پیدا کردن آخرین سبد خرید
                sabadkharid = dc.SabadKharids.Where(s => s.IsDeleted == false && s.IsKharid == false && s.UserMoshtariID == CurrentUser.UID).OrderByDescending(s => s.DateTimeAkharinTaghirat).FirstOrDefault();
            }
            if (sabadkharid == null)
            {
                sabadkharid = new SabadKharid();
                sabadkharid.UID = Guid.NewGuid();
                sabadkharid.CodeRahgiri = EmoNetUtility.GetCodeRahgiriSabadKharid();
                sabadkharid.IsDeleted = false;
                sabadkharid.IsKharid = false;
                sabadkharid.UserMoshtariID = CurrentUser.UID;
                sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
                CurrentSabadKharidID = sabadkharid.UID;

                dc.SabadKharids.InsertOnSubmit(sabadkharid);
            }
            dc.SubmitChanges();



            System.Web.HttpContext.Current.Session["CurrentSabadKharidID"] = CurrentSabadKharidID = sabadkharid.UID;


            ///بررسی شود محصول وجود دارد یا نه 

            var prod = dc.Products.SingleOrDefault(s => s.UID.ToString() == hfproductSefareshID);

            if (prod == null)
            {
                DisplayMessage.ShowErrorMessage("لطفا به نکات زیر توجه نمایید" + "</br>" + "1 - " + "کالای انتخاب شده یافت نشد." + "</br>");
                return;
            }


            string ProductFullName = (prod.ProductType.Parent.IsShowName ? prod.ProductType.Parent.Name : "") + " " + prod.ProductType.Name + " " + prod.Brand.Name;

            string CurrentDateTime = DateShamsi.GetMixShamsiDateTimeString(TodayDate_Master, DateShamsi.GetCurrentHour().Substring(0, 5));
            var LstPrices = dc.Prices.Where(s => s.ProductId == prod.UID && s.IsDeleted == false
                             &&
                                (
                                    (
                                        s.IsPriceAsli == true
                                        &&
                                        s.DateShoro != null && s.DateShoro.Trim() != "" && s.DateShoro.CompareTo(TodayDate_Master) <= 0
                                        &&
                                        (s.DatePayan == null || s.DatePayan.Trim() == "" || s.DatePayan.CompareTo(TodayDate_Master) >= 0)
                                    )
                                    ||
                                    (
                                        (s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.Trim() != "" && s.DatetimeShoro_Persian.CompareTo(CurrentDateTime) <= 0
                                        &&
                                        (s.DatetimePayan_Persian.Trim() != "" && s.DatetimePayan_Persian.CompareTo(CurrentDateTime) >= 0)
                                        &&
                                        (
                                          (s.IsTakhfifOmomi == true || s.IsDarhalEngheza == true) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0))
                                          ||
                                          (s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID) && (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0))
                                        )
                                    //(s.IsTakhfifEkhtesasi == true || s.IsDarhalEngheza == true || s.IsTakhfifOmomi == true)
                                    //&&
                                    //s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.Trim() != "" && s.DatetimeShoro_Persian.CompareTo(CurrentDateTime) <= 0
                                    //&&
                                    //(s.DatetimePayan_Persian.Trim() != "" && s.DatetimePayan_Persian.CompareTo(CurrentDateTime) >= 0)
                                    )
                                )
                             );

            string txtPRIVATE = frm["txtPRIVATE"] == null ? null : frm["txtPRIVATE"].ToString().Trim();
            string txtPUBLIC = frm["txtPUBLIC"] == null ? null : frm["txtPUBLIC"].ToString().Trim();
            string txtSPECIAL = frm["txtSPECIAL"] == null ? null : frm["txtSPECIAL"].ToString().Trim();
            string txtASLI = frm["txtASLI"] == null ? null : frm["txtASLI"].ToString().Trim();


            decimal? tedadreservhayKol = 0;
            if (txtPRIVATE != null || txtPUBLIC != null || txtASLI != null)
                tedadreservhayKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(prod.UID);
            tedadreservhayKol = tedadreservhayKol == null ? 0 : tedadreservhayKol;


            #region بررسی و ثبت جشنواره اختصاصی

            if (txtPRIVATE != null)
            {

                decimal PrivateValue = 0;
                if (!decimal.TryParse("0" + txtPRIVATE, out PrivateValue))
                {

                    string msg = "مقدار وارد شده برای جشنواره اختصاصی کالای \"" + ProductFullName + "\" صحیح نمی باشد.";
                    lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                    ResultHasError = true;
                }
                else
                {
                    var privateold = sabadkharid.SabadKharidItems.FirstOrDefault(s => s.ProductId == prod.UID && s.Price.IsTakhfifEkhtesasi == true);


                    if (PrivateValue == 0)
                    {
                        if (privateold != null)
                        {
                            tedadreservhayKol += tedadreservhayKol - privateold.Count;
                            dc.SabadKharidItems.DeleteOnSubmit(privateold);
                            dc.SubmitChanges();
                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی از سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " \"" + privateold.Count + " " + prod.Unit.Name + "\" حذف گردید.", EventTypeIds.DELETE, "SEARCH", CurrentUser.UID);
                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی از سبد خرید " + " حذف گردید." });
                            ResultHasSecsess = true;
                        }
                    }
                    else
                    {
                        ///بررسی میکنیم مقدار وارد شده در انبار وجوددارد یا نه در صورتی که وجود داشت و ما نیز اجازه خرید 
                        ///داشتیم که ان را رزرومی کنیم در غیر این صورت پیام خطا داده می شود که انقدر در انبار نمی باش
                        ///ولی در صورتی که در انبار اصلی موجود نباشد و ما موجودی نداشته باشیم یک نوتی فکیشن به مدیریت ارسال می شود
                        ///
                        var ekhtesasiPrice = LstPrices.Where(s => s.IsTakhfifEkhtesasi == true && s.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID)).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                        if (ekhtesasiPrice != null)
                        {
                            ////خریدهای اختصاصی رزرو و ثبت شده توسط این کاربر
                            var sabadkharidItems = ekhtesasiPrice.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID);
                            //// تعداد خریداری شده از این کالا توسط این کاربر
                            decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                            ////تعدادی که کاربر اجازه خرید دارد 
                            decimal TedadiKMitavanKharid = (decimal)ekhtesasiPrice.MojodiProduct - TedadKharid;


                            if (TedadiKMitavanKharid > 0)
                            {
                                /// تعداد درخواست داده شده از کالاهایی که می توانم بخریم بیشتر است
                                if (TedadiKMitavanKharid < PrivateValue)
                                {
                                    string msg = "مقدار وارد شده برای جشنواره اختصاصی کالای \"" + ProductFullName + "\" از موجودی بیشتر می باشد.";
                                    lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                    ResultHasError = true;
                                }
                                else
                                {
                                    decimal anbar_jari = ekhtesasiPrice.Product.MojodiCount - ((decimal)tedadreservhayKol - (privateold == null ? 0 : privateold.Count) + PrivateValue);


                                    if (anbar_jari < 0)
                                    {
                                        string msg = "این مقدار کالای \"" + ProductFullName + "\" موجود نمی باشد.";
                                        lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                        EmoNetUtility.SendNotification(lstroleIds,null, "موجودی کالای \"" + ProductFullName + "\" به اتمام رسیده است، ولی کاربر با نام " + CurrentUser.FullName + " در جشنواره اختصاصی خود اجازه خرید این محصول را دارد.", NotificationTypeIDs.MojodiAnbar);
                                        ResultHasError = true;
                                    }

                                    else
                                    {
                                        if (privateold == null)
                                        {
                                            privateold = new SabadKharidItem();
                                            privateold.UID = Guid.NewGuid();
                                            privateold.Count = PrivateValue;
                                            privateold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                            privateold.DateTimeSabt = DateTime.Now;
                                            privateold.Product = prod;
                                            privateold.PriceID = ekhtesasiPrice.UID;
                                            privateold.PriceVahed = ekhtesasiPrice.Price_;
                                            privateold.SabadKharidID = sabadkharid.UID;
                                            privateold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                            privateold.UserAddKonandeID = CurrentUser.UID;
                                            sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
                                            dc.SabadKharidItems.InsertOnSubmit(privateold);
                                            dc.SubmitChanges();
                                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PrivateValue + " " + prod.Unit.Name + "\" .(رزرو شد)درج گردید.", EventTypeIds.SAVE, "SEARCH", CurrentUser.UID);
                                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی در سبد خرید " + " ثبت گردید." });
                                            ResultHasSecsess = true;
                                            tedadreservhayKol += tedadreservhayKol + PrivateValue;
                                        }
                                        else
                                        {
                                            privateold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                            privateold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                            privateold.DateTimeSabt = DateTime.Now;
                                            privateold.PriceID = ekhtesasiPrice.UID;
                                            privateold.PriceVahed = ekhtesasiPrice.Price_;
                                            tedadreservhayKol += tedadreservhayKol - privateold.Count + PrivateValue;
                                            if (privateold.Count != PrivateValue)
                                            {
                                                decimal old = privateold.Count;
                                                privateold.UserAddKonandeID = CurrentUser.UID;
                                                privateold.Count = PrivateValue;
                                                dc.SubmitChanges();
                                                EventLog.Loging("مقدار کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PrivateValue + " " + prod.Unit.Name + "\" [مقدار قدیم : \"" + old + "\"] .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);
                                                lstmsg.Add(new CCheckbox { Value = "true", Name = "مقدار کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی در سبد خرید " + " ثبت گردید." });
                                                ResultHasSecsess = true;
                                            }
                                            else
                                            {

                                                dc.SubmitChanges();
                                                EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره اختصاصی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PrivateValue + " " + prod.Unit.Name + "\" .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);

                                            }
                                        }

                                    }
                                }
                            }
                            else
                            {
                                ///درصورتی که کاربر به اندازه کافی خریده است ولی دوباره به این قسمت امده است
                                ///فعلا پیغام خاصی نمی دهیم

                            }

                        }
                        ///در سبد خرید من چیزی وجود دارد یا نه

                    }
                }


            }
            #endregion

            #region بررسی و ثبت جشنواره عمومی

            if (txtPUBLIC != null)
            {

                decimal PublicValue = 0;
                if (!decimal.TryParse("0" + txtPUBLIC, out PublicValue))
                {

                    string msg = "مقدار وارد شده برای جشنواره عمومی کالای \"" + ProductFullName + "\" صحیح نمی باشد.";
                    lstmsg.Add(new CCheckbox
                    {
                        Value = "false",
                        Name = msg
                    });
                    ResultHasError = true;
                }
                else
                {
                    var Publicold = sabadkharid.SabadKharidItems.FirstOrDefault(s => s.ProductId == prod.UID && s.Price.IsTakhfifOmomi == true);


                    if (PublicValue == 0)
                    {
                        if (Publicold != null)
                        {
                            tedadreservhayKol += tedadreservhayKol - Publicold.Count;
                            dc.SabadKharidItems.DeleteOnSubmit(Publicold);
                            dc.SubmitChanges();
                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی از سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + Publicold.Count + " " + prod.Unit.Name + "\" حذف گردید.", EventTypeIds.DELETE, "SEARCH", CurrentUser.UID);
                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای " + ProductFullName + "مربوط به جشنواره عمومی از سبد خرید " + " حذف گردید." });
                            ResultHasSecsess = true;
                        }
                    }
                    else
                    {
                        ///بررسی میکنیم مقدار وارد شده در انبار وجوددارد یا نه در صورتی که وجود داشت و ما نیز اجازه خرید 
                        ///داشتیم که ان را رزرومی کنیم در غیر این صورت پیام خطا داده می شود که انقدر در انبار نمی باش
                        ///ولی در صورتی که در انبار اصلی موجود نباشد و ما موجودی نداشته باشیم یک نوتی فکیشن به مدیریت ارسال می شود
                        ///
                        var omomiPrice = LstPrices.Where(s => s.IsTakhfifOmomi == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                        if (omomiPrice != null)
                        {
                            ////خریدهای عمومی رزرو و ثبت شده 
                            var sabadkharidItems = omomiPrice.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                            //// تعداد خریداری شده از این کالا 
                            decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                            ////تعدادی که کاربر اجازه خرید دارد 
                            decimal TedadiKMitavanKharid = (decimal)omomiPrice.MojodiProduct - TedadKharid;


                            if (TedadiKMitavanKharid > 0)
                            {
                                /// تعداد درخواست داده شده از کالاهایی که می توانم بخریم بیشتر است
                                if (TedadiKMitavanKharid < PublicValue)
                                {
                                    string msg = "مقدار وارد شده برای جشنواره عمومی کالای \"" + ProductFullName + "\" از موجودی بیشتر می باشد.";
                                    lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                    ResultHasError = true;
                                }
                                else
                                {
                                    decimal anbar_jari = omomiPrice.Product.MojodiCount - ((decimal)tedadreservhayKol - (Publicold == null ? 0 : Publicold.Count) + PublicValue);


                                    if (anbar_jari < 0)
                                    {
                                        string msg = "این مقدار از کالای \"" + ProductFullName + "\" موجود نمی باشد.";
                                        lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                        EmoNetUtility.SendNotification(lstroleIds, null, "موجودی کالای \"" + ProductFullName + "\" به اتمام رسیده است، ولی کاربر با نام " + CurrentUser.FullName + " در جشنواره عمومی خود درخواست خرید کالا را دارد.", NotificationTypeIDs.MojodiAnbar);
                                        ResultHasError = true;
                                    }


                                    else
                                    {
                                        if (Publicold == null)
                                        {
                                            Publicold = new SabadKharidItem();
                                            Publicold.UID = Guid.NewGuid();
                                            Publicold.Count = PublicValue;
                                            Publicold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                            Publicold.DateTimeSabt = DateTime.Now;
                                            Publicold.Product = prod;
                                            Publicold.PriceID = omomiPrice.UID;
                                            Publicold.PriceVahed = omomiPrice.Price_;
                                            Publicold.SabadKharidID = sabadkharid.UID;
                                            Publicold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                            Publicold.UserAddKonandeID = CurrentUser.UID;
                                            sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;

                                            dc.SabadKharidItems.InsertOnSubmit(Publicold);
                                            dc.SubmitChanges();
                                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PublicValue + " " + prod.Unit.Name + "\" .(رزرو شد)درج گردید.", EventTypeIds.SAVE, "SEARCH", CurrentUser.UID);
                                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی در سبد خرید " + " ثبت گردید." });
                                            ResultHasSecsess = true;
                                            tedadreservhayKol += tedadreservhayKol + PublicValue;
                                        }
                                        else
                                        {
                                            Publicold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                            Publicold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                            Publicold.DateTimeSabt = DateTime.Now;
                                            Publicold.PriceID = omomiPrice.UID;
                                            Publicold.PriceVahed = omomiPrice.Price_;
                                            tedadreservhayKol += tedadreservhayKol - Publicold.Count + PublicValue;
                                            if (Publicold.Count != PublicValue)
                                            {
                                                decimal old = Publicold.Count;
                                                Publicold.UserAddKonandeID = CurrentUser.UID;
                                                Publicold.Count = PublicValue;
                                                dc.SubmitChanges();
                                                EventLog.Loging("مقدار کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PublicValue + " " + prod.Unit.Name + "\" [مقدار قدیم : \"" + old + "\"] .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);
                                                lstmsg.Add(new CCheckbox { Value = "true", Name = "مقدار کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی در سبد خرید " + " ثبت گردید." });
                                                ResultHasSecsess = true;
                                            }
                                            else
                                            {

                                                dc.SubmitChanges();
                                                EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به جشنواره عمومی در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + PublicValue + " " + prod.Unit.Name + "\" .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);

                                            }

                                        }
                                    }
                                }
                            }
                            else
                            {
                                ///درصورتی که کاربر به اندازه کافی خریده است ولی دوباره به این قسمت امده است
                                ///فعلا پیغام خاصی نمی دهیم

                            }

                        }
                        ///در سبد خرید من چیزی وجود دارد یا نه

                    }
                }


            }
            #endregion

            #region بررسی و ثبت فروش ویژه

            if (txtSPECIAL != null)
            {

                decimal SpecialValue = 0;
                if (!decimal.TryParse("0" + txtSPECIAL, out SpecialValue))
                {

                    string msg = "مقدار وارد شده برای فروش ویژه ی کالای \"" + ProductFullName + "\" صحیح نمی باشد.";
                    lstmsg.Add(new CCheckbox
                    {
                        Value = "false",
                        Name = msg
                    });
                    ResultHasError = true;
                }
                else
                {
                    var Specialold = sabadkharid.SabadKharidItems.FirstOrDefault(s => s.ProductId == prod.UID && s.Price.IsDarhalEngheza == true);


                    if (SpecialValue == 0)
                    {
                        if (Specialold != null)
                        {

                            dc.SabadKharidItems.DeleteOnSubmit(Specialold);
                            dc.SubmitChanges();
                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به فروش ویژه از سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + Specialold.Count + " " + prod.Unit.Name + "\" حذف گردید.", EventTypeIds.DELETE, "SEARCH", CurrentUser.UID);
                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" مربوط به فروش ویژه از سبد خرید " + " حذف گردید." });
                            ResultHasSecsess = true;
                        }
                    }
                    else
                    {
                        ///بررسی میکنیم مقدار وارد شده در انبار وجوددارد یا نه در صورتی که وجود داشت و ما نیز اجازه خرید 
                        ///داشتیم که ان را رزرومی کنیم در غیر این صورت پیام خطا داده می شود که انقدر در انبار نمی باش
                        ///ولی در صورتی که در انبار اصلی موجود نباشد و ما موجودی نداشته باشیم یک نوتی فکیشن به مدیریت ارسال می شود
                        ///
                        var SpecialPrice = LstPrices.Where(s => s.IsDarhalEngheza == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                        if (SpecialPrice != null)
                        {
                            ////خریدهای ویژه رزرو و خریداری شده 
                            var sabadkharidItems = SpecialPrice.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                            //// تعداد خریداری شده از این کالا 
                            decimal TedadKharid = sabadkharidItems.Any(s => s.SabadKharid.IsKharid == true) ? (sabadkharidItems.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count)) : 0;
                            ////تعدادی که کاربر اجازه خرید دارد 
                            decimal TedadiKMitavanKharid = (decimal)SpecialPrice.MojodiProduct - TedadKharid;

                            if (TedadiKMitavanKharid > 0)
                            {
                                decimal? SpecialtedadrezervKol = FunctionMojodi.MojodiReservHay_TedadDarHaleEngheza(prod.UID);
                                SpecialtedadrezervKol = SpecialtedadrezervKol == null ? 0 : SpecialtedadrezervKol;
                                decimal anbar_jari = TedadiKMitavanKharid - ((decimal)SpecialtedadrezervKol - (Specialold == null ? 0 : Specialold.Count) + SpecialValue);



                                if (anbar_jari < 0)
                                {
                                    string msg = "این مقدار کالای \"" + ProductFullName + "\" برای فروش ویژه موجود نمی باشد.";
                                    lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                    ResultHasError = true;
                                }


                                else
                                {
                                    if (Specialold == null)
                                    {
                                        Specialold = new SabadKharidItem();
                                        Specialold.UID = Guid.NewGuid();
                                        Specialold.Count = SpecialValue;
                                        Specialold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                        Specialold.DateTimeSabt = DateTime.Now;
                                        Specialold.Product = prod;
                                        Specialold.PriceID = SpecialPrice.UID;
                                        Specialold.PriceVahed = SpecialPrice.Price_;
                                        Specialold.SabadKharidID = sabadkharid.UID;
                                        Specialold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                        Specialold.UserAddKonandeID = CurrentUser.UID;
                                        sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
                                        dc.SabadKharidItems.InsertOnSubmit(Specialold);
                                        dc.SubmitChanges();
                                        EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به فوش ویژه در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + SpecialValue + " " + prod.Unit.Name + "\" .(رزرو شد)درج گردید.", EventTypeIds.SAVE, "SEARCH", CurrentUser.UID);
                                        lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" مربوط به فوش ویژه در سبد خرید " + " ثبت گردید." });
                                        ResultHasSecsess = true;
                                        tedadreservhayKol += tedadreservhayKol + SpecialValue;
                                    }
                                    else
                                    {
                                        Specialold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                        Specialold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                        Specialold.DateTimeSabt = DateTime.Now;
                                        Specialold.PriceID = SpecialPrice.UID;
                                        Specialold.PriceVahed = SpecialPrice.Price_;
                                        tedadreservhayKol += tedadreservhayKol - Specialold.Count + SpecialValue;
                                        if (Specialold.Count != SpecialValue)
                                        {
                                            decimal old = Specialold.Count;
                                            Specialold.UserAddKonandeID = CurrentUser.UID;
                                            Specialold.Count = SpecialValue;
                                            dc.SubmitChanges();
                                            EventLog.Loging("مقدار کالای \"" + ProductFullName + "\" مربوط به فروش ویژه در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + SpecialValue + " " + prod.Unit.Name + "\" [مقدار قدیم : \"" + old + "\"] .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);
                                            lstmsg.Add(new CCheckbox { Value = "true", Name = "مقدار کالای \"" + ProductFullName + "\" مربوط به فروش ویژه در سبد خرید " + " ثبت گردید." });
                                            ResultHasSecsess = true;
                                        }
                                        else
                                        {

                                            dc.SubmitChanges();
                                            EventLog.Loging("کالای \"" + ProductFullName + "\" مربوط به فروش ویژه در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + SpecialValue + " " + prod.Unit.Name + "\"  .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);

                                        }


                                    }
                                }
                            }
                            else
                            {
                                ///درصورتی که کاربر به اندازه کافی خریده است ولی دوباره به این قسمت امده است
                                ///فعلا پیغام خاصی نمی دهیم

                            }

                        }
                        ///در سبد خرید من چیزی وجود دارد یا نه

                    }
                }


            }
            #endregion

            #region بررسی و ثبت اصلی

            if (txtASLI != null)
            {

                decimal AsliValue = 0;
                if (!decimal.TryParse("0" + txtASLI, out AsliValue))
                {

                    string msg = "مقدار وارد شده برای کالای \"" + ProductFullName + "\" صحیح نمی باشد.";
                    lstmsg.Add(new CCheckbox
                    {
                        Value = "false",
                        Name = msg
                    });
                    ResultHasError = true;
                }
                else
                {
                    var Asliold = sabadkharid.SabadKharidItems.FirstOrDefault(s => s.ProductId == prod.UID && s.Price.IsPriceAsli == true);


                    if (AsliValue == 0)
                    {
                        if (Asliold != null)
                        {
                            tedadreservhayKol += tedadreservhayKol - Asliold.Count;
                            dc.SabadKharidItems.DeleteOnSubmit(Asliold);
                            dc.SubmitChanges();
                            EventLog.Loging("کالای " + ProductFullName + " از سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + Asliold.Count + " " + prod.Unit.Name + "\" حذف گردید.", EventTypeIds.DELETE, "SEARCH", CurrentUser.UID);
                            lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای " + ProductFullName + " از سبد خرید " + " حذف گردید." });
                            ResultHasSecsess = true;
                        }
                    }
                    else
                    {
                        ///بررسی میکنیم مقدار وارد شده در انبار وجوددارد یا نه در صورتی که وجود داشت و ما نیز اجازه خرید 
                        ///داشتیم که ان را رزرومی کنیم در غیر این صورت پیام خطا داده می شود که انقدر در انبار نمی باش
                        ///ولی در صورتی که در انبار اصلی موجود نباشد و ما موجودی نداشته باشیم یک نوتی فکیشن به مدیریت ارسال می شود
                        ///
                        var AsliPrice = LstPrices.Where(s => s.IsPriceAsli == true).OrderByDescending(s => s.DateSabt).FirstOrDefault();
                        if (AsliPrice != null)
                        {

                            if (AsliPrice.Product.MojodiCount > 0)
                            {

                                decimal anbar_jari = AsliPrice.Product.MojodiCount - ((decimal)tedadreservhayKol - (Asliold == null ? 0 : Asliold.Count) + AsliValue);


                                if (anbar_jari < 0)
                                {
                                    string msg = "کالای \"" + ProductFullName + "\" موجود نمی باشد.";
                                    lstmsg.Add(new CCheckbox { Value = "false", Name = msg });
                                    EmoNetUtility.SendNotification(lstroleIds, null, "موجودی کالای \"" + ProductFullName + "\" به اتمام رسیده است، ولی کاربر با نام " + CurrentUser.FullName + " درخواست خرید کالا را دارد.", NotificationTypeIDs.MojodiAnbar);
                                    ResultHasError = true;
                                }


                                else
                                {
                                    if (Asliold == null)
                                    {
                                        Asliold = new SabadKharidItem();
                                        Asliold.UID = Guid.NewGuid();
                                        Asliold.Count = AsliValue;
                                        Asliold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                        Asliold.DateTimeSabt = DateTime.Now;
                                        Asliold.Product = prod;
                                        Asliold.PriceID = AsliPrice.UID;
                                        Asliold.PriceVahed = AsliPrice.Price_;
                                        Asliold.SabadKharidID = sabadkharid.UID;
                                        Asliold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                        Asliold.UserAddKonandeID = CurrentUser.UID;
                                        Asliold.DarsadHadie_AllMonth = prod.DarsadTakhfif_For_AllMonth;
                                        Asliold.DarsadHadie_EndMonth = prod.DarsadTakhfif_For_EndMonth;

                                        sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
                                        dc.SabadKharidItems.InsertOnSubmit(Asliold);
                                        dc.SubmitChanges();
                                        EventLog.Loging("کالای \"" + ProductFullName + "\" در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + AsliValue + " " + prod.Unit.Name + "\" .(رزرو شد)درج گردید.", EventTypeIds.SAVE, "SEARCH", CurrentUser.UID);
                                        lstmsg.Add(new CCheckbox { Value = "true", Name = "کالای \"" + ProductFullName + "\" در سبد خرید " + " ثبت گردید." });
                                        ResultHasSecsess = true;
                                        tedadreservhayKol += tedadreservhayKol + AsliValue;
                                    }
                                    else
                                    {
                                        Asliold.DarsadHadie_AllMonth = prod.DarsadTakhfif_For_AllMonth;
                                        Asliold.DarsadHadie_EndMonth = prod.DarsadTakhfif_For_EndMonth;
                                        Asliold.DateSabt_Fa = DateShamsi.GetCurrentDate();
                                        Asliold.TimeSabt_Fa = DateShamsi.GetCurrentHour();
                                        Asliold.DateTimeSabt = DateTime.Now;
                                        Asliold.PriceID = AsliPrice.UID;
                                        Asliold.PriceVahed = AsliPrice.Price_;
                                        tedadreservhayKol += tedadreservhayKol - Asliold.Count + AsliValue;
                                        if (Asliold.Count != AsliValue)
                                        {
                                            decimal old = Asliold.Count;
                                            Asliold.UserAddKonandeID = CurrentUser.UID;
                                            Asliold.Count = AsliValue;
                                            dc.SubmitChanges();
                                            EventLog.Loging("مقدار کالای \"" + ProductFullName + "\" در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + AsliValue + " " + prod.Unit.Name + "\" [مقدار قدیم : \"" + old + "\"] .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);
                                            lstmsg.Add(new CCheckbox { Value = "true", Name = "مقدار کالای \"" + ProductFullName + "\" در سبد خرید " + " ثبت گردید." });
                                            ResultHasSecsess = true;
                                        }
                                        else
                                        {

                                            dc.SubmitChanges();
                                            EventLog.Loging("کالای \"" + ProductFullName + "\" در سبد خرید با کد رهگیری " + sabadkharid.CodeRahgiri + " با مقدار \"" + AsliValue + " " + prod.Unit.Name + "\" .(به روز رسانی شد)ویرایش گردید.", EventTypeIds.EDIT, "SEARCH", CurrentUser.UID);

                                        }


                                    }
                                }
                            }
                            else
                            {
                                ///درصورتی که کاربر به اندازه کافی خریده است ولی دوباره به این قسمت امده است
                                ///فعلا پیغام خاصی نمی دهیم

                            }

                        }
                        ///در سبد خرید من چیزی وجود دارد یا نه

                    }
                }


            }
            #endregion

            string msgInfo = "";
            if (ResultHasError == true && ResultHasSecsess == true)
            {

                for (int i = 1; i <= lstmsg.Count; i++)
                {
                    msgInfo += (i).ToString() + " - <span style=\"color:" + (lstmsg[i - 1].Value == "false" ? "red" : "green") + "\">" + lstmsg[i - 1].Name + "</span></br> ";
                }
                DisplayMessage.ShowInformationMessage(msgInfo);
            }
            else if (ResultHasSecsess)
            {
                for (int i = 1; i <= lstmsg.Count; i++)
                {
                    msgInfo += (i).ToString() + " - " + lstmsg[i - 1].Name + "</br> ";
                }
                DisplayMessage.ShowSeccessMessage(msgInfo);
            }
            else if (ResultHasError)
            {
                for (int i = 1; i <= lstmsg.Count; i++)
                {
                    msgInfo += (i).ToString() + " - " + lstmsg[i - 1].Name + "</br> ";
                }
                DisplayMessage.ShowErrorMessage(msgInfo);
            }


            FunctionMojodi.NOtificationToMinProd(prod.UID, "");

        }

        public void CheckBtnPublic(FormCollection frm, HttpResponseBase response)
        {
            if (frm["btn"] == "SEARCH")
            {
                response.Redirect("/CSearch" + "/" + EmoNetUtility.GetEncodedQueryString("Search", GetSearchParametrAsID()));

            }
            if (frm["btn"] == "SEFARESH")
            {
                SaveInSabadKharidAndCheckValidate(frm);
                LoadValueOfMaster(CurrentUser);
            }
        }
    }
}