﻿using MVC_AVASPA.App_Start.Utility;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Models.Pages
{
    public class LoginModel
    {
        DBDataContext dc = new DBDataContext();
        private string txtbox_EMAIL_DIALOG;
        private string CaptchaValue;

        public Messaging DisplayMessage;
        public string txtUserName;
        public string txtPassword;
        public string txtcaptcha;


        public LoginModel()
        {
            DisplayMessage = new Messaging();
        }
        public LoginModel(FormCollection frm, string CaptchaValue_)
        {
            DisplayMessage = new Messaging();
            txtUserName = frm["txtUserName"].ToString().Trim();
            txtPassword = frm["txtPassword"].ToString();
            txtcaptcha = frm["txtcaptcha"].ToString().ToUpper().Trim();
            txtbox_EMAIL_DIALOG = frm["txtbox_EMAIL_DIALOG"].ToString().Trim();
            CaptchaValue = CaptchaValue_;

        }

        public string Login()
        {
            var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
             && s.UserName == txtUserName.Trim() && s.Password == Utility.EncryptedQueryString.GetMD5Hash(txtPassword.Trim()));
            EventLog.Loging("ورود موفق به سیستم", EventTypeIds.VorodNamovafagh, "LOGIN", usr.UID);

            System.Web.HttpContext.Current.Session["USERID"] = usr.UID;

            if (usr.Role.IsMenagment)
            {
                return "~/MApplication/MainPage";
            }
            else if (usr.Role.IsMenagment == false)
            {
                return "~/CApplication/MainPage";
            }
            return "~/Login/Login";
        }
        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (CaptchaValue != txtcaptcha)
            {
                Msg += (++i).ToString() + " - " + "کلید امنیتی را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (txtUserName.Trim() == "")
                {
                    Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                    result = false;
                }
                if (txtPassword == "")
                {
                    Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                    result = false;
                }

                if (result == true)
                {
                    var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
                        && s.UserName == txtUserName.Trim());
                    if (usr == null || usr.Password != Utility.EncryptedQueryString.GetMD5Hash(txtPassword))
                    {
                        Msg += (++i).ToString() + " - " + "نام کاربری یا رمز عبور شما نادرست می باشد." + "</br>";
                        result = false;
                    }
                }
            }

            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.VorodNamovafagh, "LOGIN", null);
            }

            return result;
        }
        public void ChangePassword()
        {
            string email = txtbox_EMAIL_DIALOG.Trim();
            string NewPass = (new Random()).Next(1000000, 9999999).ToString();
            user obj = dc.users.FirstOrDefault(s => s.Email == txtbox_EMAIL_DIALOG.Trim());
            obj.Password = EncryptedQueryString.GetMD5Hash(NewPass);
            dc.SubmitChanges();

            string body = "با سلام" + Environment.NewLine + "رمز عبور جدید برای وارد شدن به سایت آوا اسپا عبارت است از : " + NewPass;
            Mailer.SendMail(body, "آوا اسپا", email, false, "رمز عبور جدید");
            DisplayMessage.ShowSeccessMessage("رمز عبور جدید ارسال گردید");
            EventLog.Loging(" رمز عبور به ایمیل ارسال گردید.", EventTypeIds.Forgotpassword, "LOGIN", obj.UID);
        }
        public bool CheckValidateEmail()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (txtbox_EMAIL_DIALOG.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی  را وارد نمایید." + "</br>";
                result = false;
            }
            else if (!Validation.IsEmail(txtbox_EMAIL_DIALOG.Trim()))
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی را صحیح وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
                    && s.Email == txtbox_EMAIL_DIALOG.Trim());
                if (usr == null)
                {
                    Msg += (++i).ToString() + " - " + "کاربری با پست الکترونیکی وارد شده یافت نشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.Forgotpassword, "LOGIN", null);
            }

            return result;
        }
    }
}