﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_TurnOversModel : CMasterPageModel
    {
        public string CboSelectAccount = "";
        public string CboSelectVariz = "";
        public string txtDateAz = "";
        public string txtDateTa = "";
        public string hfContent = "0";


        public string hfCustomersSelect = "";
        public string hfCustomerSelectNAME = "همه";

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<Payment> lst_content_Table = new List<Payment>();

        public C_TurnOversModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_TurnOversModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        /// <summary>
        /// در سبد خرید از هر کالا در هر نوع سفارش فقط یکی باید باشد 
        /// به همین دلیل سبد خرید بررسی می شود اگر از نوع کالا باشد کالا ویرایش می شود 
        /// همین طور اگر قیمت کالا لازم باشد به روز می شود
        /// </summary>
        /// <param name="frm"></param>
        private void BindFrom(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
            CboSelectVariz = frm["CboSelectVariz"].ToString().Trim().ToLower();
            CboSelectAccount = frm["CboSelectAccount"].ToString().Trim().ToLower();
            txtDateAz = frm["txtDateAz"].ToString().Trim();
            txtDateTa = frm["txtDateTa"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            //hfCustomersSelect = frm["hfCustomersSelect"].ToString().Trim();
            //hfCustomerSelectNAME = frm["hfCustomerSelectNAME"].ToString().Trim();
            //hfCustomerSelectNAME = hfCustomerSelectNAME == "" ? "همه" : hfCustomerSelectNAME;

        }

        public void Search()
        {
            lst_content_Table = new List<Payment>();
            var q = (from p in dc.Payments
                     where
                     p.IsDeleted == false
                     &&
                     p.UserAccountId == CurrentUser.UID
                     &&
                     (
                     CboSelectAccount == ""
                     ||
                    (CboSelectAccount == "asli" && p.IsGift == false && p.IsGift_EndMonth == false)
                     ||
                    (CboSelectAccount == "gift" && p.IsGift == true && p.IsGift_EndMonth == false)
                     ||
                    (CboSelectAccount == "giftendmonth" && p.IsGift == false && p.IsGift_EndMonth == true)
                     )
                     select p);


            //////OrderBy
            if (CboSelectVariz != "")
            {
                q = q.Where(s => s.IsVariz.ToString().ToLower() == CboSelectVariz);
            }
            txtDateAz = DateShamsi.GetShamsiDateString(txtDateAz);
            if (txtDateAz != "")
            {
                q = q.Where(s => s.DatePersianSabt.CompareTo(txtDateAz) >= 0);
            }
            txtDateTa = DateShamsi.GetShamsiDateString(txtDateTa);
            if (txtDateTa != "")
            {
                q = q.Where(s => s.DatePersianSabt.CompareTo(txtDateTa) <= 0);
            }

            q = q.OrderByDescending(s => s.DateTimeSabt);

            GridPaging.lst_headerName.Add("مبلغ");
            GridPaging.lst_headerName.Add("تاریخ");
            GridPaging.lst_headerName.Add("زمان");
            GridPaging.lst_headerName.Add("واریز/برداشت");
            GridPaging.lst_headerName.Add("موجودی کل");
            GridPaging.lst_headerName.Add("توضیحات");

            GridPaging.Columns = 7;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();



        }


    }
}