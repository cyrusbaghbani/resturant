﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;

namespace restauran.Models.Pages
{
    public class C_MainPageModel : CMasterPageModel
    {

        public List<Banners> lstTablighat = new List<Banners>();
        public List<ProductType> lstproductTypeItem_Menu = new List<ProductType>();


        public C_MainPageModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
            BindTablighat();
            BindProductType();
        }

        public C_MainPageModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            this.Controll = controller_;
            BindTablighat();
            BindProductType();

        }
        private void BindProductType()
        {
            lstproductTypeItem_Menu = dc.ProductTypes.Where(s => s.IsDeleted == false && s.ParentId == null).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();

        }
        private void BindTablighat()
        {
            var lstAdvr = dc.Advertisings.Where(s => s.DateShoro != null && s.DateShoro.CompareTo(TodayDate_Master) <= 0 && (s.DatePayan == null || s.DatePayan.Trim() == "" || s.DatePayan.CompareTo(TodayDate_Master) >= 0));
            var lstLottery = dc.Lotteries.Where(s => s.DateShoro != null && s.DatePayan != null && s.DateShoro.CompareTo(TodayDate_Master) <= 0 && s.DatePayan.CompareTo(TodayDate_Master) >= 0);
            lstTablighat = new List<Banners>();
            foreach (var p in lstAdvr)
            {
                lstTablighat.Add(new Banners() { isAdvertisment = true, UrlImage = p.Url, UrlImage800_600 = p.Url800_600, priority = p.Priority });
            }
            foreach (var p in lstLottery)
            {
                lstTablighat.Add(new Banners() { isLottory = true, UrlImage = p.Url1920_450, UrlImage800_600 = p.Url800_600, priority = p.Priority, Onvan = p.Onvam, link = p.url });
            }



        }

    }
}