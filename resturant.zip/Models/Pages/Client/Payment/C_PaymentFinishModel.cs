﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_PaymentFinishModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lst_content_Table = new List<KalaItem>();

        public decimal MablaghTax = 0;
        public decimal MablaghTransport = 0;
        public decimal MablaghGHabelPardakht = 0;

        public bool IsFree = false;
        public C_PaymentFinishModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_PaymentFinishModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void BindFrom(FormCollection frm)
        {

            GridPaging = new GridPageNumber();

        }

        public void Search()
        {



            lst_content_Table = new List<KalaItem>();



            var Sabaditems = (from p in dc.SabadKharidItems
                              where
                              p.SabadKharidID == CurrentSabadKharidID
                              &&
                              p.SabadKharid.IsDeleted == false
                              &&
                              p.SabadKharid.IsKharid == false
                              select p);

            var q1 = (from p in Sabaditems
                      select new
                      {
                          ProductTypeName = p.ProductId.ToString(),
                          UID = p.UID,
                          FullName = (p.Product.ProductType.Parent.IsShowName == false ? "" : p.Product.ProductType.Parent.Name) + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name,
                          ProductGroupTypeName = (p.Price.IsPriceAsli == true ? "عمومی" : (p.Price.IsTakhfifEkhtesasi == true ? "جشنواره اختصاصی" : (p.Price.IsTakhfifOmomi == true ? "جشنواره عمومی" : (p.Price.IsDarhalEngheza == true ? "فروش ویژه" : "")))),
                          TakhfifPrice = p.PriceVahed,
                          TedadKol = p.Count,
                          unitname = p.Product.Unit.Name,
                          Price = (p.Count * p.PriceVahed),
                          PriceKol = (p.Count * p.PriceVahed)
                      }).ToList();

            var q = (from p in q1
                     select new KalaItem()
                     {
                         ProductTypeName = p.ProductTypeName.ToString(),
                         UID = p.UID,
                         FullName = p.FullName,
                         ProductGroupTypeName = p.ProductGroupTypeName,
                         TakhfifPrice = p.TakhfifPrice.ToString("###,##0") + " ریال",
                         TedadKol = p.TedadKol.ToString("###,##0") + " " + p.unitname,
                         Price = (p.Price).ToString("###,##0") + " ریال",
                         PriceKol = (p.PriceKol)
                     }).ToList();



            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نوع خرید");
            GridPaging.lst_headerName.Add("قیمت");
            GridPaging.lst_headerName.Add("تعداد");
            GridPaging.lst_headerName.Add("قیمت کل");

            GridPaging.Columns = 6;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = q.OrderBy(s => s.FullName).ToList();


            string Datetimstring_ = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring_) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring_) >= 0))
                MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol + CurrentUser.MablaghGifts_EndMonth_KOL;
            else
                MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol;


            var transport = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TRANSPORT && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();
            var tax = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TAX && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();

            decimal mablaghkol = (lst_content_Table.Any() ? lst_content_Table.Sum(s => s.PriceKol) : 0);
            decimal baghymande = (mablaghkol+(tax == null ? 0 : ((tax.Price * mablaghkol) / 100))+(transport == null ? 0 : transport.Price)) - MablaghKolEtebarkarbar;
            MablaghGHabelPardakht = baghymande < 0 ? 0 : baghymande;



            ///چک کردن منقزض شده ها مثل جشنواره و ...بعد از 24ساعت به اتمام رسید پایان جشنواره
            ///در صورت حذف پیغام خطا داده می شود
            /// در زمان خرید رایگان بررسی می شود
            if (!Sabaditems.Any())
            {
                return;
            }
            var sabadkharid = Sabaditems.FirstOrDefault().SabadKharid;

            sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
            sabadkharid.PriceKol = Sabaditems.Sum(p => (p.Count * p.PriceVahed));


            sabadkharid.MablaghPardakhtMaliat = tax == null ? 0 : ((tax.Price * sabadkharid.PriceKol.Value) / 100);
            sabadkharid.MablaghPardakhtTransport = transport == null ? 0 : transport.Price;

            MablaghTax = sabadkharid.MablaghPardakhtMaliat;
            MablaghTransport = sabadkharid.MablaghPardakhtTransport;

        

            sabadkharid.MablaghGhabelPardakht = sabadkharid.PriceKol.Value + sabadkharid.MablaghPardakhtMaliat + sabadkharid.MablaghPardakhtTransport;
            sabadkharid.DateTimeZamanRaftanDarSafhieTaiedBank = DateTime.Now;
            sabadkharid.DateZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentDate();
            sabadkharid.TimeZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentHour();


            string Datetimstring = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring) >= 0))
            {
                sabadkharid.MablaghPardakhtShodeHadie_EndMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGifts_EndMonth_KOL ? CurrentUser.MablaghGifts_EndMonth_KOL : (sabadkharid.MablaghGhabelPardakht);
                sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_EndMonth;
            }

            sabadkharid.MablaghPardakhtShodeHadie_AllMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGiftsKol ? CurrentUser.MablaghGiftsKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_AllMonth;


            decimal takhfif_AllMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_AllMonth : 0)) / 100);
            decimal takhfif_EndMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_EndMonth : 0)) / 100);



            sabadkharid.MablaghHadieDaryafti_AllMonth = Math.Round((takhfif_AllMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);
            sabadkharid.MablaghHadieDaryafti_EndMonth = Math.Round((takhfif_EndMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);

            sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghAccountKol ? CurrentUser.MablaghAccountKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli;
            sabadkharid.UserPardakhtKonandeID = CurrentUser.UID;

            if (sabadkharid.MablaghGhabelPardakht == 0)
                IsFree = true;
            dc.SubmitChanges();
        }

        public void Save()
        {
            var Sabaditems = (from p in dc.SabadKharidItems
                              where
                              p.SabadKharidID == CurrentSabadKharidID
                              &&
                              p.SabadKharid.IsDeleted == false
                              &&
                              p.SabadKharid.IsKharid == false
                              select p);


            var sabadkharid = Sabaditems.FirstOrDefault().SabadKharid;

            sabadkharid.DateTimeZamanRaftanDarSafhieTaiedBank = DateTime.Now;
            sabadkharid.DateZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentDate();
            sabadkharid.TimeZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentHour();

            sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
            sabadkharid.PriceKol = Sabaditems.Sum(p => (p.Count * p.PriceVahed));

            // decimal oldMablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht;

            var transport = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TRANSPORT && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();
            var tax = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TAX && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();
            sabadkharid.MablaghPardakhtMaliat = tax == null ? 0 : ((tax.Price * sabadkharid.PriceKol.Value) / 100);
            sabadkharid.MablaghPardakhtTransport = transport == null ? 0 : transport.Price;

            MablaghTax = sabadkharid.MablaghPardakhtMaliat;
            MablaghTransport = sabadkharid.MablaghPardakhtTransport;

            sabadkharid.MablaghGhabelPardakht = sabadkharid.PriceKol.Value + sabadkharid.MablaghPardakhtMaliat + sabadkharid.MablaghPardakhtTransport;

            string Datetimstring = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring) >= 0))
            {
                sabadkharid.MablaghPardakhtShodeHadie_EndMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGifts_EndMonth_KOL ? CurrentUser.MablaghGifts_EndMonth_KOL : (sabadkharid.MablaghGhabelPardakht);
                sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_EndMonth;
            }

            sabadkharid.MablaghPardakhtShodeHadie_AllMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGiftsKol ? CurrentUser.MablaghGiftsKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_AllMonth;


            decimal takhfif_AllMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_AllMonth : 0)) / 100);
            decimal takhfif_EndMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_EndMonth : 0)) / 100);



            sabadkharid.MablaghHadieDaryafti_AllMonth = Math.Round((takhfif_AllMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);
            sabadkharid.MablaghHadieDaryafti_EndMonth = Math.Round((takhfif_EndMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);

            sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghAccountKol ? CurrentUser.MablaghAccountKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli;

            sabadkharid.UserPardakhtKonandeID = CurrentUser.UID;
            Transaction tr = new Transaction();
            tr.CodeRahgiri = sabadkharid.CodeRahgiri;
            tr.Date = DateShamsi.GetCurrentDate();
            tr.DateTime = DateTime.Now;
            tr.Dsc = "ارسال اطلاعات برای خرید رایگان";
            tr.mablaghGahbelPardakht = sabadkharid.MablaghGhabelPardakht;
            tr.mablaghPardakhtShode = sabadkharid.MablaghPardakhtShode;
            tr.SabadKharidID = sabadkharid.UID;
            tr.STATE = "SEND_PAY_FREE";
            tr.Time = DateShamsi.GetCurrentHour();
            tr.UID = Guid.NewGuid();
            tr.USERID = CurrentUser.UID;
            tr.FullNameUser = CurrentUser.FullName + " [" + CurrentUser.OnvaneSherkat + "]";


            dc.Transactions.InsertOnSubmit(tr);

            dc.SubmitChanges();
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;
            dc = new Access.DBDataContext();


            //var q1 = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.Price.DatePayan != null && s.Price.DatePayan != "" && s.SabadKharidID == CurrentSabadKharidID).ToList().Where(s => DateTime.Now.Subtract(DateShamsi.ConvertShamsiToMiladiDateTime(s.Price.DatePayan).Value).TotalHours > 72);
            //foreach (var p in q1)
            //{
            //    Msg += (++i).ToString() + " - " + " زمان خرید " + (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name + (p.Price.IsDarhalEngheza ? "[فروش ویژه] " : (p.Price.IsTakhfifOmomi ? "[جشنواره عمومی] " : (p.Price.IsTakhfifEkhtesasi ? "[جشنواره اختصاصی] " : ("")))) + " با قیمت " + p.PriceVahed.ToString("###,##0") + " ریال به پایان رسیده است. لطفا محصول را از سبد خرید خود حذف نمایید.";
            //    result = false;
            //}

            var Sabaditems = (from p in dc.SabadKharidItems
                              where
                              p.SabadKharidID == CurrentSabadKharidID
                              &&
                              p.SabadKharid.IsDeleted == false
                              &&
                              p.SabadKharid.IsKharid == false
                              select p);


            ///چک کردن منقزض شده ها مثل جشنواره و ...بعد از 24ساعت به اتمام رسید پایان جشنواره
            ///در صورت حذف پیغام خطا داده می شود
            if (!Sabaditems.Any())
            {
                Msg += (++i).ToString() + " - " + " کالایی یافت نشد" + "</br>";
                result = false;
            }
            var sabadkharid = Sabaditems.FirstOrDefault().SabadKharid;

            sabadkharid.DateTimeZamanRaftanDarSafhieTaiedBank = DateTime.Now;
            sabadkharid.DateZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentDate();
            sabadkharid.TimeZamanRaftanDarSafhieTaiedBank = DateShamsi.GetCurrentHour();

            sabadkharid.DateTimeAkharinTaghirat = DateTime.Now;
            sabadkharid.PriceKol = Sabaditems.Sum(p => (p.Count * p.PriceVahed));

            decimal oldMablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht;

            var transport = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TRANSPORT && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();
            var tax = dc.AdditionalFees.Where(s => s.Type == AdditionalFee_Type.TAX && s.IsDeleted == false).OrderByDescending(s => s.Date).FirstOrDefault();
            sabadkharid.MablaghPardakhtMaliat = tax == null ? 0 : ((tax.Price * sabadkharid.PriceKol.Value) / 100);
            sabadkharid.MablaghPardakhtTransport = transport == null ? 0 : transport.Price;

            MablaghTax = sabadkharid.MablaghPardakhtMaliat;
            MablaghTransport = sabadkharid.MablaghPardakhtTransport;

            sabadkharid.MablaghGhabelPardakht = sabadkharid.PriceKol.Value + sabadkharid.MablaghPardakhtMaliat + sabadkharid.MablaghPardakhtTransport;

            string Datetimstring = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring) >= 0))
            {
                sabadkharid.MablaghPardakhtShodeHadie_EndMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGifts_EndMonth_KOL ? CurrentUser.MablaghGifts_EndMonth_KOL : (sabadkharid.MablaghGhabelPardakht);
                sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_EndMonth;
            }

            sabadkharid.MablaghPardakhtShodeHadie_AllMonth = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghGiftsKol ? CurrentUser.MablaghGiftsKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_AllMonth;


            decimal takhfif_AllMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_AllMonth : 0)) / 100);
            decimal takhfif_EndMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_EndMonth : 0)) / 100);



            sabadkharid.MablaghHadieDaryafti_AllMonth = Math.Round((takhfif_AllMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);
            sabadkharid.MablaghHadieDaryafti_EndMonth = Math.Round((takhfif_EndMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);

            sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli = sabadkharid.MablaghGhabelPardakht >= CurrentUser.MablaghAccountKol ? CurrentUser.MablaghAccountKol : (sabadkharid.MablaghGhabelPardakht);
            sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli;

            sabadkharid.UserPardakhtKonandeID = CurrentUser.UID;
            dc.SubmitChanges();
            if (oldMablaghGhabelPardakht != sabadkharid.MablaghGhabelPardakht)
            {
                Msg += (++i).ToString() + " - " + " مبلغ قابل پرداخت دوباره مورد بررسی قرار بگیرد" + "</br>";
                result = false;
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }


    }
}