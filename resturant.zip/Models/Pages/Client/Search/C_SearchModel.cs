﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_SearchModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lstproductItem_Menu = new List<KalaItem>();

        public C_SearchModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_SearchModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        /// <summary>
        /// در سبد خرید از هر کالا در هر نوع سفارش فقط یکی باید باشد 
        /// به همین دلیل سبد خرید بررسی می شود اگر از نوع کالا باشد کالا ویرایش می شود 
        /// همین طور اگر قیمت کالا لازم باشد به روز می شود
        /// </summary>
        /// <param name="frm"></param>


        private void BindFrom(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            var q = (from p in dc.Prices
                     where
                     p.IsPriceAsli == true
                     &&
                     p.IsDeleted == false
                     &&
                     p.Product.IsShowInSite == true
                     &&
                     p.Product.IsDeleted == false
                     && p.DateShoro != "" && p.DateShoro.CompareTo(TodayDate_Master) <= 0
                     && (p.DatePayan == null || p.DatePayan.Trim() == "" || p.DatePayan.CompareTo(TodayDate_Master) >= 0)
                     &&
                     (
                       (
                           cboBrandSearch == ""
                           ||
                           cboBrandSearch == p.Product.BrandId.ToString()
                        )
                        &&
                        (
                           cboProductGroupSearch == ""
                           ||
                           cboProductGroupSearch == p.Product.ProductType.ParentId.ToString()
                        )
                     )
                     &&
                     p.Product.MojodiCount > 0
                     select p);

            ////OrderBy
            if (cboMoratabSazi.ToUpper() == "HOROFALEFBA" || cboMoratabSazi == "")
            {
                q = q.OrderBy(s => s.Product.ProductType.Parent.Name).ThenBy(s => s.Product.ProductType.Name).ThenBy(s => s.Product.Brand.Name);
            }
            else if (cboMoratabSazi.ToUpper() == "GRONTARIN")
            {
                q = q.OrderByDescending(s => s.Price_).ThenBy(s => s.Product.ProductType.Parent.Name).ThenBy(s => s.Product.ProductType.Name).ThenBy(s => s.Product.Brand.Name); ;
            }
            else if (cboMoratabSazi.ToUpper() == "ARZONTARIN")
            {
                q = q.OrderBy(s => s.Price_).ThenBy(s => s.Product.ProductType.Parent.Name).ThenBy(s => s.Product.ProductType.Name).ThenBy(s => s.Product.Brand.Name);
            }
            else if (cboMoratabSazi.ToUpper() == "PORFOROSHTARIN")
            {
                q = q.OrderByDescending(s => s.SabadKharidItems.Sum(t => (t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? t.Count : 0)).ThenBy(s => s.Product.ProductType.Parent.Name).ThenBy(s => s.Product.ProductType.Name).ThenBy(s => s.Product.Brand.Name);
            }


            GridPaging.CountAllRecord = q.Count();
            GridPaging.RowRecord = 16;
            GridPaging.PageNumber = 5;
            GridPaging.Next = "بعدی";
            GridPaging.Prview = "قبلی";
            GridPaging.GridLoad();
            var query = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();

            lstproductItem_Menu = new List<KalaItem>();
            var sabadkharid = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Select(s => s.ProductId).ToList();


            string TodayDateTime_Master = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            var productsTakhfif = dc.Prices.Where(s => s.IsDeleted == false
            && s.IsTakhfifOmomi == true
            && s.DatetimeShoro_Persian.CompareTo(TodayDateTime_Master) <= 0
            && s.DatetimePayan_Persian.CompareTo(TodayDateTime_Master) >= 0
            &&
            (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0)

            );

            var productIdsTakhfifEkhtesasi = (from p in dc.Prices
                                              where
                                              p.IsTakhfifEkhtesasi == true
                                              &&
                                              p.IsDeleted == false
                                              && p.DatetimeShoro_Persian != "" && p.DatetimeShoro_Persian.CompareTo(TodayDateTime_Master) <= 0
                                              && (p.DatetimePayan_Persian != null && p.DatetimePayan_Persian.Trim() != "" && p.DatetimePayan_Persian.CompareTo(TodayDateTime_Master) >= 0)
                                              &&
                                             p.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID)
                                             &&
                                             (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0)
                                              select p.ProductId);

            var productIdsSpecial = (from p in dc.Prices
                                     where
                                     p.IsDarhalEngheza == true

                                     &&
                                     p.IsDeleted == false

                                     && p.DatetimeShoro_Persian != "" && p.DatetimeShoro_Persian.CompareTo(TodayDateTime_Master) <= 0
                                     && (p.DatetimePayan_Persian != null && p.DatetimePayan_Persian.Trim() != "" && p.DatetimePayan_Persian.CompareTo(TodayDateTime_Master) >= 0)
                                     &&

                                     (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0)
                                     select p.ProductId);


            foreach (var p in query)
            {

                var takhfif = productsTakhfif.FirstOrDefault(s => s.ProductId == p.ProductId);
                var IsEkhtesasi = productIdsTakhfifEkhtesasi.Any(s => s == p.ProductId);
                var IsSpecial = productIdsSpecial.Any(s => s == p.ProductId);
                bool Has_Festival = IsEkhtesasi == true || takhfif != null || IsSpecial;

                lstproductItem_Menu.Add(new KalaItem()
                {
                    UID = p.ProductId,
                    Imageurl = (p.Product.ImageUrl == "" || p.Product.ImageUrl == null) ? p.Product.ProductType.Parent.ImageUrl : p.Product.ImageUrl,
                    IsInSabadKharid = sabadkharid.Any(s => s == p.ProductId),
                    Price = takhfif == null ? p.Price_.ToString("###,##0") : (" <span style=\"text-decoration:line-through\">" + p.Price_.ToString("###,##0") + "</span> "),
                    TakhfifPrice = takhfif == null ? "" : (takhfif.Price_.ToString("###,##0")),
                    FullName = (Has_Festival ? "<span class=\"fa fa-gift\" style=\"float: right; margin-right: 21px;font-size: 20px; color: #b01624;  margin-top: 1px;\"></span> " : "") + (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name,

                    DarsadHedie = p.Product.DarsadTakhfif_For_AllMonth == 0 ? "" : p.Product.DarsadTakhfif_For_AllMonth.ToString("0"),
                    DarsadHedieAkharSal = p.Product.DarsadTakhfif_For_EndMonth == 0 ? "" : p.Product.DarsadTakhfif_For_EndMonth.ToString("0"),
                });
            }

        }


    }
}