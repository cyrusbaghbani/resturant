﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using Utility;

namespace restauran.Models.Pages
{
    public class C_FestivalPublicModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lstproductItem_Menu = new List<KalaItem>();

        public C_FestivalPublicModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_FestivalPublicModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void BindFrom(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(TodayDate_Master, DateShamsi.GetCurrentHour().Substring(0, 5));
            var q = (from p in dc.Prices
                     where
                     p.IsTakhfifOmomi == true
                     &&
                     p.Product.IsShowInSite == true
                     &&
                     p.IsDeleted == false
                     &&
                     p.Product.IsDeleted == false
                     && p.DatetimeShoro_Persian != "" && p.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
                     && (p.DatetimePayan_Persian != null && p.DatetimePayan_Persian.Trim() != "" && p.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0)
                     &&
                     p.Product.MojodiCount > 0
                     &&
                     (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0)
                     select p);


            q = q.OrderByDescending(s => s.DateSabt).ThenBy(s => s.Product.ProductType.Parent.Name).ThenBy(s => s.Product.ProductType.Name).ThenBy(s => s.Product.Brand.Name);



            GridPaging.CountAllRecord = q.Count();
            GridPaging.RowRecord = 16;
            GridPaging.PageNumber = 5;
            GridPaging.Next = "بعدی";
            GridPaging.Prview = "قبلی";
            GridPaging.GridLoad();
            var query = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();

            lstproductItem_Menu = new List<KalaItem>();
            var sabadkharid = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Select(s => s.ProductId).ToList();

            foreach (var p in query)
            {
                var priceasli = dc.Prices.Where(s =>
                  s.IsDeleted == false
                  &&
                  s.ProductId == p.ProductId
                  &&
                  s.IsPriceAsli == true
                  &&
                  s.DateShoro.CompareTo(TodayDate_Master) <= 0
                  &&
                  (s.DatePayan == null || s.DatePayan == "" || s.DatePayan.CompareTo(TodayDate_Master) >= 0)
                ).OrderByDescending(s => s.DateSabt).FirstOrDefault();

                lstproductItem_Menu.Add(new KalaItem()
                {
                    UID = p.ProductId,
                    Imageurl = (p.Product.ImageUrl == "" || p.Product.ImageUrl == null) ? p.Product.ProductType.Parent.ImageUrl : p.Product.ImageUrl,
                    IsInSabadKharid = sabadkharid.Any(s => s == p.ProductId),
                    Price = " <span style=\"text-decoration:line-through\">" + (priceasli == null ? "" : priceasli.Price_.ToString("###,##0")) + "</span> " + p.Price_.ToString("###,##0") + " ریال"  ,
                    FullName = (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name
                });
            }

        }


    }
}