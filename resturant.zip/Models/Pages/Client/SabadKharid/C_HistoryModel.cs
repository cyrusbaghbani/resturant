﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using Utility;

namespace restauran.Models.Pages
{
    public class C_HistoryModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lstproductItem_Menu = new List<KalaItem>();

        public C_HistoryModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_HistoryModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void BindFrom(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            var q = (from p in dc.SabadKharidItems
                     where
                     p.SabadKharid.IsDeleted == false
                     &&
                     p.SabadKharid.IsKharid == true
                     &&
                     p.SabadKharid.UserMoshtariID == CurrentUser.UID
                     &&
                     p.Product.IsDeleted == false
                     &&
                     p.Product.MojodiCount > 0
                     &&
                     p.Product.IsShowInSite == true
                     select p).OrderByDescending(s => s.DateTimeSabt).Select(s => s.Product.UID).Distinct();


            GridPaging.CountAllRecord = q.Count();
            GridPaging.RowRecord = 16;
            GridPaging.PageNumber = 5;
            GridPaging.Next = "بعدی";
            GridPaging.Prview = "قبلی";
            GridPaging.GridLoad();

            lstproductItem_Menu = new List<KalaItem>();
            var sabadkharid = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.SabadKharid.UserMoshtariID == CurrentUser.UID).Select(s => s.ProductId).ToList();

            string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(TodayDate_Master, DateShamsi.GetCurrentHour().Substring(0, 5));
            var priceList = (from p in dc.Prices
                             join t in q on p.ProductId equals t
                             where
                             p.ProductId==t&&
                             p.IsDeleted == false
                             &&
                             p.Product.IsDeleted == false

                             &&
                             (
                                (
                                   (p.IsPriceAsli == true)
                                   &&
                                   p.DateShoro != "" && p.DateShoro.CompareTo(TodayDate_Master) <= 0
                                   && (p.DatePayan == null || p.DatePayan.Trim() == "" || p.DatePayan.CompareTo(TodayDate_Master) >= 0)

                                   && p.Product.MojodiCount > 0
                                )
                                ||
                              (
                                (

                                   p.DatetimeShoro_Persian != null && p.DatetimeShoro_Persian.Trim() != "" && p.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
                                   &&
                                   (p.DatetimePayan_Persian.Trim() != "" && p.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0)
                                   &&
                                   (
                                     (p.IsTakhfifOmomi == true || p.IsDarhalEngheza == true) && (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0))
                                     ||
                                     (p.IsTakhfifEkhtesasi == true && p.USER_PRICEs.Any(t => t.UserID == CurrentUser.UID) && (p.MojodiProduct - ((p.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID) ? p.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true && t.SabadKharid.UserMoshtariID == CurrentUser.UID).Sum(t => t.Count) : 0)) > 0))
                                )
                //(s.IsTakhfifEkhtesasi == true || s.IsDarhalEngheza == true || s.IsTakhfifOmomi == true)

                              )

                             )
                             select p);
            var lstallproduct = priceList.Select(s => s.Product).Distinct();
            var query = GridPaging.IsShowPageNumbering ? lstallproduct.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : lstallproduct.ToList();

            foreach (var p in query)
            {
                var takhfif = priceList.Where(s => s.ProductId == p.UID && (s.IsTakhfifEkhtesasi == true || s.IsTakhfifOmomi == true)).OrderBy(s => s.Price_).FirstOrDefault();
                var priceItem = priceList.Where(s => s.ProductId == p.UID && s.IsPriceAsli == true).FirstOrDefault();
                if (priceItem == null)
                    priceItem = priceList.Where(s => s.ProductId == p.UID && s.IsDarhalEngheza == true).FirstOrDefault();

                lstproductItem_Menu.Add(new KalaItem()
                {
                    UID = p.UID,
                    Imageurl = (p.ImageUrl == "" || p.ImageUrl == null) ? p.ProductType.Parent.ImageUrl : p.ImageUrl,
                    IsInSabadKharid = sabadkharid.Any(s => s == p.UID),
                    Price = takhfif == null ? ((priceItem == null ? "-" : priceItem.Price_.ToString("###,##0"))) : (" <span style=\"text-decoration:line-through\"> " + (priceItem == null ? "-" : priceItem.Price_.ToString("###,##0")) + " </span> " + takhfif.Price_.ToString("###,##0")),
                    FullName = (p.ProductType.Parent.IsShowName ? p.ProductType.Parent.Name : "") + " " + p.ProductType.Name + " " + p.Brand.Name
                });
            }

        }


    }
}