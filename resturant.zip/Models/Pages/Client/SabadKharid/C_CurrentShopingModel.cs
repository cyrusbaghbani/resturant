﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_CurrentShopingModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lst_content_Table = new List<KalaItem>();
        public string hf_SelectValueID = "";
        public bool IsFirstKharid = false;
        public string txtCodeMoaref;
        public C_CurrentShopingModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
            Displayinfo();
        }

        public C_CurrentShopingModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void Displayinfo()
        {
            var sabad = dc.SabadKharids.FirstOrDefault(s => s.UID == CurrentSabadKharidID && s.IsDeleted == false && s.IsKharid == false);
            txtCodeMoaref = sabad == null ? "" : sabad.CodeMaref;
        }
        private void BindFrom(FormCollection frm)
        {
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"] == null ? "" : frm["hf_SelectValueID"].Trim());
            GridPaging = new GridPageNumber();
            txtCodeMoaref = frm["txtCodeMoaref"] == null ? "" : frm["txtCodeMoaref"].Trim();
        }

        public void Search()
        {
            // IsFirstKharid = !dc.SabadKharids.Any(s => s.IsKharid == true && s.IsDeleted == false && s.UserMoshtariID == CurrentUser.UID);



            lst_content_Table = new List<KalaItem>();



            var q1 = (from p in dc.SabadKharidItems
                      where
                      p.SabadKharidID == CurrentSabadKharidID
                      &&
                      p.SabadKharid.IsDeleted == false
                      &&
                      p.SabadKharid.IsKharid == false
                      select new
                      {
                          ProductTypeName = p.ProductId.ToString(),
                          UID = p.UID,
                          FullName = (p.Product.ProductType.Parent.IsShowName == false ? "" : p.Product.ProductType.Parent.Name) + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name,
                          ProductGroupTypeName = (p.Price.IsPriceAsli == true ? "عمومی" : (p.Price.IsTakhfifEkhtesasi == true ? "جشنواره اختصاصی" : (p.Price.IsTakhfifOmomi == true ? "جشنواره عمومی" : (p.Price.IsDarhalEngheza == true ? "فروش ویژه" : "")))),
                          TakhfifPrice = p.PriceVahed,
                          TedadKol = p.Count,
                          unitname = p.Product.Unit.Name,
                          Price = (p.Count * p.PriceVahed),
                          PriceKol = (p.Count * p.PriceVahed)
                      }).ToList();

            var q = (from p in q1
                     select new KalaItem()
                     {
                         ProductTypeName = p.ProductTypeName.ToString(),
                         UID = p.UID,
                         FullName = p.FullName,
                         ProductGroupTypeName = p.ProductGroupTypeName,
                         TakhfifPrice = p.TakhfifPrice.ToString("###,##0") + " ریال",
                         TedadKol = p.TedadKol.ToString("###,##0") + " " + p.unitname,
                         Price = (p.Price).ToString("###,##0") + " ریال",
                         PriceKol = (p.PriceKol)
                     }).ToList();


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نوع خرید");
            GridPaging.lst_headerName.Add("قیمت");
            GridPaging.lst_headerName.Add("تعداد");
            GridPaging.lst_headerName.Add("قیمت کل");
            GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = 8;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = q.OrderBy(s => s.FullName).ToList();
        }

        public bool CheckValidate()
        {
            bool result = true;
            string msg = "لطفا به نکات زیر  توجه نمایید" + "</br>";
            int i = 0;


            //var q1 = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.Price.DatePayan != null && s.Price.DatePayan != "" && s.SabadKharidID == CurrentSabadKharidID).ToList().Where(s => DateTime.Now.Subtract(DateShamsi.ConvertShamsiToMiladiDateTime(s.Price.DatePayan).Value).TotalHours > 72);
            //foreach (var p in q1)
            //{
            //    msg += (++i).ToString() + " - " + " زمان خرید " + (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name + (p.Price.IsDarhalEngheza ? "[فروش ویژه] " : (p.Price.IsTakhfifOmomi ? "[جشنواره عمومی] " : (p.Price.IsTakhfifEkhtesasi ? "[جشنواره اختصاصی] " : ("")))) + " با قیمت " + p.PriceVahed.ToString("###,##0") + " ریال به پایان رسیده است. لطفا محصول را از سبد خرید خود حذف نمایید.";
            //    result = false;
            //}
           if( !dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.SabadKharidID == CurrentSabadKharidID).ToList().Any())
            {
                    msg += (++i).ToString() + " - " + "سبد خرید شما خالی می باشد.";
                    result = false;
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(msg);
            return result;
        }

        public void SabtCodeMoaref()
        {
            var sabad = dc.SabadKharids.FirstOrDefault(s => s.UID == CurrentSabadKharidID && s.IsDeleted == false && s.IsKharid == false);
            if (sabad != null)
            {
                sabad.CodeMaref = txtCodeMoaref.Trim();
                dc.SubmitChanges();
            }

        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.SabadKharidItems.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            string ProductFullName = (obj.Product.ProductType.Parent.IsShowName == false ? "" : (obj.Product.ProductType.Parent.Name)) + " " + obj.Product.ProductType.Name + " " + obj.Product.Brand.Name;


            obj.SabadKharid.DateTimeAkharinTaghirat = DateTime.Now;
            string Coderahgiri = obj.SabadKharid.CodeRahgiri;
            dc.SabadKharidItems.DeleteOnSubmit(obj);
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            EventLog.Loging("کالای " + ProductFullName + ((obj.Price.IsPriceAsli == true ? "" : (obj.Price.IsTakhfifEkhtesasi == true ? " مربوط به جشنواره اختصاصی از " : (obj.Price.IsTakhfifOmomi == true ? " مربوط به جشنواره عمومی از " : (obj.Price.IsDarhalEngheza == true ? " مربوط به فروش ویژه از " : ""))))) + " از سبد خرید با کد رهگیری " + Coderahgiri + " با مقدار \"" + obj.Count + "\" حذف گردید.", EventTypeIds.DELETE, "CURRENTSHOPPING", CurrentUser.UID);

            FunctionMojodi.NOtificationToMinProd(obj.ProductId, "");
            LoadValueOfMaster(CurrentUser);
        }



    }
}