﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using System.Web.Routing;

namespace restauran.Models.Pages
{
    public class C_DaryaftshodeModel : CMasterPageModel
    {

        public string txtOnvan = "";

        public string hfContent = "0";

        public string hf_SelectValueID = "";

        public List<SabadKharid> lst_content_Table = new List<SabadKharid>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public C_DaryaftshodeModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
         
        }

        public C_DaryaftshodeModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindForms(frm);

        }


        public void BindForms(FormCollection frm)
        {

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<SabadKharid>();



            var q = (from p in dc.SabadKharids
                     where
                     p.IsDeleted == false
                     &&
                     p.IsKharid == true
                     &&
                     p.IsTahvilBeMoshtari == true
                     &&
                     p.UserMoshtariID == CurrentUser.UID
                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.CodeRahgiri.Contains(txtOnvan.Trim()))
                           ||
                           p.userMoshtari.FullName.Contains(txtOnvan.Trim())
                           ||
                           p.userMoshtari.OnvaneSherkat.Contains(txtOnvan.Trim())
                           ||
                           (p.DateSabtSefareshKharid_Fa != null && p.DateSabtSefareshKharid_Fa.Contains(txtOnvan.Trim()))
                           ||
                           (p.DateTahvilBeMoshtari_Fa != null && p.DateTahvilBeMoshtari_Fa.Contains(txtOnvan.Trim()))
                           ||
                           (p.FullNameTahvilGirande != null && p.FullNameTahvilGirande.Contains(txtOnvan.Trim()))
                           ||
                           (p.UserTahvilDahandeID != null && p.userTahvilDahande.FullName.Contains(txtOnvan.Trim()))

                           )
                     )
                     select p).OrderByDescending(s => s.DateTimeSabtSefareshKharid);


            GridPaging.lst_headerName.Add("زمان ثبت");
            GridPaging.lst_headerName.Add("کد پیگیری");
            GridPaging.lst_headerName.Add("قیمت");
            GridPaging.lst_headerName.Add("توزیع کننده");
            GridPaging.lst_headerName.Add("زمان تحویل");
            GridPaging.lst_headerName.Add("تحویل گیرنده");
            GridPaging.lst_headerName.Add("نمایش کالا");
            GridPaging.lst_headerName.Add("چاپ");

            GridPaging.Columns = 9;

            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }



    }
}