﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_PaymentResultModel : CMasterPageModel
    {

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<KalaItem> lst_content_Table = new List<KalaItem>();

        public decimal MablaghTax = 0;
        public decimal MablaghTransport = 0;
        public decimal MablaghKalaItems = 0;
        public decimal MablaghGHabelPardakht = 0;

        public string Html_Info = "";
        public string HTMLPARDAKHTI = "";
        public string sabadid = "";
        public C_PaymentResultModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_PaymentResultModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void BindFrom(FormCollection frm)
        {

            GridPaging = new GridPageNumber();

        }

        public void SetFreePayment()
        {
            var Sabaditems = (from p in dc.SabadKharidItems
                              where
                              p.SabadKharidID == CurrentSabadKharidID
                              &&
                              p.SabadKharid.IsDeleted == false
                              &&
                              p.SabadKharid.IsKharid == false
                              select p);

            #region نمایش محصولات
            lst_content_Table = new List<KalaItem>();





            var q1 = (from p in Sabaditems
                      select new
                      {
                          ProductTypeName = p.ProductId.ToString(),
                          UID = p.UID,
                          FullName = (p.Product.ProductType.Parent.IsShowName == false ? "" : p.Product.ProductType.Parent.Name) + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name,
                          ProductGroupTypeName = (p.Price.IsPriceAsli == true ? "عمومی" : (p.Price.IsTakhfifEkhtesasi == true ? "جشنواره اختصاصی" : (p.Price.IsTakhfifOmomi == true ? "جشنواره عمومی" : (p.Price.IsDarhalEngheza == true ? "فروش ویژه" : "")))),
                          TakhfifPrice = p.PriceVahed,
                          TedadKol = p.Count,
                          unitname = p.Product.Unit.Name,
                          Price = (p.Count * p.PriceVahed),
                          PriceKol = (p.Count * p.PriceVahed)
                      }).ToList();

            var q = (from p in q1
                     select new KalaItem()
                     {
                         ProductTypeName = p.ProductTypeName.ToString(),
                         UID = p.UID,
                         FullName = p.FullName,
                         ProductGroupTypeName = p.ProductGroupTypeName,
                         TakhfifPrice = p.TakhfifPrice.ToString("###,##0") + " ریال",
                         TedadKol = p.TedadKol.ToString("###,##0") + " " + p.unitname,
                         Price = (p.Price).ToString("###,##0") + " ریال",
                         PriceKol = (p.PriceKol)
                     }).ToList();



            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نوع خرید");
            GridPaging.lst_headerName.Add("قیمت");
            GridPaging.lst_headerName.Add("تعداد");
            GridPaging.lst_headerName.Add("قیمت کل");

            GridPaging.Columns = 6;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = q.OrderBy(s => s.FullName).ToList();

            string Datetimstring_ = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring_) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring_) >= 0))
                MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol + CurrentUser.MablaghGifts_EndMonth_KOL;
            else
                MablaghKolEtebarkarbar = CurrentUser.MablaghAccountKol + CurrentUser.MablaghGiftsKol;

            if (Sabaditems.Any())
            {
                MablaghTax = Sabaditems.First().SabadKharid.MablaghPardakhtMaliat;
                MablaghTransport = Sabaditems.First().SabadKharid.MablaghPardakhtTransport;
            }
            MablaghKalaItems = (lst_content_Table.Any() ? lst_content_Table.Sum(s => s.PriceKol) : 0);
            decimal baghymande = MablaghKalaItems + (MablaghTax + MablaghTransport) - MablaghKolEtebarkarbar;
            MablaghGHabelPardakht = baghymande < 0 ? 0 : baghymande;
      
            #endregion


            ///چک کردن منقزض شده ها مثل جشنواره و ...بعد از 24ساعت به اتمام رسید پایان جشنواره
            ///در صورت حذف پیغام خطا داده می شود
            ///فعلا نیاز نیست  هرکی خرید خرید






            Transaction tr = new Transaction();
            tr.UID = Guid.NewGuid();
            tr.Date = DateShamsi.GetCurrentDate();
            tr.DateTime = DateTime.Now;
            tr.Time = DateShamsi.GetCurrentHour();
            tr.SabadKharidID = CurrentSabadKharidID;
            tr.USERID = CurrentUser.UID;
            tr.FullNameUser = CurrentUser.FullName + " [" + CurrentUser.OnvaneSherkat + "]";
            try
            {
                if (!Sabaditems.Any())
                {
                    Html_Info = "<center>" + "خطا، به صفحه اصلی مراجعه نمایید و سپس دوباره تلاش نمایید" + "</center>" + "</br>";
                    tr.Dsc = "سبد خرید یافت نشد";
                    tr.STATE = "FIND_NOT_SABADKHARID";
                    tr.Info = Html_Info;
                    dc.Transactions.InsertOnSubmit(tr);
                    dc.SubmitChanges();
                    return;
                }
                Guid sabaduid = Sabaditems.FirstOrDefault().SabadKharidID;
                dc = new Access.DBDataContext();
                var sabadkharid = dc.SabadKharids.FirstOrDefault(s => s.UID == sabaduid);

                tr.CodeRahgiri = sabadkharid.CodeRahgiri;

                if (sabadkharid.IsKharid == false)
                {
                    var usr = dc.users.SingleOrDefault(s => s.UID == CurrentUser.UID);


                    decimal oldmablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht;

                    sabadkharid.PriceKol = Sabaditems.Sum(p => (p.Count * p.PriceVahed));
                    sabadkharid.MablaghGhabelPardakht = sabadkharid.PriceKol.Value + sabadkharid.MablaghPardakhtTransport + sabadkharid.MablaghPardakhtMaliat;

                    string Datetimstring = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
                    if (dc.Loyalties.Any(s => s.DatetimeShoro_fa.CompareTo(Datetimstring) <= 0 && s.DateTimePayan_fa.CompareTo(Datetimstring) >= 0))
                    {
                        sabadkharid.MablaghPardakhtShodeHadie_EndMonth = sabadkharid.MablaghGhabelPardakht >= usr.MablaghGifts_EndMonth_KOL ? usr.MablaghGifts_EndMonth_KOL : (sabadkharid.MablaghGhabelPardakht);
                        sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_EndMonth;
                    }

                    sabadkharid.MablaghPardakhtShodeHadie_AllMonth = sabadkharid.MablaghGhabelPardakht >= usr.MablaghGiftsKol ? usr.MablaghGiftsKol : (sabadkharid.MablaghGhabelPardakht);
                    sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadie_AllMonth;


                    decimal takhfif_AllMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_AllMonth : 0)) / 100);
                    decimal takhfif_EndMonth = Sabaditems.Sum(s => (s.PriceVahed * s.Count * (s.Price.IsPriceAsli ? s.DarsadHadie_EndMonth : 0)) / 100);




                    sabadkharid.MablaghHadieDaryafti_AllMonth = Math.Round((takhfif_AllMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);
                    sabadkharid.MablaghHadieDaryafti_EndMonth = Math.Round((takhfif_EndMonth * sabadkharid.MablaghGhabelPardakht) / sabadkharid.PriceKol.Value);

                    sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli = sabadkharid.MablaghGhabelPardakht >= usr.MablaghAccountKol ? usr.MablaghAccountKol : (sabadkharid.MablaghGhabelPardakht);
                    sabadkharid.MablaghGhabelPardakht = sabadkharid.MablaghGhabelPardakht - sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli;


                    if (sabadkharid.MablaghGhabelPardakht == oldmablaghGhabelPardakht)
                    {

                        if (sabadkharid.MablaghPardakhtShode == sabadkharid.MablaghGhabelPardakht)
                        {
                            sabadkharid.DateSabtSefareshKharid_Fa = DateShamsi.GetCurrentDate();
                            sabadkharid.TimeSabtSefareshKharid_Fa = DateShamsi.GetCurrentHour();
                            sabadkharid.DateTimeSabtSefareshKharid = DateTime.Now;



                            HTMLPARDAKHTI = "";
                            sabadkharid.IsKharid = true;
                            if (sabadkharid.MablaghPardakhtShodeHadie_AllMonth > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghPardakhtShodeHadie_AllMonth, false, true, false, false, usr.MablaghGiftsKol, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri));
                                usr.MablaghGiftsKol = usr.MablaghGiftsKol - sabadkharid.MablaghPardakhtShodeHadie_AllMonth;
                            }
                            if (sabadkharid.MablaghPardakhtShodeHadie_EndMonth > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghPardakhtShodeHadie_EndMonth, false, false, true, false, usr.MablaghGifts_EndMonth_KOL, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri));
                                usr.MablaghGifts_EndMonth_KOL = usr.MablaghGifts_EndMonth_KOL - sabadkharid.MablaghPardakhtShodeHadie_EndMonth;
                            }
                            if (sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli, true, false, false, false, usr.MablaghAccountKol, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri));
                                usr.MablaghAccountKol = usr.MablaghAccountKol - sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli;
                            }
                            if (sabadkharid.MablaghHadieDaryafti_AllMonth > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghHadieDaryafti_AllMonth, false, true, false, true, usr.MablaghGiftsKol, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri));
                                usr.MablaghGiftsKol = usr.MablaghGiftsKol + sabadkharid.MablaghHadieDaryafti_AllMonth;
                            }
                            if (sabadkharid.MablaghHadieDaryafti_EndMonth > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghHadieDaryafti_EndMonth, false, false, true, true, usr.MablaghGifts_EndMonth_KOL, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri));
                                usr.MablaghGifts_EndMonth_KOL = usr.MablaghGifts_EndMonth_KOL + sabadkharid.MablaghHadieDaryafti_EndMonth;
                            }
                            if (sabadkharid.MablaghPardakhtShode > 0)
                            {
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghPardakhtShode, true, false, false, true, usr.MablaghGiftsKol, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri + "از طریق درگاه بانک پرداخت گردید"));
                            }
                            if (sabadkharid.MablaghPardakhtShode > 0)
                                dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, sabadkharid.MablaghPardakhtShode, true, false, false, false, usr.MablaghGiftsKol, "بابت سبد خرید با شماره پیگیری " + sabadkharid.CodeRahgiri + ""));






                            dc.SubmitChanges();

                            Html_Info = "<center>" + "خرید با موفقیت صورت گرفت" + "</center>" + "</br>";
                            Html_Info += "شماره پیگیری : " + sabadkharid.CodeRahgiri + "</br>";
                            Html_Info += "زمان سفارش : " + sabadkharid.DateSabtSefareshKharid_Fa + " [" + sabadkharid.TimeSabtSefareshKharid_Fa + "] " + "</br>";


                            if (sabadkharid.MablaghHadieDaryafti_AllMonth > 0)
                                Html_Info += "مبلغ هدیه  : " + sabadkharid.MablaghHadieDaryafti_AllMonth.ToString("###,##0") + " ریال" + "</br>";
                            if (sabadkharid.MablaghHadieDaryafti_EndMonth > 0)
                                Html_Info += "مبلغ هدیه وفاداری  : " + sabadkharid.MablaghHadieDaryafti_EndMonth.ToString("###,##0") + " ریال" + "</br>";





                            HTMLPARDAKHTI = "";
                            if (sabadkharid.MablaghPardakhtShodeHadie_AllMonth > 0)
                                HTMLPARDAKHTI += AddFooterForGrid(sabadkharid.MablaghPardakhtShodeHadie_AllMonth, " هدیه استفاده شده", GridPaging.Columns - 1);
                            if (sabadkharid.MablaghPardakhtShodeHadie_EndMonth > 0)
                                HTMLPARDAKHTI += AddFooterForGrid(sabadkharid.MablaghPardakhtShodeHadie_EndMonth, " هدیه وفاداری استفاده شده", GridPaging.Columns - 1);
                            if (sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli > 0)
                                HTMLPARDAKHTI += AddFooterForGrid(sabadkharid.MablaghPardakhtShodeHadieAzKifPolAsli, "کیف پول استفاده شده", GridPaging.Columns - 1);
                            if (sabadkharid.MablaghPardakhtShode > 0)
                                HTMLPARDAKHTI += AddFooterForGrid(sabadkharid.MablaghPardakhtShode, "مبلغ پرداختی از درگاه بانک", GridPaging.Columns - 1);


                            tr.Dsc = "خرید انجام شد";
                            tr.STATE = "SECCESS";
                            tr.Info = Html_Info;

                            try
                            {

                                //foreach (var o in sabadkharid.SabadKharidItems)
                                //{
                                //    o.DateSabt_Fa = o.SabadKharid.DateSabtSefareshKharid_Fa;
                                //    o.TimeSabt_Fa = o.SabadKharid.TimeSabtSefareshKharid_Fa;
                                //    o.DateTimeSabt = o.SabadKharid.DateTimeSabtSefareshKharid.Value;
                                //    //o.MablaghHadie_EndMonth = (o.PriceVahed * o.Count * (o.Price.IsPriceAsli ? o.DarsadHadie_EndMonth : 0)) / 100;
                                //    //o.MablaghHadie_EndMonth = sabadkharid.MablaghHadieDaryafti_EndMonth == 0 ? 0 : (o.MablaghHadie_EndMonth * o.MablaghHadie_EndMonth) / (sabadkharid.MablaghHadieDaryafti_EndMonth);

                                //    //o.MablaghHadie_AllMonth = (o.PriceVahed * o.Count * (o.Price.IsPriceAsli ? o.DarsadHadie_AllMonth : 0)) / 100;
                                //    //o.MablaghHadie_AllMonth = sabadkharid.MablaghHadieDaryafti_AllMonth == 0 ? 0 : (o.MablaghHadie_AllMonth * o.MablaghHadie_AllMonth) / (sabadkharid.MablaghHadieDaryafti_AllMonth);



                                //}
                                tr.mablaghPardakhtShode = sabadkharid.MablaghPardakhtShode;
                                tr.mablaghGahbelPardakht = sabadkharid.MablaghGhabelPardakht;
                                dc.SubmitChanges();
                                foreach (var o in sabadkharid.SabadKharidItems)
                                    FunctionMojodi.SETMOJODI(o.ProductId.ToString());
                            }
                            catch { }

                            dc.Transactions.InsertOnSubmit(tr);
                            dc.SubmitChanges();
                            return;
                        }
                        else
                        {
                            Html_Info = "<center>" + "خطا، مبلغ  قابل پرداخت با مبلغ پرداخت شده برابر نمی باشد، مبلغ پرداخت شده بازگشت داده می شود،لطفا دوباره تلاش نمایید" + "</center>" + "</br>";
                            Html_Info += "شماره پیگیری : " + sabadkharid.CodeRahgiri + "</br>";

                            tr.Dsc = "مبلغ  قابل پرداخت با مبلغ پرداخت شده برابر نمی باشد، مبلغ پرداخت شده بازگشت داده می شود";
                            tr.STATE = "NO_EQUALS_PARDAKHTSHODE_GHABELPARDAKHT";
                            tr.Info = Html_Info;
                        }
                    }
                    else
                    {
                        Html_Info = "<center>" + "خطا، مبلغ  قابل پرداخت تغییر کرده است،لطفا دوباره تلاش نمایید" + "</center>" + "</br>";
                        Html_Info += "شماره پیگیری : " + sabadkharid.CodeRahgiri + "</br>";

                        tr.Dsc = "مبلغ قابل پرداخت از صفحه تایید نهایی تا این صفحه انجام خرید سبد خرید تغییر کرده است";
                        tr.STATE = "NO_EQUALS_OLDGHABELPARDAKHT_GHABELPARDAKHT";
                        tr.Info = Html_Info;
                    }
                }
                else
                {
                    Html_Info = "<center>" + "خطا، عملیات خرید با مشکل روبه رو شده است لطفا دوباره تلاش نمایید" + "</center>" + "</br>";
                    Html_Info += "شماره پیگیری : " + sabadkharid.CodeRahgiri + "</br>";

                    tr.Dsc = "سبد خرید قبلا خریداری شده است";
                    tr.STATE = "GHABLAN_KHARID_SHODE_AST";
                    tr.Info = Html_Info;

                    ////خطاا
                }
            }
            catch (Exception ex)
            {
                Html_Info = "<center>" + "خطا، عملیات خرید با مشکل روبه رو شده است لطفا دوباره تلاش نمایید" + "</center>" + "</br>";
                tr.Dsc = ex.Message;
                tr.STATE = "EXCEPTION";
                tr.Info = Html_Info;
            }
            dc.Transactions.InsertOnSubmit(tr);
            dc.SubmitChanges();

        }

        private string AddFooterForGrid(decimal Mablagh, string Dsc, int colspan)
        {
            string str = "";

            str += "<tr  style=\"border: 1px solid #ccc;color:white !important\">    <td style=\"background-color:#695959;text-align:left;font-weight:bold;border-bottom-color:transparent\" colspan=\"" + colspan + "\"><span class=\"DisplayWhenTableXs_sm\">" + Dsc + " :</span></td> ";

            str += "    <td style=\"background-color:#695959;\" data-title=\"" + Dsc + "\"> " + Mablagh.ToString("###,##0") + " ریال</td> </tr>";

            return str;
        }
    }
}