﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_NotificatioSpecModel : CMasterPageModel
    {


        public string txtDsc = "";
        public string txtOnvan = "";
        public string txtDateTimeSend = "";

        public C_NotificatioSpecModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
            Displayinfo(routeData);
        }

        

        private void Displayinfo(RouteData routedate)
        {
            string ID = EmoNetUtility.GetQueryString("id", (string)routedate.Values["id"]);
            var obj = dc.Notifications.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
                return;
            txtDsc = ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? "" : obj.Price.MojodiProduct.Value.ToString("###,##0")) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_.ToString("###,##0") + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
            :
            (
            (obj.NotificationTypeId == ((int)NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
            :
            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
            :
            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
            :
            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))));
            txtOnvan = (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject);
            txtDateTimeSend = obj.DateCreate + " [" + obj.TimeCreate + "]";
        }





    }
}