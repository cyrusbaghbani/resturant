﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class C_NotificationModel : CMasterPageModel
    {
        public string txtDateAz = "";
        public string txtDateTa = "";
        public string hfContent = "0";
        public string cboRead = "";

        public GridPageNumber GridPaging = new GridPageNumber();
        public List<Notification> lst_content_Table = new List<Notification>();
        public string hf_SelectValueID = "";

        public C_NotificationModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
            Displayinfo();
        }

        public C_NotificationModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            this.Action = action_;
            Controll = controller_;
            BindFrom(frm);

        }

        private void Displayinfo()
        {
        }
        private void BindFrom(FormCollection frm)
        {
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"] == null ? "" : frm["hf_SelectValueID"].Trim());
            GridPaging = new GridPageNumber();
            txtDateAz = frm["txtDateAz"].ToString().Trim();
            txtDateTa = frm["txtDateTa"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            cboRead = frm["cboRead"].ToString().Trim();
        }

        public void Search()
        {


            lst_content_Table = new List<Notification>();

            var q = (from p in dc.Notifications
                     where
                     p.IsDeleted_Customer == false
                     &&

                     (
                     cboRead == ""
                     ||
                     (cboRead == "true" && p.IsRead == true)
                     ||
                     (cboRead == "false" && p.IsRead == false)
                     )
                     &&
                      (
                     txtDateAz == ""
                     ||
                     (p.DateCreate != null && p.DateCreate.Trim() != "" && p.DateCreate.CompareTo(txtDateAz) >= 0)
                     )
                     &&
                     (txtDateTa == ""
                     ||
                     (p.DateCreate != null && p.DateCreate.Trim() != "" && p.DateCreate.CompareTo(txtDateTa) <= 0)
                     )
                     &&
                    (
                   p.UserId == CurrentUser.UID
                    )
                     select p).OrderByDescending(s => s.DateCreate).ThenByDescending(s => s.TimeCreate).ToList();


            GridPaging.lst_headerName.Add("پیام");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("متن پیام");
            GridPaging.lst_headerName.Add("زمان");

            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 6 : 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();
        }

        public void Read()
        {

            var obj = dc.Notifications.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                return;
            }
            if (obj.IsRead == false)
            {
                obj.IsRead = true;
                obj.DateRead = DateShamsi.GetCurrentDate();
                obj.TimeRead = DateShamsi.GetCurrentHour();
                obj.UserRead_Id = CurrentUser.UID;

                string matn = ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? "" : obj.Price.MojodiProduct.Value.ToString("###,##0")) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_.ToString("###,##0") + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                              :
                              (
                              (obj.NotificationTypeId == ((int)NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                              :
                              ((obj.NotificationTypeId == ((int)NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                              :
                              ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                              :
                              ((obj.NotificationTypeId == ((int)NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))));

                dc.SubmitChanges();

                EventLog.Loging("پیام با عنوان '" + (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject) + "' با متن '" + matn + "' که در زمان '" + obj.DateCreate + " [" + obj.TimeCreate + "]" + "' ارسال گردیده بود" + " در زمان '" + obj.DateRead + " [" + obj.TimeRead + "]" + "' خوانده شد." + "", EventTypeIds.EDIT, "CNOTIFICATION", CurrentUser.UID);


            }


        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Notifications.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }

            obj.IsDeleted_Customer = true;
            string matn = ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? "" : obj.Price.MojodiProduct.Value.ToString("###,##0")) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_.ToString("###,##0") + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == ((int)NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == ((int)NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))));

            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            EventLog.Loging("پیام با عنوان '" + (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject) + "' با متن '" + matn + "' که در زمان '" + obj.DateCreate + " [" + obj.TimeCreate + "]" + "' ارسال گردیده بود" + " حذف گردید.", EventTypeIds.DELETE, "CNOTIFICATION", CurrentUser.UID);



        }



    }
}