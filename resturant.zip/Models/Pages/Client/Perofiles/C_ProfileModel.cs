﻿using App_Start.Utility;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace restauran.Models.Pages
{
    public class C_ProfileModel : CMasterPageModel
    {
        public string TxtUserName = "";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public string CODE_MOAREFI = "";
        public string txtCodeMeli = "";
        public string MablaghGiftsKol = "";
        public string MablaghAccountKol = "";
        public string txtOnvan = "";
        public C_ProfileModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);
            Display();
        }

        public C_ProfileModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            BindForms(frm);
        }
        private void Display()
        {
            if (CurrentUser != null)
            {
                TxtUserName = CurrentUser.UserName;
                TxtUserName = CurrentUser.UserName;
                CODE_MOAREFI = CurrentUser.CODE_MOAREFI;
                MablaghGiftsKol = CurrentUser.MablaghGiftsKol.ToString("###,##0");
                MablaghAccountKol = CurrentUser.MablaghAccountKol.ToString("###,##0");
                txtOnvan = CurrentUser.OnvaneSherkat;

                txtName = CurrentUser.FirstName;
                txtFamily = CurrentUser.LastName;
                txtMobile = CurrentUser.MobileNumber;
                txtTel = CurrentUser.Tel_BeHamrah_Code;
                txtCodeMeli = CurrentUser.CodeMeli;
                txtAddress = CurrentUser.Address;
                txtEmail = CurrentUser.Email;
            }
        }
        private void BindForms(FormCollection form)
        {
            if (CurrentUser != null)
            {

                TxtUserName = CurrentUser.UserName;
                CODE_MOAREFI = CurrentUser.CODE_MOAREFI;
                MablaghGiftsKol = CurrentUser.MablaghGiftsKol.ToString("###,##0");
                MablaghAccountKol = CurrentUser.MablaghAccountKol.ToString("###,##0");
                txtOnvan = form["txtOnvan"].ToString().Trim();

                txtCodeMeli = form["txtCodeMeli"].ToString().Trim();
                txtName = form["txtName"].ToString().Trim();
                txtFamily = form["txtFamily"].ToString().Trim();
                txtMobile = form["txtMobile"].ToString().Trim();
                txtTel = form["txtTel"].ToString().Trim();

                txtAddress = form["txtAddress"].ToString().Trim();
                txtEmail = form["txtEmail"].ToString().Trim();
            }
        }

        public void Save()
        {
            var obj = dc.users.Single(s => s.UID == CurrentUser.UID);

            obj.FirstName = txtName.Trim();
            obj.LastName = txtFamily.Trim();
            obj.MobileNumber = Validation.IsMobileNumber(txtMobile.Trim());
            obj.Tel_BeHamrah_Code = txtTel.Trim();
            obj.CodeMeli = txtCodeMeli.Trim();
            obj.Address = txtAddress.Trim();
            obj.Email = txtEmail.Trim();
            obj.OnvaneSherkat = txtOnvan.Trim();
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("اطلاعات وارد شده با موفقیت ذخیره شد.");


            if (Ischange)
                EventLog.Loging(" پروفایل کاربری با نام کاربری '" + obj.UserName + "' ویرایش گردید.", EventTypeIds.EDIT, "PROFILE_C", CurrentUser.UID);
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (txtCodeMeli.Trim() != "" && !Validation.IsNationalCode(txtCodeMeli.Trim()))
            {
                Msg += (i++) + " - " + "کد ملی را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (txtOnvan.Trim() == "")
            {
                Msg += (i++) + " - " + "عنوان مجموعه را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtName.Trim() == "")
            {
                Msg += (i++) + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtFamily.Trim() == "")
            {
                Msg += (i++) + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtMobile.Trim() == "" || Validation.IsMobileNumber(txtMobile.Trim()) == "")
            {
                Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                result = false;

            }

            if (txtEmail.Trim() != "" && !Validation.IsEmail(txtEmail.Trim()))
            {
                Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                result = false;
            }
            else if (txtEmail.Trim() != "")
            {
                if (dc.users.Any(S => S.UID != CurrentUser.UID && S.IsDeleted == false && S.Email == txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }
            if (txtAddress.Trim() == "")
            {
                Msg += (i++) + " - " + "آدرس را وارد نمایید." + "</br>";
                result = false;
            }


            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
    }
}