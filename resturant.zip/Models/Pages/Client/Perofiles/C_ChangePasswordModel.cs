﻿using App_Start.Utility;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace restauran.Models.Pages
{
    public class C_ChangePasswordModel : CMasterPageModel
    {
        string txtoldpass = "";
        string txtPass = "";
        string txtrepass = "";

        public C_ChangePasswordModel(user currentUser_, string PageName, string action_, string controller_, RouteData routeData, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, routeData);

        }

        public C_ChangePasswordModel(FormCollection frm, user currentUser_, string PageName, string action_, string controller_, Guid CurrentSabadKharidID)
        {
            this.Action = action_;
            this.Controll = controller_;
            Intialize(currentUser_, PageName, CurrentSabadKharidID, frm);
            BindForms(frm);
        }

        private void BindForms(FormCollection frm)
        {
            txtoldpass = frm["txtoldpass"].ToString();
            txtPass = frm["txtPass"].ToString();
            txtrepass = frm["txtrepass"].ToString();
        }

        public void Save()
        {
            var obj = dc.users.Single(s => s.UID == CurrentUser.UID);
            obj.Password = Utility.EncryptedQueryString.GetMD5Hash(txtPass);
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("رمز عبور با موفقیت تغییر یافت");

            if (Ischange)
                EventLog.Loging(" رمز عبور کاربری با نام کاربری '" + obj.UserName + "' ویرایش گردید.", EventTypeIds.EDIT, "CHANGEPASSWORD_C", CurrentUser.UID);
        }

        public bool CheckValidate()
        {
            bool result = true;
            string msg = "لطفا به نکات زیر توجه فرمایید" + "</br>";
            int i = 0;


            if (CurrentUser.Password != Utility.EncryptedQueryString.GetMD5Hash(txtoldpass))
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور قبلی وارد شده، نادرست می باشد." + "</br>";
            }

            if (txtPass == "")
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور جدید را وارد نمایید." + "</br>";
            }
            else if (txtPass.Length < 6)
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور باید حداقل دارای 6 حرف باشد." + "</br>";
            }
            else if (txtPass != txtrepass)
            {
                result = false;
                msg += (++i).ToString() + " - " + "رمز عبور جدید با تکرار آن یکسان نمی باشد." + "</br>";
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(msg);
            return result;
        }
    }
}