﻿using App_Start.Utility;
using Models.Controll;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Models.Pages
{
    public class M_SpecialModel : MasterPageModel
    {

       
        public string cboBrandID = "";
        public string cboProductTypeGroupID = "";
        public string hfContent = "0";
        public string txtStartDate = "";
        public string txtEndDate = "";
        public string hf_SelectValueID = "";

        public List<Brand> lst_Brand = new List<Brand>();
        public List<ProductType> lst_ProductType = new List<ProductType>();

        public List<KalaItem> lst_content_Table = new List<KalaItem>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_SpecialModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindCambos();
        }

        public M_SpecialModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindCambos();
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {

            cboBrandID = frm["cboBrandID"].ToString().Trim();
            cboProductTypeGroupID = frm["cboProductTypeGroupID"].ToString().Trim();
            txtStartDate = frm["txtStartDate"].ToString().Trim();
            txtEndDate = frm["txtEndDate"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<KalaItem>();

            string brandid = Utility.EncryptedQueryString.Decrypt(cboBrandID);
            string productTypeID = Utility.EncryptedQueryString.Decrypt(cboProductTypeGroupID);
            string start = DateShamsi.GetShamsiDateString(txtStartDate);
            string end = DateShamsi.GetShamsiDateString(txtEndDate);

            var q = (from p in dc.Prices
                     where
                     p.IsDeleted == false
                     &&
                     p.IsDarhalEngheza == true


                     &&
                     (
                           (cboBrandID.Trim() == ""
                           ||
                           (p.Product.BrandId != null && p.Product.BrandId.ToString() == brandid))
                           &&
                           (cboProductTypeGroupID.Trim() == ""
                           ||
                           (p.Product.ProductType.ParentId != null && p.Product.ProductType.ParentId.ToString() == productTypeID)
                           )
                           &&
                           (
                            start == ""
                            ||
                            (p.DatePayan != null && p.DatePayan.CompareTo(start) >= 0)
                           )
                           &&
                           (
                            end == ""
                            ||
                            (p.DateShoro != null && p.DateShoro.CompareTo(end) <= 0)
                           )

                     )
                     select p).OrderByDescending(s => s.DateShoro).ThenByDescending(s => s.DateSabt);


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("کالا");
            GridPaging.lst_headerName.Add("زمان شروع");
            GridPaging.lst_headerName.Add("زمان پایان");
            GridPaging.lst_headerName.Add("قیمت");
            GridPaging.lst_headerName.Add("تعداد کل");
            GridPaging.lst_headerName.Add("موجودی");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 9 : 8;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            var q1 = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();
            foreach (var item in q1)
            {

                var FestivalForokhteShode = item.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);

                var reserv = FestivalForokhteShode.Any(s => s.SabadKharid.IsKharid == false) ? FestivalForokhteShode.Where(s => s.SabadKharid.IsKharid == false).Sum(s => s.Count) : 0;
                var forokhteshod = FestivalForokhteShode.Any(s => s.SabadKharid.IsKharid == true) ? FestivalForokhteShode.Where(s => s.SabadKharid.IsKharid == true).Sum(s => s.Count) : 0;

                lst_content_Table.Add(new KalaItem()
                {
                    UID = item.UID,
                    FullName = ((item.Product.ProductTypeId != null ? ((item.Product.ProductType.ParentId == null ? "" : ((item.Product.ProductType.Parent.IsShowName ? item.Product.ProductType.Parent.Name : ""))) + " " + item.Product.ProductType.Name + " ") : "") + (item.Product.BrandId == null ? "" : item.Product.Brand.Name)),
                    DateShoro = item.DatetimeShoro_Persian,
                    DatePayan = item.DatetimePayan_Persian,
                    Price = item.Price_.ToString("###,##0") + " ریال",
                    TedadKol = item.MojodiProduct.Value.ToString("###,##0") + " " + item.Product.Unit.Name,
                    MOjodi = (item.MojodiProduct.Value - forokhteshod).ToString("###,##0") + (reserv == 0 ? "" : (" (" + reserv.ToString("###,##0") + ")")) + " " + item.Product.Unit.Name

                });
            }


        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false))
            {
                DisplayMessage.ShowErrorMessage("به دلیل اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }


            obj.IsDeleted = true;

            obj.Product.MojodiCount = obj.Product.MojodiCount + (decimal)obj.MojodiProduct;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید.");
           
            if (ischange)
                EventLog.Loging(" فروش ویژه کالای '" + ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name) + "' با قیمت '" + obj.Price_.ToString("###,##0") + "' ریال با شروع تاریخ '" + obj.DatetimeShoro_Persian + "' تا تاریخ '" + obj.DatetimePayan_Persian + "' با مقدار '" + obj.MojodiProduct + " " + obj.Product.Unit.Name + "' حذف گردید.", EventTypeIds.DELETE, "SPECIAL_M", CurrentUser.UID);
            FunctionMojodi.NOtificationToMinProd(obj.ProductId, "");
        }

        private void BindCambos()
        {

            lst_Brand = new List<Brand>();
            lst_Brand = dc.Brands.Where(s => s.IsDeleted == false).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lst_Brand.Insert(0, new Brand() { Id = -1, Name = "همه برند ها" });
            //
            lst_ProductType = new List<ProductType>();

            lst_ProductType = dc.ProductTypes.Where(s => s.IsDeleted == false && s.ParentId == null).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lst_ProductType.Insert(0, new ProductType() { Id = -1, Name = "همه ی دسته های کالا..." });



        }
    }
}