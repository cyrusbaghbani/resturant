﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_SpecialSpecModel : MasterPageModel
    {

        public string ID = "";
        public bool ShowBackProductsToAnbar = false;
        public string txtDateEnd = "";
        public string txtPrice = "";
        public string txtTedadKolMojodi = "";

        public string txtMojodiJariSpecial = "";
        public string txtMojodiJariProduct = "";
        public string hfINFOContent = "1";
        public string hfProductSelect = "";
        public string hfProductSelectNAME = "";
        public string txtTimeEnd = "";
        public bool IsShowBargashtMojodiBTN = false;

        public void BindForms(FormCollection form)
        {
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);
            hfProductSelect = form["hfProductSelect"].ToString().Trim();
            hfProductSelectNAME = form["hfProductSelectNAME"].ToString().Trim();
            hfINFOContent = form["hfINFOContent"].ToString().Trim();
            txtTedadKolMojodi = form["txtTedadKolMojodi"].ToString().Trim();
            txtPrice = form["txtPrice"].ToString().Trim();

            txtTimeEnd = form["txtTimeEnd"].ToString().Trim();
            txtDateEnd = form["txtDateEnd"].ToString().Trim();

            var product = dc.Products.SingleOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));
            if (product == null)
            {
                txtMojodiJariProduct = "";
            }
            else
            {
                decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(product.UID);
                txtMojodiJariProduct = product.MojodiCount + ((TedadReservMojodiKol == null || TedadReservMojodiKol == 0) ? "" : (" (" + TedadReservMojodiKol + " )")) + " " + product.Unit.Name;

            }
            if (obj == null)
            {

                txtMojodiJariSpecial = "";
            }
            else
            {

                var mojodiKharidariShode = obj.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                decimal mojodiKol_ = (decimal)obj.MojodiProduct;
                decimal kharidari_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
                decimal reserv_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
                txtMojodiJariSpecial = (mojodiKol_ - kharidari_shode).ToString() + (reserv_shode == 0 ? "" : (" (" + reserv_shode + ")")) + " " + obj.Product.Unit.Name;

                decimal mojodiBaghimande = (mojodiKol_ - kharidari_shode) - reserv_shode;

                if (mojodiBaghimande > 0)
                {
                    ShowBackProductsToAnbar = true;
                }

            }

        }
        private void DisplayInfo()
        {
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);

            if (obj == null)
            {

                return;
            }
            hfProductSelect = Utility.EncryptedQueryString.Encrypt(obj.ProductId.ToString());
            hfProductSelectNAME = obj.ProductId == null ? "" : (((obj.Product.ProductType.ParentId == null ? "" : ((obj.Product.ProductType.Parent.IsShowName ? obj.Product.ProductType.Parent.Name : ""))) + " " + (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name);

            txtTedadKolMojodi = obj.MojodiProduct == null ? "" : obj.MojodiProduct.Value.ToString("###,##0");
            txtPrice = obj.Price_.ToString("###,##0");
            txtTimeEnd = obj.TimePayan;
            txtDateEnd = obj.DatePayanEngheza;
            if (obj == null)
            {
                txtMojodiJariProduct = "";
                txtMojodiJariSpecial = "";
            }
            else
            {

                decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.ProductId);
                txtMojodiJariProduct = obj.Product.MojodiCount.ToString("###,##0") + ((TedadReservMojodiKol == null || TedadReservMojodiKol == 0) ? "" : (" (" + TedadReservMojodiKol.Value.ToString("###,##0") + " )")) + " " + obj.Product.Unit.Name; ;


                var mojodiKharidariShode = obj.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                decimal mojodiKol_ = (decimal)obj.MojodiProduct;
                decimal kharidari_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
                decimal reserv_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
                txtMojodiJariSpecial = (mojodiKol_ - kharidari_shode).ToString("###,##0") + (reserv_shode == 0 ? "" : (" (" + reserv_shode.ToString("###,##0") + ")")) + " " + obj.Product.Unit.Name;

          
                decimal mojodiBaghimande = (mojodiKol_ - kharidari_shode) - reserv_shode;

                if (mojodiBaghimande > 0)
                {
                    ShowBackProductsToAnbar = true;
                }


            }



        }

        public bool CheckValidateBargashtMojodi()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var price = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            var mojodiKharidariShode = price.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
            decimal mojodiKol_ = (decimal)price.MojodiProduct;
            decimal kharidari_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
            decimal reserv_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
            decimal mojodiBaghimande = (mojodiKol_ - kharidari_shode) - reserv_shode;

            if (mojodiBaghimande <= 0)
            {
                Msg += (i++).ToString() + " - " + "موجودی باقی مانده برابر صفر می باشد امکان انتقال به موجودی اصلی وجود ندارد." + "</br>";
                result = false;
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }

        public void BargashtMojodiBeAnbar()
        {
            var price = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);

            var mojodiKharidariShode = price.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
            decimal mojodiKol_ = (decimal)price.MojodiProduct;
            decimal kharidari_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
            decimal reserv_shode = mojodiKharidariShode.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShode.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
            decimal mojodiBaghimande = (mojodiKol_ - kharidari_shode) - reserv_shode;

            price.MojodiProduct = price.MojodiProduct - (int)mojodiBaghimande;
            price.Product.MojodiCount = price.Product.MojodiCount + mojodiBaghimande;
            dc.SubmitChanges();
            EventLog.Loging("مقدار '" + mojodiBaghimande +" "+price.Product.Unit.Name +"' از موجودی فروش ویژه کالای '" + ((price.Product.ProductType.ParentId != null ? (price.Product.ProductType.Parent.Name + " " + price.Product.ProductType.Name) : (price.Product.ProductType.Name)) + " " + price.Product.Brand.Name) + "' به موجودی کل کالا انتقال یافت. موجودی کل کالای جدید: '" + price.Product.MojodiCount + " " + price.Product.Unit.Name + "'", EventTypeIds.EDIT, "SPECIALSPEC_M", CurrentUser.UID);

        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var price = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            var product = dc.Products.FirstOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));
            if (product == null)
            {
                Msg += (i++).ToString() + " - " + "کالا را انتخاب نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (dc.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false && s.PriceID != null && s.PriceID.ToString() == ID && s.Price.ProductId != product.UID))
                {
                    Msg += (i++).ToString() + " - " + "امکان تغییر کالا وجود ندارد." + "</br>";
                    result = false;
                }
            }

            bool IsCheckWithTimeJari = true;
            string CurrentDate = Utility.DateShamsi.GetCurrentDate();
            string currentTime = Utility.DateShamsi.GetCurrentHour().Substring(0, 5);

            string enddate = DateShamsi.GetShamsiDateString(txtDateEnd);
            string endtime = DateShamsi.GetShamsiTimeString(txtTimeEnd);

            if (enddate == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ انقضاء را مشخص نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if (endtime == "")
            {
                Msg += (i++).ToString() + " - " + "زمان پایان را وارد نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if ((enddate != "" && CurrentDate.CompareTo(enddate) > 0))
            {
                Msg += (i++) + " - " + "تاریخ شروع باید از تاریخ پایان کوچکتر باشد." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            else if ((enddate != "" && CurrentDate.CompareTo(enddate) == 0 && endtime != "" && currentTime.CompareTo(endtime) > 0))
            {
                Msg += (i++) + " - " + "زمان شروع باید از زمان پایان کوچکتر باشد." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if (price != null && IsCheckWithTimeJari)
            {
                string dateMoghyase = DateShamsi.GetMixShamsiDateTimeString(CurrentDate, currentTime);
                string date = price.DatetimePayan_Persian.CompareTo(dateMoghyase) <= 0 ? price.DatetimePayan_Persian : "";
                dateMoghyase = date == "" ? dateMoghyase : date;
                string enddatetime_ = DateShamsi.GetMixShamsiDateTimeString(enddate, endtime);
                if (enddatetime_.CompareTo(dateMoghyase) < 0)
                {
                    Msg += (i++).ToString() + " - " + "تاریخ و زمان انقضاء از تاریخ و زمان " + (date == "" ? "جاری" : date) + " باید بزرگتر باشد." + "</br>";
                    result = false;
                }
            }


            int temp = 0;
            decimal Dtemp = 0;
            if (txtTedadKolMojodi == "" || !int.TryParse("0" + txtTedadKolMojodi.Replace(",", "").Replace("،", ""), out temp))
            {
                Msg += (i++).ToString() + " - " + "تعداد کل را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (product != null)
                {
                    decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(product == null ? Guid.Empty : product.UID);
                    TedadReservMojodiKol = TedadReservMojodiKol == null ? 0 : TedadReservMojodiKol;
                    Dtemp = (decimal)temp;
                    var obj = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);
                    if (obj != null && obj.ProductId == product.UID)
                    {

                        decimal tedadKharidariShodeha = obj.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false) ? obj.SabadKharidItems.Sum(s => s.Count) : 0;

                        if (Dtemp - tedadKharidariShodeha < 0)
                        {
                            Msg += (i++).ToString() + " - " + "تعداد \"" + tedadKharidariShodeha + "\" " + obj.Product.Unit.Name + " از این کالا توسط مشتری ها خریداری و رزرو شده است." + "." + "</br>";
                            result = false;
                        }
                        if ((obj.Product.MojodiCount - TedadReservMojodiKol) + (obj.MojodiProduct - Dtemp) < 0)
                        {
                            Msg += (i++).ToString() + " - " + "تعداد کل از موجودی جاری کالا بیشتر می باشد." + "</br>";
                            result = false;
                        }
                    }
                    else
                    {
                        if (product != null)
                        {
                            if ((product.MojodiCount - TedadReservMojodiKol) - Dtemp < 0)
                            {
                                Msg += (i++).ToString() + " - " + "تعداد کل از موجودی جاری کالا بیشتر می باشد." + "</br>";
                                result = false;
                            }
                        }
                    }
                }

            }
            if (txtPrice == "" || !decimal.TryParse("0" + txtPrice.Replace(",", "").Replace("،", ""), out Dtemp))
            {

                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else if (Dtemp <= 0)
            {
                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح و بزرگتر از صفر وارد نمایید." + "</br>";
                result = false;
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Price();
                obj.UID = Guid.NewGuid();
                obj.IsDeleted = false;
                obj.IsDarhalEngheza = true;
                obj.DateSabt = DateTime.Now;
                obj.DateShoro = DateShamsi.GetCurrentDate();
                obj.TimeShoro = DateShamsi.GetCurrentHour().Substring(0, 5);
                obj.DatetimeShoro_Persian = DateShamsi.GetMixShamsiDateTimeString(obj.DateShoro, obj.TimeShoro);
                dc.Prices.InsertOnSubmit(obj);
                IsEdit = false;
            }

            var prod = dc.Products.FirstOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));

            if (IsEdit == true)
            {
                if (obj.ProductId != Guid.Empty && obj.ProductId != prod.UID)
                {
                    obj.Product.MojodiCount += (decimal)obj.MojodiProduct;
                    prod.MojodiCount -= (decimal)obj.MojodiProduct;
                }
            }

            int? OLDMojodiProduct = obj.MojodiProduct;
            decimal OldPrice_ = obj.Price_;
            string OldDateShoro = obj.DatetimeShoro_Persian;
            string OldDatePayan = obj.DatetimePayan_Persian;
            string OLDProduct = obj.Product == null ? "" : ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name);

            obj.Product = prod;
            obj.MojodiProduct = int.Parse("0" + txtTedadKolMojodi.Replace(",", "").Replace("،", ""));
            if (IsEdit == false)
                obj.Product.MojodiCount -= (decimal)obj.MojodiProduct;
            else
                obj.Product.MojodiCount += (decimal)(OLDMojodiProduct - obj.MojodiProduct);


            obj.Price_ = decimal.Parse("0" + txtPrice.Replace(",", "").Replace("،", ""));
            obj.DatePayanEngheza = obj.DatePayan = DateShamsi.GetShamsiDateString(txtDateEnd);
            obj.TimePayan = txtTimeEnd;
            obj.DatetimePayan_Persian = DateShamsi.GetMixShamsiDateTimeString(txtDateEnd, txtTimeEnd);

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" فروش ویژه کالای '" + ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name) + "' با قیمت '" + obj.Price_.ToString("###,##0") + "' ریال با شروع تاریخ '" + obj.DatetimeShoro_Persian + "' تا تاریخ '" + obj.DatetimePayan_Persian + "' با مقدار '" + obj.MojodiProduct + " " + obj.Product.Unit.Name + "' درج گردید.", EventTypeIds.SAVE, "SPECIALSPEC_M", CurrentUser.UID);

            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" فروش ویژه کالای '" + ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name) + "' با قیمت '" + obj.Price_.ToString("###,##0") + "' ریال با شروع تاریخ '" + obj.DatetimeShoro_Persian + "' تا تاریخ '" + obj.DatetimePayan_Persian + "' با مقدار '" + obj.MojodiProduct + " " + obj.Product.Unit.Name + "' ویرایش گردید. ( کالای '" + OLDProduct + "' قیمت '" + OldPrice_.ToString("###,##0") + "' ریال با شروع تاریخ '" + OldDateShoro + "' تا تاریخ '" + OldDatePayan + "' با مقدار '" + OLDMojodiProduct + " " + obj.Product.Unit.Name + "' )", EventTypeIds.EDIT, "SPECIALSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");
            FunctionMojodi.NOtificationToMinProd(obj.ProductId, "");

        }
        public M_SpecialSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();

            DisplayInfo();
        }

        public M_SpecialSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindForms(frm);
        }



    }
}