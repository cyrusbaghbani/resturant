﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_FestivalPublicSpecModel : MasterPageModel
    {

        public string ID = "";
        public string txtDateStart = "";
        public string txtDateEnd = "";
        public string txtTimeStart = "";
        public string txtTimeEnd = "";

        public string txtPrice = "";
        public string txtTedadTakhfif = "";

        public string txtMojodiJariTakhfif = "";
        public string txtMojodiJariProduct = "";
        public string hfINFOContent = "1";
        public string hfProductSelect = "";
        public string hfProductSelectNAME = "";


        public void BindForms(FormCollection form)
        {
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);
            hfProductSelect = form["hfProductSelect"].ToString().Trim();
            hfProductSelectNAME = form["hfProductSelectNAME"].ToString().Trim();
            hfINFOContent = form["hfINFOContent"].ToString().Trim();
            txtTedadTakhfif = form["txtTedadTakhfif"].ToString().Trim();
            txtPrice = form["txtPrice"].ToString().Trim();
            txtDateStart = form["txtDateStart"].ToString().Trim();
            txtDateEnd = form["txtDateEnd"].ToString().Trim();
            txtTimeStart = form["txtTimeStart"].ToString().Trim();
            txtTimeEnd = form["txtTimeEnd"].ToString().Trim();
            var product = dc.Products.SingleOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));
            if (product == null)
            {
                txtMojodiJariProduct = "";
            }
            else
            {
                decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(product.UID);
                txtMojodiJariProduct = product.MojodiCount + ((TedadReservMojodiKol == null || TedadReservMojodiKol == 0) ? "" : (" (" + TedadReservMojodiKol + " )")) + " " + product.Unit.Name; ;

            }
            if (obj == null)
            {

                txtMojodiJariTakhfif = "";
            }
            else
            {

                var mojodiKharidariShodeTakhfif = obj.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                decimal mojodiKol_takhfif = (decimal)obj.MojodiProduct;
                decimal kharidari_shode = mojodiKharidariShodeTakhfif.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShodeTakhfif.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
                decimal reserv_shode = mojodiKharidariShodeTakhfif.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShodeTakhfif.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
                txtMojodiJariTakhfif = (mojodiKol_takhfif - kharidari_shode).ToString() + (reserv_shode == 0 ? "" : (" (" + reserv_shode + ")")) + " " + obj.Product.Unit.Name; ;
            }

        }
        private void DisplayInfo()
        {
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);

            if (obj == null)
            {
                txtDateStart = DateShamsi.GetCurrentDate();
                return;
            }
            hfProductSelect = Utility.EncryptedQueryString.Encrypt(obj.ProductId.ToString());
            hfProductSelectNAME = obj.ProductId == null ? "" : (((obj.Product.ProductType.ParentId == null ? "" : ((obj.Product.ProductType.Parent.IsShowName ? obj.Product.ProductType.Parent.Name : ""))) + " " + (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name);

            txtTedadTakhfif = obj.MojodiProduct == null ? "" : obj.MojodiProduct.Value.ToString("###,##0");
            txtPrice = obj.Price_.ToString("###,##0");
            txtDateStart = obj.DateShoro;
            txtDateEnd = obj.DatePayan;
            txtTimeStart = obj.TimeShoro;
            txtTimeEnd = obj.TimePayan;
            if (obj == null)
            {
                txtMojodiJariProduct = "";
                txtMojodiJariTakhfif = "";
            }
            else
            {

                decimal? TedadReservMojodiKol = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.ProductId);
                txtMojodiJariProduct = obj.Product.MojodiCount.ToString("###,##0") + ((TedadReservMojodiKol == null || TedadReservMojodiKol == 0) ? "" : (" (" + TedadReservMojodiKol.Value.ToString("###,##0") + " )")) + " " + obj.Product.Unit.Name ;


                var mojodiKharidariShodeTakhfif = obj.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false);
                decimal mojodiKol_takhfif = (decimal)obj.MojodiProduct;
                decimal kharidari_shode = mojodiKharidariShodeTakhfif.Any(s => s.SabadKharid.IsKharid == true) ? mojodiKharidariShodeTakhfif.Where(s => s.SabadKharid.IsKharid == true).Sum(s => (decimal)s.Count) : 0;
                decimal reserv_shode = mojodiKharidariShodeTakhfif.Any(s => s.SabadKharid.IsKharid == false) ? mojodiKharidariShodeTakhfif.Where(s => s.SabadKharid.IsKharid == false).Sum(s => (decimal)s.Count) : 0;
                txtMojodiJariTakhfif = (mojodiKol_takhfif - kharidari_shode).ToString("###,##0") + (reserv_shode == 0 ? "" : (" (" + reserv_shode.ToString("###,##0") + ")")) + " " + obj.Product.Unit.Name; 
            }

        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var price = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            var product = dc.Products.FirstOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));
            if (product == null)
            {
                Msg += (i++).ToString() + " - " + "کالا را انتخاب نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (dc.Prices.Any(s => s.UID.ToString() == ID && s.ProductId != product.UID && s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false)))
                {
                    Msg += (i++).ToString() + " - " + "امکان تغییر کالا وجود ندارد." + "</br>";
                    result = false;
                }
            }
            string startdate = DateShamsi.GetShamsiDateString(txtDateStart);
            string enddate = DateShamsi.GetShamsiDateString(txtDateEnd);


            bool IsCheckWithTimeJari = true;
            string starttime = DateShamsi.GetShamsiTimeString(txtTimeStart);
            string endtime = DateShamsi.GetShamsiTimeString(txtTimeEnd);
            if (startdate == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع را مشخص نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            else if (price == null && startdate.CompareTo(DateShamsi.GetCurrentDate()) < 0)
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع از تاریخ جاری باید بزرگتر باشد." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if (starttime == "")
            {
                Msg += (i++).ToString() + " - " + "زمان شروع را مشخص نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if (price != null && IsCheckWithTimeJari)
            {
               
                string datetimeMoghyase = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentDate().Substring(0,5));
                string date = price.DatetimeShoro_Persian.CompareTo(datetimeMoghyase) <= 0 ? price.DatetimeShoro_Persian : "";

                datetimeMoghyase = date == "" ? datetimeMoghyase : date;

                string startdatetime_ = DateShamsi.GetMixShamsiDateTimeString(startdate, starttime);
                if (startdatetime_.CompareTo(datetimeMoghyase) < 0 )
                {
                    Msg += (i++).ToString() + " - " + "تاریخ و زمان شروع از تاریخ وزمان " + (date == "" ? "جاری" : date) + " باید بزرگتر باشد." + "</br>";
                    result = false;
                }
            }


            if (enddate == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ پایان را وارد نمایید." + "</br>";
                result = false;
            }
            if (endtime == "")
            {
                Msg += (i++).ToString() + " - " + "زمان پایان را وارد نمایید." + "</br>";
                result = false;
            }
            if ((startdate != "" && enddate != "" && startdate.CompareTo(enddate) > 0))
            {
                Msg += (i++) + " - " + "تاریخ شروع باید از تاریخ پایان کوچکتر باشد." + "</br>";
                result = false;
            }
            else if ((startdate != "" && enddate != "" && startdate.CompareTo(enddate) == 0 && starttime != "" && endtime != "" && starttime.CompareTo(endtime) < 0))
            {
                Msg += (i++) + " - " + "زمان شروع باید از زمان پایان کوچکتر باشد." + "</br>";
                result = false;
            }
            int temp = 0;
            decimal Dtemp = 0;
            if (txtTedadTakhfif == "" || !int.TryParse("0" + txtTedadTakhfif.Replace(",", "").Replace("،", ""), out temp))
            {
                Msg += (i++).ToString() + " - " + "تعداد تخفیف را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else
            {
                var obj = dc.Prices.FirstOrDefault(s => s.UID.ToString() == ID);
                if (obj != null)
                {
                    decimal tedadKharidariShodeha = obj.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false) ? obj.SabadKharidItems.Sum(s => s.Count) : 0;
                    Dtemp = (decimal)temp;
                    if (Dtemp - tedadKharidariShodeha < 0)
                    {
                        Msg += (i++).ToString() + " - " + "تعداد \"" + tedadKharidariShodeha + "\" " + obj.Product.Unit.Name + " از این کالا توسط مشتری ها خریداری و رزرو شده است." + "." + "</br>";
                        result = false;
                    }
                }
            }
            if (txtPrice == "" || !decimal.TryParse("0" + txtPrice.Replace(",", "").Replace("،", ""), out Dtemp))
            {

                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else if (Dtemp <= 0)
            {
                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح و بزرگتر از صفر وارد نمایید." + "</br>";
                result = false;
            }
            if (result)
            {
                startdate = DateShamsi.GetMixShamsiDateTimeString(startdate, starttime);
                enddate = DateShamsi.GetMixShamsiDateTimeString(enddate, endtime);
                bool Find_Any_HasTakhfif = dc.Prices.Any(s => s.IsDeleted == false && s.UID.ToString() != ID && s.ProductId == product.UID && s.IsTakhfifOmomi == true
                  &&
                  (
                  (s.DatetimeShoro_Persian.CompareTo(startdate) >= 0 && s.DatetimeShoro_Persian.CompareTo(enddate) <= 0)
                  ||
                  (s.DatetimePayan_Persian.CompareTo(startdate) >= 0 && s.DatetimePayan_Persian.CompareTo(enddate) <= 0)
                  ||
                  (s.DatetimeShoro_Persian.CompareTo(startdate) >= 0 && s.DatetimePayan_Persian.CompareTo(enddate) <= 0)
                  ||
                  (s.DatetimeShoro_Persian.CompareTo(startdate) <= 0 && s.DatetimePayan_Persian.CompareTo(enddate) >= 0)

                  )

                  );
                if (Find_Any_HasTakhfif)
                {
                    Msg += (i++).ToString() + " - " + "در بازه انتخاب شده برای جشنواره ، جشنواره عمومی دیگری از همین کالا قبلا ثبت شده است." + "</br>";
                    result = false;
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.Prices.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Price();
                obj.UID = Guid.NewGuid();
                obj.IsDeleted = false;
                obj.IsTakhfifOmomi = true;
                obj.DateSabt = DateTime.Now;
                dc.Prices.InsertOnSubmit(obj);
                IsEdit = false;
            }

            int? OLDMojodiProduct = obj.MojodiProduct;
            decimal OldPrice_ = obj.Price_;
            string OldDateShoro = obj.DatetimeShoro_Persian;
            string OldDatePayan = obj.DatetimePayan_Persian;
            string OLDProduct = obj.Product == null ? "" : ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name);

            obj.Product = dc.Products.FirstOrDefault(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfProductSelect));
            obj.MojodiProduct = int.Parse("0" + txtTedadTakhfif.Replace(",", "").Replace("،", ""));
            obj.Price_ = decimal.Parse("0" + txtPrice.Replace(",", "").Replace("،", ""));
            obj.DateShoro = DateShamsi.GetShamsiDateString(txtDateStart);
            obj.DatePayan = DateShamsi.GetShamsiDateString(txtDateEnd);
            obj.TimeShoro = DateShamsi.GetShamsiTimeString(txtTimeStart);
            obj.TimePayan = DateShamsi.GetShamsiTimeString(txtTimeEnd);
            obj.DatetimeShoro_Persian = DateShamsi.GetMixShamsiDateTimeString(obj.DateShoro, obj.TimeShoro);
            obj.DatetimePayan_Persian = DateShamsi.GetMixShamsiDateTimeString(obj.DatePayan, obj.TimePayan);

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" جشنواره عمومی کالای '" + ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name) + "' با قیمت '" + obj.Price_.ToString("###,##0") + "' ریال با شروع تاریخ '" + obj.DatetimeShoro_Persian + "' تا تاریخ '" + obj.DatetimePayan_Persian + "' با مقدار '" + obj.MojodiProduct + " " + obj.Product.Unit.Name + "' درج گردید.", EventTypeIds.SAVE, "FESTIVALPUBLICSPEC_M", CurrentUser.UID);

            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" جشنواره عمومی کالای '" + ((obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name) + "' با قیمت '" + obj.Price_.ToString("###,##0") + "' ریال با شروع تاریخ '" + obj.DatetimeShoro_Persian + "' تا تاریخ '" + obj.DatetimePayan_Persian + "' با مقدار '" + obj.MojodiProduct + " " + obj.Product.Unit.Name + "' ویرایش گردید. ( کالای '" + OLDProduct + "' قیمت '" + OldPrice_.ToString("###,##0") + "' ریال با شروع تاریخ '" + OldDateShoro + "' تا تاریخ '" + OldDatePayan + "' با مقدار '" + OLDMojodiProduct + " " + obj.Product.Unit.Name + "' )", EventTypeIds.EDIT, "FESTIVALPUBLICSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_FestivalPublicSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();

            DisplayInfo();
        }

        public M_FestivalPublicSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindForms(frm);
        }



    }
}