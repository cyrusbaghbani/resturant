﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_CustomerSpecModel : MasterPageModel
    {

        public string ID = "";
        public string IsSexMan = "";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtBirthDate = "";
        public string txtDSC = "";
        public string cboRoleSelect = "";
        public string cboSelectVisitor = "";
        public string cboUserTypeSelect = "";
        public string cboMantagheSelect = "";
        public string txtCodeMeli = "";
        public string txtHadieAvalie = "";


        public string MablaghAccountKol = "0";
        public string MablaghGiftsKol = "0";
        public string MablaghGiftsKol_EndMonth = "0";
        public string CODE_MOAREFI = "";
        public string txtOnvan = "";

        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public string hfINFOContent = "1";
        public string hfUserContent = "1";

        public string IsActive = "true";
        public string txtUSERName = "";
        public string txtpass = "";
        public string txtRePass = "";

        public List<Role> lstRole = new List<Role>();
        public List<UserType> lstUserType = new List<UserType>();
        public List<Mantaghe> lstMantaghe = new List<Mantaghe>();
        public List<user> lstVisitor = new List<user>();
        public void BindForms(FormCollection form)
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            IsSexMan = form["CboSex"].ToString().Trim();
            txtName = form["txtName"].ToString().Trim();
            txtFamily = form["txtFamily"].ToString().Trim();
            txtMobile = form["txtMobile"].ToString().Trim();
            txtTel = form["txtTel"].ToString().Trim();
            txtDSC = form["txtDSC"].ToString().Trim();
            txtHadieAvalie = form["txtHadieAvalie"] == null ? null : form["txtHadieAvalie"].ToString().Trim();

            //cboRoleSelect = form["CboRole"].ToString().Trim();

            cboMantagheSelect = form["cboMantagheSelect"].ToString().Trim();
            cboSelectVisitor = form["cboSelectVisitor"].ToString().Trim();

            txtOnvan = form["txtOnvan"].ToString().Trim();

            txtBirthDate = form["txtBirthDate"].ToString().Trim();

            MablaghAccountKol = obj == null ? "0" : obj.MablaghAccountKol.ToString("###,##0");
            MablaghGiftsKol = obj == null ? "0" : obj.MablaghGiftsKol.ToString("###,##0");
            MablaghGiftsKol_EndMonth = obj == null ? "0" : obj.MablaghGifts_EndMonth_KOL.ToString("###,##0");

            CODE_MOAREFI = obj == null ? "" : obj.CODE_MOAREFI;

            txtTelCode = form["txtTel"].ToString().Trim();
            txtAddress = form["txtAddress"].ToString().Trim();
            txtEmail = form["txtEmail"].ToString().Trim();

            hfINFOContent = form["hfINFOContent"].ToString().Trim();



            if (security.Is_ShowForVisitor)
            {
                cboUserTypeSelect = form["cboUserType"].ToString().Trim();
                txtCodeMeli = form["txtCodeMeli"].ToString().Trim();

                hfUserContent = form["hfUserContent"].ToString().Trim();

                IsActive = form["CboActive"].ToString().Trim().ToLower();
                txtUSERName = form["txtUSERName"] == null ? (obj == null ? "" : obj.UserName) : form["txtUSERName"].ToString().Trim();
                txtpass = form["txtpass"] == null ? "" : form["txtpass"].ToString();
                txtRePass = form["txtRePass"] == null ? "" : form["txtRePass"].ToString();
            }
        }
        private void BindRole()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            int? obj_RoleID = obj == null ? (int?)null : obj.RoleId;

            lstRole = dc.Roles.Where(s => (s.IsShow == true && s.IsMenagment == false && s.IsDeleted == false) || s.Id == obj_RoleID).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstRole.Insert(0, new Role() { Id = -1, Name = "نقش را انتخاب کنید..." });
        }
        private void BindVisitor()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            Guid? obj_VisitorD = obj == null ? (Guid?)Guid.Empty : (obj.VisitorUserID == null ? Guid.Empty : obj.VisitorUserID.Value);

            lstVisitor = dc.users.Where(s => (s.IsDeleted == false && s.RoleId == RoleIds.M_Visitor) || s.UID == obj_VisitorD).OrderBy(s => s.FullName).ToList();
            lstVisitor.Insert(0, new user() { UID = Guid.Empty, FullName = "ویزیتور را انتخاب کنید...", FirstName = "ویزیتور را انتخاب کنید...", LastName = "" });
        }
        private void BindMantaghe()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            int? obj_MantagheID = obj == null ? (int?)null : obj.MantagheId;

            lstMantaghe = dc.Mantaghes.Where(s => (s.IsDeleted == false) || s.Id == obj_MantagheID).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstMantaghe.Insert(0, new Mantaghe() { Id = -1, Name = "منطقه را انتخاب کنید..." });
        }
        private void BindUserType()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            int? obj_UserTypeID = obj == null ? (int?)null : obj.UserTypeID;

            lstUserType = dc.UserTypes.Where(s => (s.IsDeleted == false) || s.Id == obj_UserTypeID).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.name).ToList();
            lstUserType.Insert(0, new UserType() { Id = -1, name = "نوع مشتری را انتخاب کنید..." });
        }
        private void DisplayPersonel()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
                return;
            txtDSC = obj.Dsc;
            IsSexMan = obj.Is_SexMan == null ? "" : obj.Is_SexMan.ToString().ToLower();
            txtName = obj.FirstName;
            txtFamily = obj.LastName;
            txtMobile = obj.MobileNumber;
            txtTel = obj.Tel_BeHamrah_Code;
            txtBirthDate = obj.BirthDate;

            cboRoleSelect = Utility.EncryptedQueryString.Encrypt(obj.RoleId.ToString());
            cboUserTypeSelect = obj.UserTypeID == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.UserTypeID.ToString());
            cboMantagheSelect = obj.MantagheId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.MantagheId.ToString());
            cboSelectVisitor = obj.VisitorUserID == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.VisitorUserID.ToString());

            txtCodeMeli = obj.CodeMeli;
            txtAddress = obj.Address;
            txtEmail = obj.Email;
            txtOnvan = obj.OnvaneSherkat;
            MablaghAccountKol = obj.MablaghAccountKol.ToString("###,##0");
            MablaghGiftsKol = obj.MablaghGiftsKol.ToString("###,##0");

            MablaghGiftsKol_EndMonth = obj.MablaghGifts_EndMonth_KOL.ToString("###,##0");

            CODE_MOAREFI = obj.CODE_MOAREFI == null ? "" : obj.CODE_MOAREFI;
            IsActive = obj.IsActive.ToString().Trim().ToLower();
            txtUSERName = obj.UserName;


        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            if (txtOnvan == "")
            {
                Msg += (i++).ToString() + " - " + "عنوان مجموعه را وارد نمایید." + "</br>";
                result = false;
            }

            if (txtName == "")
            {
                Msg += (i++).ToString() + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtFamily == "")
            {
                Msg += (i++).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (security.Is_ShowForVisitor)
            {
                if (txtCodeMeli.Trim() != "" && !Validation.IsNationalCode(txtCodeMeli.Trim()))
                {
                    Msg += (i++) + " - " + "کد ملی را صحیح وارد نمایید." + "</br>";
                    result = false;
                }
            }
            if (txtBirthDate != "" && DateShamsi.GetShamsiDateString(txtBirthDate) == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ تولد را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            var visitorid = Utility.EncryptedQueryString.Decrypt(cboSelectVisitor);
            if (!dc.users.Any(s => s.UID.ToString() == visitorid))
            {
                Msg += (i++).ToString() + " - " + "ویزیتور را انتخاب نمایید" + "</br>";
                result = false;
            }
            //var roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            //if (!dc.Roles.Any(s => s.Id.ToString() == roleid && s.IsMenagment == false))
            //{
            //    Msg += (i++).ToString() + " - " + "سطح دسترسی را انتخاب نمایید" + "</br>";
            //    result = false;
            //}
            if (security.Is_ShowForVisitor)
            {
                var usertypeid = Utility.EncryptedQueryString.Decrypt(cboUserTypeSelect);
                if (!dc.UserTypes.Any(s => s.Id.ToString() == usertypeid))
                {
                    Msg += (i++).ToString() + " - " + "نوع مشتری را انتخاب نمایید" + "</br>";
                    result = false;
                }
            }
            decimal temp = 0;
            if (txtHadieAvalie != null && (!decimal.TryParse("0" + txtHadieAvalie.Replace(",", "").Replace("،", ""), out temp)))
            {

                Msg += (i++).ToString() + " - " + "مبلغ هدیه را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (txtMobile.Trim() == "" || Validation.IsMobileNumber(txtMobile.Trim()) == "")
            {
                Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                result = false;

            }
            if (txtAddress == "")
            {
                Msg += (i++).ToString() + " - " + "آدرس را وارد نمایید." + "</br>";
                result = false;
            }

            if (txtEmail.Trim() != "" && !Validation.IsEmail(txtEmail.Trim()))
            {
                Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                result = false;
            }
            else if (txtEmail.Trim() != "")
            {
                if (dc.users.Any(S => S.UID != CurrentUser.UID && S.IsDeleted == false && S.Email == txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }

            if (security.Is_ShowForVisitor)
            {
                if (IsActive == "true")
                {
                    if (txtUSERName == "")
                    {
                        Msg += (i++).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                        result = false;
                    }
                    else
                    {
                        if (dc.users.Any(s => s.UID.ToString() != ID && s.IsDeleted == false && s.IsActive == true && s.UserName == txtUSERName))
                        {
                            Msg += (i++).ToString() + " - " + "نام کاربری در سیستم باید یکتا باشد." + "</br>";
                            result = false;
                        }
                    }
                    var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
                    if (obj == null || obj.Password == null || obj.Password == "")
                    {
                        if (txtpass == "")
                        {
                            Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                            result = false;
                        }
                        if (txtRePass == "")
                        {
                            Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                            result = false;
                        }
                        if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                        {
                            Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                            result = false;
                        }
                    }
                    else
                    {
                        if (txtpass == "" && txtRePass != "")
                        {
                            Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                            result = false;
                        }
                        if (txtpass != "" && txtRePass == "")
                        {
                            Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                            result = false;
                        }
                        if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                        {
                            Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                            result = false;
                        }
                    }
                }
                if (IsActive == "false")
                {
                    if (ID == CurrentUser.UID.ToString())
                    {
                        Msg += (i++).ToString() + " - " + "اجازه غیر فعال کردن نام کاربری خود را ندارید." + "</br>";
                        result = false;
                    }
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            string msgPayment = "";
            bool IsEdit = true;
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new user();
                obj.UID = Guid.NewGuid();
                obj.IsDeleted = false;
                obj.Password = "";
                obj.UserName = "";
                obj.CODE_MOAREFI = ImportentFunction.GetCodeMoarefi();

                dc.users.InsertOnSubmit(obj);
                IsEdit = false;

                decimal hadieAvalie = decimal.Parse("0" + txtHadieAvalie.Replace(",", "").Replace("،", ""));
                if (hadieAvalie > 0)
                {
                    obj.MablaghGiftsKol = hadieAvalie;
                    var pay = new Payment();
                    pay.DatePersianSabt = DateShamsi.GetCurrentDate();
                    pay.TimePersianSabt = DateShamsi.GetCurrentHour();
                    pay.DateTimeSabt = DateTime.Now;
                    pay.IsGift = true;
                    pay.IsGift_EndMonth = false;
                    pay.MablaghKol = obj.MablaghGiftsKol;
                    pay.IsVariz = true;
                    pay.UID = Guid.NewGuid();
                    pay.UserAccountId = obj.UID;
                    pay.DSC = "هدیه خوش آمد گویی";
                    pay.UserPardakhKonandeID = CurrentUser.UID;
                    pay.MablaghVariziYaBardashti = hadieAvalie;
                    dc.Payments.InsertOnSubmit(pay);
                    msgPayment = "مبلغ '" + hadieAvalie + "' ریال به عنوان هدیه اولیه به کیف پول '" + txtName.Trim() + " " + txtFamily.Trim() + " [" + txtOnvan.Trim() + "] " + "' تزریق شد. ";
                }

                Notification noti = new Notification();
                noti.DateCreate = DateShamsi.GetCurrentDate();
                noti.TimeCreate = DateShamsi.GetCurrentHour();
                noti.NotificationTypeId = NotificationTypeIDs.KhoshamadGoie_custmers;
                noti.UID = Guid.NewGuid();
                noti.GruopIDs = Guid.NewGuid();
                noti.SenderID = null;
                noti.userNotificationsMalek = obj;
                dc.Notifications.InsertOnSubmit(noti);
            }

            obj.BirthDate = DateShamsi.GetShamsiDateString(txtBirthDate);

            obj.Is_SexMan = IsSexMan == "" ? (bool?)null : IsSexMan == "true";
            obj.FirstName = txtName;
            obj.LastName = txtFamily;
            obj.MobileNumber = txtMobile;
            obj.Tel_BeHamrah_Code = txtTel;
            obj.Dsc = txtDSC.Trim();
            obj.Address = txtAddress;
            obj.Email = txtEmail;
            obj.OnvaneSherkat = txtOnvan;
            //string roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            string roleid = RoleIds.C_MoshtariIds.ToString();
            obj.Role = dc.Roles.First(s => s.Id.ToString() == roleid);

            string mantagheid = Utility.EncryptedQueryString.Decrypt(cboMantagheSelect);
            obj.Mantaghe = dc.Mantaghes.FirstOrDefault(s => s.Id.ToString() == mantagheid);

            string visitorid = Utility.EncryptedQueryString.Decrypt(cboSelectVisitor);
            obj.VisitorUser = dc.users.FirstOrDefault(s => s.UID.ToString() == visitorid);


            if (security.Is_ShowForVisitor)
            {
                obj.CodeMeli = txtCodeMeli;


                string usertypeid = Utility.EncryptedQueryString.Decrypt(cboUserTypeSelect);
                obj.UserType = dc.UserTypes.FirstOrDefault(s => s.Id.ToString() == usertypeid);

                obj.IsActive = IsActive == "true";
                if (obj.IsActive)
                {
                    obj.UserName = txtUSERName;
                    if (txtpass != "")
                        obj.Password = Utility.EncryptedQueryString.GetMD5Hash(txtpass);

                }
            }
            else
            {
                if (obj.UserTypeID == null)
                    obj.UserType = dc.UserTypes.FirstOrDefault(s => s.Id == 1);//معمولی
            }

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" مشتری با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' درج گردید.", EventTypeIds.SAVE, "CUSTOMERSPEC_M", CurrentUser.UID);
            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" مشتری با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' ویرایش گردید.", EventTypeIds.EDIT, "CUSTOMERSPEC_M", CurrentUser.UID);
            }
            if (msgPayment != "")
            {
                EventLog.Loging(msgPayment, EventTypeIds.SAVE, "CUSTOMERSPEC_M", CurrentUser.UID);
            }

            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_CustomerSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindRole();
            BindMantaghe();
            BindUserType();
            BindVisitor();
            DisplayPersonel();
        }

        public M_CustomerSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindRole();
            BindMantaghe();
            BindUserType();
            BindVisitor();
            BindForms(frm);
        }



    }
}