﻿using App_Start.Utility;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Models.Pages
{
    public class LoginModel
    {
        DBDataContext dc = new DBDataContext();
        private string txtbox_EMAIL_DIALOG;
        private string CaptchaValue;

        public Messaging DisplayMessage;
        public string txtUserName;
        public string txtPassword;
        public string txtcaptcha;
        public string SRCCaptcha;

        public LoginModel()
        {
            DisplayMessage = new Messaging();
        }
        public LoginModel(FormCollection frm, string CaptchaValue_)
        {
            DisplayMessage = new Messaging();
            txtUserName = frm["txtUserName"].ToString().Trim();
            txtPassword = frm["txtPassword"].ToString();
            txtcaptcha = frm["txtcaptcha"].ToString().ToUpper().Trim();
            txtbox_EMAIL_DIALOG = frm["txtbox_EMAIL_DIALOG"].ToString().Trim();
            CaptchaValue = CaptchaValue_;

        }

        public string Login()
        {

            DeleteAllSabadKharid();
            FunctionMojodi.NOtificationToMinProd(null, "");

            var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
             && s.UserName == txtUserName.Trim() && s.Password == Utility.EncryptedQueryString.GetMD5Hash(txtPassword));
            EventLog.Loging("ورود موفق به سیستم", EventTypeIds.VorodBSystem, "LOGIN", usr.UID);

            System.Web.HttpContext.Current.Session["USERID"] = usr.UID;

            KifPolEsfandane(usr);

            if (usr.Role.IsMenagment)
            {
                return "~/MApplication/MainPage";
            }
            else if (usr.Role.IsMenagment == false)
            {
                var lstSabadKharid = dc.SabadKharids.Where(s => s.UserMoshtariID == usr.UID && s.IsDeleted == false && s.IsKharid == false).ToList().OrderByDescending(s => s.DateTimeAkharinTaghirat).FirstOrDefault();
                System.Web.HttpContext.Current.Session["CurrentSabadKharidID"] = lstSabadKharid == null ? Guid.Empty : lstSabadKharid.UID;
                if (lstSabadKharid != null)
                {
                    lstSabadKharid.DateTimeAkharinTaghirat = DateTime.Now;

                    System.Web.HttpContext.Current.Session["CurrentSabadKharidID"] = lstSabadKharid.UID;
                    dc.SubmitChanges();
                }
                return "~/CMainPage/MainPage";
            }
            return "~/Login/Login";
        }

        private void DeleteAllSabadKharid()
        {
            //var q = dc.SabadKharids.Where(s => s.IsDeleted == false && s.IsKharid == false).ToList().Where(s => s.DateTimeAkharinTaghirat.Subtract(DateTime.Now).TotalHours > 72);
            //foreach (var p in q)
            //{
            //    p.IsDeleted = true;
            //    EventLog.Loging("سبد خرید با شماره پیگیری '" + p.CodeRahgiri + "' به دلیل عدم به روز رسانی حذف گردید. ", EventTypeIds.DELETE, "LOGIN_SYSTEM", null);
            //}
            //dc.SubmitChanges();

            string cureentdate = DateShamsi.GetCurrentDate();
            //لیست کالاهای خرید شده ای که 3 روز از زمان رزرو انها در سبد خرید گذشته است 
            //var q1 = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && s.Price.DatePayan != null && s.Price.DatePayan != "").ToList().Where(s => DateTime.Now.Subtract(DateShamsi.ConvertShamsiToMiladiDateTime(s.Price.DatePayan).Value).TotalHours > 72);
            var q1 = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false).ToList().Where(s => DateTime.Now.Subtract(DateShamsi.ConvertShamsiToMiladiDateTime(s.DateSabt_Fa).Value).TotalHours > 72);
            q1 = q1.Where(s => s.SabadKharid.DateTimeZamanRaftanDarSafhieTaiedBank == null || DateTime.Now.Subtract(s.SabadKharid.DateTimeZamanRaftanDarSafhieTaiedBank.Value).TotalHours > 1);
            try
            {
                foreach (var p in q1)
                {
                    string msg = " زمان خرید " + (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name + (p.Price.IsDarhalEngheza ? "[فروش ویژه] " : (p.Price.IsTakhfifOmomi ? "[جشنواره عمومی] " : (p.Price.IsTakhfifEkhtesasi ? "[جشنواره اختصاصی] " : ("")))) + " با قیمت " + p.PriceVahed.ToString("###,##0") + " ریال به پایان رسیده است.  محصول از سبد خرید حذف گردید.";



                    Notification b = new Notification();
                    b.UID = Guid.NewGuid();
                    b.SenderID = null;
                    b.TimeCreate = DateShamsi.GetCurrentHour();
                    b.DateCreate = DateShamsi.GetCurrentDate();
                    b.NotificationTypeId = NotificationTypeIDs.Customid;
                    b.Price_UID = null;
                    b.UserId = p.SabadKharid.UserMoshtariID;
                    b.Dsc = msg;
                    b.Subject = "حذف کالا از سبد خرید";
                    b.GruopIDs = Guid.NewGuid();
                    dc.Notifications.InsertOnSubmit(b);
                    dc.SabadKharidItems.DeleteOnSubmit(p);
                    EventLog.Loging("در سبد خرید با شماره پیگیری '" + p.SabadKharid.CodeRahgiri + "'" + msg, EventTypeIds.DELETE, "LOGIN_SYSTEM", null);
                }
                dc.SubmitChanges();
            }
            catch { }

        }
        private void KifPolEsfandane(user usr)
        {


            if (usr.MablaghGifts_EndMonth_KOL > 0)
            {
                string curentdate = DateShamsi.GetCurrentDate();
                string lastdate31 = DateShamsi.AddDaysToShamsiDate(curentdate, 0, 0, -31);
                if (!dc.SabadKharids.Any(s => s.IsDeleted == false && s.IsKharid == true && s.UserMoshtariID == usr.UID
                && curentdate.CompareTo(s.DateSabtSefareshKharid_Fa) >= 0
                && lastdate31.CompareTo(s.DateSabtSefareshKharid_Fa) <= 0))
                {
                    Notification b = new Notification();
                    b.UID = Guid.NewGuid();
                    b.TimeCreate = DateShamsi.GetCurrentHour();
                    b.DateCreate = DateShamsi.GetCurrentDate();
                    b.NotificationTypeId = NotificationTypeIDs.Customid;
                    b.Price_UID = null;
                    b.SenderID = null;
                    b.UserId = usr.UID;
                    b.Dsc = "به دلیل اینکه از تاریخ " + lastdate31 + " تا تاریخ " + curentdate + " هیچ خریدی برای شما ثبت نشده است کیف پول هدیه وفاداری شما برابر 0 ریال می گردد.";
                    b.Subject = " کیف پول هدیه وفاداری";
                    b.GruopIDs = Guid.NewGuid();
                    dc.Notifications.InsertOnSubmit(b);

                    dc.Payments.InsertOnSubmit(FunctionMojodi.CreatePayment(usr.UID, usr.MablaghGifts_EndMonth_KOL, false, false, true, false, usr.MablaghGifts_EndMonth_KOL, b.Dsc));
                    usr.MablaghGifts_EndMonth_KOL = 0;
                    EventLog.Loging("به دلیل اینکه '" + usr.FullName + " [" + usr.OnvaneSherkat + "] " + "' از تاریخ " + lastdate31 + " تا تاریخ " + curentdate + " هیچ خریدی ثبت نشده است کیف پول هدیه وفاداری برابر 0 ریال می گردد.", EventTypeIds.DELETE, "LOGIN_SYSTEM", null);

                }
            }

            dc.SubmitChanges();

        }
        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (CaptchaValue != txtcaptcha)
            {
                Msg += (++i).ToString() + " - " + "کلید امنیتی را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else
            {
                if (txtUserName.Trim() == "")
                {
                    Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                    result = false;
                }
                if (txtPassword == "")
                {
                    Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                    result = false;
                }

                if (result == true)
                {
                    var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
                        && s.UserName == txtUserName.Trim());
                    if (usr == null || usr.Password != Utility.EncryptedQueryString.GetMD5Hash(txtPassword))
                    {
                        Msg += (++i).ToString() + " - " + "نام کاربری یا رمز عبور شما نادرست می باشد." + "</br>";
                        result = false;
                    }
                }
            }

            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.VorodNamovafagh, "LOGIN", null);
            }

            return result;
        }
        public void ChangePassword()
        {
            string email = txtbox_EMAIL_DIALOG.Trim();
            string NewPass = (new Random()).Next(1000000, 9999999).ToString();
            user obj = dc.users.FirstOrDefault(s => s.Email == txtbox_EMAIL_DIALOG.Trim());
            obj.Password = EncryptedQueryString.GetMD5Hash(NewPass);
            dc.SubmitChanges();

            string body = "با سلام" + Environment.NewLine + "رمز عبور جدید برای وارد شدن به سایت تکاپو پخش عبارت است از : " + NewPass;
            Mailer.SendMail(body, "تکاپو پخش", email, false, "رمز عبور جدید");
            DisplayMessage.ShowSeccessMessage("رمز عبور جدید ارسال گردید");
            EventLog.Loging(" رمز عبور به ایمیل ارسال گردید.", EventTypeIds.Forgotpassword, "LOGIN", obj.UID);
        }
        public bool CheckValidateEmail()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (txtbox_EMAIL_DIALOG.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی  را وارد نمایید." + "</br>";
                result = false;
            }
            else if (!Validation.IsEmail(txtbox_EMAIL_DIALOG.Trim()))
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی را صحیح وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.users.FirstOrDefault(s => s.IsDeleted == false && s.IsActive == true
                    && s.Email == txtbox_EMAIL_DIALOG.Trim());
                if (usr == null)
                {
                    Msg += (++i).ToString() + " - " + "کاربری با پست الکترونیکی وارد شده یافت نشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.Forgotpassword, "LOGIN", null);
            }

            return result;
        }
    }
}