﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;

namespace restauran.Models.Pages
{
    public class M_UnitType : MasterPageModel
    {
        public string hfContentValue = "1";
        public string hf_SelectID = "";
        public string txtName = "";
        public string txtprioroty = "";
        public List<Unit> lst_content_Table = new List<Unit>();

        public GridPageNumber GridPaging = new GridPageNumber();

        public M_UnitType(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
           
        }

        public M_UnitType(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            hf_SelectID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectID"].ToString().Trim());
            txtName = frm["txtName"].ToString().Trim();
            txtprioroty = frm["txtprioroty"].ToString().Trim();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void BindTable()
        {
            lst_content_Table = new List<Unit>();
            var q = (from p in dc.Units
                     where
                     p.IsDeleted == false
                     select p).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();

            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("اولویت نمایش");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 5 : 4;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }
        public void DeleteRows()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید.");
                return;
            }
            var obj = dc.Units.SingleOrDefault(s => s.Id.ToString() == hf_SelectID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.Products.Any())
            {
                DisplayMessage.ShowErrorMessage("به دلیل وجود اطلاعات وابسطه امکان حذف وجود ندارد");
                return;
            }

            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" واحد با عنوان '" + obj.Name + "' حذف گردید.", EventTypeIds.DELETE, "UNIT_M", CurrentUser.UID);
        }
        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره را ندارید.");
                return false;
            }

            if (txtName.Trim() == "")
            {
                Msg += (i++) + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
            }
            else if (dc.Units.Any(s => s.Name == txtName.Trim() && s.IsDeleted == false && s.Id.ToString() != hf_SelectID))
            {
                Msg += (i++) + " - " + "عنوان وارد شده قبلا ثبت شده است." + "</br>";
                result = false;
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        public void Save()
        {
            bool IsEdit = true;

            var obj = dc.Units.SingleOrDefault(s => s.Id.ToString() == hf_SelectID);
            if (obj == null)
            {
                obj = new Unit();
                obj.Id = dc.Units.Any() == false ? 1 : (dc.Units.Max(s => s.Id) + 1);

                obj.IsDeleted = false;
                dc.Units.InsertOnSubmit(obj);
                IsEdit = false;
            }
            int tmp = 0;
            obj.Name = txtName.Trim();
            obj.Priority = int.TryParse(txtprioroty.Trim(), out tmp) == false ? ((int?)null) : tmp;
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ذخیره گردید.");

            if (IsEdit == false)
                EventLog.Loging(" واحد با عنوان '" + obj.Name + "' درج گردید.", EventTypeIds.SAVE, "UNIT_M", CurrentUser.UID);
            else if (IsEdit == true && Ischange)
                EventLog.Loging(" واحد با عنوان '" + obj.Name + "' ویرایش گردید.", EventTypeIds.EDIT, "UNIT_M", CurrentUser.UID);

        }
    }
}