﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_GroupProductTypeModel : MasterPageModel
    {


        public string txtOnvan = "";
        public string hfContent = "0";
        public string hf_SelectValueID = "";



        public List<ProductType> lst_content_Table = new List<ProductType>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_GroupProductTypeModel(user currentUser_, string PageName)
        {

            Intialize(currentUser_, PageName);

        }

        public M_GroupProductTypeModel(FormCollection frm, user currentUser_, string PageName)
        {

            Intialize(currentUser_, PageName);

            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            hfContent = frm["hfContent"].ToString().Trim();

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<ProductType>();



            var q = (from p in dc.ProductTypes
                     where
                     p.IsDeleted == false
                     &&
                     p.ParentId == null
                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.Name.Contains(txtOnvan))
                           )

                     )
                     select p).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name);


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نمایش در نام کالا");
            GridPaging.lst_headerName.Add("اولویت");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 6 : 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();



        }

        public void DeleteRow(HttpServerUtilityBase server)
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.ProductTypes.SingleOrDefault(s => s.Id.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.Products.Any(s => s.IsDeleted == false) || obj.Childs.Any(s => s.IsDeleted == false))
            {
                DisplayMessage.ShowErrorMessage("به دلیل اطلاعات وابسطه امکان حذف کالا وجود نخواهد داشت.");
                return;
            }
            if (obj.ImageUrl != null && obj.ImageUrl != "")
            {
                try
                {
                    string path = server.MapPath(obj.ImageUrl);
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                    obj.ImageUrl = "";
                }
                catch { }
            }
            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" دسته کالا با عنوان  '" + obj.Name + "' حذف گردید.", EventTypeIds.DELETE, "PRODUCTTYPEGROUP_M", CurrentUser.UID);


        }

    }
}

