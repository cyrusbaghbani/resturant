﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_GroupProductTypeSpecModel : MasterPageModel
    {
        public string ID = "";
        public string txtOnvan = "";
        public string txtPriority = "";
        public string CboShow = "true";

        public string hfIDimgDisplay = "";
        public string hfimgDisplay = "/Images/Img/Emptyimg300.png";
        public string ImageEmpty = "/Images/Img/Emptyimg300.png";
        public string hfINFOContent = "1";




        public void BindForms(FormCollection form)
        {

            txtOnvan = form["txtOnvan"] == null ? "" : form["txtOnvan"].ToString().Trim();
            txtPriority = form["txtPriority"] == null ? "" : form["txtPriority"].ToString().Trim();
            CboShow = form["CboShow"] == null ? "" : form["CboShow"].ToString().Trim();

            hfINFOContent = form["hfINFOContent"] == null ? "0" : form["hfINFOContent"].ToString().Trim();

            hfimgDisplay = form["hfimgDisplay"].ToString();
            hfIDimgDisplay = form["hfIDimgDisplay"].ToString();

        }


        private void DisplayInfo()
        {
            dc = new DBDataContext();
            var obj = dc.ProductTypes.SingleOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {

                return;
            }

            ID = obj.Id.ToString();
            txtOnvan = obj.Name;
            txtPriority = obj.Periority == null ? "" : obj.Periority.ToString();
            CboShow = obj.IsShowName.ToString().Trim();

            hfimgDisplay = (obj.ImageUrl == null || obj.ImageUrl.Trim() == "") ? ImageEmpty : obj.ImageUrl;
            hfIDimgDisplay = (obj.ImageUrl == null || obj.ImageUrl.Trim() == "") ? "" : "HASIMAGE";
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (txtOnvan == "")
            {
                Msg += (i++).ToString() + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
            }
            else if (dc.ProductTypes.Any(s => s.Name == txtOnvan.Trim() && s.ParentId == null && s.IsDeleted == false && s.Id.ToString() != ID))
            {
                Msg += (i++) + " - " + "عنوان وارد شده قبلا ثبت شده است." + "</br>";
                result = false;
            }

            int temp = 0;
            if (txtPriority != "" && !int.TryParse("0" + txtPriority.Replace(",", "").Replace("،", ""), out temp))
            {
                Msg += (i++).ToString() + " - " + "اولویت را به صورت عددی صحیح وارد نمایید." + "</br>";
                result = false;
            }

            if (!dc.Temps.Any(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfIDimgDisplay)) && hfIDimgDisplay != "HASIMAGE")
            {
                Msg += (i++).ToString() + " - " + "عکس را انتخاب نمایید." + "</br>";
                result = false;
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }
        public void Save(HttpServerUtilityBase server = null)
        {
            bool IsNew = true;
            var obj = dc.ProductTypes.SingleOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {
                obj = new ProductType();
                obj.Id = dc.ProductTypes.Any() ? (dc.ProductTypes.Max(s => s.Id) + 1) : 1;
                obj.IsDeleted = false;
                obj.ParentId = null;
                IsNew = false;
                dc.ProductTypes.InsertOnSubmit(obj);

            }

            int temp = 0;
            obj.Periority = (txtPriority == "" || !int.TryParse("0" + txtPriority.Replace(",", "").Replace("،", ""), out temp)) ? (int?)null : temp;
            obj.Name = txtOnvan;
            obj.IsShowName = CboShow == "false" ? false : true;
            if (hfIDimgDisplay != "HASIMAGE")
            {
                if (obj.ImageUrl != null && obj.ImageUrl != "")
                {
                    try
                    {
                        string path = server.MapPath(obj.ImageUrl);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        obj.ImageUrl = "";
                    }
                    catch { }
                }

                if (hfimgDisplay != "REMOVE" && hfimgDisplay != "")
                {
                    string id = EncryptedQueryString.Decrypt(hfIDimgDisplay);
                    var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);

                    if (tmp != null)
                    {
                        string src = server.MapPath(tmp.src);
                        if (System.IO.File.Exists(src))
                        {
                            string dst = "/Attachment/Images/Kala/Type" + Guid.NewGuid().ToString() + System.IO.Path.GetExtension(tmp.src);
                            System.IO.File.Move(src, server.MapPath(dst));
                            obj.ImageUrl = dst;
                            dc.Temps.DeleteOnSubmit(tmp);
                        }
                        else
                            dc.Temps.DeleteOnSubmit(tmp);
                    }
                }
            }
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsNew == true)
            {
                EventLog.Loging(" دسته کالایی با عنوان '" + obj.Name + " درج گردید.", EventTypeIds.SAVE, "PRODUCTGROUPTYPESPEC_M", CurrentUser.UID);
            }
            else if (IsNew == false && ischange == true)
            {
                EventLog.Loging(" دسته کالایی با عنوان '" +  obj.Name + "' ویرایش گردید.", EventTypeIds.EDIT, "PRODUCTGROUPTYPESPEC_M", CurrentUser.UID);

            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");
           

        }
        public M_GroupProductTypeSpecModel(string ID_, user currentUser_, string PageName)
        {
            FunctionMojodi.SETMOJODI(ID);
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();

            DisplayInfo();


        }

        public M_GroupProductTypeSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();


            BindForms(frm);


        }




    }
}
