﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;

namespace restauran.Models.Pages
{
    public class M_MainPageModel : MasterPageModel
    {
        

        public M_MainPageModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
           
        }

        public M_MainPageModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
                      
        }
    }
}