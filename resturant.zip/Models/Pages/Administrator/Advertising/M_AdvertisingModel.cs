﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using System.IO;

namespace restauran.Models.Pages
{
    public class M_AdvertisingModel : MasterPageModel
    {

        public string txtOnvan = "";
        public string hfContent = "0";
        public string hf_SelectValueID = "";

        public List<Advertising> lst_content_Table = new List<Advertising>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_AdvertisingModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_AdvertisingModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Advertising>();



            var q = (from p in dc.Advertisings
                     where
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.Onvan != null && p.Onvan.Contains(txtOnvan.Trim())))

                     )
                     select p).OrderByDescending(s => s.DateSabt).ThenByDescending(s => s.Onvan);


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("تاریخ شروع");
            GridPaging.lst_headerName.Add("تاریخ پایان");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 6 : 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }

        public void DeleteRow(HttpServerUtilityBase server)
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Advertisings.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            string path = server.MapPath(obj.Url);
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                dc.Advertisings.DeleteOnSubmit(obj);
            }
            catch { }
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");

            EventLog.Loging(" تبلیغ با عنوان '" + obj.Onvan + "' با تاریخ '" + obj.DateShoro + "' حذف گردید.", EventTypeIds.DELETE, "ADVERTISING_M", CurrentUser.UID);

        }

    }
}