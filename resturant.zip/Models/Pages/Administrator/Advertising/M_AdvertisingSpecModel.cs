﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_AdvertisingSpecModel : MasterPageModel
    {

        public string ID = "";
        public string txtPriority = "";
        public string txtDateShoro = "";
        public string txtDatePayan = "";
    
        public string hfUploadID = "";
        public string hfUploadDisplay = "";
        public string txtOnvan = "";
        public string hfUploadID800_600 = "";
        public string hfUploadDisplay800_600 = "";
        public void BindForms(FormCollection form)
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            hfUploadID = form["hfUploadID"].ToString().Trim();
            hfUploadDisplay = form["hfUploadDisplay"].ToString().Trim();
            txtOnvan = form["txtOnvan"].ToString().Trim();
            txtPriority = form["txtPriority"].ToString().Trim();
            txtDateShoro = form["txtDateShoro"].ToString().Trim();
            txtDatePayan = form["txtDatePayan"].ToString().Trim();

            hfUploadID800_600 = form["hfUploadID800_600"].ToString().Trim();
            hfUploadDisplay800_600 = form["hfUploadDisplay800_600"].ToString().Trim();
        }


        private void DisplayInfo()
        {
            var obj = dc.Advertisings.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
                return;

            txtOnvan = obj.Onvan;
            txtPriority = obj.Priority == null ? "" : obj.Priority.ToString();
            txtDateShoro = obj.DateShoro;
            txtDatePayan = obj.DatePayan;
            hfUploadDisplay = (obj.Url == null || obj.Url.Trim() == "") ? "" : obj.Url;
            hfUploadID = (obj.Url == null || obj.Url.Trim() == "") ? "" : "HASIMAGE";

            hfUploadDisplay800_600 = (obj.Url800_600 == null || obj.Url800_600.Trim() == "") ? "" : obj.Url800_600;
            hfUploadID800_600 = (obj.Url800_600 == null || obj.Url800_600.Trim() == "") ? "" : "HASIMAGE";

        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            if (txtOnvan == "")
            {
                Msg += (i++).ToString() + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
            }
            string start = DateShamsi.GetShamsiDateString(txtDateShoro);
            string end = DateShamsi.GetShamsiDateString(txtDatePayan);
            if (start == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtDatePayan != "" && end == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ پایان را وارد نمایید." + "</br>";
                result = false;
            }
            if (end != "" && start != "" && start.CompareTo(end) > 0)
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع نباید از تاریخ پایان بزرگتر باشد." + "</br>";
                result = false;
            }

            if (!dc.Temps.Any(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfUploadID)) && hfUploadID != "HASIMAGE")
            {
                Msg += (i++).ToString() + " - " + "عکس را انتخاب نمایید." + "</br>";
                result = false;
            }
            if (!dc.Temps.Any(s => s.UID.ToString() == Utility.EncryptedQueryString.Decrypt(hfUploadID800_600)) && hfUploadID800_600 != "HASIMAGE")
            {
                Msg += (i++).ToString() + " - " + "عکس 800 * 600 را انتخاب نمایید." + "</br>";
                result = false;
            }



            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save(HttpServerUtilityBase server = null)
        {
            bool IsEdit = true;
            var obj = dc.Advertisings.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Advertising();
                obj.UID = Guid.NewGuid();
                obj.DateSabt = DateTime.Now;



                dc.Advertisings.InsertOnSubmit(obj);
                IsEdit = false;
            }
            int tmpInt = 0;
            obj.Onvan = txtOnvan.Trim();
            obj.Priority = int.TryParse(txtPriority.Trim(), out tmpInt) == false ? (int?)null : tmpInt;
            obj.DateShoro = DateShamsi.GetShamsiDateString(txtDateShoro);
            obj.DatePayan = DateShamsi.GetShamsiDateString(txtDatePayan);


            if (hfUploadID != "HASIMAGE")
            {
                if (obj.Url != null && obj.Url != "")
                {
                    try
                    {
                        string path = server.MapPath(obj.Url);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        obj.Url = "";
                    }
                    catch { }
                }

                if (hfUploadID != "REMOVE" && hfUploadID != "")
                {
                    string id = EncryptedQueryString.Decrypt(hfUploadID);
                    var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);

                    if (tmp != null)
                    {
                        string src = server.MapPath(tmp.src);
                        if (System.IO.File.Exists(src))
                        {
                            string dst = AdvertisingPath + Guid.NewGuid().ToString() + System.IO.Path.GetExtension(tmp.src);
                            System.IO.File.Move(src, server.MapPath(dst));
                            obj.Url = dst;
                            dc.Temps.DeleteOnSubmit(tmp);
                        }
                        else
                            dc.Temps.DeleteOnSubmit(tmp);
                    }
                }
            }


            if (hfUploadID800_600 != "HASIMAGE")
            {
                if (obj.Url800_600 != null && obj.Url800_600 != "")
                {
                    try
                    {
                        string path = server.MapPath(obj.Url800_600);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        obj.Url800_600 = "";
                    }
                    catch { }
                }

                if (hfUploadID800_600 != "REMOVE" && hfUploadID800_600 != "")
                {
                    string id = EncryptedQueryString.Decrypt(hfUploadID800_600);
                    var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);

                    if (tmp != null)
                    {
                        string src = server.MapPath(tmp.src);
                        if (System.IO.File.Exists(src))
                        {
                            string dst = AdvertisingPath + Guid.NewGuid().ToString() + System.IO.Path.GetExtension(tmp.src);
                            System.IO.File.Move(src, server.MapPath(dst));
                            obj.Url800_600 = dst;
                            dc.Temps.DeleteOnSubmit(tmp);
                        }
                        else
                            dc.Temps.DeleteOnSubmit(tmp);
                    }
                }
            }

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" تبلیغ با عنوان '" + obj.Onvan + "' با تاریخ '" + obj.DateShoro + "' درج گردید.", EventTypeIds.SAVE, "ADVERTISINGSPEC_M", CurrentUser.UID);
            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" تبلیغ با عنوان '" + obj.Onvan + "' با تاریخ '" + obj.DateShoro + "' ویرایش گردید.", EventTypeIds.EDIT, "ADVERTISINGSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_AdvertisingSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            DisplayInfo();
        }

        public M_AdvertisingSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindForms(frm);
        }



    }
}