﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using System.IO;

namespace restauran.Models.Pages
{
    public class M_LotteryModel : MasterPageModel
    {

        public string txtOnvan = "";
        public string hfContent = "0";
        public string hf_SelectValueID = "";

        public List<Lottery> lst_content_Table = new List<Lottery>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_LotteryModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_LotteryModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Lottery>();



            var q = (from p in dc.Lotteries
                     where
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.Onvam != null && p.Onvam.Contains(txtOnvan.Trim())))

                     )
                     select p).OrderByDescending(s => s.DateShoro).ThenBy(s => s.Priority);


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("تاریخ");
            GridPaging.lst_headerName.Add("دانلود");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 6 : 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }

        public void DeleteRow(HttpServerUtilityBase server)
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Lotteries.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            string path = server.MapPath( obj.url);
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
                dc.Lotteries.DeleteOnSubmit(obj);
            }
            catch { }
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");

            EventLog.Loging(" نتیجه قرعه کشی با عنوان '" + obj.Onvam + "' با تاریخ '" + obj.DateShoro + "' حذف گردید.", EventTypeIds.DELETE, "LOTTERY_M", CurrentUser.UID);

        }

    }
}