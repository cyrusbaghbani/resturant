﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_FactorReportsModel : MasterPageModel
    {

        public string txtOnvan = "";

        public string hfContent = "0";

        public string hf_SelectValueID = "";

        public string cboSelectTozieKonande = "";

        public List<SabadKharid> lst_content_Table = new List<SabadKharid>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_FactorReportsModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }
        public M_FactorReportsModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            cboSelectTozieKonande = frm["cboSelectTozieKonande"] == null ? "" : Utility.EncryptedQueryString.Decrypt(frm["cboSelectTozieKonande"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<SabadKharid>();



            var q = (from p in dc.SabadKharids
                     where
                     p.IsDeleted == false
                     &&
                     p.IsKharid == true
                     &&
                     p.IsTahvilBeMoshtari == false
                     &&
                     (p.UserTahvilDahandeID == null || p.UserTahvilDahandeID == Guid.Empty)
                     &&
                     (
                         (CurrentUser.RoleId != RoleIds.M_ToziKonande && CurrentUser.RoleId != RoleIds.M_Visitor)
                         ||
                         (CurrentUser.RoleId == RoleIds.M_Visitor && p.userMoshtari.VisitorUserID == CurrentUser.UID)
                     )
                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.CodeRahgiri.Contains(txtOnvan.Trim()))
                           ||
                           p.userMoshtari.FullName.Contains(txtOnvan.Trim())
                           ||
                           p.userMoshtari.OnvaneSherkat.Contains(txtOnvan.Trim())
                           ||
                           (p.DateSabtSefareshKharid_Fa != null && p.DateSabtSefareshKharid_Fa.Contains(txtOnvan.Trim()))
                           )
                     )
                     select p).OrderByDescending(s => s.DateTimeSabtSefareshKharid);


            GridPaging.lst_headerName.Add("تاریخ سفارش");
            GridPaging.lst_headerName.Add("کد رهگیری");
            GridPaging.lst_headerName.Add("درخواست دهنده");
            GridPaging.lst_headerName.Add("بررسی");

            GridPaging.Columns = 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }



    }
}