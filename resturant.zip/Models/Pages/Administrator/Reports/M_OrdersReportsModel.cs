﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_OrdersReportsModel : MasterPageModel
    {
        public string txtDateAz_REPORT = "";
        public string txtDateTa_REPORT = "";

        public string txtTimeStart_Report = "";
        public string txtTimeEnd_Report = "";

        public M_OrdersReportsModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            DisplayInfo();

        }
        private void DisplayInfo()
        {
            txtDateTa_REPORT = DateShamsi.GetCurrentDate();
            txtDateAz_REPORT = DateShamsi.AddDaysToShamsiDate(txtDateTa_REPORT, 0, 0, -1);

            txtTimeStart_Report = "08:00";
            txtTimeEnd_Report = "08:00";
        }





    }
}