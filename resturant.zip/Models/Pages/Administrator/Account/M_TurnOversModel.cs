﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class M_TurnOversModel : MasterPageModel
    {
        public string hfContentValue = "1";
        public string hf_SelectValueID = "";
        public string hf_SelectuserID = "";

        public string cboselectvariz_EDIT = "";
        public string CboSelectAccount = "";
        public string CboSelectVariz = "";
        public string txtDateAz = "";
        public string txtDateTa = "";
        public string hfContent = "0";

        public bool IsEditNewDelete = false;

        public string txtOnvan = "";
        public string hfCustomersSelect = "";
        public string hfCustomerSelectNAME = "همه";

        public string txtPriceDialog = "";
        public string txtDscDialog = "";

        public List<Payment> lst_content_Table = new List<Payment>();

        public GridPageNumber GridPaging = new GridPageNumber();
        public M_TurnOversModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_TurnOversModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

            BindForms(frm);
        }
        public void BindForms(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            CboSelectAccount = frm["CboSelectAccount"].ToString().Trim().ToLower();
            CboSelectVariz = frm["CboSelectVariz"].ToString().Trim().ToLower();
            txtDateAz = frm["txtDateAz"].ToString().Trim();
            txtDateTa = frm["txtDateTa"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            cboselectvariz_EDIT = frm["cboselectvariz_EDIT"].ToString().Trim();

            txtPriceDialog = frm["txtPriceDialog"].ToString().Trim();
            txtDscDialog = frm["txtDscDialog"].ToString().Trim();
            txtOnvan = frm["txtOnvan"].ToString().Trim();

            hf_SelectuserID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectuserID"].ToString().Trim());
            hfCustomersSelect = frm["hfCustomersSelect"].ToString().Trim();
            hfCustomerSelectNAME = frm["hfCustomerSelectNAME"].ToString().Trim();
            hfCustomerSelectNAME = hfCustomerSelectNAME == "" ? "همه" : hfCustomerSelectNAME;

            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Payment>();
            var q = (from p in dc.Payments
                     where
                     p.IsDeleted == false
                     &&
                     (
                     CboSelectAccount == ""
                     ||
                    (CboSelectAccount == "asli" && p.IsGift == false && p.IsGift_EndMonth == false)
                     ||
                    (CboSelectAccount == "gift" && p.IsGift == true && p.IsGift_EndMonth == false)
                     ||
                    (CboSelectAccount == "giftendmonth" && p.IsGift == false && p.IsGift_EndMonth == true)
                     )
                     &&
                     (
                     CboSelectVariz == ""
                     ||
                    (CboSelectVariz == "false" && p.IsVariz == false)
                     ||
                     (CboSelectVariz == "true" && p.IsVariz == true)
                     )
                     select p);


            List<string> userIds = hfCustomersSelect.Split(',').Where(s => s != null && s.Trim() != "").Select(s => Utility.EncryptedQueryString.Decrypt(s)).ToList();


            if (userIds.Count == 1)
            {
                IsEditNewDelete = true;
                hf_SelectuserID = userIds.First();
            }

            if (txtOnvan != "")
            {
                q = q.Where(s => s.DSC.Contains(txtOnvan));
            }
            txtDateAz = DateShamsi.GetShamsiDateString(txtDateAz);
            if (txtDateAz != "")
            {
                q = q.Where(s => s.DatePersianSabt.CompareTo(txtDateAz) >= 0);
            }
            txtDateTa = DateShamsi.GetShamsiDateString(txtDateTa);
            if (txtDateTa != "")
            {
                q = q.Where(s => s.DatePersianSabt.CompareTo(txtDateTa) <= 0);
            }
            if (userIds.Any())
            {
                q = (from p in q
                     where
                     p.UserAccountId != null &&
                     userIds.Contains(p.UserAccountId.ToString())

                     select p);
            }



            q = q.OrderByDescending(s => s.DateTimeSabt);

            GridPaging.lst_headerName.Add("مشتری");
            GridPaging.lst_headerName.Add("مبلغ");
            GridPaging.lst_headerName.Add("تاریخ");
            GridPaging.lst_headerName.Add("زمان");
            GridPaging.lst_headerName.Add("واریز/برداشت");
            GridPaging.lst_headerName.Add("موجودی کل");
            GridPaging.lst_headerName.Add("توضیحات");

            if (security.IsDelete && IsEditNewDelete)
                GridPaging.lst_headerName.Add("ویرایش/حذف");
            GridPaging.Columns = security.IsDelete && IsEditNewDelete ? 9 : 8;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }
        public void DeleteRows()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید.");
                return;
            }
            var obj = dc.Payments.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (!(obj.IsGift == true && obj.IsVariz == true && obj.userPardakhtkonande.Role.IsMenagment))
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید.");
                return;
            }

            var usr = dc.users.FirstOrDefault(s => hf_SelectuserID == s.UID.ToString());
            if (usr == null || usr.UID != obj.UserAccountId)
            {
                DisplayMessage.ShowErrorMessage("باید یک مشتری انتخاب شود.");
                return;
            }
            if (usr.MablaghGiftsKol < obj.MablaghVariziYaBardashti)
            {
                DisplayMessage.ShowErrorMessage("در کیف پول هدیه مشتری به اندازه کافی موجودی وجود ندارد.");
                return;
            }
            string oldMablaghGiftsKol = usr.MablaghGiftsKol.ToString("###,##0");
            usr.MablaghGiftsKol -= obj.MablaghVariziYaBardashti;


            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" مبلغ هدیه  '" + obj.MablaghVariziYaBardashti.ToString("###,##0") + "' ریال از کیف پول هدیه مشتری '" + usr.FullName + " [" + usr.OnvaneSherkat + "] " + "' کسر گردید. [حساب جدید هدیه کاربر : " + usr.MablaghGiftsKol.ToString("###,##0") + " حساب هدیه قدیمی : " + oldMablaghGiftsKol + " ]", EventTypeIds.DELETE, "TURNOVERS_M", CurrentUser.UID);
        }
        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره را ندارید.");
                return false;
            }
            var obj = dc.Payments.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj != null)
            {
                if (!(obj.IsGift == true && obj.IsVariz == true && obj.userPardakhtkonande.Role.IsMenagment))
                {
                    Msg += (i++).ToString() + " - " + "شما اجازه ویرایش این رکورد را ندارید" + "</br>";
                    result = false;

                }
            }
            var usr = dc.users.FirstOrDefault(s => hf_SelectuserID == s.UID.ToString());
            if (usr == null || (obj != null && usr.UID != obj.UserAccountId))
            {
                Msg += (i++).ToString() + " - " + " مشتری را انتخاب نمایید" + "</br>";
                result = false;
            }
            if (cboselectvariz_EDIT == "")
            {
                Msg += (i++).ToString() + " - " + "واریز یا برداشت را مشخص نمایید." + "</br>";
                result = false;
            }
            decimal temp;
            if (txtPriceDialog == "" || !decimal.TryParse("0" + txtPriceDialog.Replace(",", "").Replace("،", ""), out temp))
            {

                Msg += (i++).ToString() + " - " + "مبلغ هدیه را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (result)
            {
                temp = decimal.Parse("0" + txtPriceDialog.Replace(",", "").Replace("،", ""));
                if (usr != null && obj != null)
                {
                    ///ویرایش

                }
                else if (usr != null && obj == null)
                {
                    ///برداشت
                    if (cboselectvariz_EDIT == "false")
                    {
                        if ((usr.MablaghGiftsKol - temp) < 0)
                        {
                            Msg += (i++).ToString() + " - " + " در کیف پول هدیه مشتری به اندازه کافی موجودی وجود ندارد." + "</br>";
                            result = false;
                        }
                    }
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        public void Save()
        {
            bool IsEdit = true;
            decimal oldprice = 0;
            string olddsc = "";
            string Oldvaziat = "";
            bool IsOldVariz = false;
            decimal OLDMablaghKol = 0;
            decimal oldMablaghGiftsKol = 0;

            user usr = dc.users.FirstOrDefault(s => hf_SelectuserID == s.UID.ToString());
            Payment obj = dc.Payments.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);

            if (obj == null)
            {
                obj = new Payment();
                obj.UID = Guid.NewGuid();
                obj.DatePersianSabt = DateShamsi.GetCurrentDate();
                obj.TimePersianSabt = DateShamsi.GetCurrentHour();
                obj.IsGift = true;

                obj.DateTimeSabt = DateTime.Now;
                obj.UserAccountId = usr.UID;
                obj.UserPardakhKonandeID = CurrentUser.UID;
                obj.IsDeleted = false;

                dc.Payments.InsertOnSubmit(obj);
                IsEdit = false;
            }
            oldprice = obj.MablaghVariziYaBardashti;
            olddsc = obj.DSC;
            oldMablaghGiftsKol = usr.MablaghGiftsKol;
            Oldvaziat = obj.IsVariz ? "واریز" : "برداشت";
            OLDMablaghKol = obj.MablaghKol;

            IsOldVariz = obj.IsVariz;
            obj.DSC = txtDscDialog.Trim();
            obj.MablaghVariziYaBardashti = decimal.Parse("0" + txtPriceDialog.Replace(",", "").Replace("،", ""));
            obj.IsVariz = cboselectvariz_EDIT.ToLower() == "true";
            if (IsEdit)
                obj.MablaghKol = obj.MablaghKol + (IsOldVariz ? (-1 * oldprice) : oldprice) + (obj.IsVariz ? obj.MablaghVariziYaBardashti : (-1 * obj.MablaghVariziYaBardashti));
            else
                obj.MablaghKol = usr.MablaghGiftsKol + (IsOldVariz ? (-1 * oldprice) : oldprice) + (obj.IsVariz ? obj.MablaghVariziYaBardashti : (-1 * obj.MablaghVariziYaBardashti));

            usr.MablaghGiftsKol = usr.MablaghGiftsKol + (IsOldVariz ? (-1 * oldprice) : oldprice) + (obj.IsVariz ? obj.MablaghVariziYaBardashti : (-1 * obj.MablaghVariziYaBardashti));



            bool Ischange = false;
            if (IsEdit == true)
                Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ذخیره گردید.");

            if (IsEdit == false)
                EventLog.Loging(" مبلغ هدیه '" + obj.MablaghVariziYaBardashti.ToString("###,##0") + "' ریال " + (obj.IsVariz ? "واریز" : "برداشت") + " شد با توضیحات '" + obj.DSC + "' برای مشتری '" + usr.FullName + " [" + usr.OnvaneSherkat + "]" + "' درج گردید. [حساب جدید هدیه کاربر : " + usr.MablaghGiftsKol.ToString("###,##0") + " حساب کل هدیه قدیمی : " + oldMablaghGiftsKol + " ]", EventTypeIds.SAVE, "TURNOVERS_M", CurrentUser.UID);
            else if (IsEdit == true && Ischange)
                EventLog.Loging(" مبلغ هدیه '" + obj.MablaghVariziYaBardashti.ToString("###,##0") + "' ریال " + (obj.IsVariz ? "واریز" : "برداشت") + " شد مجموع مبلغ هدیه کل'" + obj.MablaghKol.ToString("###,##0") + "' ریال  با توضیحات '" + obj.DSC + "' برای مشتری '" + usr.FullName + " [" + usr.OnvaneSherkat + "]" + "' ویرایش گردید. [حساب جدید هدیه کاربر : " + usr.MablaghGiftsKol.ToString("###,##0") + " حساب هدیه قدیمی : " + oldMablaghGiftsKol + " ] مبلغ قدیمی : '" + oldprice.ToString("###,##0") + "' ریال نوع واریز/برداشت:'" + Oldvaziat + "' مجموع مبلغ هدیه کل'" + OLDMablaghKol.ToString("###,##0") + "' ریال و توضیحات '" + olddsc + "'", EventTypeIds.SAVE, "TURNOVERS_M", CurrentUser.UID);

            if (OLDMablaghKol != obj.MablaghKol)
            {
                ///تمام فیلدها باید ویرایش گردد از این تاریخ به بعد
            }

        }
    }
}