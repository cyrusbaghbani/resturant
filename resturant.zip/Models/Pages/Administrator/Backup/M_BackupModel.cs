﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using System.IO;
using restauran.Models.Controll;
using Utility;


namespace restauran.Models.Pages
{
    public class M_BackupModel : MasterPageModel
    {


        public string hfContent = "0";
        public string hf_SelectValueID = "";

        public List<BackupControll> lst_content_Table = new List<BackupControll>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_BackupModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_BackupModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {


            hfContent = frm["hfContent"].ToString().Trim();
            hf_SelectValueID = frm["hf_SelectValueID"].ToString().Trim();
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            string BackupPath = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];
            DirectoryInfo dir = new DirectoryInfo(BackupPath);
            lst_content_Table = new List<BackupControll>();


            GridPaging.lst_headerName.Add("دانلود");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نوع");
            GridPaging.lst_headerName.Add("تاریخ ثبت");
            GridPaging.lst_headerName.Add("زمان ثبت");
            GridPaging.lst_headerName.Add("اندازه");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 8 : 7;
            if (Directory.Exists(BackupPath))
            {
                var q = (from p in dir.GetFiles("*.bak").AsQueryable()//تمام فایل ها که پسوند بک دارند را بخوان
                         select new BackupControll
                         {
                             Date = DateShamsi.GetDate(p.CreationTime, "/"),
                             Time = p.CreationTime.Hour.ToString("00") + ":" + p.CreationTime.Minute.ToString("00") + ":" + p.CreationTime.Second.ToString("00"),
                             Length = (p.Length / 1024).ToString("###,##0") + " کیلوبایت",
                             Name = p.Name,
                             Type = p.Name.StartsWith("DB") ? "دیتابیس" : "فایل"
                         }).OrderByDescending(p => p.Date).ThenByDescending(p => p.Time);





                GridPaging.CountAllRecord = q.Count();
                GridPaging.GridLoad();
                lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();

            }
        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            try
            {
                string BackupPath = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];
                if (File.Exists(BackupPath + hf_SelectValueID))
                    File.Delete(BackupPath + hf_SelectValueID);

                EventLog.Loging(" پشتیبانی با عنوان '" + hf_SelectValueID + "' حذف گردید.", EventTypeIds.DELETE, "BACKUP_M", CurrentUser.UID);
                DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید");
            }
            catch { }
        }

        public void GetbackupDB()
        {
            try
            {
                string fileName = "DB" + DateShamsi.GetCurrentDate("") + "" + DateShamsi.GetCurrentHour("") + "";
                string BackupPath = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];//آدرس مکانی که باید پشتیبانی گرفته شود
                if (!Directory.Exists(BackupPath))
                {
                    Directory.CreateDirectory(BackupPath);
                }
                dc.ExecuteCommand("BackUp DATABASE " + dc.Connection.Database + " to disk='" + BackupPath + fileName + ".emo" + "'  with compression, init;");


                if (!Directory.Exists(BackupPath))
                {
                    Directory.CreateDirectory(BackupPath);
                }

                using (var zip = new Ionic.Zip.ZipFile())
                {
                    zip.Password = EmoNetUtility.PasswordZipFile;
                    zip.AddFile(BackupPath + fileName + ".emo");
                    zip.Save(BackupPath + fileName + ".bak");
                }
                if (File.Exists(BackupPath + fileName + ".emo"))
                {
                    File.Delete(BackupPath + fileName + ".emo");
                }

                EventLog.Loging("پشتیبانی از فایل دیتابیس با عنوان'"+ fileName + ".bak" + "' گرفته شد. ", EventTypeIds.SAVE, "BACKUP_M", CurrentUser.UID);
                DisplayMessage.ShowSeccessMessage("فایل پشتیبانی با موفقیت گرفته شد");
            }
            catch { }
        }

        public void GetBackupAttachment(HttpServerUtilityBase server)
        {
            try
            {
                string fileName = "IMG" + DateShamsi.GetCurrentDate("") + "" + DateShamsi.GetCurrentHour("") + ".bak";
                string BackupPath = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];//آدرس مکانی که باید پشتیبانی گرفته شود
                if (!Directory.Exists(BackupPath))
                {
                    Directory.CreateDirectory(BackupPath);
                }
                string DirectoryOnDisk = server.MapPath("~/Attachment");
                using (var zip = new Ionic.Zip.ZipFile())
                {
                    zip.Password = EmoNetUtility.PasswordZipFile;
                    zip.AddDirectory(DirectoryOnDisk + "/Advertising", "Advertising");
                    zip.AddDirectory(DirectoryOnDisk + "/Images", "Images");
                    zip.AddDirectory(DirectoryOnDisk + "/Lottary", "Lottary");
                    zip.Save(BackupPath + fileName);
                }

                EventLog.Loging("پشتیبانی از فایل سیستم با عنوان'" + fileName  + "' گرفته شد. ", EventTypeIds.SAVE, "BACKUP_M", CurrentUser.UID);
                DisplayMessage.ShowSeccessMessage("فایل پشتیبانی با موفقیت گرفته شد");
            }
            catch { }

        }

    }
}