﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;

namespace restauran.Models.Pages
{
    public class M_EventsModel : MasterPageModel
    {
        public string hfContentValue = "0";

        public string txtOnvan = "";
        public string txtStartDate = "";
        public string txtPagename = "";
        public string txtEndDate = "";
        public string cboSelectEvebtTypeids = "";

        public List<EventType> lstEventTypes = new List<EventType>();
        public List<Event> lst_content_Table = new List<Event>();

        public GridPageNumber GridPaging = new GridPageNumber();

        public M_EventsModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            Bind();
        }

        public M_EventsModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            Bind();
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            hfContentValue=frm["hfContent"].ToString().Trim();
            txtOnvan = frm["txtOnvan"].ToString().Trim();
            txtPagename = frm["txtPagename"].ToString().Trim();
            txtStartDate = frm["txtStartDate"].ToString().Trim();
            cboSelectEvebtTypeids = Utility.EncryptedQueryString.Decrypt(frm["cboSelectEvebtTypeids"].ToString().Trim());
            txtEndDate = frm["txtEndDate"].ToString().Trim();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Event>();
            var q = dc.Events.Where(s => txtStartDate == "" || s.DatePersian.CompareTo(txtStartDate) >= 0);

            if (cboSelectEvebtTypeids != "")
            {
                q = q.Where(s => s.EventTypeId.ToString() == cboSelectEvebtTypeids);
            }

            if (txtEndDate != "")
            {
                q = q.Where(s => s.DatePersian.CompareTo(txtEndDate) <= 0);
            }
            if (txtOnvan != "")
            {
                q = q.Where(
                s => s.DSC.Contains(txtOnvan)
                );
            }
            if (txtPagename != "")
            {
                q = q.Where(
                s => 
                 s.PageName.Contains(txtPagename)
                );
            }
            q = q.OrderByDescending(s => s.DatePersian).ThenByDescending(s => s.TimePersian);

            GridPaging.lst_headerName.Add("نام کاربر");
            GridPaging.lst_headerName.Add("IP");
            GridPaging.lst_headerName.Add("تاریخ");
            GridPaging.lst_headerName.Add("زمان");
            GridPaging.lst_headerName.Add("رخداد");
            GridPaging.lst_headerName.Add("عنوان صفحه");
            GridPaging.lst_headerName.Add("توضیحات");


            GridPaging.Columns = 8;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }

        public void Bind()
        {
            lstEventTypes= new List<EventType>();
            lstEventTypes = dc.EventTypes.OrderBy(s => s.Priority).ToList();
            lstEventTypes.Insert(0, new EventType { Id = -1, Name = "همه" });
        }

    }
}