﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_Edit_SabadKharidModel : MasterPageModel
    {

        public string txtOnvan = "";
        public string hfContent = "0";

        public string cboSelectVaziatType = "";
        public string txtStartDate = "";
        public string txtEndDate = "";

        public string hf_SelectValueID = "";

        public List<SabadKharid> lst_content_Table = new List<SabadKharid>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_Edit_SabadKharidModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_Edit_SabadKharidModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            cboSelectVaziatType = frm["cboSelectVaziatType"].ToString().Trim().ToUpper();
            txtStartDate = frm["txtStartDate"].ToString().Trim();
            txtEndDate = frm["txtEndDate"].ToString().Trim();

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<SabadKharid>();



            var q = (from p in dc.SabadKharids
                     where
                     p.IsDeleted == false
                     &&
                     p.SabadKharidItems.Any()
                     &&
                     (
                     (cboSelectVaziatType == "" || cboSelectVaziatType == "ALL")
                     ||
                     (
                        cboSelectVaziatType == "DARHALKHARID"
                        &&
                        p.IsKharid == false
                     )
                     ||
                     (
                        cboSelectVaziatType == "BARRASSI"
                        &&
                        p.IsKharid == true
                        &&
                        p.IsTahvilBeMoshtari == false
                        &&
                        (p.UserTahvilDahandeID == null || p.UserTahvilDahandeID == Guid.Empty)
                     )
                     ||
                     (
                        cboSelectVaziatType == "TOZIE"
                        &&
                        p.IsKharid == true
                        &&
                        p.IsTahvilBeMoshtari == false
                        &&
                        (p.UserTahvilDahandeID != null && p.UserTahvilDahandeID != Guid.Empty)
                     )
                     ||
                     (
                        cboSelectVaziatType == "FINISH"
                        &&
                        p.IsKharid == true
                        &&
                        p.IsTahvilBeMoshtari == true
                        &&
                        (p.UserTahvilDahandeID != null && p.UserTahvilDahandeID != Guid.Empty)
                     )
                     )

                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.CodeRahgiri.Contains(txtOnvan.Trim()))
                           ||
                           p.userMoshtari.FullName.Contains(txtOnvan.Trim())
                           ||
                           p.userMoshtari.OnvaneSherkat.Contains(txtOnvan.Trim())
                           )
                     )
                     select p);
            if (txtStartDate != "")
            {
                q = q.Where(s => s.DateSabtSefareshKharid_Fa != null && s.DateSabtSefareshKharid_Fa.CompareTo(txtStartDate) >= 0);
            }

            if (txtEndDate != "")
            {
                q = q.Where(s => s.DateSabtSefareshKharid_Fa != null && s.DateSabtSefareshKharid_Fa.CompareTo(txtEndDate) <= 0);
            }

            q = q.OrderByDescending(s => s.DateTimeSabtSefareshKharid);

            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("تاریخ سفارش");
            GridPaging.lst_headerName.Add("کد رهگیری");
            GridPaging.lst_headerName.Add("درخواست دهنده");
            GridPaging.lst_headerName.Add("وضعیت");
            GridPaging.lst_headerName.Add("آخرین تغییرات");
            GridPaging.lst_headerName.Add("توضیحات");
            GridPaging.Columns = 8;

            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }



    }
}