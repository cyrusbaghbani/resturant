﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_Reserve_ProductsModel : MasterPageModel
    {

        public string hfContentValue = "0";
        public string hf_SelectID = "";
        public string txtonvan = "";



        public string txtStartDate = "";
        public string txtEndDate = "";
        public string cboSelectBrand = "";
        public string CboProductType = "";

        public List<SabadKharidItem> lst_content_Table = new List<SabadKharidItem>();
        public List<ProductType> lst_ProductType = new List<ProductType>();
        public List<Brand> lst_Brand = new List<Brand>();
        public GridPageNumber GridPaging = new GridPageNumber();
        public M_Reserve_ProductsModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindCambo();
        }

        public M_Reserve_ProductsModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindCambo();
            BindForms(frm);
        }
        public void BindCambo()
        {
            lst_ProductType = new List<ProductType>();
            lst_ProductType = dc.ProductTypes.Where(s => s.IsDeleted == false && s.ParentId == null).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lst_ProductType.Insert(0, new ProductType() { Id = -1, Name = "همه ..." });

            lst_Brand = new List<Brand>();
            lst_Brand = dc.Brands.Where(s => s.IsDeleted == false).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lst_Brand.Insert(0, new Brand() { Id = -1, Name = "همه ..." });
        }
        public void BindForms(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            hf_SelectID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectID"].ToString().Trim());
            CboProductType = Utility.EncryptedQueryString.Decrypt(frm["CboProductType"].ToString().Trim());
            cboSelectBrand = Utility.EncryptedQueryString.Decrypt(frm["cboSelectBrand"].ToString().Trim());
            txtonvan = frm["txtonvan"].ToString().Trim();
            hfContentValue = frm["hfContentValue"].ToString().Trim();
            txtStartDate = frm["txtStartDate"].ToString().Trim();
            txtEndDate = frm["txtEndDate"].ToString().Trim();

            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<SabadKharidItem>();
            var q = (from p in dc.SabadKharidItems
                     where
                     p.SabadKharid.IsDeleted == false
                     &&
                     p.SabadKharid.IsKharid == false
                     select p);



            if (txtStartDate != "")
            {
                q = q.Where(s => s.DateSabt_Fa.CompareTo(txtStartDate) >= 0);
            }

            if (txtEndDate != "")
            {
                q = q.Where(s => s.DateSabt_Fa.CompareTo(txtEndDate) <= 0);
            }
            if (txtonvan != "")
            {
                q = q.Where(s => s.SabadKharid.CodeRahgiri.Contains(txtonvan) || (s.SabadKharid.userMoshtari.FullName + " [" + (s.SabadKharid.userMoshtari.OnvaneSherkat==null?"": s.SabadKharid.userMoshtari.OnvaneSherkat) + "]").Contains(txtonvan));
            }
            if (CboProductType != "")
            {
                q = q.Where(s => s.Product.ProductType.ParentId != null && s.Product.ProductType.ParentId.ToString() == CboProductType);
            }
            if (cboSelectBrand != "")
            {
                q = q.Where(s => s.Product.BrandId.ToString() == cboSelectBrand);
            }
            q = q.OrderByDescending(s => s.SabadKharid.DateTimeAkharinTaghirat).ThenByDescending(s => s.SabadKharid.CodeRahgiri);

            GridPaging.lst_headerName.Add("کدرهگیری");
            GridPaging.lst_headerName.Add("نام مشتری");
            GridPaging.lst_headerName.Add("زمان ثبت");
            GridPaging.lst_headerName.Add("زمان آخرین تغییر سبد");           
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("نوع خرید");
            GridPaging.lst_headerName.Add("تعداد");
            GridPaging.lst_headerName.Add("قیمت واحد ثبت شده");
            GridPaging.lst_headerName.Add("قیمت واحد جاری");
           
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 11 : 10;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }
        public void DeleteRows()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید.");
                return;
            }
            var obj = dc.SabadKharidItems.SingleOrDefault(s => s.UID.ToString() == hf_SelectID);
            if (obj == null || obj.SabadKharid.IsDeleted == true || obj.SabadKharid.IsKharid == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.SabadKharid.IsKharid == true)
            {
                DisplayMessage.ShowErrorMessage("این کالا خریداری شده است");
                return;
            }

            string Dsc = " کالای \'" + (obj.Product.ProductType.Parent.IsShowName ? obj.Product.ProductType.Parent.Name : "") + " " + obj.Product.ProductType.Name + " " + obj.Product.Brand.Name + " [" + (obj.Price.IsDarhalEngheza ? "فروش ویژه" : (obj.Price.IsTakhfifOmomi ? "جشنواره عمومی" : (obj.Price.IsTakhfifEkhtesasi ? "جشنواره اختصاصی" : (obj.Price.IsPriceAsli ? "اصلی" : "")))) + "]\' در سبد خرید با کد رهگیری '" + obj.SabadKharid.CodeRahgiri + "' به تعداد '" + obj.Count + " " + obj.Product.Unit.Name + "' قیمت '" + obj.PriceVahed.ToString("###,##0") + " ریال' مربوط به مشتری '" + obj.SabadKharid.userMoshtari.FullName + " [" + obj.SabadKharid.userMoshtari.OnvaneSherkat + "] " + "' حذف گردید ";
            dc.SabadKharidItems.DeleteOnSubmit(obj);
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");

            EventLog.Loging(Dsc, EventTypeIds.DELETE, "RESERVE_PRODUCTS_M", CurrentUser.UID);
        }

    }
}

