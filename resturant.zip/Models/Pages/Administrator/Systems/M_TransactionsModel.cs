﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using App_Start.Utility;
using Models.Controll;

namespace restauran.Models.Pages
{
    public class M_TransactionsModel : MasterPageModel
    {
        public string hfContentValue = "0";

        public string txtOnvan = "";

        public string txtStartDate = "";
        public string txtEndDate = "";

        public List<Transaction> lst_content_Table = new List<Transaction>();

        public GridPageNumber GridPaging = new GridPageNumber();

        public M_TransactionsModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_TransactionsModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            GridPaging = new GridPageNumber();
            hfContentValue = frm["hfContent"].ToString().Trim();
            txtOnvan = frm["txtOnvan"].ToString().Trim();
            txtStartDate = frm["txtStartDate"].ToString().Trim();
            txtEndDate = frm["txtEndDate"].ToString().Trim();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Transaction>();
            var q = dc.Transactions.Where(s => txtStartDate == "" || s.Date.CompareTo(txtStartDate) >= 0);

            if (txtEndDate != "")
            {
                q = q.Where(s => s.Date.CompareTo(txtEndDate) <= 0);
            }
            if (txtOnvan != "")
            {
                q = q.Where(
                s => s.CodeRahgiri.Contains(txtOnvan)
                || s.FullNameUser.Contains(txtOnvan)
                || s.Info.Contains(txtOnvan)
                || s.STATE.Contains(txtOnvan)
                || s.Dsc.Contains(txtOnvan)
                );
            }
            q = q.OrderByDescending(s => s.DateTime);

            GridPaging.lst_headerName.Add("نام کاربر");
            GridPaging.lst_headerName.Add("کدرهگیری");
            GridPaging.lst_headerName.Add("تاریخ");
            GridPaging.lst_headerName.Add("زمان");
            GridPaging.lst_headerName.Add("مبلغ قابل پرداخت");
            GridPaging.lst_headerName.Add("مبلغ پرداخت شده");
            GridPaging.lst_headerName.Add("وضعیت");
            GridPaging.lst_headerName.Add("توضیحات");
            GridPaging.lst_headerName.Add("پیام");

            GridPaging.Columns = 10;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }
    }
}