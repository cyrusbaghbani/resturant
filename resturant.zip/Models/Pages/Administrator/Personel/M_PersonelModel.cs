﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_PersonelModel : MasterPageModel
    {

        public string txtFullName = "";
        public string hfContent = "0";
        public string txtMobile = "";
        public string hf_SelectValueID = "";

        public List<user> lst_content_Table = new List<user>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_PersonelModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_PersonelModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            hfContent = frm["hfContent"].ToString().Trim();
            txtFullName = frm["txtFullName"].ToString().Trim();
            txtMobile = frm["txtMobile"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<user>();



            var q = (from p in dc.users
                     where
                     p.IsDeleted == false
                     &&
                     p.Role.IsShow == true
                     &&
                     p.Role.IsMenagment == true

                     &&
                     (
                           (txtFullName.Trim() == ""
                           ||
                           p.FullName.Contains(txtFullName.Trim()))
                           &&
                           (txtMobile.Trim() == ""
                           ||
                           ("0" + p.MobileNumber).Contains(txtMobile.Trim()))
                     )
                     select p).OrderBy(s => s.FirstName).ThenBy(s => s.LastName);


            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("نام");
            GridPaging.lst_headerName.Add("نام خانوادگی");
            GridPaging.lst_headerName.Add("شماره همراه");
            GridPaging.lst_headerName.Add("نقش");
            GridPaging.lst_headerName.Add("وضعیت کاربری");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 8 : 7;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.UID == CurrentUser.UID)
            {
                DisplayMessage.ShowErrorMessage("امکان حذف کاربری خود را ندارید");
                return;
            }
            if (obj.CustomerUser.Any(s => s.IsDeleted == false))
            {
                DisplayMessage.ShowErrorMessage("این کاربر در حال حاضر ویزیتور چندین مشتری می باشد. امکان حذف وجود ندارد .");
                return;
            }
            //if (ImportentFunction.IsDependencyUser(obj))
            //{
            //    DisplayMessage.ShowErrorMessage("به دلیل اطلاعات وابسطه امکان حذف کاربر وجود نخواهد داشت.");
            //    return;
            //}

            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' حذف گردید.", EventTypeIds.DELETE, "PERSONEL_M", CurrentUser.UID);

        }

    }
}