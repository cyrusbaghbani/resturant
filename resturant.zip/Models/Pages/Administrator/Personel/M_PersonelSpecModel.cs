﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;

namespace restauran.Models.Pages
{
    public class M_PersonelSpecModel : MasterPageModel
    {

        public string ID = "";
        public string IsSexMan = "";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtDSC = "";
        public string cboRoleSelect = "";
        public string cboSematSelect = "";
        public string txtCodeMeli = "";

        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public string hfINFOContent = "1";
        public string hfUserContent = "1";

        public string IsActive = "true";
        public string txtUSERName = "";
        public string txtpass = "";
        public string txtRePass = "";

        public List<Role> lstRole = new List<Role>();
        public List<Semat> lstSemat = new List<Semat>();

        public void BindForms(FormCollection form)
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            IsSexMan = form["CboSex"].ToString().Trim();
            txtName = form["txtName"].ToString().Trim();
            txtFamily = form["txtFamily"].ToString().Trim();
            txtMobile = form["txtMobile"].ToString().Trim();
            txtTel = form["txtTel"].ToString().Trim();
            txtDSC = form["txtDSC"].ToString().Trim();
            cboRoleSelect = form["CboRole"].ToString().Trim();
            cboSematSelect = form["cboSemat"].ToString().Trim();
            txtCodeMeli = form["txtCodeMeli"].ToString().Trim();

            txtTelCode = form["txtTel"].ToString().Trim();
            txtAddress = form["txtAddress"].ToString().Trim();
            txtEmail = form["txtEmail"].ToString().Trim();

            hfINFOContent = form["hfINFOContent"].ToString().Trim();
            hfUserContent = form["hfUserContent"].ToString().Trim();

            IsActive = form["CboActive"].ToString().Trim().ToLower();
            txtUSERName = form["txtUSERName"] == null ? (obj == null ? "" : obj.UserName) : form["txtUSERName"].ToString().Trim();
            txtpass = form["txtpass"] == null ? "" : form["txtpass"].ToString();
            txtRePass = form["txtRePass"] == null ? "" : form["txtRePass"].ToString();
        }
        private void BindRole()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            int? obj_RoleID = obj == null ? (int?)null : obj.RoleId;

            lstRole = dc.Roles.Where(s => (s.IsShow == true && s.IsMenagment == true && s.IsDeleted == false) || s.Id == obj_RoleID).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstRole.Insert(0, new Role() { Id = -1, Name = "سطح دسترسی را انتخاب کنید..." });
        }
        private void BindSemat()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            int? obj_SematID = obj == null ? (int?)null : obj.SematId;

            lstSemat = dc.Semats.Where(s => (s.IsDeleted == false) || s.Id == obj_SematID).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lstSemat.Insert(0, new Semat() { Id = -1, Name = "سمت را انتخاب کنید..." });
        }
        private void DisplayPersonel()
        {
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
                return;
            txtDSC = obj.Dsc;
            IsSexMan = obj.Is_SexMan == null ? "" : obj.Is_SexMan.ToString().ToLower();
            txtName = obj.FirstName;
            txtFamily = obj.LastName;
            txtMobile = obj.MobileNumber;
            txtTel = obj.Tel_BeHamrah_Code;
            cboRoleSelect = Utility.EncryptedQueryString.Encrypt(obj.RoleId.ToString());
            cboSematSelect = obj.SematId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.SematId.ToString());
            txtCodeMeli = obj.CodeMeli;
            txtAddress = obj.Address;
            txtEmail = obj.Email;
            IsActive = obj.IsActive.ToString().Trim().ToLower();
            txtUSERName = obj.UserName;


        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            var roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            if (!dc.Roles.Any(s => s.Id.ToString() == roleid && s.IsMenagment))
            {
                Msg += (i++).ToString() + " - " + "سطح دسترسی را انتخاب نمایید" + "</br>";
                result = false;
            }
            else
            {
                if (obj != null && obj.RoleId == RoleIds.M_Visitor&& RoleIds.M_Visitor.ToString()!= roleid)
                {
                    if(obj.CustomerUser.Any(s=>s.IsDeleted==false))
                    {
                        Msg += (i++).ToString() + " - " + "به دلیل اینکه کاربر ویزیتور چند مشتری می باشد، در حال حاضر امکان تغییر سطوح دسترسی برای ایشان نمی باشد." + "</br>";
                        result = false;
                    }
                }
            }
            if (txtName == "")
            {
                Msg += (i++).ToString() + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtFamily == "")
            {
                Msg += (i++).ToString() + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtCodeMeli.Trim() != "" && !Validation.IsNationalCode(txtCodeMeli.Trim()))
            {
                Msg += (i++) + " - " + "کد ملی را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (txtMobile.Trim() != "" && Validation.IsMobileNumber(txtMobile.Trim()) == "")
            {
                Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                result = false;

            }

            if (txtEmail.Trim() != "" && !Validation.IsEmail(txtEmail.Trim()))
            {
                Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                result = false;
            }
            else if (txtEmail.Trim() != "")
            {
                if (dc.users.Any(S => S.UID != CurrentUser.UID && S.IsDeleted == false && S.Email == txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }



            if (IsActive == "true")
            {
                if (txtUSERName == "")
                {
                    Msg += (i++).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                    result = false;
                }
                else
                {
                    if (dc.users.Any(s => s.UID.ToString() != ID && s.IsDeleted == false && s.IsActive == true && s.UserName == txtUSERName))
                    {
                        Msg += (i++).ToString() + " - " + "نام کاربری در سیستم باید یکتا باشد." + "</br>";
                        result = false;
                    }
                }

                if (obj == null || obj.Password == null || obj.Password == "")
                {
                    if (txtpass == "")
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtRePass == "")
                    {
                        Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                        result = false;
                    }
                }
                else
                {
                    if (txtpass == "" && txtRePass != "")
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass == "")
                    {
                        Msg += (i++).ToString() + " - " + "تکرار رمز عبور را وارد نمایید." + "</br>";
                        result = false;
                    }
                    if (txtpass != "" && txtRePass != "" && txtpass != txtRePass)
                    {
                        Msg += (i++).ToString() + " - " + "رمز عبور با تکرار آن برابر نمی باشد." + "</br>";
                        result = false;
                    }
                }
            }
            if (IsActive == "false")
            {
                if (ID == CurrentUser.UID.ToString())
                {
                    Msg += (i++).ToString() + " - " + "اجازه غیر فعال کردن نام کاربری خود را ندارید." + "</br>";
                    result = false;
                }
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.users.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new user();
                obj.UID = Guid.NewGuid();
                obj.IsDeleted = false;
                obj.Password = "";
                obj.UserName = "";
                dc.users.InsertOnSubmit(obj);
                IsEdit = false;
            }

            obj.CodeMeli = txtCodeMeli;
            obj.Is_SexMan = IsSexMan == "" ? (bool?)null : IsSexMan == "true";
            obj.FirstName = txtName;
            obj.LastName = txtFamily;
            obj.MobileNumber = txtMobile;
            obj.Tel_BeHamrah_Code = txtTel;
            obj.Dsc = txtDSC.Trim();
            obj.Address = txtAddress;
            obj.Email = txtEmail;


            string roleid = Utility.EncryptedQueryString.Decrypt(cboRoleSelect);
            obj.Role = dc.Roles.First(s => s.Id.ToString() == roleid);

            string sematid = Utility.EncryptedQueryString.Decrypt(cboSematSelect);
            obj.Semat = dc.Semats.FirstOrDefault(s => s.Id.ToString() == sematid);

            obj.IsActive = IsActive == "true";
            if (obj.IsActive)
            {
                obj.UserName = txtUSERName;
                if (txtpass != "")
                    obj.Password = Utility.EncryptedQueryString.GetMD5Hash(txtpass);

            }


            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' درج گردید.", EventTypeIds.SAVE, "PERSONELSPEC_M", CurrentUser.UID);
            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" پرسنل با نام و نام خانوادگی '" + obj.FullName + "' با سطح دسترسی '" + obj.Role.Name + "' ویرایش گردید.", EventTypeIds.EDIT, "PERSONELSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_PersonelSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindRole();
            BindSemat();
            DisplayPersonel();
        }

        public M_PersonelSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindRole();
            BindSemat();
            BindForms(frm);
        }



    }
}