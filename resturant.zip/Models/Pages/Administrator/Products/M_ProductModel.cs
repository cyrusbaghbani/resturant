﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_ProductModel : MasterPageModel
    {


        public string cboProductGroup = "";
        public string hfContent = "0";
        public string cboBrand = "";
        public string hf_SelectValueID = "";
        public string cboSearchTypeSelect = "";


        public List<KalaItem> lst_content_Table = new List<KalaItem>();
        public List<Brand> lstBrand = new List<Brand>();
        public List<ProductType> lstProductType = new List<ProductType>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_ProductModel(user currentUser_, string PageName)
        {

            Intialize(currentUser_, PageName);
            BindCambo();
        }

        public M_ProductModel(FormCollection frm, user currentUser_, string PageName)
        {

            Intialize(currentUser_, PageName);
            BindCambo();
            BindForms(frm);
        }
        private void BindCambo()
        {
            lstBrand = dc.Brands.Where(s => s.IsDeleted == false).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstBrand.Insert(0, new Brand() { Id = -1, Name = "همه ی برند ها" });

            lstProductType = dc.ProductTypes.Where(s => s.IsDeleted == false && s.ParentId == null).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lstProductType.Insert(0, new ProductType() { Id = -1, Name = "همه ی دسته های کالا" });
        }
        public void BindForms(FormCollection frm)
        {
            hfContent = frm["hfContent"].ToString().Trim();
            cboProductGroup = Utility.EncryptedQueryString.Decrypt(frm["cboProductGroup"].ToString().Trim());
            cboSearchTypeSelect = (frm["cboSearchTypeSelect"].ToString().ToUpper().Trim());
            cboBrand = Utility.EncryptedQueryString.Decrypt(frm["cboBrand"].ToString().Trim());
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<KalaItem>();



            var q = (from p in dc.Products
                     where
                     p.IsDeleted == false
                     &&
                     (
                           (cboBrand.Trim() == ""
                           ||
                           (p.BrandId != null && p.BrandId.ToString() == cboBrand)
                           )
                           &&
                           (cboProductGroup.Trim() == ""
                           ||
                           (p.ProductTypeId != null && p.ProductType.ProductGroupTypeId.ToString() == cboProductGroup)
                           )
                     )
                     select p).OrderByDescending(s => s.DateSabt);
            if (cboSearchTypeSelect.ToUpper() == "MOJODIMIN")
            {
                q = q.Where(p =>
                    (
                    p.MojodiCount <= p.MinMojodi
                    ||
                    (p.MojodiCount - (p.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)) ? p.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)).Sum(s => s.Count) : 0
                    )) <= p.MinMojodi
                    )
                    ).OrderByDescending(s => s.DateSabt);

            }

            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("دسته کالا");
            GridPaging.lst_headerName.Add("نوع کالا");
            GridPaging.lst_headerName.Add("برند");
            GridPaging.lst_headerName.Add("نمایش در سایت");
            GridPaging.lst_headerName.Add("موجودی");
            GridPaging.lst_headerName.Add("قیمت جاری");
            GridPaging.lst_headerName.Add("امتیاز کالا");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 10 : 9;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();

            string currentdate = DateShamsi.GetCurrentDate();
            string currentdateTime = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            foreach (var item in list)
            {
                var lstprice = dc.Prices.Where(s => s.ProductId == item.UID && s.IsDeleted == false && (
                (s.IsPriceAsli == true && (s.DateShoro == null || s.DateShoro == "" || s.DateShoro.CompareTo(currentdate) <= 0) && (s.DatePayan == null || s.DatePayan == "" || s.DatePayan.CompareTo(currentdate) >= 0))
                ||
                (

                s.IsTakhfifOmomi == true && (s.DatetimeShoro_Persian != "" && s.DatetimeShoro_Persian.CompareTo(currentdateTime) <= 0) && (s.DatetimePayan_Persian != "" && s.DatetimePayan_Persian.CompareTo(currentdateTime) >= 0)
                            &&
                (s.MojodiProduct - ((s.SabadKharidItems.Any(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true) ? s.SabadKharidItems.Where(t => t.SabadKharid.IsDeleted == false && t.SabadKharid.IsKharid == true).Sum(t => t.Count) : 0)) > 0)

                )
                )).OrderByDescending(s => s.DateSabt);
                var last_price = lstprice.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsPriceAsli == true);
                var last_priceTakhfif = lstprice.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsTakhfifOmomi == true);

                decimal? tedtadReserv = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(item.UID);

                lst_content_Table.Add(new KalaItem()
                {
                    BrandName = item.BrandId == null ? "" : item.Brand.Name,
                    UID = item.UID,
                    FullName = ((item.ProductTypeId != null ? ((item.ProductType.ParentId == null ? "" : item.ProductType.Parent.Name) + " " + item.ProductType.Name + " ") : "") + (item.BrandId == null ? "" : item.Brand.Name)),
                    ProductGroupTypeName = item.ProductTypeId == null ? "" : (item.ProductType.ParentId == null ? "" : item.ProductType.Parent.Name),
                    ProductTypeName = item.ProductTypeId == null ? "" : item.ProductType.Name,
                    Price = last_price == null ? "" : (last_priceTakhfif == null ? (last_price.Price_.ToString("###,##0") + " ریال") : ("<span style=\" text-decoration: line-through;\">" + last_price.Price_.ToString("###,##0") + " ریال" + "</span> ")),
                    TakhfifPrice = last_priceTakhfif == null ? "" : last_priceTakhfif.Price_.ToString("###,##0") + " ریال",
                    MOjodi = item.MojodiCount.ToString("###,##0") + ((tedtadReserv == null || tedtadReserv == 0) ? "" : (" [" + tedtadReserv.Value.ToString("###,##0") + "]")) + " " + item.Unit.Name,
                    NamayeshDarSite = item.IsShowInSite == true ? "بلی" : "خیر",
                    Point_ = item.Points.Any() ? ((item.Points.Sum(s => s.Point1) / item.Points.Count()).ToString("0.0")) : "0",
                    FakePoint = item.Point_Fake == null ? "" : item.Point_Fake.Value.ToString("0.00")
                });
            }

        }

        public void DeleteRow(HttpServerUtilityBase server)
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Products.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null || obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }
            if (obj.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false) || obj.Prices.Any(s => s.IsDeleted == false))
            {
                DisplayMessage.ShowErrorMessage("به دلیل اطلاعات وابسطه امکان حذف کالا وجود نخواهد داشت.");
                return;
            }
            if (obj.ImageUrl != null && obj.ImageUrl != "")
            {
                try
                {
                    string path = server.MapPath(obj.ImageUrl);
                    if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);
                    obj.ImageUrl = "";
                }
                catch { }
            }
            obj.IsDeleted = true;
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
            if (ischange)
                EventLog.Loging(" کالای  '" + ((obj.ProductTypeId != null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name + " ") : "") + (obj.BrandId == null ? "" : obj.Brand.Name)) + "' حذف گردید.", EventTypeIds.DELETE, "PRODUCT_M", CurrentUser.UID);
            FunctionMojodi.NOtificationToMinProd(obj.UID, "");

        }

    }
}

