﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_ProductSpecModel : MasterPageModel
    {
        public string hf_SelectID = "";
        public string txtDatePayanPriceDialog = "";
        public string txtDateShoroPriceDialog = "";
        public string txtPriceDialog = "";
        public string txtMojodiForoshVizhe = "";
        public string txtMaxMojodi = "";
        public string txtMinMojodi = "";
        public string txtFakepoint = "";
        public string txtDarsadHadie = "";
        public string txtDarsadHadieAkharSal = "";

        public string txtMOJODIDialog = "";

        public string ID = "";
        public string txtCodeHamkaran = "";
        public string CboBrand = "";
        public string CboKalaGroup = "";
        public string CboKalaType = "";
        public string CboUnit = "";
        public string txtMojodi = "";
        public string CboShow = "true";
        public string txtPrice = "";
        public string txtInfo = "";


        public string hfIDimgDisplay = "";
        public string hfimgDisplay = "/Images/Img/Emptyimg300.png";
        public string ImageEmpty = "/Images/Img/Emptyimg300.png";
        public string hfINFOContent = "1";
        public string hfContentPrice = "0";
        public string hfContentMojodi = "0";


        public bool IsNew = true;

        public List<Unit> lstUnit = new List<Unit>();
        public List<ProductType> lstKalaType = new List<ProductType>();
        public List<ProductType> lstKalaGroup = new List<ProductType>();
        public List<Brand> lstBrand = new List<Brand>();
        public List<Price> lst_content_TablePrice = new List<Price>();
        public List<Mojodi> lst_content_TableMOJODI = new List<Mojodi>();

        public GridPageNumber GridPagingPrice = new GridPageNumber("price");
        public GridPageNumber GridPagingMOJODI = new GridPageNumber("MOJODI");

        public void BindForms(FormCollection form)
        {
            dc = new DBDataContext();
            var obj = dc.Products.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                IsNew = true;
            }
            else
                IsNew = false;

            txtFakepoint = form["txtFakepoint"].ToString().Trim();
            txtDarsadHadie = form["txtDarsadHadie"] == null ? "" : form["txtDarsadHadie"].ToString().Trim();
            txtDarsadHadieAkharSal = form["txtDarsadHadieAkharSal"] == null ? "" : form["txtDarsadHadieAkharSal"].ToString().Trim();
            txtMinMojodi = form["txtMinMojodi"] == null ? "" : form["txtMinMojodi"].ToString().Trim();
            txtMaxMojodi = form["txtMaxMojodi"] == null ? "" : form["txtMaxMojodi"].ToString().Trim();
            txtPriceDialog = form["txtPriceDialog"] == null ? "" : form["txtPriceDialog"].ToString().Trim();
            txtDateShoroPriceDialog = form["txtDateShoroPriceDialog"] == null ? "" : form["txtDateShoroPriceDialog"].ToString().Trim();
            txtDatePayanPriceDialog = form["txtDatePayanPriceDialog"] == null ? "" : form["txtDatePayanPriceDialog"].ToString().Trim();
            hf_SelectID = form["hf_SelectID"] == null ? "" : Utility.EncryptedQueryString.Decrypt(form["hf_SelectID"].ToString().Trim());

            GridPagingPrice = new GridPageNumber("price");
            GridPagingPrice.pageIndex = form["pageIndex" + GridPagingPrice.name] == null ? (form["hfCurrentPageIndex" + GridPagingPrice.name] == null ? "0" : form["hfCurrentPageIndex" + GridPagingPrice.name].ToString().Trim()) : (form["pageIndex" + GridPagingPrice.name].ToString().Trim());

            txtMOJODIDialog = form["txtMOJODIDialog"] == null ? "" : form["txtMOJODIDialog"].ToString().Trim();

            GridPagingMOJODI = new GridPageNumber("MOJODI");
            GridPagingMOJODI.pageIndex = form["pageIndex" + GridPagingMOJODI.name] == null ? (form["hfCurrentPageIndex" + GridPagingMOJODI.name] == null ? "0" : form["hfCurrentPageIndex" + GridPagingMOJODI.name].ToString().Trim()) : (form["pageIndex" + GridPagingMOJODI.name].ToString().Trim());


            txtCodeHamkaran = form["txtCodeHamkaran"].ToString().Trim();
            CboBrand = form["CboBrand"].ToString().Trim();
            CboKalaGroup = form["CboKalaGroup"].ToString().Trim();
            CboKalaType = form["CboKalaType"].ToString().Trim();
            CboShow = form["CboShow"].ToString().Trim();
            txtInfo = form["txtInfo"].ToString().Trim();
            CboUnit = form["CboUnit"].ToString().Trim();

            hfINFOContent = form["hfINFOContent"] == null ? "0" : form["hfINFOContent"].ToString().Trim();
            hfContentPrice = form["hfContentPrice"] == null ? "0" : form["hfContentPrice"].ToString().Trim();
            hfContentMojodi = form["hfContentMojodi"] == null ? "0" : form["hfContentMojodi"].ToString().Trim();


            hfimgDisplay = form["hfimgDisplay"].ToString();
            hfIDimgDisplay = form["hfIDimgDisplay"].ToString();

            string currentDate = DateShamsi.GetCurrentDate();
            string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(currentDate, DateShamsi.GetCurrentHour().Substring(0, 5));
            if (obj != null)
            {


                var price_objs = dc.Prices.Where(s => s.ProductId == obj.UID && s.IsDeleted == false && (
                     (
                        s.IsPriceAsli == true
                        &&
                        (
                             s.DateShoro != null && s.DateShoro.CompareTo(currentDate) <= 0
                            && (s.DatePayan == null || s.DatePayan == "" || s.DatePayan.CompareTo(currentDate) >= 0)
                        )
                     )
                     ||
                    (
                        s.IsTakhfifOmomi == true
                        &&
                        (
                             s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
                            && (s.DatetimePayan_Persian != null && s.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0)
                        )
                     )
                     ));

                var price_Asli = price_objs.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsPriceAsli == true);
                var price_Takhfif = price_objs.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsTakhfifOmomi == true);

                txtPrice = (price_Asli == null ? "" : price_Asli.Price_.ToString("###,##0")) + (price_Takhfif == null ? "" : ("[" + price_Takhfif.Price_.ToString("###,##0") + " (تخفیف)]"));

                decimal objs_DarHalEngheza = FunctionMojodi.MojodiTedadDarHaleEngheza(obj.UID);
                decimal? objs_ReservDarHalEngheza = FunctionMojodi.MojodiReservHay_TedadDarHaleEngheza(obj.UID);

                decimal? tedtadReserv = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.UID);

                decimal? tedtadReserv_MonghaziShavande = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.UID);
                txtMojodi = obj.MojodiCount.ToString() + (tedtadReserv != null ? (" [" + tedtadReserv + "]") : "");
                txtMojodiForoshVizhe = objs_DarHalEngheza == 0 ? "" : (objs_DarHalEngheza.ToString() + (tedtadReserv_MonghaziShavande != null ? (" [" + tedtadReserv_MonghaziShavande + "]") : ""));

            }
            else
            {
                txtMojodi = form["txtMojodi"] == null ? "" : form["txtMojodi"].ToString();
                txtPrice = form["txtPrice"] == null ? "" : form["txtPrice"].ToString();
            }
        }
        private void BindCambos()
        {
            var obj = dc.Products.SingleOrDefault(s => s.UID.ToString() == ID);



            //
            lstBrand = new List<Brand>();
            int? obj_BrandID = obj == null ? (int?)null : (obj.BrandId);
            lstBrand = dc.Brands.Where(s => s.IsDeleted == false || (s.Id == obj_BrandID)).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstBrand.Insert(0, new Brand() { Id = -1, Name = "برند را انتخاب کنید..." });
            //
            lstKalaGroup = new List<ProductType>();
            int? obj_KalaGroupID = obj == null ? (int?)null : (obj.ProductTypeId == null ? (int?)null : obj.ProductType.ParentId);
            lstKalaGroup = dc.ProductTypes.Where(s => (s.IsDeleted == false && s.ParentId == null) || (s.Id == obj_KalaGroupID)).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lstKalaGroup.Insert(0, new ProductType() { Id = -1, Name = "دسته کالا را انتخاب کنید..." });
            ///
            lstKalaType = new List<ProductType>();
            int? obj_KalaTypID = obj == null ? (int?)null : (obj.ProductTypeId);
            lstKalaType = dc.ProductTypes.Where(s => (s.IsDeleted == false && s.ParentId != null && s.ParentId.ToString() == Utility.EncryptedQueryString.Decrypt(CboKalaGroup)) || (s.Id == obj_KalaTypID)).OrderBy(s => s.Periority == null ? int.MaxValue : s.Periority).ThenBy(s => s.Name).ToList();
            lstKalaType.Insert(0, new ProductType() { Id = -1, Name = (CboKalaGroup == "" ? "ابتدا دسته کالا را انتخاب نمایید..." : "نوع کالا را انتخاب کنید...") });
            //
            lstUnit = new List<Unit>();
            int? obj_UNITID = obj == null ? (int?)null : (obj.UnitId);
            lstUnit = dc.Units.Where(s => (s.IsDeleted == false) || (s.Id == obj_UNITID)).OrderBy(s => s.Priority == null ? int.MaxValue : s.Priority).ThenBy(s => s.Name).ToList();
            lstUnit.Insert(0, new Unit() { Id = -1, Name = "واحد را انتخاب کنید..." });


        }

        private void DisplayInfo()
        {
            dc = new DBDataContext();
            var obj = dc.Products.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                IsNew = true;
                return;
            }
            IsNew = false;
            ID = obj.UID.ToString();
            txtCodeHamkaran = obj.Code;
            CboBrand = obj.BrandId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.BrandId.ToString());
            CboKalaGroup = obj.ProductTypeId == null ? "" : (obj.ProductType.ParentId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.ProductType.ParentId.ToString()));
            CboKalaType = obj.ProductTypeId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.ProductTypeId.ToString());
            CboUnit = obj.UnitId == null ? "" : Utility.EncryptedQueryString.Encrypt(obj.UnitId.ToString());
            txtFakepoint = obj.Point_Fake == null ? "" : obj.Point_Fake.Value.ToString("0.00");
            txtDarsadHadie = obj.DarsadTakhfif_For_AllMonth.ToString("0");
            txtDarsadHadieAkharSal = obj.DarsadTakhfif_For_EndMonth.ToString("0");

            CboShow = obj.IsShowInSite.ToString().ToLower();
            txtInfo = obj.Information;
            hfimgDisplay = (obj.ImageUrl == null || obj.ImageUrl.Trim() == "") ? ImageEmpty : obj.ImageUrl;
            hfIDimgDisplay = (obj.ImageUrl == null || obj.ImageUrl.Trim() == "") ? "" : "HASIMAGE";

            string currentDate = DateShamsi.GetCurrentDate();
            string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(currentDate, DateShamsi.GetCurrentHour().Substring(0, 5));

            var price_objs = dc.Prices.Where(s => s.ProductId == obj.UID && s.IsDeleted == false && (
                 (
                    s.IsPriceAsli == true
                    &&
                    (
                         s.DateShoro != null && s.DateShoro.CompareTo(currentDate) <= 0
                        && (s.DatePayan == null || s.DatePayan == "" || s.DatePayan.CompareTo(currentDate) >= 0)
                    )
                 )
                 ||
                (
                    s.IsTakhfifOmomi == true
                    &&
                    (
                         s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
                        && (s.DatetimePayan_Persian != null && s.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0)
                    )
                 )
                 ));



            txtMinMojodi = obj.MinMojodi.ToString("###,##0");
            txtMaxMojodi = obj.MaxMojodi.ToString("###,##0");


            var price_Asli = price_objs.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsPriceAsli == true);
            var price_Takhfif = price_objs.OrderByDescending(s => s.DateSabt).FirstOrDefault(s => s.IsTakhfifOmomi == true);


            decimal objs_DarHalEngheza = FunctionMojodi.MojodiTedadDarHaleEngheza(obj.UID);
            decimal? objs_ReservDarHalEngheza = FunctionMojodi.MojodiReservHay_TedadDarHaleEngheza(obj.UID);

            decimal? tedtadReserv = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.UID);

            decimal? tedtadReserv_MonghaziShavande = FunctionMojodi.TedadReserveProduct_BdoneMonghaziHa(obj.UID);
            txtMojodi = obj.MojodiCount.ToString("###,##0") + (tedtadReserv != null ? (" [" + tedtadReserv.Value.ToString("###,##0") + "]") : "");
            txtMojodiForoshVizhe = objs_DarHalEngheza == 0 ? "" : (objs_DarHalEngheza.ToString("###,##0") + (tedtadReserv_MonghaziShavande != null ? (" [" + tedtadReserv_MonghaziShavande.Value.ToString("###,##0") + "]") : ""));

            txtPrice = (price_Asli == null ? "" : price_Asli.Price_.ToString("###,##0")) + (price_Takhfif == null ? "" : ("[" + price_Takhfif.Price_.ToString("###,##0") + " (تخفیف)]"));
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (txtCodeHamkaran == "")
            {
                Msg += (i++).ToString() + " - " + "کد کالا را وارد نمایید." + "</br>";
                result = false;
            }
            else if (dc.Products.Any(s => s.UID.ToString() != ID && s.IsDeleted == false && s.Code == txtCodeHamkaran))
            {
                Msg += (i++).ToString() + " - " + "این کد کالا قبلا در سیستم ثبت شده است." + "</br>";
                result = false;
            }
            string brandid = EncryptedQueryString.Decrypt(CboBrand);
            if (!dc.Brands.Any(s => s.Id.ToString() == brandid))
            {
                Msg += (i++).ToString() + " - " + "برند را انتخاب نمایید" + "</br>";
                result = false;
            }
            if (!dc.ProductTypes.Any(s => s.Id.ToString() == EncryptedQueryString.Decrypt(CboKalaGroup)))
            {
                Msg += (i++).ToString() + " - " + "دسته کالا را انتخاب نمایید" + "</br>";
                result = false;
            }
            string producttypeid = EncryptedQueryString.Decrypt(CboKalaType);
            if (!dc.ProductTypes.Any(s => s.Id.ToString() == producttypeid))
            {
                Msg += (i++).ToString() + " - " + "نوع کالا را انتخاب نمایید" + "</br>";
                result = false;
            }
            string unitid = EncryptedQueryString.Decrypt(CboUnit);
            if (!dc.Units.Any(s => s.Id.ToString() == unitid))
            {
                Msg += (i++).ToString() + " - " + "واحد را انتخاب نمایید" + "</br>";
                result = false;
            }
            decimal temphadie = 0;



            if (txtFakepoint != "" && !decimal.TryParse("0" + txtFakepoint.Replace(",", "").Replace("،", ""), out temphadie))
            {
                Msg += (i++).ToString() + " - " + "امتیاز کالا را صحیح و عددی بین 0 تا 5 وارد نمایید." + "</br>";
                result = false;
            }
            else if (txtFakepoint != "")
            {
                if (temphadie > 5 || temphadie < 0)
                {
                    Msg += (i++).ToString() + " - " + "امتیاز کالا را صحیح و عددی بین 0 تا 5 وارد نمایید." + "</br>";
                    result = false;
                }
            }
            temphadie = 0;
            if (txtDarsadHadie == "" || !decimal.TryParse("0" + txtDarsadHadie.Replace(",", "").Replace("،", ""), out temphadie))
            {
                Msg += (i++).ToString() + " - " + "درصد هدیه را به صورت عددی و صحیح بین 0 تا 100 وارد نمایید." + "</br>";
                result = false;
            }
            else if (temphadie < 0 || temphadie > 100)
            {
                Msg += (i++).ToString() + " - " + "درصد هدیه را به صورت عددی و صحیح بین 0 تا 100 وارد نمایید." + "</br>";
                result = false;
            }



            if (txtDarsadHadieAkharSal == "" || !decimal.TryParse("0" + txtDarsadHadieAkharSal.Replace(",", "").Replace("،", ""), out temphadie))
            {
                Msg += (i++).ToString() + " - " + "درصد هدیه وفاداری را به صورت عددی و صحیح بین 0 تا 100 وارد نمایید." + "</br>";
                result = false;
            }
            else if (temphadie < 0 || temphadie > 100)
            {
                Msg += (i++).ToString() + " - " + "درصد هدیه وفاداری را به صورت عددی و صحیح بین 0 تا 100 وارد نمایید." + "</br>";
                result = false;
            }

            decimal maxtemp = 0;
            if (txtMaxMojodi == "" || !decimal.TryParse("0" + txtMaxMojodi.Replace(",", "").Replace("،", ""), out maxtemp))
            {
                Msg += (i++).ToString() + " - " + "حداکثر موجودی کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            decimal mintemp = 0;
            if (txtMinMojodi == "" || !decimal.TryParse("0" + txtMinMojodi.Replace(",", "").Replace("،", ""), out mintemp))
            {
                Msg += (i++).ToString() + " - " + "حداقل موجودی کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (IsNew)
            {
                decimal temp = 0;
                if (txtMojodi == "" || !decimal.TryParse("0" + txtMojodi.Replace(",", "").Replace("،", ""), out temp))
                {
                    Msg += (i++).ToString() + " - " + "موجودی کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                    result = false;
                }
                else if (maxtemp < temp)
                {
                    Msg += (i++).ToString() + " - " + "موجودی وارد شده از حداکثر موجودی بیشتر است." + "</br>";
                    result = false;
                }
                if (txtPrice == "" || !decimal.TryParse("0" + txtPrice.Replace(",", "").Replace("،", ""), out temp))
                {

                    Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                    result = false;
                }
                else if (temp <= 0)
                {
                    Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح و بزرگتر از صفر وارد نمایید." + "</br>";
                    result = false;
                }
            }
            if (result)
            {
                if (dc.Products.Any(s => s.UID.ToString() != ID && s.BrandId.ToString() == brandid && s.ProductTypeId.ToString() == producttypeid && s.UnitId.ToString() == unitid && s.IsDeleted == false))
                {
                    Msg += (i++).ToString() + " - " + "این کالا قبلا در سیستم ثبت شده است." + "</br>";
                    result = false;
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }
        public void Save(HttpServerUtilityBase server = null)
        {
            decimal price = 0;
            var obj = dc.Products.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Product();
                obj.UID = Guid.NewGuid();
                obj.IsDeleted = false;
                decimal temp = 0;
                obj.MojodiCount = (txtMojodi == "" || !decimal.TryParse("0" + txtMojodi.Replace(",", "").Replace("،", ""), out temp)) ? 0 : temp;
                obj.DateSabt = DateTime.Now;
                if (obj.MojodiCount != 0)
                {
                    Mojodi m = new Mojodi();
                    m.Count = obj.MojodiCount;
                    m.DateShoro = DateShamsi.GetCurrentDate();
                    m.DateTimeSabt = DateTime.Now;
                    m.IsDeleted = false;
                    m.Product = obj;
                    m.TimeShoro = DateShamsi.GetCurrentHour();
                    m.UID = Guid.NewGuid();
                    dc.Mojodis.InsertOnSubmit(m);
                }
                price = (txtPrice == "" || !decimal.TryParse("0" + txtPrice.Replace(",", "").Replace("،", ""), out temp)) ? 0 : temp;
                if (temp != 0)
                {
                    Price p = new Price();
                    p.UID = Guid.NewGuid();
                    p.IsDeleted = false;
                    p.Product = obj;
                    p.Price_ = price;
                    p.IsPriceAsli = true;
                    p.DateShoro = DateShamsi.GetCurrentDate();
                    p.DateSabt = DateTime.Now;

                    dc.Prices.InsertOnSubmit(p);
                }
                dc.Products.InsertOnSubmit(obj);

            }
            decimal ttemp = 0;
            obj.MaxMojodi = (txtMaxMojodi == "" || !decimal.TryParse("0" + txtMaxMojodi.Replace(",", "").Replace("،", ""), out ttemp)) ? 0 : ttemp;
            obj.MinMojodi = (txtMinMojodi == "" || !decimal.TryParse("0" + txtMinMojodi.Replace(",", "").Replace("،", ""), out ttemp)) ? 0 : ttemp;
            obj.DarsadTakhfif_For_EndMonth = (txtDarsadHadieAkharSal == "" || !decimal.TryParse("0" + txtDarsadHadieAkharSal.Replace(",", "").Replace("،", ""), out ttemp)) ? 0 : ttemp;
            obj.DarsadTakhfif_For_AllMonth = (txtDarsadHadie == "" || !decimal.TryParse("0" + txtDarsadHadie.Replace(",", "").Replace("،", ""), out ttemp)) ? 0 : ttemp;


            obj.Point_Fake = txtFakepoint == "" ? (decimal?)null : ((!decimal.TryParse("0" + txtFakepoint.Replace(",", "").Replace("،", ""), out ttemp)) ? 0 : ttemp);

            obj.Code = txtCodeHamkaran;
            obj.Brand = dc.Brands.FirstOrDefault(s => s.Id.ToString() == EncryptedQueryString.Decrypt(CboBrand));
            obj.ProductType = dc.ProductTypes.FirstOrDefault(s => s.Id.ToString() == EncryptedQueryString.Decrypt(CboKalaType));
            obj.Unit = dc.Units.FirstOrDefault(s => s.Id.ToString() == EncryptedQueryString.Decrypt(CboUnit));
            obj.IsShowInSite = CboShow.ToLower() == "true";
            obj.Information = txtInfo;

            if (hfIDimgDisplay != "HASIMAGE")
            {
                if (obj.ImageUrl != null && obj.ImageUrl != "")
                {
                    try
                    {
                        string path = server.MapPath(obj.ImageUrl);
                        if (System.IO.File.Exists(path))
                            System.IO.File.Delete(path);
                        obj.ImageUrl = "";
                    }
                    catch { }
                }

                if (hfimgDisplay != "REMOVE" && hfimgDisplay != "")
                {
                    string id = EncryptedQueryString.Decrypt(hfIDimgDisplay);
                    var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == id);

                    if (tmp != null)
                    {
                        string src = server.MapPath(tmp.src);
                        if (System.IO.File.Exists(src))
                        {
                            string dst = "/Attachment/Images/Kala/" + Guid.NewGuid().ToString() + System.IO.Path.GetExtension(tmp.src);
                            System.IO.File.Move(src, server.MapPath(dst));
                            obj.ImageUrl = dst;
                            dc.Temps.DeleteOnSubmit(tmp);
                        }
                        else
                            dc.Temps.DeleteOnSubmit(tmp);
                    }
                }
            }
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsNew == true)
            {
                EventLog.Loging(" کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' با قیمت '" + price.ToString("###,##0") + "' ريال و تعداد اولیه '" + obj.MojodiCount.ToString("###,##0") + "' " + obj.Unit.Name + " درج گردید.", EventTypeIds.SAVE, "PRODUCTSPEC_M", CurrentUser.UID);
            }
            else if (IsNew == false && ischange == true)
            {
                EventLog.Loging(" کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' ویرایش گردید.", EventTypeIds.EDIT, "PRODUCTSPEC_M", CurrentUser.UID);

            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");
            FunctionMojodi.NOtificationToMinProd(obj.UID, "");

        }
        public M_ProductSpecModel(string ID_, user currentUser_, string PageName)
        {
            FunctionMojodi.SETMOJODI(ID);
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();

            DisplayInfo();
            BindCambos();

        }

        public M_ProductSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();


            BindForms(frm);
            BindCambos();

        }

        #region Price
        public void SearchPrice()
        {
            lst_content_TablePrice = new List<Price>();

            var q = (from p in dc.Prices
                     where
                     p.IsDeleted == false
                     &&
                     (
                     p.IsPriceAsli == true
                     )
                     &&

                     p.ProductId.ToString() == ID
                     select p).OrderByDescending(s => s.DateShoro).ThenByDescending(s => s.DateSabt);


            GridPagingPrice.lst_headerName.Add("ویرایش");
            GridPagingPrice.lst_headerName.Add("قیمت");
            GridPagingPrice.lst_headerName.Add("تاریخ شروع");
            GridPagingPrice.lst_headerName.Add("تاریخ پایان");
            if (security.IsDelete)
                GridPagingPrice.lst_headerName.Add("حذف");
            GridPagingPrice.Columns = security.IsDelete ? 6 : 5;
            GridPagingPrice.CountAllRecord = q.Count();
            GridPagingPrice.GridLoad();
            lst_content_TablePrice = GridPagingPrice.IsShowPageNumbering ? q.Skip(GridPagingPrice.SkypeItem()).Take(GridPagingPrice.RowRecord).ToList() : q.ToList();
        }

        public bool CheckValidatePrice()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            decimal temp = 0;
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            var obj = dc.Products.First(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                Msg += (i++).ToString() + " - " + "برای ثبت قیمت ابتدا باید کالا را ثبت نمود." + "</br>";
                result = false;
            }
            if (txtPriceDialog == "" || !decimal.TryParse("0" + txtPriceDialog.Replace(",", "").Replace("،", ""), out temp))
            {

                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }
            else if (temp <= 0)
            {
                Msg += (i++).ToString() + " - " + "قیمت کالا را به صورت عددی و صحیح و بزرگتر از صفر وارد نمایید." + "</br>";
                result = false;
            }
            string dateshoro = DateShamsi.GetShamsiDateString(txtDateShoroPriceDialog);
            string datepayan = DateShamsi.GetShamsiDateString(txtDatePayanPriceDialog);
            if (dateshoro == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (txtDatePayanPriceDialog != "")
            {
                if (datepayan == "")
                {
                    Msg += (i++).ToString() + " - " + "تاریخ پایان را صحیح وارد نمایید." + "</br>";
                    result = false;
                }
                else if (dateshoro.CompareTo(datepayan) > 0)
                {
                    Msg += (i++).ToString() + " - " + "تاریخ شروع باید از تاریخ پایان کوچکتر یا مساوی باشد." + "</br>";
                    result = false;
                }
            }
            if (result)
            {
                if (dc.Prices.Any(s => s.IsDeleted == false && s.IsPriceAsli == true && s.UID.ToString() != hf_SelectID && s.ProductId.ToString() == ID &&
                        (
                        (
                            datepayan == ""
                            &&
                            (
                                dateshoro.CompareTo(s.DateShoro) <= 0
                                ||
                                (
                                    s.DatePayan != null && s.DatePayan != "" && dateshoro.CompareTo(s.DatePayan) <= 0
                                )
                            )
                        )
                        ||
                        (
                            datepayan != ""
                            &&
                            (
                                (
                                    dateshoro.CompareTo(s.DateShoro) <= 0 && datepayan.CompareTo(s.DateShoro) >= 0
                                )
                                ||
                                (
                                    dateshoro.CompareTo(s.DateShoro) >= 0 && s.DatePayan != null
                                    && s.DatePayan != "" && datepayan.CompareTo(s.DatePayan) <= 0
                                )
                                ||
                                (
                                    s.DatePayan != null && s.DatePayan != ""
                                    && dateshoro.CompareTo(s.DatePayan) <= 0 && datepayan.CompareTo(s.DatePayan) >= 0
                                )
                             )
                        )
                        )

                    )
                )
                {
                    Msg += (i++).ToString() + " - " + "بازه ی تاریخی وارد شده، با دیگر بازه های تاریخی تداخل دارد." + "</br>";
                    result = false;
                }
            }

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void SavePrice()
        {
            var obj = dc.Products.First(s => s.UID.ToString() == ID);
            bool Isedit = true;
            var price = dc.Prices.SingleOrDefault(s => s.UID.ToString() == hf_SelectID);
            if (price == null)
            {
                price = new Price();
                price.UID = Guid.NewGuid();
                price.Product = obj;
                price.IsDeleted = false;
                price.IsPriceAsli = true;
                price.DateSabt = DateTime.Now;

                dc.Prices.InsertOnSubmit(price);
                Isedit = false;
            }
            string oldDateShoro = price.DateShoro;
            string oldDatePayan = price.DatePayan;
            decimal oldprice = price.Price_;

            price.DateShoro = DateShamsi.GetShamsiDateString(txtDateShoroPriceDialog);
            price.DatePayan = DateShamsi.GetShamsiDateString(txtDatePayanPriceDialog);
            price.Price_ = decimal.Parse("0" + txtPriceDialog.Replace(",", "").Replace("،", ""));

            var prices = dc.Prices.Where(s => s.IsDeleted == false && s.IsPriceAsli == true && s.ProductId == obj.UID && (s.DatePayan == null || s.DatePayan == "") && price.DateShoro.CompareTo(s.DateShoro) > 0 && s.UID != price.UID);
            foreach (var q in prices)
            {
                q.DatePayan = DateShamsi.AddDaysToShamsiDate(price.DateShoro, 0, 0, -1);
            }
            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (Isedit == false)
            {
                EventLog.Loging("قیمت اصلی کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' درج گردید.(مبلغ: '" + price.Price_.ToString("###,##0") + "' ريال ، تاریخ شروع: '" + price.DateShoro + "' ، تاریخ پایان: '" + price.DatePayan + "')", EventTypeIds.EDIT, "PRODUCTSPEC_M", CurrentUser.UID);
            }
            else if (Isedit == true && ischange == true)
            {
                EventLog.Loging("قیمت اصلی کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' ویرایش گردید.(مبلغ: '" + price.Price_.ToString("###,##0") + "' ريال [" + oldprice.ToString("###,##0") + "] ، تاریخ شروع: '" + price.DateShoro + "' [" + oldDateShoro + "] ، تاریخ پایان: '" + price.DatePayan + "' [" + oldDatePayan + "] گردید)", EventTypeIds.EDIT, "PRODUCTSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");

        }

        public void RemovePrice()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Prices.FirstOrDefault(s => s.UID.ToString() == hf_SelectID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("رکورد یافت نشد.");
                return;
            }
            if (obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این رکورد قبلا حذف شده است");
                return;
            }
            if (obj.IsPriceAsli == true)
            {
                obj.IsDeleted = true;
                dc.SubmitChanges();
                DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید.");
                EventLog.Loging("قیمت اصلی کالای '" + (obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name + "' حذف گردید.(مبلغ: '" + obj.Price_.ToString("###,##0") + "' ريال ، تاریخ شروع: '" + obj.DateShoro + "' ، تاریخ پایان: '" + obj.DatePayan + "')", EventTypeIds.DELETE, "PRODUCTSPEC_M", CurrentUser.UID);

            }

        }
        #endregion

        #region MOJODI
        public void SearchMOJODI()
        {
            lst_content_TableMOJODI = new List<Mojodi>();

            var q = (from p in dc.Mojodis
                     where
                     p.IsDeleted == false
                     &&
                     p.ProductId.ToString() == ID

                     select p).OrderByDescending(s => s.DateShoro).ThenByDescending(s => s.DateTimeSabt);


            GridPagingMOJODI.lst_headerName.Add("ویرایش");
            GridPagingMOJODI.lst_headerName.Add("موجودی");
            GridPagingMOJODI.lst_headerName.Add("تاریخ ثبت");
            if (security.IsDelete)
                GridPagingMOJODI.lst_headerName.Add("حذف");
            GridPagingMOJODI.Columns = security.IsDelete ? 5 : 4;
            GridPagingMOJODI.CountAllRecord = q.Count();
            GridPagingMOJODI.GridLoad();
            lst_content_TableMOJODI = GridPagingMOJODI.IsShowPageNumbering ? q.Skip(GridPagingMOJODI.SkypeItem()).Take(GridPagingMOJODI.RowRecord).ToList() : q.ToList();
        }

        public bool CheckValidateMOJODI()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            decimal temp = 0;
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            var obj = dc.Products.First(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                Msg += (i++).ToString() + " - " + "برای ثبت موجودی ابتدا باید کالا را ثبت نمود." + "</br>";
                result = false;
            }
            if (txtMOJODIDialog == "" || !decimal.TryParse("0" + txtMOJODIDialog.Replace(",", "").Replace("،", ""), out temp))
            {

                Msg += (i++).ToString() + " - " + "موجودی کالا را به صورت عددی و صحیح وارد نمایید." + "</br>";
                result = false;
            }


            if (result)
            {
                if (hf_SelectID != "")
                {

                    if (!IsAllowEditMojodi(temp))
                    {
                        Msg += (i++).ToString() + " - " + "به دلیل اینکه موجودی منفی می شود اجازه ویرایش داده نمی شود." + "</br>";
                        result = false;
                    }


                }
                var Mojodis = dc.Mojodis.SingleOrDefault(s => s.UID.ToString() == hf_SelectID);
                if (Mojodis == null)
                {
                    if (obj.MojodiCount + temp > obj.MaxMojodi)
                    {
                        Msg += (i++).ToString() + " - " + "مجموع موجودی بیشتر از حداکثر موجودی می باشد." + "</br>";
                        result = false;
                    }
                }
                else
                {
                    if (((obj.MojodiCount + temp) - Mojodis.Count) > obj.MaxMojodi)
                    {
                        Msg += (i++).ToString() + " - " + "مجموع موجودی بیشتر از حداکثر موجودی می باشد." + "</br>";
                        result = false;
                    }
                }
            }


            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }
        public void SaveMOJODI()
        {
            var obj = dc.Products.First(s => s.UID.ToString() == ID);
            bool Isedit = true;
            var Mojodis = dc.Mojodis.SingleOrDefault(s => s.UID.ToString() == hf_SelectID);
            if (Mojodis == null)
            {
                Mojodis = new Mojodi();
                Mojodis.UID = Guid.NewGuid();
                Mojodis.Product = obj;
                Mojodis.IsDeleted = false;
                Mojodis.DateTimeSabt = DateTime.Now;
                Mojodis.TimeShoro = DateShamsi.GetCurrentHour();
                Mojodis.DateShoro = DateShamsi.GetCurrentDate();
                dc.Mojodis.InsertOnSubmit(Mojodis);

                Isedit = false;
            }

            decimal oldcount = Mojodis.Count;


            Mojodis.Count = decimal.Parse("0" + txtMOJODIDialog.Replace(",", "").Replace("،", ""));

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (Isedit == false)
            {
                EventLog.Loging("موجودی کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' درج گردید.(موجودی: '" + Mojodis.Count.ToString("###,##0") + "'  ، تاریخ شروع: '" + Mojodis.DateShoro + "' )", EventTypeIds.EDIT, "PRODUCTSPEC_M", CurrentUser.UID);
            }
            else if (Isedit == true && ischange == true)
            {
                EventLog.Loging("موجودی کالای '" + (obj.ProductType.ParentId == null ? (obj.ProductType.Parent.Name + " " + obj.ProductType.Name) : (obj.ProductType.Name)) + " " + obj.Brand.Name + "' ویرایش گردید.(موجودی: '" + Mojodis.Count.ToString("###,##0") + "'  [" + oldcount.ToString("###,##0") + "]   گردید)", EventTypeIds.EDIT, "PRODUCTSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");

            FunctionMojodi.SETMOJODI(obj.UID.ToString());
            FunctionMojodi.NOtificationToMinProd(obj.UID, "");
        }

        public void RemoveMOJODI()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            var obj = dc.Mojodis.FirstOrDefault(s => s.UID.ToString() == hf_SelectID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("رکورد یافت نشد.");
                return;
            }
            if (!IsAllowEditMojodi(0))
            {
                DisplayMessage.ShowErrorMessage("موجودی کالا منفی می شود اجازه حذف موجودی را ندارید.");
                return;
            }


            if (obj.IsDeleted == true)
            {
                DisplayMessage.ShowErrorMessage("این رکورد قبلا حذف شده است");
                return;
            }

            obj.IsDeleted = true;

            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید.");
            EventLog.Loging("موجودی کالای '" + (obj.Product.ProductType.ParentId == null ? (obj.Product.ProductType.Parent.Name + " " + obj.Product.ProductType.Name) : (obj.Product.ProductType.Name)) + " " + obj.Product.Brand.Name + "' حذف گردید.(موجودی: '" + obj.Count.ToString("###,##0") + "'  ، تاریخ ثبت: '" + obj.DateShoro + "')", EventTypeIds.DELETE, "PRODUCTSPEC_M", CurrentUser.UID);

            FunctionMojodi.SETMOJODI(obj.UID.ToString());
            FunctionMojodi.NOtificationToMinProd(obj.ProductId, "");
        }

        /// <summary>
        /// تعداد رزرو ها به همراه فروخته شده ها را از کل مجودی کم می کنیم
        /// همچنین تعداد کل منقضی ها را نیز از کل موجودی کم می کنیم
        /// در این بررسی در صورتی که رکوردی در حال ویرایش باشد مقدار جدید ان به عنوانم پارامتر وارد می شود
        /// و موجودی ان در موجدی کل محاسبه نشده و مقدار ویرایش شده محاسبه می شود
        /// </summary>
        /// <param name="temp">مقدار تغییر کرده جاری می باشد</param>
        /// <returns></returns>
        private bool IsAllowEditMojodi(decimal temp)
        {
            string currentDate = DateShamsi.GetCurrentDate();
            string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
            ///تعداد اختصاصی
            var EkhtesassiOrOmomi = dc.Prices.Where(s => s.IsDeleted == false && s.ProductId.ToString() == ID
              && (s.IsTakhfifEkhtesasi == true || s.IsTakhfifOmomi == true)
              && s.DateShoro.CompareTo(currentDatetime) <= 0 && (s.DatePayan.CompareTo(currentDatetime) >= 0));

            decimal ekhtesasi = EkhtesassiOrOmomi.Any(s => s.IsTakhfifEkhtesasi) ? EkhtesassiOrOmomi.Where(s => s.IsTakhfifEkhtesasi == true).Sum(s => (s.MojodiProduct.Value * s.USER_PRICEs.Count())) : 0;
            decimal Omomi = EkhtesassiOrOmomi.Any(s => s.IsTakhfifOmomi) ? EkhtesassiOrOmomi.Where(s => s.IsTakhfifOmomi == true).Sum(s => (s.MojodiProduct.Value)) : 0;
            List<Guid?> lstUID = (EkhtesassiOrOmomi.Select(s => (Guid?)s.UID).ToList());


            decimal MojodiMonghazi = (decimal)(dc.Prices.Any(s => s.IsDeleted == false && s.IsDarhalEngheza == true && s.ProductId.ToString() == ID) ? dc.Prices.Where(s => s.IsDeleted == false && s.IsDarhalEngheza == true && s.ProductId.ToString() == ID).Sum(s => s.MojodiProduct) : 0);

            var sabadKharidlist = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && !lstUID.Contains(s.PriceID) && s.ProductId.ToString() == ID && (s.PriceID == null || (s.Price.IsDarhalEngheza == false)));
            decimal sabadKharidCount = sabadKharidlist.Any() ? sabadKharidlist.Sum(s => s.Count) : 0;
            decimal sumKol = (dc.Mojodis.Any(s => s.UID.ToString() != hf_SelectID && s.IsDeleted == false && s.ProductId.ToString() == ID) ? dc.Mojodis.Where(s => s.UID.ToString() != hf_SelectID && s.IsDeleted == false && s.ProductId.ToString() == ID).Sum(s => s.Count) : 0);

            sumKol = (sumKol + temp) - sabadKharidCount - MojodiMonghazi - ekhtesasi - Omomi;
            return sumKol >= 0;
        }
        #endregion




    }
}
