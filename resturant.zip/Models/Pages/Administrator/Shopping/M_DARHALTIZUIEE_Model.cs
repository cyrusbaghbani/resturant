﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_DARHALTOZIEE_Model : MasterPageModel
    {
        public string txtTahvilGirande = "";
        public string txtOnvan = "";

        public string hfContent = "0";

        public string hf_SelectValueID = "";

        public List<KalaItem> lst_content_Table = new List<KalaItem>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_DARHALTOZIEE_Model(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_DARHALTOZIEE_Model(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            txtTahvilGirande = frm["txtTahvilGirande"].ToString().Trim();
            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<KalaItem>();



            var q = (from p in dc.SabadKharids
                     where
                     p.IsDeleted == false
                     &&
                     p.IsKharid == true
                     &&
                     p.IsTahvilBeMoshtari == false
                     &&
                     p.IsTaiedBarrasi == true
                     &&
                     (p.UserTahvilDahandeID != null && p.UserTahvilDahandeID != Guid.Empty)
                      &&
                     (
                         (CurrentUser.RoleId != RoleIds.M_ToziKonande && CurrentUser.RoleId != RoleIds.M_Visitor)
                         ||
                         (CurrentUser.RoleId == RoleIds.M_ToziKonande && p.UserTahvilDahandeID == CurrentUser.UID)
                         ||
                         (CurrentUser.RoleId == RoleIds.M_Visitor && p.userMoshtari.VisitorUserID == CurrentUser.UID)
                     )
                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.CodeRahgiri.Contains(txtOnvan.Trim()))
                           ||
                           p.userMoshtari.FullName.Contains(txtOnvan.Trim())
                           ||
                           p.userMoshtari.OnvaneSherkat.Contains(txtOnvan.Trim())
                           ||
                           (p.UserTahvilDahandeID != null && p.userTahvilDahande.FullName.Contains(txtOnvan.Trim()))
                           ||
                           (p.DateSabtSefareshKharid_Fa != null && p.DateSabtSefareshKharid_Fa.Contains(txtOnvan.Trim()))
                          ||
                           (p.userMoshtari != null && p.userMoshtari.Address.Contains(txtOnvan.Trim()))
                           )
                     )
                     select p).OrderByDescending(s => s.DateTimeSabtSefareshKharid);


            GridPaging.lst_headerName.Add("تاریخ سفارش");
            GridPaging.lst_headerName.Add("کد رهگیری");
            GridPaging.lst_headerName.Add("درخواست دهنده");
            GridPaging.lst_headerName.Add("توزیع کننده");
            GridPaging.lst_headerName.Add("آدرس");
            GridPaging.lst_headerName.Add("تحویل از انبار");
            GridPaging.lst_headerName.Add("تحویل به مشتری");

            GridPaging.Columns = 8;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();
            foreach (var p in list)
            {
                lst_content_Table.Add(new KalaItem()
                {
                    UID = p.UID,
                    DateShoro = p.DateSabtSefareshKharid_Fa,
                    FullName = p.CodeRahgiri,
                    BrandName = p.UserMoshtariID == null ? "-" : p.userMoshtari.FullName,
                    DatePayan = p.UserTahvilDahandeID == null ? "-" : p.userTahvilDahande.FullName,
                    Imageurl = p.userMoshtari.Address,
                    NamayeshDarSite = p.FullNameTahvilGirande,
                    IsInSabadKharid = !p.SabadKharidItems.Any(s => s.IsTahvilAzAnbar == false || s.IsTahvilAzAnbar == null),
                });
            }

        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            var sabadKharid = dc.SabadKharids.FirstOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (sabadKharid == null)
            {
                Msg += (i++).ToString() + " - " + "سبد خرید انتخاب شده یافت نشد" + "</br>";
                result = false;
            }
            //if (txtTahvilGirande.Trim() == "")
            //{
            //    Msg += (i++).ToString() + " - " + "نام و نام خانوادگی تحویل گیرنده را وارد نمایید" + "</br>";
            //    result = false;
            //}

            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        public void Save()
        {
            var sabadKharid = dc.SabadKharids.FirstOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (sabadKharid != null)
            {
                sabadKharid.IsTahvilBeMoshtari = true;
                sabadKharid.FullNameTahvilGirande = txtTahvilGirande;
                string date = DateShamsi.GetCurrentDate();
                string time = DateShamsi.GetCurrentHour();

                DateTime dt = DateTime.Now;

                sabadKharid.DateTahvilBeMoshtari_Fa = date;
                sabadKharid.DateTimeTahvilBeMoshtari = dt;
                sabadKharid.TimeTahvilBeMoshtari_Fa = time;

                foreach (var q in sabadKharid.SabadKharidItems)
                {
                    q.DateTahvilBeMoshtari_Fa = date;
                    q.DateTimeTahvilBeMoshtari = dt;
                    q.IsTahvilBeMoshtari = true;

                }
                dc.SubmitChanges();
                Notification nt = new Notification();
                nt.SenderID = null;
                nt.DateCreate = DateShamsi.GetCurrentDate();
                nt.NotificationTypeId = NotificationTypeIDs.TahvilSabadKharid;
                nt.TimeCreate = DateShamsi.GetCurrentHour();
                nt.UserId = sabadKharid.UserMoshtariID;
                nt.UID = Guid.NewGuid();
                nt.GruopIDs = Guid.NewGuid();
                nt.Dsc = " سبد خرید با شماره پیگیری " + sabadKharid.CodeRahgiri + " در تاریخ " + sabadKharid.DateTahvilBeMoshtari_Fa + " ساعت " + sabadKharid.TimeTahvilBeMoshtari_Fa + " تحویل " + sabadKharid.FullNameTahvilGirande + "گردید.";
                dc.Notifications.InsertOnSubmit(nt);


                dc.SubmitChanges();
                EventLog.Loging("فاکتور با کد رهگیری " + sabadKharid.CodeRahgiri + " تحویل شد. [" + txtTahvilGirande + "]", EventTypeIds.SAVE, "DARHALTOZIE_M", CurrentUser.UID);
                DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید");
            }
        }

    }
}