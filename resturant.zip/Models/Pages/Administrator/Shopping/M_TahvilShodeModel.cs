﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_TahvilShodeModel : MasterPageModel
    {

        public string txtOnvan = "";

        public string hfContent = "0";

        public string hf_SelectValueID = "";

        public List<SabadKharid> lst_content_Table = new List<SabadKharid>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_TahvilShodeModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_TahvilShodeModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {

            txtOnvan = frm["txtOnvan"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();

            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<SabadKharid>();



            var q = (from p in dc.SabadKharids
                     where
                     p.IsDeleted == false
                     &&
                     p.IsKharid == true
                     &&
                     p.IsTahvilBeMoshtari == true
                      &&
                     (
                         (CurrentUser.RoleId != RoleIds.M_ToziKonande && CurrentUser.RoleId != RoleIds.M_Visitor)
                         ||
                         (CurrentUser.RoleId == RoleIds.M_ToziKonande && p.UserTahvilDahandeID == CurrentUser.UID)
                         ||
                         (CurrentUser.RoleId == RoleIds.M_Visitor && p.userMoshtari.VisitorUserID == CurrentUser.UID)
                     )
                     &&
                     (
                           (txtOnvan.Trim() == ""
                           ||
                           (p.CodeRahgiri.Contains(txtOnvan.Trim()))
                           ||
                           p.userMoshtari.FullName.Contains(txtOnvan.Trim())
                           ||
                           p.userMoshtari.OnvaneSherkat.Contains(txtOnvan.Trim())
                           ||
                           (p.DateSabtSefareshKharid_Fa!=null&&p.DateSabtSefareshKharid_Fa.Contains(txtOnvan.Trim()))
                           ||
                           (p.DateTahvilBeMoshtari_Fa != null && p.DateTahvilBeMoshtari_Fa.Contains(txtOnvan.Trim()))
                           ||
                           (p.FullNameTahvilGirande!= null && p.FullNameTahvilGirande.Contains(txtOnvan.Trim()))
                           ||
                           (p.UserTahvilDahandeID != null && p.userTahvilDahande.FullName.Contains(txtOnvan.Trim()))
                           )
                     )
                     select p).OrderByDescending(s => s.DateTimeTahvilBeMoshtari);


            GridPaging.lst_headerName.Add("تاریخ سفارش");
            GridPaging.lst_headerName.Add("کد رهگیری");
            GridPaging.lst_headerName.Add("درخواست دهنده");
            GridPaging.lst_headerName.Add("تحویل دهنده");
            GridPaging.lst_headerName.Add("تاریخ تحویل");
            GridPaging.lst_headerName.Add("تحویل گیرنده");
            GridPaging.lst_headerName.Add("امتیاز مشتری");
            GridPaging.lst_headerName.Add("نمایش کالا");

            GridPaging.Columns = 9;

            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();


        }



    }
}