﻿using App_Start.Utility;
using Models.Controll;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

namespace restauran.Models.Pages
{
    public class M_SettingModel : MasterPageModel
    {



        public string hfContent = "0";
        public string txtStartDate = "";
        public string txtEndDate = "";
        public string hf_SelectValueID = "";


        public List<Loyalty> lst_content_Table = new List<Loyalty>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_SettingModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
        }

        public M_SettingModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {


            txtStartDate = frm["txtStartDate"].ToString().Trim();
            txtEndDate = frm["txtEndDate"].ToString().Trim();
            hfContent = frm["hfContent"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<Loyalty>();

            string start = DateShamsi.GetShamsiDateString(txtStartDate);
            string end = DateShamsi.GetShamsiDateString(txtEndDate);

            var q = (from p in dc.Loyalties
                     where

                     
                     (

                           (
                            start == ""
                            ||
                            (p.Datepayan != null && p.Datepayan.CompareTo(start) >= 0)
                           )
                           &&
                           (
                            end == ""
                            ||
                            (p.DateShoro != null && p.DateShoro.CompareTo(end) <= 0)
                           )

                     )
                     select p).OrderByDescending(s => s.DatetimeShoro_fa);

        
            GridPaging.lst_headerName.Add("ویرایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("زمان شروع");
            GridPaging.lst_headerName.Add("زمان پایان");
            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 6 : 5;
            GridPaging.CountAllRecord = q.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q.ToList();



        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;

            }

            var obj = dc.Loyalties.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                return;
            }

            dc.Loyalties.DeleteOnSubmit(obj);
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید.");

            EventLog.Loging(" تنظیم هدیه وفاداری با تاریخ شروع '" + obj.DatetimeShoro_fa + "' با تاریخ پایان '" + obj.DateTimePayan_fa + "' حذف گردید.", EventTypeIds.DELETE, "LOYALTY_M", CurrentUser.UID);

        }
    }
}