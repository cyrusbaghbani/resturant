﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;
using Utility;

namespace restauran.Models.Pages
{
    public class M_SettingSpecModel : MasterPageModel
    {

        public string ID = "";
        public string txtDateStart = "";
        public string txtDateEnd = "";
        public string txtTimeStart = "";
        public string txtTimeEnd = "";
        public string txtOnvan = "";

        public string hfINFOContent = "1";



        public void BindForms(FormCollection form)
        {

            hfINFOContent = form["hfINFOContent"].ToString().Trim();
   
            txtOnvan = form["txtOnvan"].ToString().Trim();
            txtDateStart = form["txtDateStart"].ToString().Trim();
            txtDateEnd = form["txtDateEnd"].ToString().Trim();
            txtTimeStart = form["txtTimeStart"].ToString().Trim();
            txtTimeEnd = form["txtTimeEnd"].ToString().Trim();


        }
        private void DisplayInfo()
        {
            var obj = dc.Loyalties.SingleOrDefault(s => s.UID.ToString() == ID);

            if (obj == null)
            {
                txtDateStart = DateShamsi.GetCurrentDate();
                txtTimeStart = DateShamsi.GetCurrentHour().Substring(0, 5);
                return;
            }

            txtOnvan = obj.Onvan;

            txtDateStart = obj.DateShoro;
            txtDateEnd = obj.Datepayan;
            txtTimeStart = obj.TimeShoro;
            txtTimeEnd = obj.TimePayan;
          

        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var obj = dc.Loyalties.SingleOrDefault(s => s.UID.ToString() == ID);
            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (txtOnvan == "")
            {
                Msg += (i++).ToString() + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
                
            }

            string startdate = DateShamsi.GetShamsiDateString(txtDateStart);
            string enddate = DateShamsi.GetShamsiDateString(txtDateEnd);


            bool IsCheckWithTimeJari = true;
            string starttime = DateShamsi.GetShamsiTimeString(txtTimeStart);
            string endtime = DateShamsi.GetShamsiTimeString(txtTimeEnd);

            if (startdate == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع را مشخص نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            else if (obj == null && startdate.CompareTo(DateShamsi.GetCurrentDate()) < 0)
            {
                Msg += (i++).ToString() + " - " + "تاریخ شروع از تاریخ جاری باید بزرگتر باشد." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            if (starttime == "")
            {
                Msg += (i++).ToString() + " - " + "زمان شروع را مشخص نمایید." + "</br>";
                result = false;
                IsCheckWithTimeJari = false;
            }
            //else if (obj == null && starttime.CompareTo(DateShamsi.GetCurrentHour().Substring(0, 5)) < 0)
            //{
            //    Msg += (i++).ToString() + " - " + "زمان شروع از زمان جاری باید بزرگتر باشد." + "</br>";
            //    result = false;
            //    IsCheckWithTimeJari = false;
            //}

            if (obj != null && IsCheckWithTimeJari)
            {

                string datetimeMoghyase = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentDate().Substring(0, 5));
                string date = obj.DatetimeShoro_fa.CompareTo(datetimeMoghyase) <= 0 ? obj.DatetimeShoro_fa : "";

                datetimeMoghyase = date == "" ? datetimeMoghyase : date;

                string startdatetime_ = DateShamsi.GetMixShamsiDateTimeString(startdate, starttime);
                if (startdatetime_.CompareTo(datetimeMoghyase) < 0)
                {
                    Msg += (i++).ToString() + " - " + "تاریخ و زمان شروع از تاریخ وزمان " + (date == "" ? "جاری" : date) + " باید بزرگتر باشد." + "</br>";
                    result = false;
                }
            }


            if (enddate == "")
            {
                Msg += (i++).ToString() + " - " + "تاریخ پایان را وارد نمایید." + "</br>";
                result = false;
            }
            if (endtime == "")
            {
                Msg += (i++).ToString() + " - " + "زمان پایان را وارد نمایید." + "</br>";
                result = false;
            }
            if ((startdate != "" && enddate != "" && startdate.CompareTo(enddate) > 0))
            {
                Msg += (i++) + " - " + "تاریخ شروع باید از تاریخ پایان کوچکتر باشد." + "</br>";
                result = false;
            }
            else if ((startdate != "" && enddate != "" && startdate.CompareTo(enddate) == 0 && starttime != "" && endtime != "" && starttime.CompareTo(endtime) < 0))
            {
                Msg += (i++) + " - " + "زمان شروع باید از زمان پایان کوچکتر باشد." + "</br>";
                result = false;
            }


            if (result)
            {
                startdate = DateShamsi.GetMixShamsiDateTimeString(startdate, starttime);
                enddate = DateShamsi.GetMixShamsiDateTimeString(enddate, endtime);
                bool Find_Any_HasTakhfif = dc.Loyalties.Any(s =>  s.UID.ToString() != ID  
                  &&
                  (
                  (s.DatetimeShoro_fa.CompareTo(startdate) >= 0 && s.DatetimeShoro_fa.CompareTo(enddate) <= 0)
                  ||
                  (s.DateTimePayan_fa.CompareTo(startdate) >= 0 && s.DateTimePayan_fa.CompareTo(enddate) <= 0)
                  ||
                  (s.DatetimeShoro_fa.CompareTo(startdate) >= 0 && s.DateTimePayan_fa.CompareTo(enddate) <= 0)
                  ||
                  (s.DatetimeShoro_fa.CompareTo(startdate) <= 0 && s.DateTimePayan_fa.CompareTo(enddate) >= 0)

                  )

                  );
                if (Find_Any_HasTakhfif)
                {
                    Msg += (i++).ToString() + " - " + "در بازه انتخاب شده هدیه وفاداری دیگری ثبت شده است." + "</br>";
                    result = false;
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = true;
            var obj = dc.Loyalties.SingleOrDefault(s => s.UID.ToString() == ID);
            if (obj == null)
            {
                obj = new Loyalty();
                obj.UID = Guid.NewGuid();
                dc.Loyalties.InsertOnSubmit(obj);
                IsEdit = false;
            }


            string OldDateShoro = obj.DatetimeShoro_fa;
            string OldDatePayan = obj.DateTimePayan_fa;

            obj.Onvan = txtOnvan;
            obj.DateShoro = DateShamsi.GetShamsiDateString(txtDateStart);
            obj.Datepayan = DateShamsi.GetShamsiDateString(txtDateEnd);
            obj.TimeShoro = DateShamsi.GetShamsiTimeString(txtTimeStart);
            obj.TimePayan = DateShamsi.GetShamsiTimeString(txtTimeEnd);
            obj.DatetimeShoro_fa = DateShamsi.GetMixShamsiDateTimeString(obj.DateShoro, obj.TimeShoro);
            obj.DateTimePayan_fa = DateShamsi.GetMixShamsiDateTimeString(obj.Datepayan, obj.TimePayan);

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsEdit == false)
            {
                EventLog.Loging(" هدیه وفاداری با عنوان '" + obj.Onvan + "' با شروع تاریخ '" + obj.DatetimeShoro_fa + "' تا تاریخ '" + obj.DateTimePayan_fa + "' درج گردید.", EventTypeIds.SAVE, "LOYALTYGIFTSPEC_M", CurrentUser.UID);

            }
            else if (IsEdit == true && ischange == true)
            {
                EventLog.Loging(" هدیه وفاداری با عنوان '" + obj.Onvan + "' با شروع تاریخ '" + obj.DatetimeShoro_fa + "' تا تاریخ '" + obj.DateTimePayan_fa  + "' ویرایش گردید. (  شروع تاریخ '" + OldDateShoro + "' تا تاریخ '" + OldDatePayan + "' )", EventTypeIds.EDIT, "LOYALTYGIFTSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_SettingSpecModel(string ID_, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();

            DisplayInfo();
        }

        public M_SettingSpecModel(string ID_, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            BindForms(frm);
        }


    }
}