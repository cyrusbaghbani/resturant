﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using restauran.Models.Access;

namespace restauran.Models.Pages
{
    public class M_NotificationModel : MasterPageModel
    {

        public string txtDateAz = "";
        public string txtDateTa = "";
        public string hfContent = "0";

        public string CboSelectVaziat = "";
        public string CboSelectType = "";
        public string hf_SelectValueID = "";
        public string hf_SelectValueReciveMsg = "";
        public List<NotificationItem> lst_content_Table = new List<NotificationItem>();
        public GridPageNumber GridPaging = new GridPageNumber();

        public M_NotificationModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);

        }

        public M_NotificationModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }

        public void BindForms(FormCollection frm)
        {
            CboSelectVaziat = frm["CboSelectVaziat"] == null ? "" : frm["CboSelectVaziat"].ToString().Trim().ToLower();
            CboSelectType = frm["CboSelectType"] == null ? "" : frm["CboSelectType"].ToString().Trim().ToLower();
            hfContent = frm["hfContent"].ToString().Trim();
            txtDateAz = frm["txtDateAz"].ToString().Trim();
            txtDateTa = frm["txtDateTa"].ToString().Trim();
            hf_SelectValueReciveMsg = frm["hf_SelectValueReciveMsg"].ToString().Trim();
            hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
            GridPaging = new GridPageNumber();
            GridPaging.pageIndex = frm["pageIndex"] == null ? frm["hfCurrentPageIndex"].ToString().Trim() : (frm["pageIndex"].ToString().Trim());
        }

        public void Search()
        {
            lst_content_Table = new List<NotificationItem>();
            List<NotificationItem> q_concat = new List<NotificationItem>();

            ///پیامهای دریافتی
            var System_Notifications = (from p in dc.Notifications
                                        where
                                       (CboSelectType == "" || CboSelectType == "false")
                                        &&
                                        p.IsDeleted_Customer == false
                                        &&
                                        p.UserId == CurrentUser.UID
                                        &&
                                        (
                                        CboSelectVaziat == ""
                                        ||
                                        (CboSelectVaziat == "true" && p.IsRead == true)
                                        ||
                                        (CboSelectVaziat == "false" && p.IsRead == false)
                                        )
                                        &&
                                        //(
                                        //cboRead == ""
                                        //||
                                        //(cboRead == "true" && p.IsRead == true)
                                        //||
                                        //(cboRead == "false" && p.IsRead == false)
                                        //)
                                        //&&
                                        (
                                              (txtDateAz.Trim() == ""
                                              ||
                                              p.DateCreate.CompareTo(txtDateAz.Trim()) >= 0)
                                              &&
                                              (txtDateTa.Trim() == ""
                                              ||
                                              p.DateCreate.CompareTo(txtDateTa.Trim()) <= 0)
                                        )

                                        //group p by new { p.GruopIDs, p.DateCreate, p.TimeCreate, p.Subject, p.Dsc } into g
                                        //select new NotificationItem
                                        select new
                                        {
                                            UID = p.GruopIDs,
                                            DSC = (((p.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + p.NotificationType.Name + " از محصول " + (p.Price.Product.ProductType.Parent.IsShowName ? p.Price.Product.ProductType.Parent.Name : "") + " " + p.Price.Product.ProductType.Name + " " + p.Price.Product.Brand.Name + " به مقدار " + (p.Price.MojodiProduct == null ? (int?)null : p.Price.MojodiProduct.Value) + " " + p.Price.Product.Unit.Name + " با قیمت " + p.Price.Price_ + " ريال از تاریخ " + p.Price.DatetimeShoro_Persian + " تا " + p.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (p.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((p.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (p.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + p.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (p.Dsc) : ""))))).Length < 80
                            ?
                            ((p.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + p.NotificationType.Name + " از محصول " + (p.Price.Product.ProductType.Parent.IsShowName ? p.Price.Product.ProductType.Parent.Name : "") + " " + p.Price.Product.ProductType.Name + " " + p.Price.Product.Brand.Name + " به مقدار " + (p.Price.MojodiProduct == null ? (int?)null : p.Price.MojodiProduct.Value) + " " + p.Price.Product.Unit.Name + " با قیمت " + p.Price.Price_ + " ريال از تاریخ " + p.Price.DatetimeShoro_Persian + " تا " + p.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (p.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((p.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (p.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + p.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (p.Dsc) : "")))))

                            :

                            (((p.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + p.NotificationType.Name + " از محصول " + (p.Price.Product.ProductType.Parent.IsShowName ? p.Price.Product.ProductType.Parent.Name : "") + " " + p.Price.Product.ProductType.Name + " " + p.Price.Product.Brand.Name + " به مقدار " + (p.Price.MojodiProduct == null ? (int?)null : p.Price.MojodiProduct.Value) + " " + p.Price.Product.Unit.Name + " با قیمت " + p.Price.Price_ + " ريال از تاریخ " + p.Price.DatetimeShoro_Persian + " تا " + p.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (p.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((p.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (p.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + p.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (p.Dsc)
                            :
                            ((p.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (p.Dsc) : ""))))).Substring(0, 77) + "...")



                            ),

                                            IsAnyRead = p.IsRead,
                                            recivename = "-",
                                            subject = (p.NotificationTypeId != NotificationTypeIDs.Customid ? p.NotificationType.Name : p.Subject),
                                            DateCreate = p.DateCreate,
                                            TimeCreate = p.TimeCreate,
                                            IsReciveMsg = true,

                                        });

            var query_sys_msg = (from p in System_Notifications
                                 group p by new { p.UID, p.DateCreate, p.TimeCreate, p.subject, p.DSC, p.IsReciveMsg } into g
                                 select new NotificationItem
                                 {

                                     UID = g.Key.UID,
                                     DSC = g.Key.DSC.Length < 120 ? g.Key.DSC : (g.Key.DSC.Substring(0, 120) + "..."),

                                     IsAnyRead = g.Any(t => t.IsAnyRead),
                                     recivename = g.Select(s => s.recivename).ToList(),
                                     subject = g.Key.subject.Length < 60 ? g.Key.subject : (g.Key.subject.Substring(0, 60) + "..."),
                                     DateCreate = g.Key.DateCreate,
                                     TimeCreate = g.Key.TimeCreate,
                                     IsReciveMsg = true,
                                 }).OrderByDescending(s => s.DateCreate).ThenByDescending(s => s.TimeCreate);
            if (security.IsAllowToSendMsg)
            {
                ///پیام های ارسالی
                var q = (from p in dc.Notifications
                         where


                         (CboSelectType == "" || CboSelectType == "true")
                         &&
                         p.IsDeleted_Creater == false
                         &&
                         p.NotificationTypeId == NotificationTypeIDs.Customid
                         &&
                         (p.SenderID == null || p.SenderID == CurrentUser.UID)
                         &&
                         (
                               (txtDateAz.Trim() == ""
                               ||
                               p.DateCreate.CompareTo(txtDateAz.Trim()) >= 0)
                               &&
                               (txtDateTa.Trim() == ""
                               ||
                               p.DateCreate.CompareTo(txtDateTa.Trim()) <= 0)
                         )
                         group p by new { p.GruopIDs, p.DateCreate, p.TimeCreate, p.Subject, p.Dsc } into g
                         select new NotificationItem
                         {
                             UID = g.Key.GruopIDs,
                             DSC = g.Key.Dsc.Length < 120 ? g.Key.Dsc : (g.Key.Dsc.Substring(0, 120) + "..."),

                             IsAnyRead = g.Any(t => t.IsRead),
                             recivename = g.Select(s => s.userNotificationsMalek.FullName).ToList(),
                             subject = g.Key.Subject.Length < 60 ? g.Key.Subject : (g.Key.Subject.Substring(0, 60) + "..."),
                             DateCreate = g.Key.DateCreate,
                             TimeCreate = g.Key.TimeCreate,
                             IsReciveMsg = false,
                         }).OrderByDescending(s => s.DateCreate).ThenByDescending(s => s.TimeCreate);


                q_concat.AddRange(q.ToList());
            }

            q_concat.AddRange(query_sys_msg.ToList());
            q_concat = q_concat.OrderByDescending(s => s.DateCreate).ThenByDescending(s => s.TimeCreate).ToList();
            GridPaging.lst_headerName.Add("ویرایش/نمایش");
            GridPaging.lst_headerName.Add("عنوان");
            GridPaging.lst_headerName.Add("متن");
            GridPaging.lst_headerName.Add("فرستنده");
            GridPaging.lst_headerName.Add("زمان ارسال");

            if (security.IsDelete)
                GridPaging.lst_headerName.Add("حذف");
            GridPaging.Columns = security.IsDelete ? 7 : 6;
            GridPaging.CountAllRecord = q_concat.Count();
            GridPaging.GridLoad();
            lst_content_Table = GridPaging.IsShowPageNumbering ? q_concat.Skip(GridPaging.SkypeItem()).Take(GridPaging.RowRecord).ToList() : q_concat.ToList();


        }

        public void DeleteRow()
        {
            if (!security.IsDelete)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه حذف این رکورد را ندارید");
                return;
            }
            
            //پیام های ارسالی
            if (hf_SelectValueReciveMsg == "false"&&security.IsAllowToSendMsg)
            {
                var obj = dc.Notifications.Where(s => s.GruopIDs.ToString() == hf_SelectValueID);
                if (obj.Any(s => s.IsDeleted_Creater == true) || obj.Any() == false)
                {
                    DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                    return;
                }
                string nameReciver = "";
                if (!obj.Any(s => s.IsRead == true))
                    dc.Notifications.DeleteAllOnSubmit(obj);
                else
                {
                    foreach (var o in obj)
                        o.IsDeleted_Creater = true;
                }

                nameReciver = obj.Select(s => s.userNotificationsMalek.FullName).ToList().Aggregate((a, b) => a + " ," + b);

                var item = obj.FirstOrDefault();

                bool ischange = dc.GetChangeSet().Updates.Any() || dc.GetChangeSet().Deletes.Any();
                dc.SubmitChanges();
                DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
                if (ischange)
                    EventLog.Loging(" پیام با عنوان '" + item.Subject + "' مربوط به کاربر  '" + nameReciver + "' با متن '" + item.Dsc + "' حذف گردید.", EventTypeIds.DELETE, "NOTIFICATION_M", CurrentUser.UID);
            }

            ///پیامهای دریافتی
            else if (hf_SelectValueReciveMsg == "true")
            {

                var obj = dc.Notifications.SingleOrDefault(s => s.UID.ToString() == hf_SelectValueID);
                if (obj == null)
                {
                    DisplayMessage.ShowErrorMessage("این سطر قبلا حذف شده است");
                    return;
                }

                obj.IsDeleted_Customer = true;
                string matn = (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))).Length < 80
                            ?
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))))

                            :

                            (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))))



                            );

                dc.SubmitChanges();
                DisplayMessage.ShowSeccessMessage("سطر با موفقیت حذف گردید.");
                EventLog.Loging("پیام با عنوان '" + (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject) + "' با متن '" + matn + "' که در زمان '" + obj.DateCreate + " [" + obj.TimeCreate + "]" + "' ارسال گردیده بود" + " حذف گردید.", EventTypeIds.DELETE, "NOTIFICATION_M", CurrentUser.UID);

            }

        }

    }
}