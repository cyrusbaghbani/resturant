﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using restauran.Models.Access.Tables;
using Models.Controll;
using App_Start.Utility;
using Utility;

namespace restauran.Models.Pages
{
    public class M_NotificationSpecModel : MasterPageModel
    {

        public string txtDsc = "";


        public string ID = "";
        public string isMessage = "";
        public string txtDateTimeSend = "";
        public bool IsAnyRead = false;
        public string txtOnvan = "";
        public bool isedit = false;


        public string hfINFOContent = "";
        public string hfCustomersSelect = "";
        public string hfCustomerSelectNAME = "";

        public void BindForms(FormCollection form)
        {
            var objs = dc.Notifications.Where(s => s.GruopIDs.ToString() == ID);

            if (isMessage.ToLower() == "false")
            {
                hfCustomersSelect = form["hfCustomersSelect"].ToString().Trim();
                hfCustomerSelectNAME = form["hfCustomerSelectNAME"].ToString().Trim();

                hfINFOContent = form["hfINFOContent"].ToString().Trim();

                txtOnvan = form["txtOnvan"].ToString().Trim();
                IsAnyRead = objs.Any() == false ? false : objs.Any(s => s.IsRead == true);
                isedit = objs.Any();


                txtDsc = form["txtDsc"].ToString().Trim();
                txtDateTimeSend = objs.Any() == false ? "" : (objs.First().DateCreate + " [" + objs.First().TimeCreate + "] ");
            }
            else if (isMessage.ToLower() == "false")
            {
                var obj = objs.First();


                IsAnyRead = true;

                txtDsc = (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))).Length < 80
                            ?
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))))

                            :

                            (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))))



                            );

                txtOnvan = (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject);
                txtDateTimeSend = obj.DateCreate + " [" + obj.TimeCreate + "]";
            }
        }
        private void DisplayInfo()
        {
            var objs = dc.Notifications.Where(s => s.GruopIDs.ToString() == ID);
            isedit = objs.Any();
            if (isedit == false)
            {

                return;
            }

            if (isMessage.ToLower() == "false")
            {
                hfCustomersSelect = objs.Select(s => Utility.EncryptedQueryString.Encrypt(s.UserId.ToString())).ToList().Aggregate((a, b) => a + "," + b);
                hfCustomerSelectNAME = objs.Select(s => s.userNotificationsMalek.FullName + ((s.userNotificationsMalek.OnvaneSherkat == null || s.userNotificationsMalek.OnvaneSherkat == "") ? "" : (" [ " + s.userNotificationsMalek.OnvaneSherkat + " ] "))).ToList().Aggregate((a, b) => a + ", " + b);


                txtOnvan = objs.First().Subject.ToString();
                IsAnyRead = objs.Any() == false ? false : objs.Any(s => s.IsRead == true);

                txtDsc = objs.First().Dsc.ToString();
                txtDateTimeSend = objs.Any() == false ? "" : (objs.First().DateCreate + " [" + objs.First().TimeCreate + "] ");
            }
            else if (isMessage.ToLower() == "true")
            {

                var obj = objs.First();

                obj.IsRead = true;
                IsAnyRead = true;
                dc.SubmitChanges();
                txtDsc = (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))).Length < 80
                            ?
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : "")))))

                            :

                            (((obj.NotificationTypeId == (NotificationTypeIDs.TakhfifEkhtesasi)) ? ("شما می توانید در " + obj.NotificationType.Name + " از محصول " + (obj.Price.Product.ProductType.Parent.IsShowName ? obj.Price.Product.ProductType.Parent.Name : "") + " " + obj.Price.Product.ProductType.Name + " " + obj.Price.Product.Brand.Name + " به مقدار " + (obj.Price.MojodiProduct == null ? (int?)null : obj.Price.MojodiProduct.Value) + " " + obj.Price.Product.Unit.Name + " با قیمت " + obj.Price.Price_ + " ريال از تاریخ " + obj.Price.DatetimeShoro_Persian + " تا " + obj.Price.DatetimePayan_Persian + " خریداری نمایید. ")
                            :
                            (
                            (obj.NotificationTypeId == (NotificationTypeIDs.KhoshamadGoie_custmers)) ? ((obj.userNotificationsMalek.Is_SexMan == null ? "جناب آقای/سرکار خانم " : (obj.userNotificationsMalek.Is_SexMan == true ? "جناب آقای " : "سرکار خانم ")) + obj.userNotificationsMalek.FullName + " " + "از اینکه برای خرید خود ما را انتخاب کردید کمال تشکر را داریم.")
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.MojodiAnbar)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.TahvilSabadKharid)) ? (obj.Dsc)
                            :
                            ((obj.NotificationTypeId == (NotificationTypeIDs.Customid)) ? (obj.Dsc) : ""))))))



                            );

                txtOnvan = (obj.NotificationTypeId != NotificationTypeIDs.Customid ? obj.NotificationType.Name : obj.Subject);
                txtDateTimeSend = obj.DateCreate + " [" + obj.TimeCreate + "]";
            }
        }



        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;

            var objs = dc.Notifications.Where(s => s.GruopIDs.ToString() == ID);
            if (!security.IsSave || security.IsAllowToSendMsg == false)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }
            if (objs.Any() && objs.Any(s => s.IsRead == true))
            {
                Msg += (i++).ToString() + " - " + "به دلیل اینکه گیرنده ای،  پیام را مشاهده کرده است امکان ویرایش ان وجود ندارد." + "</br>";
                result = false;
            }
            List<string> userIds = hfCustomersSelect.Split(',').Where(s => s != null && s.Trim() != "").Select(s => Utility.EncryptedQueryString.Decrypt(s)).ToList();
            if (!dc.users.Any(s => userIds.Contains(s.UID.ToString())))
            {
                Msg += (i++).ToString() + " - " + "گیرندگان را انتخاب نمایید." + "</br>";
                result = false;
            }
            if (txtOnvan == "")
            {
                Msg += (i++).ToString() + " - " + "عنوان را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtDsc == "")
            {
                Msg += (i++).ToString() + " - " + "متن را وارد نمایید." + "</br>";
                result = false;
            }






            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);

            return result;
        }

        public void Save()
        {
            bool IsEdit = false;
            string date = DateShamsi.GetCurrentDate();
            string time = DateShamsi.GetCurrentHour();
            Guid groupids = Guid.NewGuid();
            var obj = dc.Notifications.Where(s => s.GruopIDs.ToString() == ID);
            if (obj.Any())
            {
                date = obj.First().DateCreate;
                time = obj.First().TimeCreate;
                groupids = obj.First().GruopIDs;
                IsEdit = true;
            }




            var allsendnotification = dc.Notifications.Where(s => s.GruopIDs == groupids).ToList();
            List<string> userIds = hfCustomersSelect.Split(',').Where(s => s != null && s.Trim() != "").Select(s => Utility.EncryptedQueryString.Decrypt(s)).ToList();

            var listnotificationHazfShavand = allsendnotification.Where(s => userIds.Contains(s.UID.ToString()) == false).ToList();

            foreach (var userid in userIds)
            {
                var n = allsendnotification.FirstOrDefault(s => s.UserId.ToString() == userid);
                if (n == null)
                {

                    n = new Notification();
                    n.DateCreate = date;
                    n.IsRead = false;
                    n.SenderNotification = dc.users.SingleOrDefault(s => s.UID == CurrentUser.UID);
                    n.userNotificationsMalek = dc.users.SingleOrDefault(s => s.UID.ToString() == userid);
                    n.TimeCreate = time;

                    n.UID = Guid.NewGuid();
                    n.NotificationTypeId = NotificationTypeIDs.Customid;
                    n.IsDeleted_Customer = false;
                    n.GruopIDs = groupids;
                    dc.Notifications.InsertOnSubmit(n);

                }
                n.Dsc = txtDsc;
                n.Subject = txtOnvan;

            }


            string listhazfia = "";
            if (listnotificationHazfShavand.Any())
            {
                listhazfia = listnotificationHazfShavand.Select(p => p.userNotificationsMalek.FullName + ((p.userNotificationsMalek.OnvaneSherkat == null || p.userNotificationsMalek.OnvaneSherkat == "") ? "" : (" [ " + p.userNotificationsMalek.OnvaneSherkat + " ] "))).Aggregate((a, b) => a + " ," + b);


                dc.Notifications.DeleteAllOnSubmit(listnotificationHazfShavand);
            }

            bool ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();


            if (IsEdit == false)
            {

                EventLog.Loging(" پیام با عنوان '" + txtOnvan + "' با متن '" + txtDsc + "' با گیرندگان '" + hfCustomerSelectNAME + "' ارسال و درج گردید.", EventTypeIds.SAVE, "NOTIFICATIONSPEC_M", CurrentUser.UID);

            }
            else if ((IsEdit == true && ischange == true) || listhazfia != "")
            {
                EventLog.Loging(" پیام با عنوان '" + txtOnvan + "' با متن '" + txtDsc + "' با گیرندگان '" + hfCustomerSelectNAME + "' ویرایش گردید." + "' (اسامی افراد حذف شده'" + listhazfia + "')", EventTypeIds.EDIT, "NOTIFICATIONSPEC_M", CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثیت گردید");


        }
        public M_NotificationSpecModel(string ID_, string type, user currentUser_, string PageName)
        {
            ID = ID_;
            isMessage = type;
            isMessage = isMessage == null ? "false" : isMessage.ToLower().Trim();
            isMessage = (isMessage == "true" || isMessage == "false") ? isMessage : "false";
            Intialize(currentUser_, PageName);
            DisplayInfo();
        }

        public M_NotificationSpecModel(string ID_, string type, FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            ID = ID_ == null ? "" : ID_.Trim();
            isMessage = type;
            isMessage = isMessage == null ? "false" : isMessage.ToLower().Trim();
            isMessage = (isMessage == "true" || isMessage == "false") ? isMessage : "false";
            BindForms(frm);
        }



    }
}