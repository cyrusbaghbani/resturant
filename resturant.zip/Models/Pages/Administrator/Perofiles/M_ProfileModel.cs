﻿using App_Start.Utility;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace restauran.Models.Pages
{
    public class M_ProfileModel : MasterPageModel
    {
        public string TxtUserName = "";
        public string txtName = "";
        public string txtFamily = "";
        public string txtMobile = "";
        public string txtTel = "";
        public string txtTelCode = "";
        public string txtAddress = "";
        public string txtEmail = "";
        public string txtSemat = "";
        public string txtCodeMeli = "";
        public M_ProfileModel(user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            Display();
        }

        public M_ProfileModel(FormCollection frm, user currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);
        }
        private void Display()
        {
            if (CurrentUser != null)
            {
                TxtUserName = CurrentUser.UserName;
                txtSemat = CurrentUser.SematId == null ? "" : CurrentUser.Semat.Name;
                txtName = CurrentUser.FirstName;
                txtFamily = CurrentUser.LastName;
                txtMobile = CurrentUser.MobileNumber;
                txtTel = CurrentUser.Tel_BeHamrah_Code;
                txtCodeMeli = CurrentUser.CodeMeli;
                txtAddress = CurrentUser.Address;
                txtEmail = CurrentUser.Email;
            }
        }
        private void BindForms(FormCollection form)
        {
            if (CurrentUser != null)
            {

                TxtUserName = CurrentUser.UserName;
                txtSemat = CurrentUser.SematId == null ? "" : CurrentUser.Semat.Name;
                txtCodeMeli = form["txtCodeMeli"].ToString().Trim();
                txtName = form["txtName"].ToString().Trim();
                txtFamily = form["txtFamily"].ToString().Trim();
                txtMobile = form["txtMobile"].ToString().Trim();
                txtTel = form["txtTel"].ToString().Trim();

                txtAddress = form["txtAddress"].ToString().Trim();
                txtEmail = form["txtEmail"].ToString().Trim();
            }
        }

        public void Save()
        {
            var obj = dc.users.Single(s => s.UID == CurrentUser.UID);

            obj.FirstName = txtName.Trim();
            obj.LastName = txtFamily.Trim();
            obj.MobileNumber = Validation.IsMobileNumber(txtMobile.Trim());
            obj.Tel_BeHamrah_Code = txtTel.Trim();
            obj.CodeMeli = txtCodeMeli.Trim();
            obj.Address = txtAddress.Trim();
            obj.Email = txtEmail.Trim();
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            DisplayMessage.ShowSeccessMessage("اطلاعات وارد شده با موفقیت ذخیره شد.");


            if (Ischange)
                EventLog.Loging(" پروفایل کاربری با نام کاربری '" + obj.UserName + "' ویرایش گردید.", EventTypeIds.EDIT, "PROFILE_M", CurrentUser.UID);
        }

        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 1;


            if (!security.IsSave)
            {
                DisplayMessage.ShowErrorMessage("شما اجازه ذخیره اطلاعات را ندارید");
                return false;
            }

            if (txtCodeMeli.Trim() != "" && !Validation.IsNationalCode(txtCodeMeli.Trim()))
            {
                Msg += (i++) + " - " + "کد ملی را صحیح وارد نمایید." + "</br>";
                result = false;
            }
            if (txtName.Trim() == "")
            {
                Msg += (i++) + " - " + "نام را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtFamily.Trim() == "")
            {
                Msg += (i++) + " - " + "نام خانوادگی را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtMobile.Trim() == "" || Validation.IsMobileNumber(txtMobile.Trim()) == "")
            {
                Msg += (i++) + " - " + "شماره موبایل را صحیح وارد نمایید." + "</br>";
                result = false;

            }

            if (txtEmail.Trim() != "" && !Validation.IsEmail(txtEmail.Trim()))
            {
                Msg += (i++) + " - " + "ایمیل را صحیح نمایید." + "</br>";
                result = false;
            }
            else if (txtEmail.Trim() != "")
            {
                if (dc.users.Any(S => S.UID != CurrentUser.UID && S.IsDeleted == false && S.Email == txtEmail.Trim()))
                {
                    Msg += (i++) + " - " + "قبلا این پست الکترونیکی توسط کاربری دیگر در سیستم ثبت شده است، پست الکترونیکی جدیدی را وارد نمایید." + "</br>";
                    result = false;
                }
            }


            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
    }
}