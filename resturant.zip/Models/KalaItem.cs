﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace restauran.Models
{
    public class KalaItem
    {
        public string BrandName;
        public Guid UID;
        public string ProductGroupTypeName;
        public string ProductTypeName;
        public string Price;
        public string TakhfifPrice;
        public string FullName;
        public string NamayeshDarSite;
        public string MOjodi;
        public string TedadKol;
        public string DateShoro;
        public string DatePayan;
        public int TedadUsers;
        public bool IsInSabadKharid = false;
        public string Imageurl = "";
        public decimal PriceKol;
        public string TimeShoro = "";
        public string TimePayan = "";
        public string Point_ = "";
        public string DarsadHedie = "";
        public string DarsadHedieAkharSal = "";
        public string FakePoint = "";
    }
}