﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;
using restauran.Models.Access.Tables;

namespace restauran.Models.Access
{



    [global::System.Data.Linq.Mapping.DatabaseAttribute(Name = "ResturantDB")]
    public partial class DBDataContext : System.Data.Linq.DataContext
    {

        private static System.Data.Linq.Mapping.MappingSource mappingSource = new AttributeMappingSource();

        #region Extensibility Method Definitions
        partial void OnCreated();
        partial void InsertLoyalty(Loyalty instance);
        partial void UpdateLoyalty(Loyalty instance);
        partial void DeleteLoyalty(Loyalty instance);
        partial void InsertTransaction(Transaction instance);
        partial void UpdateTransaction(Transaction instance);
        partial void DeleteTransaction(Transaction instance);
        partial void InsertPoint(Point instance);
        partial void UpdatePoint(Point instance);
        partial void DeletePoint(Point instance);
        partial void InsertMantaghe(Mantaghe instance);
        partial void UpdateMantaghe(Mantaghe instance);
        partial void DeleteMantaghe(Mantaghe instance);
        partial void InsertSabadKharidItem(SabadKharidItem instance);
        partial void UpdateSabadKharidItem(SabadKharidItem instance);
        partial void DeleteSabadKharidItem(SabadKharidItem instance);
        partial void InsertSabadKharid(SabadKharid instance);
        partial void UpdateSabadKharid(SabadKharid instance);
        partial void DeleteSabadKharid(SabadKharid instance);
        partial void Insertuser(user instance);
        partial void Updateuser(user instance);
        partial void Deleteuser(user instance);
        partial void InsertNotification(Notification instance);
        partial void UpdateNotification(Notification instance);
        partial void DeleteNotification(Notification instance);
        partial void InsertNotificationType(NotificationType instance);
        partial void UpdateNotificationType(NotificationType instance);
        partial void DeleteNotificationType(NotificationType instance);
        partial void InsertRole(Role instance);
        partial void UpdateRole(Role instance);
        partial void DeleteRole(Role instance);
        partial void InsertSemat(Semat instance);
        partial void UpdateSemat(Semat instance);
        partial void DeleteSemat(Semat instance);
        partial void InsertProductType(ProductType instance);
        partial void UpdateProductType(ProductType instance);
        partial void DeleteProductType(ProductType instance);
        partial void InsertProductGroupType(ProductGroupType instance);
        partial void UpdateProductGroupType(ProductGroupType instance);
        partial void DeleteProductGroupType(ProductGroupType instance);
        partial void InsertBrand(Brand instance);
        partial void UpdateBrand(Brand instance);
        partial void DeleteBrand(Brand instance);
        partial void InsertEvent(Event instance);
        partial void UpdateEvent(Event instance);
        partial void DeleteEvent(Event instance);
        partial void InsertEventType(EventType instance);
        partial void UpdateEventType(EventType instance);
        partial void DeleteEventType(EventType instance);
        partial void InsertPayment(Payment instance);
        partial void UpdatePayment(Payment instance);
        partial void DeletePayment(Payment instance);
        partial void InsertUserType(UserType instance);
        partial void UpdateUserType(UserType instance);
        partial void DeleteUserType(UserType instance);
        partial void InsertProduct(Product instance);
        partial void UpdateProduct(Product instance);
        partial void DeleteProduct(Product instance);
        partial void InsertUnit(Unit instance);
        partial void UpdateUnit(Unit instance);
        partial void DeleteUnit(Unit instance);
        partial void InsertPrice(Price instance);
        partial void UpdatePrice(Price instance);
        partial void DeletePrice(Price instance);
        partial void InsertTemp(Temp instance);
        partial void UpdateTemp(Temp instance);
        partial void DeleteTemp(Temp instance);
        partial void InsertUSER_PRICE(USER_PRICE instance);
        partial void UpdateUSER_PRICE(USER_PRICE instance);
        partial void DeleteUSER_PRICE(USER_PRICE instance);
        partial void InsertAdvertising(Advertising instance);
        partial void UpdateAdvertising(Advertising instance);
        partial void DeleteAdvertising(Advertising instance);
        partial void InsertLottery(Lottery instance);
        partial void UpdateLottery(Lottery instance);
        partial void DeleteLottery(Lottery instance);
        partial void InsertNotificationMojodi(NotificationMojodi instance);
        partial void UpdateNotificationMojodi(NotificationMojodi instance);
        partial void DeleteNotificationMojodi(NotificationMojodi instance);
        partial void InsertAdditionalFee(AdditionalFee instance);
        partial void UpdateAdditionalFee(AdditionalFee instance);
        partial void DeleteAdditionalFee(AdditionalFee instance);
        #endregion

        public DBDataContext() :
                base(EmoNetUtility.ConnectionString, mappingSource)
        {
            OnCreated();
        }

        public DBDataContext(string connection) :
                base(connection, mappingSource)
        {
            OnCreated();
        }

        public DBDataContext(System.Data.IDbConnection connection) :
                base(connection, mappingSource)
        {
            OnCreated();
        }

        public DBDataContext(string connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
                base(connection, mappingSource)
        {
            OnCreated();
        }

        public DBDataContext(System.Data.IDbConnection connection, System.Data.Linq.Mapping.MappingSource mappingSource) :
                base(connection, mappingSource)
        {
            OnCreated();
        }

        public System.Data.Linq.Table<user> users
        {
            get
            {
                return this.GetTable<user>();
            }
        }

        public System.Data.Linq.Table<Notification> Notifications
        {
            get
            {
                return this.GetTable<Notification>();
            }
        }

        public System.Data.Linq.Table<NotificationType> NotificationTypes
        {
            get
            {
                return this.GetTable<NotificationType>();
            }
        }

        public System.Data.Linq.Table<Role> Roles
        {
            get
            {
                return this.GetTable<Role>();
            }
        }

        public System.Data.Linq.Table<Semat> Semats
        {
            get
            {
                return this.GetTable<Semat>();
            }
        }

        public System.Data.Linq.Table<Event> Events
        {
            get
            {
                return this.GetTable<Event>();
            }
        }

        public System.Data.Linq.Table<EventType> EventTypes
        {
            get
            {
                return this.GetTable<EventType>();
            }
        }

        public System.Data.Linq.Table<ProductType> ProductTypes
        {
            get
            {
                return this.GetTable<ProductType>();
            }
        }

        public System.Data.Linq.Table<ProductGroupType> ProductGroupTypes
        {
            get
            {
                return this.GetTable<ProductGroupType>();
            }
        }

        public System.Data.Linq.Table<Brand> Brands
        {
            get
            {
                return this.GetTable<Brand>();
            }
        }

        public System.Data.Linq.Table<Payment> Payments
        {
            get
            {
                return this.GetTable<Payment>();
            }
        }

        public System.Data.Linq.Table<UserType> UserTypes
        {
            get
            {
                return this.GetTable<UserType>();
            }
        }

        public System.Data.Linq.Table<Product> Products
        {
            get
            {
                return this.GetTable<Product>();
            }
        }

        public System.Data.Linq.Table<Unit> Units
        {
            get
            {
                return this.GetTable<Unit>();
            }
        }

        public System.Data.Linq.Table<Price> Prices
        {
            get
            {
                return this.GetTable<Price>();
            }
        }
        public System.Data.Linq.Table<Mojodi> Mojodis
        {
            get
            {
                return this.GetTable<Mojodi>();
            }
        }
        public System.Data.Linq.Table<Temp> Temps
        {
            get
            {
                return this.GetTable<Temp>();
            }
        }

        public System.Data.Linq.Table<SabadKharidItem> SabadKharidItems
        {
            get
            {
                return this.GetTable<SabadKharidItem>();
            }
        }

        public System.Data.Linq.Table<SabadKharid> SabadKharids
        {
            get
            {
                return this.GetTable<SabadKharid>();
            }
        }

        public System.Data.Linq.Table<USER_PRICE> USER_PRICEs
        {
            get
            {
                return this.GetTable<USER_PRICE>();
            }
        }

        public System.Data.Linq.Table<Advertising> Advertisings
        {
            get
            {
                return this.GetTable<Advertising>();
            }
        }

        public System.Data.Linq.Table<Lottery> Lotteries
        {
            get
            {
                return this.GetTable<Lottery>();
            }
        }
        public System.Data.Linq.Table<Mantaghe> Mantaghes
        {
            get
            {
                return this.GetTable<Mantaghe>();
            }
        }
        public System.Data.Linq.Table<Point> Points
        {
            get
            {
                return this.GetTable<Point>();
            }
        }
        public System.Data.Linq.Table<NotificationMojodi> NotificationMojodis
        {
            get
            {
                return this.GetTable<NotificationMojodi>();
            }
        }
        public System.Data.Linq.Table<Transaction> Transactions
        {
            get
            {
                return this.GetTable<Transaction>();
            }
        }
        public System.Data.Linq.Table<Loyalty> Loyalties
        {
            get
            {
                return this.GetTable<Loyalty>();
            }
        }
        public System.Data.Linq.Table<AdditionalFee> AdditionalFees
        {
            get
            {
                return this.GetTable<AdditionalFee>();
            }
        }
    }


}