﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Event")]
    public partial class Event : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _DSC;

        private string _IP;

        private int _EventTypeId;

        private System.Nullable<System.DateTime> _DateTimeEn;

        private string _TimePersian;

        private string _DatePersian;

        private System.Nullable<System.Guid> _UserId;

        private string _NAMEOFPROJECT;

        private string _PageName;

        private EntityRef<user> _user;

        private EntityRef<EventType> _EventType;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDSCChanging(string value);
        partial void OnDSCChanged();
        partial void OnIPChanging(string value);
        partial void OnIPChanged();
        partial void OnEventTypeIdChanging(int value);
        partial void OnEventTypeIdChanged();
        partial void OnDateTimeEnChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeEnChanged();
        partial void OnTimePersianChanging(string value);
        partial void OnTimePersianChanged();
        partial void OnDatePersianChanging(string value);
        partial void OnDatePersianChanged();
        partial void OnUserIdChanging(System.Nullable<System.Guid> value);
        partial void OnUserIdChanged();
        partial void OnNAMEOFPROJECTChanging(string value);
        partial void OnNAMEOFPROJECTChanged();
        partial void OnPageNameChanging(string value);
        partial void OnPageNameChanged();
        #endregion

        public Event()
        {
            this._user = default(EntityRef<user>);
            this._EventType = default(EntityRef<EventType>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DSC", DbType = "NVarChar(MAX)")]
        public string DSC
        {
            get
            {
                return this._DSC;
            }
            set
            {
                if ((this._DSC != value))
                {
                    this.OnDSCChanging(value);
                    this.SendPropertyChanging();
                    this._DSC = value;
                    this.SendPropertyChanged("DSC");
                    this.OnDSCChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IP", DbType = "NVarChar(100)")]
        public string IP
        {
            get
            {
                return this._IP;
            }
            set
            {
                if ((this._IP != value))
                {
                    this.OnIPChanging(value);
                    this.SendPropertyChanging();
                    this._IP = value;
                    this.SendPropertyChanged("IP");
                    this.OnIPChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EventTypeId", DbType = "Int NOT NULL")]
        public int EventTypeId
        {
            get
            {
                return this._EventTypeId;
            }
            set
            {
                if ((this._EventTypeId != value))
                {
                    if (this._EventType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnEventTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._EventTypeId = value;
                    this.SendPropertyChanged("EventTypeId");
                    this.OnEventTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeEn", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeEn
        {
            get
            {
                return this._DateTimeEn;
            }
            set
            {
                if ((this._DateTimeEn != value))
                {
                    this.OnDateTimeEnChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeEn = value;
                    this.SendPropertyChanged("DateTimeEn");
                    this.OnDateTimeEnChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimePersian", DbType = "NVarChar(50)")]
        public string TimePersian
        {
            get
            {
                return this._TimePersian;
            }
            set
            {
                if ((this._TimePersian != value))
                {
                    this.OnTimePersianChanging(value);
                    this.SendPropertyChanging();
                    this._TimePersian = value;
                    this.SendPropertyChanged("TimePersian");
                    this.OnTimePersianChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePersian", DbType = "NVarChar(50)")]
        public string DatePersian
        {
            get
            {
                return this._DatePersian;
            }
            set
            {
                if ((this._DatePersian != value))
                {
                    this.OnDatePersianChanging(value);
                    this.SendPropertyChanging();
                    this._DatePersian = value;
                    this.SendPropertyChanged("DatePersian");
                    this.OnDatePersianChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this._user.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NAMEOFPROJECT", DbType = "NVarChar(1000)")]
        public string NAMEOFPROJECT
        {
            get
            {
                return this._NAMEOFPROJECT;
            }
            set
            {
                if ((this._NAMEOFPROJECT != value))
                {
                    this.OnNAMEOFPROJECTChanging(value);
                    this.SendPropertyChanging();
                    this._NAMEOFPROJECT = value;
                    this.SendPropertyChanged("NAMEOFPROJECT");
                    this.OnNAMEOFPROJECTChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PageName", DbType = "NVarChar(500)")]
        public string PageName
        {
            get
            {
                return this._PageName;
            }
            set
            {
                if ((this._PageName != value))
                {
                    this.OnPageNameChanging(value);
                    this.SendPropertyChanging();
                    this._PageName = value;
                    this.SendPropertyChanged("PageName");
                    this.OnPageNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Event", Storage = "_user", ThisKey = "UserId", OtherKey = "UID", IsForeignKey = true)]
        public user user
        {
            get
            {
                return this._user.Entity;
            }
            set
            {
                user previousValue = this._user.Entity;
                if (((previousValue != value)
                            || (this._user.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._user.Entity = null;
                        previousValue.Events.Remove(this);
                    }
                    this._user.Entity = value;
                    if ((value != null))
                    {
                        value.Events.Add(this);
                        this._UserId = value.UID;
                    }
                    else
                    {
                        this._UserId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("user");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "EventType_Event", Storage = "_EventType", ThisKey = "EventTypeId", OtherKey = "Id", IsForeignKey = true)]
        public EventType EventType
        {
            get
            {
                return this._EventType.Entity;
            }
            set
            {
                EventType previousValue = this._EventType.Entity;
                if (((previousValue != value)
                            || (this._EventType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._EventType.Entity = null;
                        previousValue.Events.Remove(this);
                    }
                    this._EventType.Entity = value;
                    if ((value != null))
                    {
                        value.Events.Add(this);
                        this._EventTypeId = value.Id;
                    }
                    else
                    {
                        this._EventTypeId = default(int);
                    }
                    this.SendPropertyChanged("EventType");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}