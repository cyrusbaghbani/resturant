﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Points")]
    public partial class Point : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _UserID;

        private System.Guid _ProductID;

        private decimal _Point1;

        private EntityRef<user> _user;

        private EntityRef<Product> _Product;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIDChanging(System.Guid value);
        partial void OnUserIDChanged();
        partial void OnProductIDChanging(System.Guid value);
        partial void OnProductIDChanged();
        partial void OnPoint1Changing(decimal value);
        partial void OnPoint1Changed();
        #endregion

        public Point()
        {
            this._user = default(EntityRef<user>);
            this._Product = default(EntityRef<Product>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserID
        {
            get
            {
                return this._UserID;
            }
            set
            {
                if ((this._UserID != value))
                {
                    if (this._user.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserID = value;
                    this.SendPropertyChanged("UserID");
                    this.OnUserIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid ProductID
        {
            get
            {
                return this._ProductID;
            }
            set
            {
                if ((this._ProductID != value))
                {
                    if (this._Product.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductIDChanging(value);
                    this.SendPropertyChanging();
                    this._ProductID = value;
                    this.SendPropertyChanged("ProductID");
                    this.OnProductIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Name = "Point", Storage = "_Point1", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Point1
        {
            get
            {
                return this._Point1;
            }
            set
            {
                if ((this._Point1 != value))
                {
                    this.OnPoint1Changing(value);
                    this.SendPropertyChanging();
                    this._Point1 = value;
                    this.SendPropertyChanged("Point1");
                    this.OnPoint1Changed();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Point", Storage = "_user", ThisKey = "UserID", OtherKey = "UID", IsForeignKey = true)]
        public user user
        {
            get
            {
                return this._user.Entity;
            }
            set
            {
                user previousValue = this._user.Entity;
                if (((previousValue != value)
                            || (this._user.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._user.Entity = null;
                        previousValue.Points.Remove(this);
                    }
                    this._user.Entity = value;
                    if ((value != null))
                    {
                        value.Points.Add(this);
                        this._UserID = value.UID;
                    }
                    else
                    {
                        this._UserID = default(System.Guid);
                    }
                    this.SendPropertyChanged("user");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Point", Storage = "_Product", ThisKey = "ProductID", OtherKey = "UID", IsForeignKey = true)]
        public Product Product
        {
            get
            {
                return this._Product.Entity;
            }
            set
            {
                Product previousValue = this._Product.Entity;
                if (((previousValue != value)
                            || (this._Product.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Product.Entity = null;
                        previousValue.Points.Remove(this);
                    }
                    this._Product.Entity = value;
                    if ((value != null))
                    {
                        value.Points.Add(this);
                        this._ProductID = value.UID;
                    }
                    else
                    {
                        this._ProductID = default(System.Guid);
                    }
                    this.SendPropertyChanged("Product");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}