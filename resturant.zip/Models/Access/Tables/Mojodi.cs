﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Mojodi")]
    public partial class Mojodi : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.DateTime _DateTimeSabt;

        private string _DateShoro;

        private string _TimeShoro;

        private bool _IsDeleted;

        private decimal _Count;

        private System.Guid _ProductId;

        private EntityRef<Product> _Product;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDateTimeSabtChanging(System.DateTime value);
        partial void OnDateTimeSabtChanged();
        partial void OnDateShoroChanging(string value);
        partial void OnDateShoroChanged();
        partial void OnTimeShoroChanging(string value);
        partial void OnTimeShoroChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnCountChanging(decimal value);
        partial void OnCountChanged();
        partial void OnProductIdChanging(System.Guid value);
        partial void OnProductIdChanged();
        #endregion

        public Mojodi()
        {
            this._Product = default(EntityRef<Product>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateTimeSabt
        {
            get
            {
                return this._DateTimeSabt;
            }
            set
            {
                if ((this._DateTimeSabt != value))
                {
                    this.OnDateTimeSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabt = value;
                    this.SendPropertyChanged("DateTimeSabt");
                    this.OnDateTimeSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateShoro", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string DateShoro
        {
            get
            {
                return this._DateShoro;
            }
            set
            {
                if ((this._DateShoro != value))
                {
                    this.OnDateShoroChanging(value);
                    this.SendPropertyChanging();
                    this._DateShoro = value;
                    this.SendPropertyChanged("DateShoro");
                    this.OnDateShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeShoro", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string TimeShoro
        {
            get
            {
                return this._TimeShoro;
            }
            set
            {
                if ((this._TimeShoro != value))
                {
                    this.OnTimeShoroChanging(value);
                    this.SendPropertyChanging();
                    this._TimeShoro = value;
                    this.SendPropertyChanged("TimeShoro");
                    this.OnTimeShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Count", DbType = "Decimal(18,0) NOT NULL")]
        public decimal Count
        {
            get
            {
                return this._Count;
            }
            set
            {
                if ((this._Count != value))
                {
                    this.OnCountChanging(value);
                    this.SendPropertyChanging();
                    this._Count = value;
                    this.SendPropertyChanged("Count");
                    this.OnCountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid ProductId
        {
            get
            {
                return this._ProductId;
            }
            set
            {
                if ((this._ProductId != value))
                {
                    if (this._Product.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductIdChanging(value);
                    this.SendPropertyChanging();
                    this._ProductId = value;
                    this.SendPropertyChanged("ProductId");
                    this.OnProductIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Mojodi", Storage = "_Product", ThisKey = "ProductId", OtherKey = "UID", IsForeignKey = true)]
        public Product Product
        {
            get
            {
                return this._Product.Entity;
            }
            set
            {
                Product previousValue = this._Product.Entity;
                if (((previousValue != value)
                            || (this._Product.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Product.Entity = null;
                        previousValue.Mojodis.Remove(this);
                    }
                    this._Product.Entity = value;
                    if ((value != null))
                    {
                        value.Mojodis.Add(this);
                        this._ProductId = value.UID;
                    }
                    else
                    {
                        this._ProductId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Product");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}