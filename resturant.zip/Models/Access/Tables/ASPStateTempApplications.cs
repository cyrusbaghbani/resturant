﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.ASPStateTempApplications")]
    public partial class ASPStateTempApplication : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _AppId;

        private string _AppName;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnAppIdChanging(int value);
        partial void OnAppIdChanged();
        partial void OnAppNameChanging(string value);
        partial void OnAppNameChanged();
        #endregion

        public ASPStateTempApplication()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AppId", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int AppId
        {
            get
            {
                return this._AppId;
            }
            set
            {
                if ((this._AppId != value))
                {
                    this.OnAppIdChanging(value);
                    this.SendPropertyChanging();
                    this._AppId = value;
                    this.SendPropertyChanged("AppId");
                    this.OnAppIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AppName", DbType = "Char(280) NOT NULL", CanBeNull = false)]
        public string AppName
        {
            get
            {
                return this._AppName;
            }
            set
            {
                if ((this._AppName != value))
                {
                    this.OnAppNameChanging(value);
                    this.SendPropertyChanging();
                    this._AppName = value;
                    this.SendPropertyChanged("AppName");
                    this.OnAppNameChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}