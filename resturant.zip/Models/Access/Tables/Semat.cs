﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Semat")]
    public partial class Semat : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private System.Nullable<int> _Periority;

        private bool _IsDeleted;

        private string _DSC;

        private EntitySet<user> _users;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnPeriorityChanging(System.Nullable<int> value);
        partial void OnPeriorityChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnDSCChanging(string value);
        partial void OnDSCChanged();
        #endregion

        public Semat()
        {
            this._users = new EntitySet<user>(new Action<user>(this.attach_users), new Action<user>(this.detach_users));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(500)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periority", DbType = "Int")]
        public System.Nullable<int> Periority
        {
            get
            {
                return this._Periority;
            }
            set
            {
                if ((this._Periority != value))
                {
                    this.OnPeriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Periority = value;
                    this.SendPropertyChanged("Periority");
                    this.OnPeriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DSC", DbType = "NVarChar(MAX)")]
        public string DSC
        {
            get
            {
                return this._DSC;
            }
            set
            {
                if ((this._DSC != value))
                {
                    this.OnDSCChanging(value);
                    this.SendPropertyChanging();
                    this._DSC = value;
                    this.SendPropertyChanged("DSC");
                    this.OnDSCChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Semat_user", Storage = "_users", ThisKey = "Id", OtherKey = "SematId")]
        public EntitySet<user> users
        {
            get
            {
                return this._users;
            }
            set
            {
                this._users.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_users(user entity)
        {
            this.SendPropertyChanging();
            entity.Semat = this;
        }

        private void detach_users(user entity)
        {
            this.SendPropertyChanging();
            entity.Semat = null;
        }
    }
}