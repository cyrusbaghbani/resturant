﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.NotificationMojodi")]
    public partial class NotificationMojodi : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _ProductID;

        private decimal _MojodiJari;

        private System.Nullable<System.DateTime> _DateTime;

        private string _Dsc;

        private bool _IsAfzayesh;

        private string _Date;

        private string _Time;

        private EntityRef<Product> _Product;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnProductIDChanging(System.Guid value);
        partial void OnProductIDChanged();
        partial void OnMojodiJariChanging(decimal value);
        partial void OnMojodiJariChanged();
        partial void OnDateTimeChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnIsAfzayeshChanging(bool value);
        partial void OnIsAfzayeshChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnTimeChanging(string value);
        partial void OnTimeChanged();
        #endregion

        public NotificationMojodi()
        {
            this._Product = default(EntityRef<Product>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid ProductID
        {
            get
            {
                return this._ProductID;
            }
            set
            {
                if ((this._ProductID != value))
                {
                    if (this._Product.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductIDChanging(value);
                    this.SendPropertyChanging();
                    this._ProductID = value;
                    this.SendPropertyChanged("ProductID");
                    this.OnProductIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MojodiJari", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MojodiJari
        {
            get
            {
                return this._MojodiJari;
            }
            set
            {
                if ((this._MojodiJari != value))
                {
                    this.OnMojodiJariChanging(value);
                    this.SendPropertyChanging();
                    this._MojodiJari = value;
                    this.SendPropertyChanged("MojodiJari");
                    this.OnMojodiJariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTime", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTime
        {
            get
            {
                return this._DateTime;
            }
            set
            {
                if ((this._DateTime != value))
                {
                    this.OnDateTimeChanging(value);
                    this.SendPropertyChanging();
                    this._DateTime = value;
                    this.SendPropertyChanged("DateTime");
                    this.OnDateTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsAfzayesh", DbType = "Bit NOT NULL")]
        public bool IsAfzayesh
        {
            get
            {
                return this._IsAfzayesh;
            }
            set
            {
                if ((this._IsAfzayesh != value))
                {
                    this.OnIsAfzayeshChanging(value);
                    this.SendPropertyChanging();
                    this._IsAfzayesh = value;
                    this.SendPropertyChanged("IsAfzayesh");
                    this.OnIsAfzayeshChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NVarChar(50)")]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Time", DbType = "NVarChar(50)")]
        public string Time
        {
            get
            {
                return this._Time;
            }
            set
            {
                if ((this._Time != value))
                {
                    this.OnTimeChanging(value);
                    this.SendPropertyChanging();
                    this._Time = value;
                    this.SendPropertyChanged("Time");
                    this.OnTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_NotificationMojodi", Storage = "_Product", ThisKey = "ProductID", OtherKey = "UID", IsForeignKey = true)]
        public Product Product
        {
            get
            {
                return this._Product.Entity;
            }
            set
            {
                Product previousValue = this._Product.Entity;
                if (((previousValue != value)
                            || (this._Product.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Product.Entity = null;
                        previousValue.NotificationMojodis.Remove(this);
                    }
                    this._Product.Entity = value;
                    if ((value != null))
                    {
                        value.NotificationMojodis.Add(this);
                        this._ProductID = value.UID;
                    }
                    else
                    {
                        this._ProductID = default(System.Guid);
                    }
                    this.SendPropertyChanged("Product");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}