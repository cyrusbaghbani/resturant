﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.ProductType")]
    public partial class ProductType : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private System.Nullable<int> _Periority;

        private bool _IsDeleted;

        private bool _IsShowName = true;

        private string _DSC;

        private string _ImageUrl;

        private System.Nullable<int> _ParentId;

        private System.Nullable<int> _ProductGroupTypeId;

        private EntitySet<Product> _Products;

        private EntitySet<ProductType> _Childs;

        private EntityRef<ProductType> _Parent;

        private EntityRef<ProductGroupType> _ProductGroupType;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnPeriorityChanging(System.Nullable<int> value);
        partial void OnPeriorityChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnIsShowNameChanging(bool value);
        partial void OnIsShowNameChanged();
        partial void OnDSCChanging(string value);
        partial void OnDSCChanged();
        partial void OnParentIdChanging(System.Nullable<int> value);
        partial void OnParentIdChanged();
        partial void OnProductGroupTypeIdChanging(System.Nullable<int> value);
        partial void OnProductGroupTypeIdChanged();
        partial void OnImageUrlChanging(string value);
        partial void OnImageUrlChanged();
        #endregion

        public ProductType()
        {
            this._Childs = new EntitySet<ProductType>(new Action<ProductType>(this.attach_Childs), new Action<ProductType>(this.detach_Childs));
            this._Parent = default(EntityRef<ProductType>);
            this._ProductGroupType = default(EntityRef<ProductGroupType>);
            this._Products = new EntitySet<Product>(new Action<Product>(this.attach_Products), new Action<Product>(this.detach_Products));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL", IsPrimaryKey = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(500)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periority", DbType = "Int")]
        public System.Nullable<int> Periority
        {
            get
            {
                return this._Periority;
            }
            set
            {
                if ((this._Periority != value))
                {
                    this.OnPeriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Periority = value;
                    this.SendPropertyChanged("Periority");
                    this.OnPeriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowName", DbType = "Bit NOT NULL")]
        public bool IsShowName
        {
            get
            {
                return this._IsShowName;
            }
            set
            {
                if ((this._IsShowName != value))
                {
                    this.OnIsShowNameChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowName = value;
                    this.SendPropertyChanged("IsShowName");
                    this.OnIsShowNameChanged();
                }
            }
        }



        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DSC", DbType = "NVarChar(MAX)")]
        public string DSC
        {
            get
            {
                return this._DSC;
            }
            set
            {
                if ((this._DSC != value))
                {
                    this.OnDSCChanging(value);
                    this.SendPropertyChanging();
                    this._DSC = value;
                    this.SendPropertyChanged("DSC");
                    this.OnDSCChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "Int")]
        public System.Nullable<int> ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    if (this._Parent.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnParentIdChanging(value);
                    this.SendPropertyChanging();
                    this._ParentId = value;
                    this.SendPropertyChanged("ParentId");
                    this.OnParentIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductGroupTypeId", DbType = "Int")]
        public System.Nullable<int> ProductGroupTypeId
        {
            get
            {
                return this._ProductGroupTypeId;
            }
            set
            {
                if ((this._ProductGroupTypeId != value))
                {
                    if (this._ProductGroupType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductGroupTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._ProductGroupTypeId = value;
                    this.SendPropertyChanged("ProductGroupTypeId");
                    this.OnProductGroupTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ImageUrl", DbType = "NVarChar(MAX)")]
        public string ImageUrl
        {
            get
            {
                return this._ImageUrl;
            }
            set
            {
                if ((this._ImageUrl != value))
                {
                    this.OnImageUrlChanging(value);
                    this.SendPropertyChanging();
                    this._ImageUrl = value;
                    this.SendPropertyChanged("ImageUrl");
                    this.OnImageUrlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "ProductType_ProductType", Storage = "_Childs", ThisKey = "Id", OtherKey = "ParentId")]
        public EntitySet<ProductType> Childs
        {
            get
            {
                return this._Childs;
            }
            set
            {
                this._Childs.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "ProductType_ProductType", Storage = "_Parent", ThisKey = "ParentId", OtherKey = "Id", IsForeignKey = true)]
        public ProductType Parent
        {
            get
            {
                return this._Parent.Entity;
            }
            set
            {
                ProductType previousValue = this._Parent.Entity;
                if (((previousValue != value)
                            || (this._Parent.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Parent.Entity = null;
                        previousValue.Childs.Remove(this);
                    }
                    this._Parent.Entity = value;
                    if ((value != null))
                    {
                        value.Childs.Add(this);
                        this._ParentId = value.Id;
                    }
                    else
                    {
                        this._ParentId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Parent");
                }
            }
        }

        public EntitySet<Product> Products
        {
            get
            {
                return this._Products;
            }
            set
            {
                this._Products.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "ProductGroupType_ProductType", Storage = "_ProductGroupType", ThisKey = "ProductGroupTypeId", OtherKey = "Id", IsForeignKey = true)]
        public ProductGroupType ProductGroupType
        {
            get
            {
                return this._ProductGroupType.Entity;
            }
            set
            {
                ProductGroupType previousValue = this._ProductGroupType.Entity;
                if (((previousValue != value)
                            || (this._ProductGroupType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._ProductGroupType.Entity = null;
                        previousValue.ProductTypes.Remove(this);
                    }
                    this._ProductGroupType.Entity = value;
                    if ((value != null))
                    {
                        value.ProductTypes.Add(this);
                        this._ProductGroupTypeId = value.Id;
                    }
                    else
                    {
                        this._ProductGroupTypeId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("ProductGroupType");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Childs(ProductType entity)
        {
            this.SendPropertyChanging();
            entity.Parent = this;
        }

        private void detach_Childs(ProductType entity)
        {
            this.SendPropertyChanging();
            entity.Parent = null;
        }

        private void attach_Products(Product entity)
        {
            this.SendPropertyChanging();
            entity.ProductType = this;
        }

        private void detach_Products(Product entity)
        {
            this.SendPropertyChanging();
            entity.ProductType = null;
        }
    }
}