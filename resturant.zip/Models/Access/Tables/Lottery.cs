﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Lottery")]
    public partial class Lottery : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.DateTime _DateSabt;

        private string _DateShoro;

        private string _DatePayan;

        private string _url;

        private string _NameOfUrl;

        private string _Onvam;

        private string _Url800_600;

        private string _Url1920_450;

        private string _Dsc;

        private System.Nullable<int> _Priority;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDateSabtChanging(System.DateTime value);
        partial void OnDateSabtChanged();
        partial void OnDateShoroChanging(string value);
        partial void OnDateShoroChanged();
        partial void OnDatePayanChanging(string value);
        partial void OnDatePayanChanged();
        partial void OnurlChanging(string value);
        partial void OnurlChanged();
        partial void OnUrl800_600Changing(string value);
        partial void OnUrl800_600Changed();
        partial void OnUrl1920_450Changing(string value);
        partial void OnUrl1920_450Changed();
        partial void OnNameOfUrlChanging(string value);
        partial void OnNameOfUrlChanged();
        partial void OnOnvamChanging(string value);
        partial void OnOnvamChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        #endregion

        public Lottery()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateSabt
        {
            get
            {
                return this._DateSabt;
            }
            set
            {
                if ((this._DateSabt != value))
                {
                    this.OnDateSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt = value;
                    this.SendPropertyChanged("DateSabt");
                    this.OnDateSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateShoro", DbType = "NVarChar(50)")]
        public string DateShoro
        {
            get
            {
                return this._DateShoro;
            }
            set
            {
                if ((this._DateShoro != value))
                {
                    this.OnDateShoroChanging(value);
                    this.SendPropertyChanging();
                    this._DateShoro = value;
                    this.SendPropertyChanged("DateShoro");
                    this.OnDateShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePayan", DbType = "NVarChar(50)")]
        public string DatePayan
        {
            get
            {
                return this._DatePayan;
            }
            set
            {
                if ((this._DatePayan != value))
                {
                    this.OnDatePayanChanging(value);
                    this.SendPropertyChanging();
                    this._DatePayan = value;
                    this.SendPropertyChanged("DatePayan");
                    this.OnDatePayanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_url", DbType = "NVarChar(MAX)")]
        public string url
        {
            get
            {
                return this._url;
            }
            set
            {
                if ((this._url != value))
                {
                    this.OnurlChanging(value);
                    this.SendPropertyChanging();
                    this._url = value;
                    this.SendPropertyChanged("url");
                    this.OnurlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NameOfUrl", DbType = "NVarChar(MAX)")]
        public string NameOfUrl
        {
            get
            {
                return this._NameOfUrl;
            }
            set
            {
                if ((this._NameOfUrl != value))
                {
                    this.OnNameOfUrlChanging(value);
                    this.SendPropertyChanging();
                    this._NameOfUrl = value;
                    this.SendPropertyChanged("NameOfUrl");
                    this.OnNameOfUrlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Onvam", DbType = "NVarChar(MAX)")]
        public string Onvam
        {
            get
            {
                return this._Onvam;
            }
            set
            {
                if ((this._Onvam != value))
                {
                    this.OnOnvamChanging(value);
                    this.SendPropertyChanging();
                    this._Onvam = value;
                    this.SendPropertyChanged("Onvam");
                    this.OnOnvamChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Url800_600", DbType = "NVarChar(MAX)")]
        public string Url800_600
        {
            get
            {
                return this._Url800_600;
            }
            set
            {
                if ((this._Url800_600 != value))
                {
                    this.OnUrl800_600Changing(value);
                    this.SendPropertyChanging();
                    this._Url800_600 = value;
                    this.SendPropertyChanged("Url800_600");
                    this.OnUrl800_600Changed();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Url1920_450", DbType = "NVarChar(MAX)")]
        public string Url1920_450
        {
            get
            {
                return this._Url1920_450;
            }
            set
            {
                if ((this._Url1920_450 != value))
                {
                    this.OnUrl1920_450Changing(value);
                    this.SendPropertyChanging();
                    this._Url1920_450 = value;
                    this.SendPropertyChanged("Url1920_450");
                    this.OnUrl1920_450Changed();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}