﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.[Transaction]")]
    public partial class Transaction : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Nullable<System.Guid> _USERID;

        private decimal _mablaghPardakhtShode;

        private string _Dsc;

        private string _STATE;

        private System.Nullable<System.DateTime> _DateTime;

        private string _Date;

        private string _Time;

        private System.Nullable<System.Guid> _SabadKharidID;

        private string _CodeRahgiri;

        private string _Info;

        private decimal _mablaghGahbelPardakht;

        private string _FullNameUser;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUSERIDChanging(System.Nullable<System.Guid> value);
        partial void OnUSERIDChanged();
        partial void OnmablaghPardakhtShodeChanging(decimal value);
        partial void OnmablaghPardakhtShodeChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnSTATEChanging(string value);
        partial void OnSTATEChanged();
        partial void OnDateTimeChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnTimeChanging(string value);
        partial void OnTimeChanged();
        partial void OnSabadKharidIDChanging(System.Nullable<System.Guid> value);
        partial void OnSabadKharidIDChanged();
        partial void OnCodeRahgiriChanging(string value);
        partial void OnCodeRahgiriChanged();
        partial void OnInfoChanging(string value);
        partial void OnInfoChanged();
        partial void OnmablaghGahbelPardakhtChanging(decimal value);
        partial void OnmablaghGahbelPardakhtChanged();
        partial void OnFullNameUserChanging(string value);
        partial void OnFullNameUserChanged();
        #endregion

        public Transaction()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_USERID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> USERID
        {
            get
            {
                return this._USERID;
            }
            set
            {
                if ((this._USERID != value))
                {
                    this.OnUSERIDChanging(value);
                    this.SendPropertyChanging();
                    this._USERID = value;
                    this.SendPropertyChanged("USERID");
                    this.OnUSERIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_mablaghPardakhtShode", DbType = "Decimal(18,0) NOT NULL")]
        public decimal mablaghPardakhtShode
        {
            get
            {
                return this._mablaghPardakhtShode;
            }
            set
            {
                if ((this._mablaghPardakhtShode != value))
                {
                    this.OnmablaghPardakhtShodeChanging(value);
                    this.SendPropertyChanging();
                    this._mablaghPardakhtShode = value;
                    this.SendPropertyChanged("mablaghPardakhtShode");
                    this.OnmablaghPardakhtShodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_STATE", DbType = "NVarChar(MAX)")]
        public string STATE
        {
            get
            {
                return this._STATE;
            }
            set
            {
                if ((this._STATE != value))
                {
                    this.OnSTATEChanging(value);
                    this.SendPropertyChanging();
                    this._STATE = value;
                    this.SendPropertyChanged("STATE");
                    this.OnSTATEChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTime", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTime
        {
            get
            {
                return this._DateTime;
            }
            set
            {
                if ((this._DateTime != value))
                {
                    this.OnDateTimeChanging(value);
                    this.SendPropertyChanging();
                    this._DateTime = value;
                    this.SendPropertyChanged("DateTime");
                    this.OnDateTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NVarChar(50)")]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Time", DbType = "NVarChar(50)")]
        public string Time
        {
            get
            {
                return this._Time;
            }
            set
            {
                if ((this._Time != value))
                {
                    this.OnTimeChanging(value);
                    this.SendPropertyChanging();
                    this._Time = value;
                    this.SendPropertyChanged("Time");
                    this.OnTimeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SabadKharidID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> SabadKharidID
        {
            get
            {
                return this._SabadKharidID;
            }
            set
            {
                if ((this._SabadKharidID != value))
                {
                    this.OnSabadKharidIDChanging(value);
                    this.SendPropertyChanging();
                    this._SabadKharidID = value;
                    this.SendPropertyChanged("SabadKharidID");
                    this.OnSabadKharidIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CodeRahgiri", DbType = "NVarChar(MAX)")]
        public string CodeRahgiri
        {
            get
            {
                return this._CodeRahgiri;
            }
            set
            {
                if ((this._CodeRahgiri != value))
                {
                    this.OnCodeRahgiriChanging(value);
                    this.SendPropertyChanging();
                    this._CodeRahgiri = value;
                    this.SendPropertyChanged("CodeRahgiri");
                    this.OnCodeRahgiriChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Info", DbType = "NVarChar(MAX)")]
        public string Info
        {
            get
            {
                return this._Info;
            }
            set
            {
                if ((this._Info != value))
                {
                    this.OnInfoChanging(value);
                    this.SendPropertyChanging();
                    this._Info = value;
                    this.SendPropertyChanged("Info");
                    this.OnInfoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_mablaghGahbelPardakht", DbType = "Decimal(18,0) NOT NULL")]
        public decimal mablaghGahbelPardakht
        {
            get
            {
                return this._mablaghGahbelPardakht;
            }
            set
            {
                if ((this._mablaghGahbelPardakht != value))
                {
                    this.OnmablaghGahbelPardakhtChanging(value);
                    this.SendPropertyChanging();
                    this._mablaghGahbelPardakht = value;
                    this.SendPropertyChanged("mablaghGahbelPardakht");
                    this.OnmablaghGahbelPardakhtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullNameUser", DbType = "NVarChar(MAX)")]
        public string FullNameUser
        {
            get
            {
                return this._FullNameUser;
            }
            set
            {
                if ((this._FullNameUser != value))
                {
                    this.OnFullNameUserChanging(value);
                    this.SendPropertyChanging();
                    this._FullNameUser = value;
                    this.SendPropertyChanged("FullNameUser");
                    this.OnFullNameUserChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}