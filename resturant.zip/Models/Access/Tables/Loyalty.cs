﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Loyalty")]
    public partial class Loyalty : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _DateShoro;

        private string _Datepayan;

        private string _TimeShoro;

        private string _TimePayan;

        private string _Onvan;

        private string _Dsc;

        private string _DatetimeShoro_fa;

        private string _DateTimePayan_fa;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDateShoroChanging(string value);
        partial void OnDateShoroChanged();
        partial void OnDatepayanChanging(string value);
        partial void OnDatepayanChanged();
        partial void OnTimeShoroChanging(string value);
        partial void OnTimeShoroChanged();
        partial void OnTimePayanChanging(string value);
        partial void OnTimePayanChanged();
        partial void OnOnvanChanging(string value);
        partial void OnOnvanChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnDatetimeShoro_faChanging(string value);
        partial void OnDatetimeShoro_faChanged();
        partial void OnDateTimePayan_faChanging(string value);
        partial void OnDateTimePayan_faChanged();
        #endregion

        public Loyalty()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateShoro", DbType = "NVarChar(50)")]
        public string DateShoro
        {
            get
            {
                return this._DateShoro;
            }
            set
            {
                if ((this._DateShoro != value))
                {
                    this.OnDateShoroChanging(value);
                    this.SendPropertyChanging();
                    this._DateShoro = value;
                    this.SendPropertyChanged("DateShoro");
                    this.OnDateShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Datepayan", DbType = "NVarChar(50)")]
        public string Datepayan
        {
            get
            {
                return this._Datepayan;
            }
            set
            {
                if ((this._Datepayan != value))
                {
                    this.OnDatepayanChanging(value);
                    this.SendPropertyChanging();
                    this._Datepayan = value;
                    this.SendPropertyChanged("Datepayan");
                    this.OnDatepayanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeShoro", DbType = "NVarChar(50)")]
        public string TimeShoro
        {
            get
            {
                return this._TimeShoro;
            }
            set
            {
                if ((this._TimeShoro != value))
                {
                    this.OnTimeShoroChanging(value);
                    this.SendPropertyChanging();
                    this._TimeShoro = value;
                    this.SendPropertyChanged("TimeShoro");
                    this.OnTimeShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimePayan", DbType = "NVarChar(50)")]
        public string TimePayan
        {
            get
            {
                return this._TimePayan;
            }
            set
            {
                if ((this._TimePayan != value))
                {
                    this.OnTimePayanChanging(value);
                    this.SendPropertyChanging();
                    this._TimePayan = value;
                    this.SendPropertyChanged("TimePayan");
                    this.OnTimePayanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Onvan", DbType = "NVarChar(MAX)")]
        public string Onvan
        {
            get
            {
                return this._Onvan;
            }
            set
            {
                if ((this._Onvan != value))
                {
                    this.OnOnvanChanging(value);
                    this.SendPropertyChanging();
                    this._Onvan = value;
                    this.SendPropertyChanged("Onvan");
                    this.OnOnvanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatetimeShoro_fa", DbType = "NVarChar(50)")]
        public string DatetimeShoro_fa
        {
            get
            {
                return this._DatetimeShoro_fa;
            }
            set
            {
                if ((this._DatetimeShoro_fa != value))
                {
                    this.OnDatetimeShoro_faChanging(value);
                    this.SendPropertyChanging();
                    this._DatetimeShoro_fa = value;
                    this.SendPropertyChanged("DatetimeShoro_fa");
                    this.OnDatetimeShoro_faChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimePayan_fa", DbType = "NVarChar(50)")]
        public string DateTimePayan_fa
        {
            get
            {
                return this._DateTimePayan_fa;
            }
            set
            {
                if ((this._DateTimePayan_fa != value))
                {
                    this.OnDateTimePayan_faChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimePayan_fa = value;
                    this.SendPropertyChanged("DateTimePayan_fa");
                    this.OnDateTimePayan_faChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}