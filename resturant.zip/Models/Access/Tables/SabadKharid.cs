﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.SabadKharid")]
    public partial class SabadKharid : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private bool _IsDeleteFromClient;

        private bool _IsDeleted;

        private bool _IsKharid;

        private System.Guid _UserMoshtariID;

        private string _CodeRahgiri;

        private System.Nullable<System.Guid> _UserTahvilDahandeID;

        private System.DateTime _DateTimeAkharinTaghirat;

        private System.Nullable<System.DateTime> _DateTimeSabtSefareshKharid;

        private string _DateSabtSefareshKharid_Fa;

        private string _TimeSabtSefareshKharid_Fa;

        private System.Nullable<System.DateTime> _DateTimeTahvilBeUserTahvilDahande;

        private string _DateTahvilBeUserTahvilDahande;

        private string _TimeTahvilBeUserTahvilDahande;

        private System.Nullable<decimal> _PriceKol;

        private System.Nullable<System.Guid> _UserPardakhtKonandeID;

        private string _FullNameTahvilGirande;

        private bool _IsTahvilBeMoshtari;

        private System.Nullable<System.DateTime> _DateTimeTahvilBeMoshtari;

        private string _DateTahvilBeMoshtari_Fa;

        private string _TimeTahvilBeMoshtari_Fa;

        private string _CodeMaref;

        private System.Nullable<int> _PointService;

        private decimal _MablaghPardakhtShodeHadie_AllMonth;

        private decimal _MablaghGhabelPardakht;

        private decimal _MablaghHadieDaryafti_AllMonth;

        private decimal _MablaghHadieDaryafti_EndMonth;

        private decimal _MablaghPardakhtShodeHadie_EndMonth;

        private decimal _MablaghPardakhtShode;

        private decimal _MablaghPardakhtShodeHadieAzKifPolAsli;

        private string _DSC;

        private decimal _MablaghPardakhtMaliat;

        private decimal _MablaghPardakhtTransport;

        private bool _IsTaiedBarrasi;

        private System.Nullable<System.DateTime> _DateTimeTaiedBarrasi;

        private string _TimeTaiedBarrasi;

        private string _DateTaiedBarrasi;

        private System.Nullable<System.DateTime> _DateTimeZamanRaftanDarSafhieTaiedBank;

        private string _TimeZamanRaftanDarSafhieTaiedBank;

        private string _DateZamanRaftanDarSafhieTaiedBank;

        private EntitySet<SabadKharidItem> _SabadKharidItems;

        private EntityRef<user> _userMoshtari;

        private EntityRef<user> _userPardakhtKonande;

        private EntityRef<user> _userTahvilDahande;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnIsDeleteFromClientChanging(bool value);
        partial void OnIsDeleteFromClientChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnIsKharidChanging(bool value);
        partial void OnIsKharidChanged();
        partial void OnUserMoshtariIDChanging(System.Guid value);
        partial void OnUserMoshtariIDChanged();
        partial void OnCodeRahgiriChanging(string value);
        partial void OnCodeRahgiriChanged();
        partial void OnUserTahvilDahandeIDChanging(System.Nullable<System.Guid> value);
        partial void OnUserTahvilDahandeIDChanged();
        partial void OnDateTimeAkharinTaghiratChanging(System.DateTime value);
        partial void OnDateTimeAkharinTaghiratChanged();
        partial void OnDateTimeSabtSefareshKharidChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeSabtSefareshKharidChanged();
        partial void OnDateSabtSefareshKharid_FaChanging(string value);
        partial void OnDateSabtSefareshKharid_FaChanged();
        partial void OnTimeSabtSefareshKharid_FaChanging(string value);
        partial void OnTimeSabtSefareshKharid_FaChanged();
        partial void OnDateTimeTahvilBeUserTahvilDahandeChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeTahvilBeUserTahvilDahandeChanged();
        partial void OnDateTahvilBeUserTahvilDahandeChanging(string value);
        partial void OnDateTahvilBeUserTahvilDahandeChanged();
        partial void OnTimeTahvilBeUserTahvilDahandeChanging(string value);
        partial void OnTimeTahvilBeUserTahvilDahandeChanged();
        partial void OnPriceKolChanging(System.Nullable<decimal> value);
        partial void OnPriceKolChanged();
        partial void OnUserPardakhtKonandeIDChanging(System.Nullable<System.Guid> value);
        partial void OnUserPardakhtKonandeIDChanged();
        partial void OnFullNameTahvilGirandeChanging(string value);
        partial void OnFullNameTahvilGirandeChanged();
        partial void OnIsTahvilBeMoshtariChanging(bool value);
        partial void OnIsTahvilBeMoshtariChanged();
        partial void OnDateTimeTahvilBeMoshtariChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeTahvilBeMoshtariChanged();
        partial void OnDateTahvilBeMoshtari_FaChanging(string value);
        partial void OnDateTahvilBeMoshtari_FaChanged();
        partial void OnTimeTahvilBeMoshtari_FaChanging(string value);
        partial void OnTimeTahvilBeMoshtari_FaChanged();
        partial void OnCodeMarefChanging(string value);
        partial void OnCodeMarefChanged();
        partial void OnPointServiceChanging(System.Nullable<int> value);
        partial void OnPointServiceChanged();
        partial void OnMablaghPardakhtShodeHadie_AllMonthChanging(decimal value);
        partial void OnMablaghPardakhtShodeHadie_AllMonthChanged();
        partial void OnMablaghGhabelPardakhtChanging(decimal value);
        partial void OnMablaghGhabelPardakhtChanged();
        partial void OnMablaghHadieDaryafti_AllMonthChanging(decimal value);
        partial void OnMablaghHadieDaryafti_AllMonthChanged();
        partial void OnMablaghHadieDaryafti_EndMonthChanging(decimal value);
        partial void OnMablaghHadieDaryafti_EndMonthChanged();
        partial void OnMablaghPardakhtShodeHadie_EndMonthChanging(decimal value);
        partial void OnMablaghPardakhtShodeHadie_EndMonthChanged();
        partial void OnMablaghPardakhtShodeChanging(decimal value);
        partial void OnMablaghPardakhtShodeChanged();
        partial void OnMablaghPardakhtShodeHadieAzKifPolAsliChanging(decimal value);
        partial void OnMablaghPardakhtShodeHadieAzKifPolAsliChanged();
        partial void OnDSCChanging(string value);
        partial void OnDSCChanged();
        partial void OnMablaghPardakhtMaliatChanging(decimal value);
        partial void OnMablaghPardakhtMaliatChanged();
        partial void OnMablaghPardakhtTransportChanging(decimal value);
        partial void OnMablaghPardakhtTransportChanged();
        partial void OnIsTaiedBarrasiChanging(bool value);
        partial void OnIsTaiedBarrasiChanged();
        partial void OnDateTimeTaiedBarrasiChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeTaiedBarrasiChanged();
        partial void OnTimeTaiedBarrasiChanging(string value);
        partial void OnTimeTaiedBarrasiChanged();
        partial void OnDateTaiedBarrasiChanging(string value);
        partial void OnDateTaiedBarrasiChanged();

        partial void OnDateTimeZamanRaftanDarSafhieTaiedBankChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeZamanRaftanDarSafhieTaiedBankChanged();
        partial void OnTimeZamanRaftanDarSafhieTaiedBankChanging(string value);
        partial void OnTimeZamanRaftanDarSafhieTaiedBankChanged();
        partial void OnDateZamanRaftanDarSafhieTaiedBankChanging(string value);
        partial void OnDateZamanRaftanDarSafhieTaiedBankChanged();
        #endregion

        public SabadKharid()
        {
            this._SabadKharidItems = new EntitySet<SabadKharidItem>(new Action<SabadKharidItem>(this.attach_SabadKharidItems), new Action<SabadKharidItem>(this.detach_SabadKharidItems));
            this._userMoshtari = default(EntityRef<user>);
            this._userPardakhtKonande = default(EntityRef<user>);
            this._userTahvilDahande = default(EntityRef<user>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleteFromClient", DbType = "Bit NOT NULL")]
        public bool IsDeleteFromClient
        {
            get
            {
                return this._IsDeleteFromClient;
            }
            set
            {
                if ((this._IsDeleteFromClient != value))
                {
                    this.OnIsDeleteFromClientChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleteFromClient = value;
                    this.SendPropertyChanged("IsDeleteFromClient");
                    this.OnIsDeleteFromClientChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsKharid", DbType = "Bit NOT NULL")]
        public bool IsKharid
        {
            get
            {
                return this._IsKharid;
            }
            set
            {
                if ((this._IsKharid != value))
                {
                    this.OnIsKharidChanging(value);
                    this.SendPropertyChanging();
                    this._IsKharid = value;
                    this.SendPropertyChanged("IsKharid");
                    this.OnIsKharidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserMoshtariID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserMoshtariID
        {
            get
            {
                return this._UserMoshtariID;
            }
            set
            {
                if ((this._UserMoshtariID != value))
                {
                    if (this._userMoshtari.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserMoshtariIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserMoshtariID = value;
                    this.SendPropertyChanged("UserMoshtariID");
                    this.OnUserMoshtariIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CodeRahgiri", DbType = "NVarChar(MAX) NOT NULL", CanBeNull = false)]
        public string CodeRahgiri
        {
            get
            {
                return this._CodeRahgiri;
            }
            set
            {
                if ((this._CodeRahgiri != value))
                {
                    this.OnCodeRahgiriChanging(value);
                    this.SendPropertyChanging();
                    this._CodeRahgiri = value;
                    this.SendPropertyChanged("CodeRahgiri");
                    this.OnCodeRahgiriChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserTahvilDahandeID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserTahvilDahandeID
        {
            get
            {
                return this._UserTahvilDahandeID;
            }
            set
            {
                if ((this._UserTahvilDahandeID != value))
                {
                    if (this._userTahvilDahande.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserTahvilDahandeIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserTahvilDahandeID = value;
                    this.SendPropertyChanged("UserTahvilDahandeID");
                    this.OnUserTahvilDahandeIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeAkharinTaghirat", DbType = "DateTime NOT NULL")]
        public System.DateTime DateTimeAkharinTaghirat
        {
            get
            {
                return this._DateTimeAkharinTaghirat;
            }
            set
            {
                if ((this._DateTimeAkharinTaghirat != value))
                {
                    this.OnDateTimeAkharinTaghiratChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeAkharinTaghirat = value;
                    this.SendPropertyChanged("DateTimeAkharinTaghirat");
                    this.OnDateTimeAkharinTaghiratChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabtSefareshKharid", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeSabtSefareshKharid
        {
            get
            {
                return this._DateTimeSabtSefareshKharid;
            }
            set
            {
                if ((this._DateTimeSabtSefareshKharid != value))
                {
                    this.OnDateTimeSabtSefareshKharidChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabtSefareshKharid = value;
                    this.SendPropertyChanged("DateTimeSabtSefareshKharid");
                    this.OnDateTimeSabtSefareshKharidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabtSefareshKharid_Fa", DbType = "NVarChar(50)")]
        public string DateSabtSefareshKharid_Fa
        {
            get
            {
                return this._DateSabtSefareshKharid_Fa;
            }
            set
            {
                if ((this._DateSabtSefareshKharid_Fa != value))
                {
                    this.OnDateSabtSefareshKharid_FaChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabtSefareshKharid_Fa = value;
                    this.SendPropertyChanged("DateSabtSefareshKharid_Fa");
                    this.OnDateSabtSefareshKharid_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeSabtSefareshKharid_Fa", DbType = "NVarChar(50)")]
        public string TimeSabtSefareshKharid_Fa
        {
            get
            {
                return this._TimeSabtSefareshKharid_Fa;
            }
            set
            {
                if ((this._TimeSabtSefareshKharid_Fa != value))
                {
                    this.OnTimeSabtSefareshKharid_FaChanging(value);
                    this.SendPropertyChanging();
                    this._TimeSabtSefareshKharid_Fa = value;
                    this.SendPropertyChanged("TimeSabtSefareshKharid_Fa");
                    this.OnTimeSabtSefareshKharid_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeTahvilBeUserTahvilDahande", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeTahvilBeUserTahvilDahande
        {
            get
            {
                return this._DateTimeTahvilBeUserTahvilDahande;
            }
            set
            {
                if ((this._DateTimeTahvilBeUserTahvilDahande != value))
                {
                    this.OnDateTimeTahvilBeUserTahvilDahandeChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeTahvilBeUserTahvilDahande = value;
                    this.SendPropertyChanged("DateTimeTahvilBeUserTahvilDahande");
                    this.OnDateTimeTahvilBeUserTahvilDahandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTahvilBeUserTahvilDahande", DbType = "NVarChar(50)")]
        public string DateTahvilBeUserTahvilDahande
        {
            get
            {
                return this._DateTahvilBeUserTahvilDahande;
            }
            set
            {
                if ((this._DateTahvilBeUserTahvilDahande != value))
                {
                    this.OnDateTahvilBeUserTahvilDahandeChanging(value);
                    this.SendPropertyChanging();
                    this._DateTahvilBeUserTahvilDahande = value;
                    this.SendPropertyChanged("DateTahvilBeUserTahvilDahande");
                    this.OnDateTahvilBeUserTahvilDahandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeTahvilBeUserTahvilDahande", DbType = "NVarChar(50)")]
        public string TimeTahvilBeUserTahvilDahande
        {
            get
            {
                return this._TimeTahvilBeUserTahvilDahande;
            }
            set
            {
                if ((this._TimeTahvilBeUserTahvilDahande != value))
                {
                    this.OnTimeTahvilBeUserTahvilDahandeChanging(value);
                    this.SendPropertyChanging();
                    this._TimeTahvilBeUserTahvilDahande = value;
                    this.SendPropertyChanged("TimeTahvilBeUserTahvilDahande");
                    this.OnTimeTahvilBeUserTahvilDahandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PriceKol", DbType = "Decimal(18,0)")]
        public System.Nullable<decimal> PriceKol
        {
            get
            {
                return this._PriceKol;
            }
            set
            {
                if ((this._PriceKol != value))
                {
                    this.OnPriceKolChanging(value);
                    this.SendPropertyChanging();
                    this._PriceKol = value;
                    this.SendPropertyChanged("PriceKol");
                    this.OnPriceKolChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserPardakhtKonandeID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserPardakhtKonandeID
        {
            get
            {
                return this._UserPardakhtKonandeID;
            }
            set
            {
                if ((this._UserPardakhtKonandeID != value))
                {
                    if (this._userPardakhtKonande.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserPardakhtKonandeIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserPardakhtKonandeID = value;
                    this.SendPropertyChanged("UserPardakhtKonandeID");
                    this.OnUserPardakhtKonandeIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullNameTahvilGirande", DbType = "NVarChar(MAX)")]
        public string FullNameTahvilGirande
        {
            get
            {
                return this._FullNameTahvilGirande;
            }
            set
            {
                if ((this._FullNameTahvilGirande != value))
                {
                    this.OnFullNameTahvilGirandeChanging(value);
                    this.SendPropertyChanging();
                    this._FullNameTahvilGirande = value;
                    this.SendPropertyChanged("FullNameTahvilGirande");
                    this.OnFullNameTahvilGirandeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTahvilBeMoshtari", DbType = "Bit NOT NULL")]
        public bool IsTahvilBeMoshtari
        {
            get
            {
                return this._IsTahvilBeMoshtari;
            }
            set
            {
                if ((this._IsTahvilBeMoshtari != value))
                {
                    this.OnIsTahvilBeMoshtariChanging(value);
                    this.SendPropertyChanging();
                    this._IsTahvilBeMoshtari = value;
                    this.SendPropertyChanged("IsTahvilBeMoshtari");
                    this.OnIsTahvilBeMoshtariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeTahvilBeMoshtari", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeTahvilBeMoshtari
        {
            get
            {
                return this._DateTimeTahvilBeMoshtari;
            }
            set
            {
                if ((this._DateTimeTahvilBeMoshtari != value))
                {
                    this.OnDateTimeTahvilBeMoshtariChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeTahvilBeMoshtari = value;
                    this.SendPropertyChanged("DateTimeTahvilBeMoshtari");
                    this.OnDateTimeTahvilBeMoshtariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTahvilBeMoshtari_Fa", DbType = "NVarChar(50)")]
        public string DateTahvilBeMoshtari_Fa
        {
            get
            {
                return this._DateTahvilBeMoshtari_Fa;
            }
            set
            {
                if ((this._DateTahvilBeMoshtari_Fa != value))
                {
                    this.OnDateTahvilBeMoshtari_FaChanging(value);
                    this.SendPropertyChanging();
                    this._DateTahvilBeMoshtari_Fa = value;
                    this.SendPropertyChanged("DateTahvilBeMoshtari_Fa");
                    this.OnDateTahvilBeMoshtari_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeTahvilBeMoshtari_Fa", DbType = "NVarChar(50)")]
        public string TimeTahvilBeMoshtari_Fa
        {
            get
            {
                return this._TimeTahvilBeMoshtari_Fa;
            }
            set
            {
                if ((this._TimeTahvilBeMoshtari_Fa != value))
                {
                    this.OnTimeTahvilBeMoshtari_FaChanging(value);
                    this.SendPropertyChanging();
                    this._TimeTahvilBeMoshtari_Fa = value;
                    this.SendPropertyChanged("TimeTahvilBeMoshtari_Fa");
                    this.OnTimeTahvilBeMoshtari_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CodeMaref", DbType = "NVarChar(MAX)")]
        public string CodeMaref
        {
            get
            {
                return this._CodeMaref;
            }
            set
            {
                if ((this._CodeMaref != value))
                {
                    this.OnCodeMarefChanging(value);
                    this.SendPropertyChanging();
                    this._CodeMaref = value;
                    this.SendPropertyChanged("CodeMaref");
                    this.OnCodeMarefChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PointService", DbType = "Int")]
        public System.Nullable<int> PointService
        {
            get
            {
                return this._PointService;
            }
            set
            {
                if ((this._PointService != value))
                {
                    this.OnPointServiceChanging(value);
                    this.SendPropertyChanging();
                    this._PointService = value;
                    this.SendPropertyChanged("PointService");
                    this.OnPointServiceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtShodeHadie_AllMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtShodeHadie_AllMonth
        {
            get
            {
                return this._MablaghPardakhtShodeHadie_AllMonth;
            }
            set
            {
                if ((this._MablaghPardakhtShodeHadie_AllMonth != value))
                {
                    this.OnMablaghPardakhtShodeHadie_AllMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtShodeHadie_AllMonth = value;
                    this.SendPropertyChanged("MablaghPardakhtShodeHadie_AllMonth");
                    this.OnMablaghPardakhtShodeHadie_AllMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghGhabelPardakht", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghGhabelPardakht
        {
            get
            {
                return this._MablaghGhabelPardakht;
            }
            set
            {
                if ((this._MablaghGhabelPardakht != value))
                {
                    this.OnMablaghGhabelPardakhtChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghGhabelPardakht = value;
                    this.SendPropertyChanged("MablaghGhabelPardakht");
                    this.OnMablaghGhabelPardakhtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghHadieDaryafti_AllMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghHadieDaryafti_AllMonth
        {
            get
            {
                return this._MablaghHadieDaryafti_AllMonth;
            }
            set
            {
                if ((this._MablaghHadieDaryafti_AllMonth != value))
                {
                    this.OnMablaghHadieDaryafti_AllMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghHadieDaryafti_AllMonth = value;
                    this.SendPropertyChanged("MablaghHadieDaryafti_AllMonth");
                    this.OnMablaghHadieDaryafti_AllMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghHadieDaryafti_EndMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghHadieDaryafti_EndMonth
        {
            get
            {
                return this._MablaghHadieDaryafti_EndMonth;
            }
            set
            {
                if ((this._MablaghHadieDaryafti_EndMonth != value))
                {
                    this.OnMablaghHadieDaryafti_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghHadieDaryafti_EndMonth = value;
                    this.SendPropertyChanged("MablaghHadieDaryafti_EndMonth");
                    this.OnMablaghHadieDaryafti_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtShodeHadie_EndMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtShodeHadie_EndMonth
        {
            get
            {
                return this._MablaghPardakhtShodeHadie_EndMonth;
            }
            set
            {
                if ((this._MablaghPardakhtShodeHadie_EndMonth != value))
                {
                    this.OnMablaghPardakhtShodeHadie_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtShodeHadie_EndMonth = value;
                    this.SendPropertyChanged("MablaghPardakhtShodeHadie_EndMonth");
                    this.OnMablaghPardakhtShodeHadie_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtShode", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtShode
        {
            get
            {
                return this._MablaghPardakhtShode;
            }
            set
            {
                if ((this._MablaghPardakhtShode != value))
                {
                    this.OnMablaghPardakhtShodeChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtShode = value;
                    this.SendPropertyChanged("MablaghPardakhtShode");
                    this.OnMablaghPardakhtShodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtShodeHadieAzKifPolAsli", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtShodeHadieAzKifPolAsli
        {
            get
            {
                return this._MablaghPardakhtShodeHadieAzKifPolAsli;
            }
            set
            {
                if ((this._MablaghPardakhtShodeHadieAzKifPolAsli != value))
                {
                    this.OnMablaghPardakhtShodeHadieAzKifPolAsliChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtShodeHadieAzKifPolAsli = value;
                    this.SendPropertyChanged("MablaghPardakhtShodeHadieAzKifPolAsli");
                    this.OnMablaghPardakhtShodeHadieAzKifPolAsliChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DSC", DbType = "NVarChar(MAX)")]
        public string DSC
        {
            get
            {
                return this._DSC;
            }
            set
            {
                if ((this._DSC != value))
                {
                    this.OnDSCChanging(value);
                    this.SendPropertyChanging();
                    this._DSC = value;
                    this.SendPropertyChanged("DSC");
                    this.OnDSCChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtMaliat", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtMaliat
        {
            get
            {
                return this._MablaghPardakhtMaliat;
            }
            set
            {
                if ((this._MablaghPardakhtMaliat != value))
                {
                    this.OnMablaghPardakhtMaliatChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtMaliat = value;
                    this.SendPropertyChanged("MablaghPardakhtMaliat");
                    this.OnMablaghPardakhtMaliatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakhtTransport", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakhtTransport
        {
            get
            {
                return this._MablaghPardakhtTransport;
            }
            set
            {
                if ((this._MablaghPardakhtTransport != value))
                {
                    this.OnMablaghPardakhtTransportChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakhtTransport = value;
                    this.SendPropertyChanged("MablaghPardakhtTransport");
                    this.OnMablaghPardakhtTransportChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTaiedBarrasi", DbType = "Bit NOT NULL")]
        public bool IsTaiedBarrasi
        {
            get
            {
                return this._IsTaiedBarrasi;
            }
            set
            {
                if ((this._IsTaiedBarrasi != value))
                {
                    this.OnIsTaiedBarrasiChanging(value);
                    this.SendPropertyChanging();
                    this._IsTaiedBarrasi = value;
                    this.SendPropertyChanged("IsTaiedBarrasi");
                    this.OnIsTaiedBarrasiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeTaiedBarrasi", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeTaiedBarrasi
        {
            get
            {
                return this._DateTimeTaiedBarrasi;
            }
            set
            {
                if ((this._DateTimeTaiedBarrasi != value))
                {
                    this.OnDateTimeTaiedBarrasiChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeTaiedBarrasi = value;
                    this.SendPropertyChanged("DateTimeTaiedBarrasi");
                    this.OnDateTimeTaiedBarrasiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeTaiedBarrasi", DbType = "NVarChar(50)")]
        public string TimeTaiedBarrasi
        {
            get
            {
                return this._TimeTaiedBarrasi;
            }
            set
            {
                if ((this._TimeTaiedBarrasi != value))
                {
                    this.OnTimeTaiedBarrasiChanging(value);
                    this.SendPropertyChanging();
                    this._TimeTaiedBarrasi = value;
                    this.SendPropertyChanged("TimeTaiedBarrasi");
                    this.OnTimeTaiedBarrasiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTaiedBarrasi", DbType = "NVarChar(50)")]
        public string DateTaiedBarrasi
        {
            get
            {
                return this._DateTaiedBarrasi;
            }
            set
            {
                if ((this._DateTaiedBarrasi != value))
                {
                    this.OnDateTaiedBarrasiChanging(value);
                    this.SendPropertyChanging();
                    this._DateTaiedBarrasi = value;
                    this.SendPropertyChanged("DateTaiedBarrasi");
                    this.OnDateTaiedBarrasiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeZamanRaftanDarSafhieTaiedBank", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeZamanRaftanDarSafhieTaiedBank
        {
            get
            {
                return this._DateTimeZamanRaftanDarSafhieTaiedBank;
            }
            set
            {
                if ((this._DateTimeZamanRaftanDarSafhieTaiedBank != value))
                {
                    this.OnDateTimeZamanRaftanDarSafhieTaiedBankChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeZamanRaftanDarSafhieTaiedBank = value;
                    this.SendPropertyChanged("DateTimeZamanRaftanDarSafhieTaiedBank");
                    this.OnDateTimeZamanRaftanDarSafhieTaiedBankChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeZamanRaftanDarSafhieTaiedBank", DbType = "NVarChar(50)")]
        public string TimeZamanRaftanDarSafhieTaiedBank
        {
            get
            {
                return this._TimeZamanRaftanDarSafhieTaiedBank;
            }
            set
            {
                if ((this._TimeZamanRaftanDarSafhieTaiedBank != value))
                {
                    this.OnTimeZamanRaftanDarSafhieTaiedBankChanging(value);
                    this.SendPropertyChanging();
                    this._TimeZamanRaftanDarSafhieTaiedBank = value;
                    this.SendPropertyChanged("TimeZamanRaftanDarSafhieTaiedBank");
                    this.OnTimeZamanRaftanDarSafhieTaiedBankChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateZamanRaftanDarSafhieTaiedBank", DbType = "NVarChar(50)")]
        public string DateZamanRaftanDarSafhieTaiedBank
        {
            get
            {
                return this._DateZamanRaftanDarSafhieTaiedBank;
            }
            set
            {
                if ((this._DateZamanRaftanDarSafhieTaiedBank != value))
                {
                    this.OnDateZamanRaftanDarSafhieTaiedBankChanging(value);
                    this.SendPropertyChanging();
                    this._DateZamanRaftanDarSafhieTaiedBank = value;
                    this.SendPropertyChanged("DateZamanRaftanDarSafhieTaiedBank");
                    this.OnDateZamanRaftanDarSafhieTaiedBankChanged();
                }
            }
        }
        

       [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "SabadKharid_SabadKharidItem", Storage = "_SabadKharidItems", ThisKey = "UID", OtherKey = "SabadKharidID")]
        public EntitySet<SabadKharidItem> SabadKharidItems
        {
            get
            {
                return this._SabadKharidItems;
            }
            set
            {
                this._SabadKharidItems.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid", Storage = "_userMoshtari", ThisKey = "UserMoshtariID", OtherKey = "UID", IsForeignKey = true)]
        public user userMoshtari
        {
            get
            {
                return this._userMoshtari.Entity;
            }
            set
            {
                user previousValue = this._userMoshtari.Entity;
                if (((previousValue != value)
                            || (this._userMoshtari.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userMoshtari.Entity = null;
                        previousValue.SabadKharidsMoshtari.Remove(this);
                    }
                    this._userMoshtari.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidsMoshtari.Add(this);
                        this._UserMoshtariID = value.UID;
                    }
                    else
                    {
                        this._UserMoshtariID = default(System.Guid);
                    }
                    this.SendPropertyChanged("userMoshtari");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid1", Storage = "_userPardakhtKonande", ThisKey = "UserPardakhtKonandeID", OtherKey = "UID", IsForeignKey = true)]
        public user userPardakhtKonande
        {
            get
            {
                return this._userPardakhtKonande.Entity;
            }
            set
            {
                user previousValue = this._userPardakhtKonande.Entity;
                if (((previousValue != value)
                            || (this._userPardakhtKonande.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userPardakhtKonande.Entity = null;
                        previousValue.SabadKharidsPardakhtKonande.Remove(this);
                    }
                    this._userPardakhtKonande.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidsPardakhtKonande.Add(this);
                        this._UserPardakhtKonandeID = value.UID;
                    }
                    else
                    {
                        this._UserPardakhtKonandeID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("userPardakhtKonande");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid2", Storage = "_userTahvilDahande", ThisKey = "UserTahvilDahandeID", OtherKey = "UID", IsForeignKey = true)]
        public user userTahvilDahande
        {
            get
            {
                return this._userTahvilDahande.Entity;
            }
            set
            {
                user previousValue = this._userTahvilDahande.Entity;
                if (((previousValue != value)
                            || (this._userTahvilDahande.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userTahvilDahande.Entity = null;
                        previousValue.SabadKharidsTahvilDahande.Remove(this);
                    }
                    this._userTahvilDahande.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidsTahvilDahande.Add(this);
                        this._UserTahvilDahandeID = value.UID;
                    }
                    else
                    {
                        this._UserTahvilDahandeID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("userTahvilDahande");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.SabadKharid = this;
        }

        private void detach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.SabadKharid = null;
        }
    }

}