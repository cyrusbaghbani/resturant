﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.USER_PRICE")]
    public partial class USER_PRICE : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _UserID;

        private System.Guid _PriceID;

        private EntityRef<user> _user;

        private EntityRef<Price> _Price;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIDChanging(System.Guid value);
        partial void OnUserIDChanged();
        partial void OnPriceIDChanging(System.Guid value);
        partial void OnPriceIDChanged();
        #endregion

        public USER_PRICE()
        {
            this._user = default(EntityRef<user>);
            this._Price = default(EntityRef<Price>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserID
        {
            get
            {
                return this._UserID;
            }
            set
            {
                if ((this._UserID != value))
                {
                    if ((this._user.HasLoadedOrAssignedValue || this._Price.HasLoadedOrAssignedValue))
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserID = value;
                    this.SendPropertyChanged("UserID");
                    this.OnUserIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PriceID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid PriceID
        {
            get
            {
                return this._PriceID;
            }
            set
            {
                if ((this._PriceID != value))
                {
                    this.OnPriceIDChanging(value);
                    this.SendPropertyChanging();
                    this._PriceID = value;
                    this.SendPropertyChanged("PriceID");
                    this.OnPriceIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_USER_PRICE", Storage = "_user", ThisKey = "UserID", OtherKey = "UID", IsForeignKey = true)]
        public user user
        {
            get
            {
                return this._user.Entity;
            }
            set
            {
                user previousValue = this._user.Entity;
                if (((previousValue != value)
                            || (this._user.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._user.Entity = null;
                        previousValue.USER_PRICEs.Remove(this);
                    }
                    this._user.Entity = value;
                    if ((value != null))
                    {
                        value.USER_PRICEs.Add(this);
                        this._UserID = value.UID;
                    }
                    else
                    {
                        this._UserID = default(System.Guid);
                    }
                    this.SendPropertyChanged("user");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_USER_PRICE", Storage = "_Price", ThisKey = "PriceID", OtherKey = "UID", IsForeignKey = true)]
        public Price Price
        {
            get
            {
                return this._Price.Entity;
            }
            set
            {
                Price previousValue = this._Price.Entity;
                if (((previousValue != value)
                            || (this._Price.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Price.Entity = null;
                        previousValue.USER_PRICEs.Remove(this);
                    }
                    this._Price.Entity = value;
                    if ((value != null))
                    {
                        value.USER_PRICEs.Add(this);
                        this._UserID = value.UID;
                    }
                    else
                    {
                        this._UserID = default(System.Guid);
                    }
                    this.SendPropertyChanged("Price");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}