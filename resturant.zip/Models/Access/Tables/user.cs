﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.[user]")]
    public partial class user : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private string _FirstName;

        private string _LastName;

        private string _FullName;

        private string _UserName;

        private string _Password;

        private string _MobileNumber;

        private string _Tel_BeHamrah_Code;

        private string _CodeMeli;

        private string _BirthDate;

        private string _Address;

        private System.Nullable<int> _SematId;

        private int _RoleId;

        private string _Email;

        private bool _IsHoghoghi;

        private System.Nullable<System.Guid> _ParentId;

        private bool _IsActive;

        private bool _IsDeleted;

        private string _CODE_MOAREFI;

        private System.Nullable<bool> _Is_SexMan;

        private string _Dsc;

        private decimal _MablaghAccountKol;

        private decimal _MablaghGiftsKol;

        private decimal _MablaghCreditMinAccount;

        private decimal _MablaghGifts_EndMonth_KOL;

        private System.Nullable<int> _UserTypeID;

        private string _OnvaneSherkat;

        private System.Nullable<int> _MantagheId;

        private System.Nullable<System.Guid> _VisitorUserID;

        private EntitySet<user> _CustomerUser;

        private EntityRef<user> _VisitorUser;

        private EntityRef<Mantaghe> _Mantaghe;

        private EntitySet<Event> _Events;

        private EntitySet<Notification> _NotificationsUserMalek;

        private EntitySet<Notification> _NotificationsReaduser;

        private EntitySet<Payment> _PaymentsAccunt;

        private EntitySet<Payment> _PaymentsPardakhtKonande;

        private EntitySet<SabadKharid> _SabadKharidsMoshtari;

        private EntitySet<SabadKharid> _SabadKharidsPardakhtKonande;

        private EntitySet<SabadKharid> _SabadKharidsTahvilDahande;

        private EntitySet<SabadKharidItem> _SabadKharidItems;

        private EntitySet<Temp> _Temps;

        private EntitySet<user> _Child;

        private EntitySet<USER_PRICE> _USER_PRICEs;

        private EntityRef<Role> _Role;

        private EntityRef<Semat> _Semat;

        private EntityRef<user> _Parent;

        private EntityRef<UserType> _UserType;

        private EntitySet<Point> _Points;

        private EntitySet<Notification> _NotificationSender;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnFirstNameChanging(string value);
        partial void OnFirstNameChanged();
        partial void OnLastNameChanging(string value);
        partial void OnLastNameChanged();
        partial void OnFullNameChanging(string value);
        partial void OnFullNameChanged();
        partial void OnUserNameChanging(string value);
        partial void OnUserNameChanged();
        partial void OnPasswordChanging(string value);
        partial void OnPasswordChanged();
        partial void OnMobileNumberChanging(string value);
        partial void OnMobileNumberChanged();
        partial void OnTel_BeHamrah_CodeChanging(string value);
        partial void OnTel_BeHamrah_CodeChanged();
        partial void OnCodeMeliChanging(string value);
        partial void OnCodeMeliChanged();
        partial void OnAddressChanging(string value);
        partial void OnAddressChanged();       
        partial void OnBirthDateChanging(string value);
        partial void OnBirthDateChanged();
        partial void OnSematIdChanging(System.Nullable<int> value);
        partial void OnSematIdChanged();
        partial void OnRoleIdChanging(int value);
        partial void OnRoleIdChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        partial void OnIsHoghoghiChanging(bool value);
        partial void OnIsHoghoghiChanged();
        partial void OnParentIdChanging(System.Nullable<System.Guid> value);
        partial void OnParentIdChanged();
        partial void OnIsActiveChanging(bool value);
        partial void OnIsActiveChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnCODE_MOAREFIChanging(string value);
        partial void OnCODE_MOAREFIChanged();
        partial void OnIs_SexManChanging(System.Nullable<bool> value);
        partial void OnIs_SexManChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnMablaghAccountKolChanging(decimal value);
        partial void OnMablaghAccountKolChanged();
        partial void OnMablaghGiftsKolChanging(decimal value);
        partial void OnMablaghGiftsKolChanged();
        partial void OnMablaghCreditMinAccountChanging(decimal value);
        partial void OnMablaghCreditMinAccountChanged();
        partial void OnUserTypeIDChanging(System.Nullable<int> value);
        partial void OnUserTypeIDChanged();
        partial void OnOnvaneSherkatChanging(string value);
        partial void OnOnvaneSherkatChanged();
        partial void OnMantagheIdChanging(System.Nullable<int> value);
        partial void OnMantagheIdChanged();
        partial void OnVisitorUserIDChanging(System.Nullable<System.Guid> value);
        partial void OnVisitorUserIDChanged();
        partial void OnMablaghGifts_EndMonth_KOLChanging(decimal value);
        partial void OnMablaghGifts_EndMonth_KOLChanged();
        #endregion

        public user()
        {
            this._NotificationSender = new EntitySet<Notification>(new Action<Notification>(this.attach_NotificationSender), new Action<Notification>(this.detach_NotificationSender));
            this._CustomerUser = new EntitySet<user>(new Action<user>(this.attach_CustomerUser), new Action<user>(this.detach_CustomerUser));
            this._VisitorUser = default(EntityRef<user>);
            this._Points = new EntitySet<Point>(new Action<Point>(this.attach_Points), new Action<Point>(this.detach_Points));
            this._Mantaghe = default(EntityRef<Mantaghe>);
            this._Events = new EntitySet<Event>(new Action<Event>(this.attach_Events), new Action<Event>(this.detach_Events));
            this._NotificationsUserMalek = new EntitySet<Notification>(new Action<Notification>(this.attach_NotificationsUserMalek), new Action<Notification>(this.detach_NotificationsUserMalek));
            this._NotificationsReaduser = new EntitySet<Notification>(new Action<Notification>(this.attach_NotificationsReaduser), new Action<Notification>(this.detach_NotificationsReaduser));
            this._PaymentsAccunt = new EntitySet<Payment>(new Action<Payment>(this.attach_PaymentsAccunt), new Action<Payment>(this.detach_PaymentsAccunt));
            this._PaymentsPardakhtKonande = new EntitySet<Payment>(new Action<Payment>(this.attach_PaymentsPardakhtKonande), new Action<Payment>(this.detach_PaymentsPardakhtKonande));
            this._SabadKharidsMoshtari = new EntitySet<SabadKharid>(new Action<SabadKharid>(this.attach_SabadKharidsMoshtari), new Action<SabadKharid>(this.detach_SabadKharidsMoshtari));
            this._SabadKharidsPardakhtKonande = new EntitySet<SabadKharid>(new Action<SabadKharid>(this.attach_SabadKharidsPardakhtKonande), new Action<SabadKharid>(this.detach_SabadKharidsPardakhtKonande));
            this._SabadKharidsTahvilDahande = new EntitySet<SabadKharid>(new Action<SabadKharid>(this.attach_SabadKharidsTahvilDahande), new Action<SabadKharid>(this.detach_SabadKharidsTahvilDahande));
            this._SabadKharidItems = new EntitySet<SabadKharidItem>(new Action<SabadKharidItem>(this.attach_SabadKharidItems), new Action<SabadKharidItem>(this.detach_SabadKharidItems));
            this._Temps = new EntitySet<Temp>(new Action<Temp>(this.attach_Temps), new Action<Temp>(this.detach_Temps));
            this._Child = new EntitySet<user>(new Action<user>(this.attach_Child), new Action<user>(this.detach_Child));
            this._USER_PRICEs = new EntitySet<USER_PRICE>(new Action<USER_PRICE>(this.attach_USER_PRICEs), new Action<USER_PRICE>(this.detach_USER_PRICEs));
            this._Role = default(EntityRef<Role>);
            this._Semat = default(EntityRef<Semat>);
            this._Parent = default(EntityRef<user>);
            this._UserType = default(EntityRef<UserType>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FirstName", DbType = "NVarChar(500)")]
        public string FirstName
        {
            get
            {
                return this._FirstName;
            }
            set
            {
                if ((this._FirstName != value))
                {
                    this.OnFirstNameChanging(value);
                    this.SendPropertyChanging();
                    this._FirstName = value;
                    this.SendPropertyChanged("FirstName");
                    this.OnFirstNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LastName", DbType = "NVarChar(500)")]
        public string LastName
        {
            get
            {
                return this._LastName;
            }
            set
            {
                if ((this._LastName != value))
                {
                    this.OnLastNameChanging(value);
                    this.SendPropertyChanging();
                    this._LastName = value;
                    this.SendPropertyChanged("LastName");
                    this.OnLastNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FullName", AutoSync = AutoSync.Always, DbType = "NVarChar(1001)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string FullName
        {
            get
            {
                return this._FullName;
            }
            set
            {
                if ((this._FullName != value))
                {
                    this.OnFullNameChanging(value);
                    this.SendPropertyChanging();
                    this._FullName = value;
                    this.SendPropertyChanged("FullName");
                    this.OnFullNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserName", DbType = "NVarChar(500)")]
        public string UserName
        {
            get
            {
                return this._UserName;
            }
            set
            {
                if ((this._UserName != value))
                {
                    this.OnUserNameChanging(value);
                    this.SendPropertyChanging();
                    this._UserName = value;
                    this.SendPropertyChanged("UserName");
                    this.OnUserNameChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BirthDate", DbType = "NVarChar(50)")]
        public string BirthDate
        {
            get
            {
                return this._BirthDate;
            }
            set
            {
                if ((this._BirthDate != value))
                {
                    this.OnBirthDateChanging(value);
                    this.SendPropertyChanging();
                    this._BirthDate = value;
                    this.SendPropertyChanged("BirthDate");
                    this.OnBirthDateChanged();
                }
            }
        }
        

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Password", DbType = "NVarChar(MAX)")]
        public string Password
        {
            get
            {
                return this._Password;
            }
            set
            {
                if ((this._Password != value))
                {
                    this.OnPasswordChanging(value);
                    this.SendPropertyChanging();
                    this._Password = value;
                    this.SendPropertyChanged("Password");
                    this.OnPasswordChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MobileNumber", DbType = "NVarChar(50)")]
        public string MobileNumber
        {
            get
            {
                return this._MobileNumber;
            }
            set
            {
                if ((this._MobileNumber != value))
                {
                    this.OnMobileNumberChanging(value);
                    this.SendPropertyChanging();
                    this._MobileNumber = value;
                    this.SendPropertyChanged("MobileNumber");
                    this.OnMobileNumberChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Tel_BeHamrah_Code", DbType = "NVarChar(50)")]
        public string Tel_BeHamrah_Code
        {
            get
            {
                return this._Tel_BeHamrah_Code;
            }
            set
            {
                if ((this._Tel_BeHamrah_Code != value))
                {
                    this.OnTel_BeHamrah_CodeChanging(value);
                    this.SendPropertyChanging();
                    this._Tel_BeHamrah_Code = value;
                    this.SendPropertyChanged("Tel_BeHamrah_Code");
                    this.OnTel_BeHamrah_CodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CodeMeli", DbType = "NVarChar(50)")]
        public string CodeMeli
        {
            get
            {
                return this._CodeMeli;
            }
            set
            {
                if ((this._CodeMeli != value))
                {
                    this.OnCodeMeliChanging(value);
                    this.SendPropertyChanging();
                    this._CodeMeli = value;
                    this.SendPropertyChanged("CodeMeli");
                    this.OnCodeMeliChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Address", DbType = "NVarChar(MAX)")]
        public string Address
        {
            get
            {
                return this._Address;
            }
            set
            {
                if ((this._Address != value))
                {
                    this.OnAddressChanging(value);
                    this.SendPropertyChanging();
                    this._Address = value;
                    this.SendPropertyChanged("Address");
                    this.OnAddressChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SematId", DbType = "Int")]
        public System.Nullable<int> SematId
        {
            get
            {
                return this._SematId;
            }
            set
            {
                if ((this._SematId != value))
                {
                    if (this._Semat.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnSematIdChanging(value);
                    this.SendPropertyChanging();
                    this._SematId = value;
                    this.SendPropertyChanged("SematId");
                    this.OnSematIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_RoleId", DbType = "Int NOT NULL")]
        public int RoleId
        {
            get
            {
                return this._RoleId;
            }
            set
            {
                if ((this._RoleId != value))
                {
                    if (this._Role.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnRoleIdChanging(value);
                    this.SendPropertyChanging();
                    this._RoleId = value;
                    this.SendPropertyChanged("RoleId");
                    this.OnRoleIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(MAX)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsHoghoghi", DbType = "Bit NOT NULL")]
        public bool IsHoghoghi
        {
            get
            {
                return this._IsHoghoghi;
            }
            set
            {
                if ((this._IsHoghoghi != value))
                {
                    this.OnIsHoghoghiChanging(value);
                    this.SendPropertyChanging();
                    this._IsHoghoghi = value;
                    this.SendPropertyChanged("IsHoghoghi");
                    this.OnIsHoghoghiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    if (this._Parent.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnParentIdChanging(value);
                    this.SendPropertyChanging();
                    this._ParentId = value;
                    this.SendPropertyChanged("ParentId");
                    this.OnParentIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsActive", DbType = "Bit NOT NULL")]
        public bool IsActive
        {
            get
            {
                return this._IsActive;
            }
            set
            {
                if ((this._IsActive != value))
                {
                    this.OnIsActiveChanging(value);
                    this.SendPropertyChanging();
                    this._IsActive = value;
                    this.SendPropertyChanged("IsActive");
                    this.OnIsActiveChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CODE_MOAREFI", DbType = "NVarChar(50)")]
        public string CODE_MOAREFI
        {
            get
            {
                return this._CODE_MOAREFI;
            }
            set
            {
                if ((this._CODE_MOAREFI != value))
                {
                    this.OnCODE_MOAREFIChanging(value);
                    this.SendPropertyChanging();
                    this._CODE_MOAREFI = value;
                    this.SendPropertyChanged("CODE_MOAREFI");
                    this.OnCODE_MOAREFIChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Is_SexMan", DbType = "Bit")]
        public System.Nullable<bool> Is_SexMan
        {
            get
            {
                return this._Is_SexMan;
            }
            set
            {
                if ((this._Is_SexMan != value))
                {
                    this.OnIs_SexManChanging(value);
                    this.SendPropertyChanging();
                    this._Is_SexMan = value;
                    this.SendPropertyChanged("Is_SexMan");
                    this.OnIs_SexManChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghAccountKol", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghAccountKol
        {
            get
            {
                return this._MablaghAccountKol;
            }
            set
            {
                if ((this._MablaghAccountKol != value))
                {
                    this.OnMablaghAccountKolChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghAccountKol = value;
                    this.SendPropertyChanged("MablaghAccountKol");
                    this.OnMablaghAccountKolChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghGiftsKol", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghGiftsKol
        {
            get
            {
                return this._MablaghGiftsKol;
            }
            set
            {
                if ((this._MablaghGiftsKol != value))
                {
                    this.OnMablaghGiftsKolChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghGiftsKol = value;
                    this.SendPropertyChanged("MablaghGiftsKol");
                    this.OnMablaghGiftsKolChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghCreditMinAccount", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghCreditMinAccount
        {
            get
            {
                return this._MablaghCreditMinAccount;
            }
            set
            {
                if ((this._MablaghCreditMinAccount != value))
                {
                    this.OnMablaghCreditMinAccountChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghCreditMinAccount = value;
                    this.SendPropertyChanged("MablaghCreditMinAccount");
                    this.OnMablaghCreditMinAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserTypeID", DbType = "Int")]
        public System.Nullable<int> UserTypeID
        {
            get
            {
                return this._UserTypeID;
            }
            set
            {
                if ((this._UserTypeID != value))
                {
                    if (this._UserType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserTypeIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserTypeID = value;
                    this.SendPropertyChanged("UserTypeID");
                    this.OnUserTypeIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OnvaneSherkat", DbType = "NVarChar(MAX)")]
        public string OnvaneSherkat
        {
            get
            {
                return this._OnvaneSherkat;
            }
            set
            {
                if ((this._OnvaneSherkat != value))
                {
                    this.OnOnvaneSherkatChanging(value);
                    this.SendPropertyChanging();
                    this._OnvaneSherkat = value;
                    this.SendPropertyChanged("OnvaneSherkat");
                    this.OnOnvaneSherkatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MantagheId", DbType = "Int")]
        public System.Nullable<int> MantagheId
        {
            get
            {
                return this._MantagheId;
            }
            set
            {
                if ((this._MantagheId != value))
                {
                    if (this._Mantaghe.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnMantagheIdChanging(value);
                    this.SendPropertyChanging();
                    this._MantagheId = value;
                    this.SendPropertyChanged("MantagheId");
                    this.OnMantagheIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Mantaghe_user", Storage = "_Mantaghe", ThisKey = "MantagheId", OtherKey = "Id", IsForeignKey = true)]
        public Mantaghe Mantaghe
        {
            get
            {
                return this._Mantaghe.Entity;
            }
            set
            {
                Mantaghe previousValue = this._Mantaghe.Entity;
                if (((previousValue != value)
                            || (this._Mantaghe.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Mantaghe.Entity = null;
                        previousValue.users.Remove(this);
                    }
                    this._Mantaghe.Entity = value;
                    if ((value != null))
                    {
                        value.users.Add(this);
                        this._MantagheId = value.Id;
                    }
                    else
                    {
                        this._MantagheId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Mantaghe");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Event", Storage = "_Events", ThisKey = "UID", OtherKey = "UserId")]
        public EntitySet<Event> Events
        {
            get
            {
                return this._Events;
            }
            set
            {
                this._Events.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification", Storage = "_NotificationsUserMalek", ThisKey = "UID", OtherKey = "UserId")]
        public EntitySet<Notification> NotificationsUserMalek
        {
            get
            {
                return this._NotificationsUserMalek;
            }
            set
            {
                this._NotificationsUserMalek.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification1", Storage = "_NotificationsReaduser", ThisKey = "UID", OtherKey = "UserRead_Id")]
        public EntitySet<Notification> NotificationsReaduser
        {
            get
            {
                return this._NotificationsReaduser;
            }
            set
            {
                this._NotificationsReaduser.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Payment", Storage = "_PaymentsAccunt", ThisKey = "UID", OtherKey = "UserAccountId")]
        public EntitySet<Payment> PaymentsAccunt
        {
            get
            {
                return this._PaymentsAccunt;
            }
            set
            {
                this._PaymentsAccunt.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Payment1", Storage = "_PaymentsPardakhtKonande", ThisKey = "UID", OtherKey = "UserPardakhKonandeID")]
        public EntitySet<Payment> PaymentsPardakhtKonande
        {
            get
            {
                return this._PaymentsPardakhtKonande;
            }
            set
            {
                this._PaymentsPardakhtKonande.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid", Storage = "_SabadKharidsMoshtari", ThisKey = "UID", OtherKey = "UserMoshtariID")]
        public EntitySet<SabadKharid> SabadKharidsMoshtari
        {
            get
            {
                return this._SabadKharidsMoshtari;
            }
            set
            {
                this._SabadKharidsMoshtari.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid1", Storage = "_SabadKharidsPardakhtKonande", ThisKey = "UID", OtherKey = "UserPardakhtKonandeID")]
        public EntitySet<SabadKharid> SabadKharidsPardakhtKonande
        {
            get
            {
                return this._SabadKharidsPardakhtKonande;
            }
            set
            {
                this._SabadKharidsPardakhtKonande.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharid2", Storage = "_SabadKharidsTahvilDahande", ThisKey = "UID", OtherKey = "UserTahvilDahandeID")]
        public EntitySet<SabadKharid> SabadKharidsTahvilDahande
        {
            get
            {
                return this._SabadKharidsTahvilDahande;
            }
            set
            {
                this._SabadKharidsTahvilDahande.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_VisitorUserID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> VisitorUserID
        {
            get
            {
                return this._VisitorUserID;
            }
            set
            {
                if ((this._VisitorUserID != value))
                {
                    if (this._VisitorUser.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnVisitorUserIDChanging(value);
                    this.SendPropertyChanging();
                    this._VisitorUserID = value;
                    this.SendPropertyChanged("VisitorUserID");
                    this.OnVisitorUserIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghGifts_EndMonth_KOL", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghGifts_EndMonth_KOL
        {
            get
            {
                return this._MablaghGifts_EndMonth_KOL;
            }
            set
            {
                if ((this._MablaghGifts_EndMonth_KOL != value))
                {
                    this.OnMablaghGifts_EndMonth_KOLChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghGifts_EndMonth_KOL = value;
                    this.SendPropertyChanged("MablaghGifts_EndMonth_KOL");
                    this.OnMablaghGifts_EndMonth_KOLChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_user1", Storage = "_CustomerUser", ThisKey = "UID", OtherKey = "VisitorUserID")]
        public EntitySet<user> CustomerUser
        {
            get
            {
                return this._CustomerUser;
            }
            set
            {
                this._CustomerUser.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_user1", Storage = "_VisitorUser", ThisKey = "VisitorUserID", OtherKey = "UID", IsForeignKey = true)]
        public user VisitorUser
        {
            get
            {
                return this._VisitorUser.Entity;
            }
            set
            {
                user previousValue = this._VisitorUser.Entity;
                if (((previousValue != value)
                            || (this._VisitorUser.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._VisitorUser.Entity = null;
                        previousValue.CustomerUser.Remove(this);
                    }
                    this._VisitorUser.Entity = value;
                    if ((value != null))
                    {
                        value.CustomerUser.Add(this);
                        this._VisitorUserID = value.UID;
                    }
                    else
                    {
                        this._VisitorUserID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("VisitorUser");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharidItem", Storage = "_SabadKharidItems", ThisKey = "UID", OtherKey = "UserAddKonandeID")]
        public EntitySet<SabadKharidItem> SabadKharidItems
        {
            get
            {
                return this._SabadKharidItems;
            }
            set
            {
                this._SabadKharidItems.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Temp", Storage = "_Temps", ThisKey = "UID", OtherKey = "UserID")]
        public EntitySet<Temp> Temps
        {
            get
            {
                return this._Temps;
            }
            set
            {
                this._Temps.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_user", Storage = "_Child", ThisKey = "UID", OtherKey = "ParentId")]
        public EntitySet<user> Child
        {
            get
            {
                return this._Child;
            }
            set
            {
                this._Child.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_USER_PRICE", Storage = "_USER_PRICEs", ThisKey = "UID", OtherKey = "UserID")]
        public EntitySet<USER_PRICE> USER_PRICEs
        {
            get
            {
                return this._USER_PRICEs;
            }
            set
            {
                this._USER_PRICEs.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Role_user", Storage = "_Role", ThisKey = "RoleId", OtherKey = "Id", IsForeignKey = true)]
        public Role Role
        {
            get
            {
                return this._Role.Entity;
            }
            set
            {
                Role previousValue = this._Role.Entity;
                if (((previousValue != value)
                            || (this._Role.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Role.Entity = null;
                        previousValue.users.Remove(this);
                    }
                    this._Role.Entity = value;
                    if ((value != null))
                    {
                        value.users.Add(this);
                        this._RoleId = value.Id;
                    }
                    else
                    {
                        this._RoleId = default(int);
                    }
                    this.SendPropertyChanged("Role");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Semat_user", Storage = "_Semat", ThisKey = "SematId", OtherKey = "Id", IsForeignKey = true)]
        public Semat Semat
        {
            get
            {
                return this._Semat.Entity;
            }
            set
            {
                Semat previousValue = this._Semat.Entity;
                if (((previousValue != value)
                            || (this._Semat.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Semat.Entity = null;
                        previousValue.users.Remove(this);
                    }
                    this._Semat.Entity = value;
                    if ((value != null))
                    {
                        value.users.Add(this);
                        this._SematId = value.Id;
                    }
                    else
                    {
                        this._SematId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Semat");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_user", Storage = "_Parent", ThisKey = "ParentId", OtherKey = "UID", IsForeignKey = true)]
        public user Parent
        {
            get
            {
                return this._Parent.Entity;
            }
            set
            {
                user previousValue = this._Parent.Entity;
                if (((previousValue != value)
                            || (this._Parent.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Parent.Entity = null;
                        previousValue.Child.Remove(this);
                    }
                    this._Parent.Entity = value;
                    if ((value != null))
                    {
                        value.Child.Add(this);
                        this._ParentId = value.UID;
                    }
                    else
                    {
                        this._ParentId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("Parent");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification1", Storage = "_NotificationSender", ThisKey = "UID", OtherKey = "SenderID")]
        public EntitySet<Notification> NotificationSender
        {
            get
            {
                return this._NotificationSender;
            }
            set
            {
                this._NotificationSender.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "UserType_user", Storage = "_UserType", ThisKey = "UserTypeID", OtherKey = "Id", IsForeignKey = true)]
        public UserType UserType
        {
            get
            {
                return this._UserType.Entity;
            }
            set
            {
                UserType previousValue = this._UserType.Entity;
                if (((previousValue != value)
                            || (this._UserType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._UserType.Entity = null;
                        previousValue.users.Remove(this);
                    }
                    this._UserType.Entity = value;
                    if ((value != null))
                    {
                        value.users.Add(this);
                        this._UserTypeID = value.Id;
                    }
                    else
                    {
                        this._UserTypeID = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("UserType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Point", Storage = "_Points", ThisKey = "UID", OtherKey = "UserID")]
        public EntitySet<Point> Points
        {
            get
            {
                return this._Points;
            }
            set
            {
                this._Points.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Events(Event entity)
        {
            this.SendPropertyChanging();
            entity.user = this;
        }

        private void detach_Events(Event entity)
        {
            this.SendPropertyChanging();
            entity.user = null;
        }

        private void attach_NotificationsUserMalek(Notification entity)
        {
            this.SendPropertyChanging();
            entity.userNotificationsMalek = this;
        }

        private void detach_NotificationsUserMalek(Notification entity)
        {
            this.SendPropertyChanging();
            entity.userNotificationsMalek = null;
        }

        private void attach_NotificationsReaduser(Notification entity)
        {
            this.SendPropertyChanging();
            entity.userReadNotification = this;
        }

        private void detach_NotificationsReaduser(Notification entity)
        {
            this.SendPropertyChanging();
            entity.userReadNotification = null;
        }

        private void attach_PaymentsAccunt(Payment entity)
        {
            this.SendPropertyChanging();
            entity.userAccunt = this;
        }

        private void detach_PaymentsAccunt(Payment entity)
        {
            this.SendPropertyChanging();
            entity.userAccunt = null;
        }

        private void attach_PaymentsPardakhtKonande(Payment entity)
        {
            this.SendPropertyChanging();
            entity.userPardakhtkonande = this;
        }

        private void detach_PaymentsPardakhtKonande(Payment entity)
        {
            this.SendPropertyChanging();
            entity.userPardakhtkonande = null;
        }

        private void attach_SabadKharidsMoshtari(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userMoshtari = this;
        }

        private void detach_SabadKharidsMoshtari(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userMoshtari = null;
        }

        private void attach_SabadKharidsPardakhtKonande(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userPardakhtKonande = this;
        }

        private void detach_SabadKharidsPardakhtKonande(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userPardakhtKonande = null;
        }

        private void attach_SabadKharidsTahvilDahande(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userTahvilDahande = this;
        }

        private void detach_SabadKharidsTahvilDahande(SabadKharid entity)
        {
            this.SendPropertyChanging();
            entity.userTahvilDahande = null;
        }

        private void attach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.user = this;
        }

        private void detach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.user = null;
        }

        private void attach_Temps(Temp entity)
        {
            this.SendPropertyChanging();
            entity.user = this;
        }

        private void detach_Temps(Temp entity)
        {
            this.SendPropertyChanging();
            entity.user = null;
        }

        private void attach_Child(user entity)
        {
            this.SendPropertyChanging();
            entity.Parent = this;
        }

        private void detach_Child(user entity)
        {
            this.SendPropertyChanging();
            entity.Parent = null;
        }

        private void attach_USER_PRICEs(USER_PRICE entity)
        {
            this.SendPropertyChanging();
            entity.user = this;
        }

        private void detach_USER_PRICEs(USER_PRICE entity)
        {
            this.SendPropertyChanging();
            entity.user = null;
        }


        private void attach_Points(Point entity)
        {
            this.SendPropertyChanging();
            entity.user = this;
        }

        private void detach_Points(Point entity)
        {
            this.SendPropertyChanging();
            entity.user = null;
        }

        private void attach_CustomerUser(user entity)
        {
            this.SendPropertyChanging();
            entity.VisitorUser = this;
        }

        private void detach_CustomerUser(user entity)
        {
            this.SendPropertyChanging();
            entity.VisitorUser = null;
        }

        private void attach_NotificationSender(Notification entity)
        {
            this.SendPropertyChanging();
            entity.SenderNotification = this;
        }

        private void detach_NotificationSender(Notification entity)
        {
            this.SendPropertyChanging();
            entity.SenderNotification = null;
        }
    }
}