﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Payment")]
    public partial class Payment : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Nullable<System.Guid> _UserPardakhKonandeID;

        private System.Guid _UserAccountId;

        private string _DSC;

        private decimal _MablaghVariziYaBardashti = 0;

        private decimal _MablaghKol = 0;

        private bool _IsVariz;

        private bool _IsGift;

        private bool _IsDeleted;

        private System.DateTime _DateTimeSabt;

        private string _DatePersianSabt;

        private string _TimePersianSabt;

        private bool _IsGift_EndMonth;

        private EntityRef<user> _userAccunt;

        private EntityRef<user> _userPardakhtkonande;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserPardakhKonandeIDChanging(System.Nullable<System.Guid> value);
        partial void OnUserPardakhKonandeIDChanged();
        partial void OnUserAccountIdChanging(System.Guid value);
        partial void OnUserAccountIdChanged();
        partial void OnDSCChanging(string value);
        partial void OnDSCChanged();
        partial void OnMablaghVariziYaBardashtiChanging(decimal value);
        partial void OnMablaghVariziYaBardashtiChanged();
        partial void OnMablaghKolChanging(decimal value);
        partial void OnMablaghKolChanged();
        partial void OnIsVarizChanging(bool value);
        partial void OnIsVarizChanged();
        partial void OnIsGiftChanging(bool value);
        partial void OnIsGiftChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnDateTimeSabtChanging(System.DateTime value);
        partial void OnDateTimeSabtChanged();
        partial void OnDatePersianSabtChanging(string value);
        partial void OnDatePersianSabtChanged();
        partial void OnTimePersianSabtChanging(string value);
        partial void OnTimePersianSabtChanged();
        partial void OnIsGift_EndMonthChanging(bool value);
        partial void OnIsGift_EndMonthChanged();
        #endregion

        public Payment()
        {
            this._userAccunt = default(EntityRef<user>);
            this._userPardakhtkonande = default(EntityRef<user>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserPardakhKonandeID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserPardakhKonandeID
        {
            get
            {
                return this._UserPardakhKonandeID;
            }
            set
            {
                if ((this._UserPardakhKonandeID != value))
                {
                    if (this._userPardakhtkonande.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserPardakhKonandeIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserPardakhKonandeID = value;
                    this.SendPropertyChanged("UserPardakhKonandeID");
                    this.OnUserPardakhKonandeIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserAccountId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserAccountId
        {
            get
            {
                return this._UserAccountId;
            }
            set
            {
                if ((this._UserAccountId != value))
                {
                    if (this._userAccunt.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserAccountIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserAccountId = value;
                    this.SendPropertyChanged("UserAccountId");
                    this.OnUserAccountIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DSC", DbType = "NVarChar(MAX)")]
        public string DSC
        {
            get
            {
                return this._DSC;
            }
            set
            {
                if ((this._DSC != value))
                {
                    this.OnDSCChanging(value);
                    this.SendPropertyChanging();
                    this._DSC = value;
                    this.SendPropertyChanged("DSC");
                    this.OnDSCChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghVariziYaBardashti", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghVariziYaBardashti
        {
            get
            {
                return this._MablaghVariziYaBardashti;
            }
            set
            {
                if ((this._MablaghVariziYaBardashti != value))
                {
                    this.OnMablaghVariziYaBardashtiChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghVariziYaBardashti = value;
                    this.SendPropertyChanged("MablaghVariziYaBardashti");
                    this.OnMablaghVariziYaBardashtiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghKol", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghKol
        {
            get
            {
                return this._MablaghKol;
            }
            set
            {
                if ((this._MablaghKol != value))
                {
                    this.OnMablaghKolChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghKol = value;
                    this.SendPropertyChanged("MablaghKol");
                    this.OnMablaghKolChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsVariz", DbType = "Bit NOT NULL")]
        public bool IsVariz
        {
            get
            {
                return this._IsVariz;
            }
            set
            {
                if ((this._IsVariz != value))
                {
                    this.OnIsVarizChanging(value);
                    this.SendPropertyChanging();
                    this._IsVariz = value;
                    this.SendPropertyChanged("IsVariz");
                    this.OnIsVarizChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsGift", DbType = "Bit NOT NULL")]
        public bool IsGift
        {
            get
            {
                return this._IsGift;
            }
            set
            {
                if ((this._IsGift != value))
                {
                    this.OnIsGiftChanging(value);
                    this.SendPropertyChanging();
                    this._IsGift = value;
                    this.SendPropertyChanged("IsGift");
                    this.OnIsGiftChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateTimeSabt
        {
            get
            {
                return this._DateTimeSabt;
            }
            set
            {
                if ((this._DateTimeSabt != value))
                {
                    this.OnDateTimeSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabt = value;
                    this.SendPropertyChanged("DateTimeSabt");
                    this.OnDateTimeSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePersianSabt", DbType = "NVarChar(50)")]
        public string DatePersianSabt
        {
            get
            {
                return this._DatePersianSabt;
            }
            set
            {
                if ((this._DatePersianSabt != value))
                {
                    this.OnDatePersianSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DatePersianSabt = value;
                    this.SendPropertyChanged("DatePersianSabt");
                    this.OnDatePersianSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimePersianSabt", DbType = "NVarChar(50)")]
        public string TimePersianSabt
        {
            get
            {
                return this._TimePersianSabt;
            }
            set
            {
                if ((this._TimePersianSabt != value))
                {
                    this.OnTimePersianSabtChanging(value);
                    this.SendPropertyChanging();
                    this._TimePersianSabt = value;
                    this.SendPropertyChanged("TimePersianSabt");
                    this.OnTimePersianSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsGift_EndMonth", DbType = "Bit NOT NULL")]
        public bool IsGift_EndMonth
        {
            get
            {
                return this._IsGift_EndMonth;
            }
            set
            {
                if ((this._IsGift_EndMonth != value))
                {
                    this.OnIsGift_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._IsGift_EndMonth = value;
                    this.SendPropertyChanged("IsGift_EndMonth");
                    this.OnIsGift_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Payment", Storage = "_userAccunt", ThisKey = "UserAccountId", OtherKey = "UID", IsForeignKey = true)]
        public user userAccunt
        {
            get
            {
                return this._userAccunt.Entity;
            }
            set
            {
                user previousValue = this._userAccunt.Entity;
                if (((previousValue != value)
                            || (this._userAccunt.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userAccunt.Entity = null;
                        previousValue.PaymentsAccunt.Remove(this);
                    }
                    this._userAccunt.Entity = value;
                    if ((value != null))
                    {
                        value.PaymentsAccunt.Add(this);
                        this._UserAccountId = value.UID;
                    }
                    else
                    {
                        this._UserAccountId = default(System.Guid);
                    }
                    this.SendPropertyChanged("userAccunt");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Payment1", Storage = "_userPardakhtkonande", ThisKey = "UserPardakhKonandeID", OtherKey = "UID", IsForeignKey = true)]
        public user userPardakhtkonande
        {
            get
            {
                return this._userPardakhtkonande.Entity;
            }
            set
            {
                user previousValue = this._userPardakhtkonande.Entity;
                if (((previousValue != value)
                            || (this._userPardakhtkonande.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userPardakhtkonande.Entity = null;
                        previousValue.PaymentsPardakhtKonande.Remove(this);
                    }
                    this._userPardakhtkonande.Entity = value;
                    if ((value != null))
                    {
                        value.PaymentsPardakhtKonande.Add(this);
                        this._UserPardakhKonandeID = value.UID;
                    }
                    else
                    {
                        this._UserPardakhKonandeID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("userPardakhtkonande");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}