﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Advertising")]
    public partial class Advertising : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.DateTime _DateSabt;

        private string _DateShoro;

        private string _DatePayan;

        private System.Nullable<int> _Priority;

        private string _Url;

        private string _Url800_600;

        private string _Onvan;

        private string _Dsc;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnDateSabtChanging(System.DateTime value);
        partial void OnDateSabtChanged();
        partial void OnDateShoroChanging(string value);
        partial void OnDateShoroChanged();
        partial void OnDatePayanChanging(string value);
        partial void OnDatePayanChanged();
        partial void OnPriorityChanging(System.Nullable<int> value);
        partial void OnPriorityChanged();
        partial void OnUrlChanging(string value);
        partial void OnUrlChanged();
        partial void OnUrl800_600Changing(string value);
        partial void OnUrl800_600Changed();
        partial void OnOnvanChanging(string value);
        partial void OnOnvanChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        #endregion

        public Advertising()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateSabt
        {
            get
            {
                return this._DateSabt;
            }
            set
            {
                if ((this._DateSabt != value))
                {
                    this.OnDateSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt = value;
                    this.SendPropertyChanged("DateSabt");
                    this.OnDateSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateShoro", DbType = "NVarChar(50)")]
        public string DateShoro
        {
            get
            {
                return this._DateShoro;
            }
            set
            {
                if ((this._DateShoro != value))
                {
                    this.OnDateShoroChanging(value);
                    this.SendPropertyChanging();
                    this._DateShoro = value;
                    this.SendPropertyChanged("DateShoro");
                    this.OnDateShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePayan", DbType = "NVarChar(50)")]
        public string DatePayan
        {
            get
            {
                return this._DatePayan;
            }
            set
            {
                if ((this._DatePayan != value))
                {
                    this.OnDatePayanChanging(value);
                    this.SendPropertyChanging();
                    this._DatePayan = value;
                    this.SendPropertyChanged("DatePayan");
                    this.OnDatePayanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Priority", DbType = "Int")]
        public System.Nullable<int> Priority
        {
            get
            {
                return this._Priority;
            }
            set
            {
                if ((this._Priority != value))
                {
                    this.OnPriorityChanging(value);
                    this.SendPropertyChanging();
                    this._Priority = value;
                    this.SendPropertyChanged("Priority");
                    this.OnPriorityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Url", DbType = "NVarChar(MAX)")]
        public string Url
        {
            get
            {
                return this._Url;
            }
            set
            {
                if ((this._Url != value))
                {
                    this.OnUrlChanging(value);
                    this.SendPropertyChanging();
                    this._Url = value;
                    this.SendPropertyChanged("Url");
                    this.OnUrlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Url800_600", DbType = "NVarChar(MAX)")]
        public string Url800_600
        {
            get
            {
                return this._Url800_600;
            }
            set
            {
                if ((this._Url800_600 != value))
                {
                    this.OnUrl800_600Changing(value);
                    this.SendPropertyChanging();
                    this._Url800_600 = value;
                    this.SendPropertyChanged("Url800_600");
                    this.OnUrl800_600Changed();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Onvan", DbType = "NVarChar(MAX)")]
        public string Onvan
        {
            get
            {
                return this._Onvan;
            }
            set
            {
                if ((this._Onvan != value))
                {
                    this.OnOnvanChanging(value);
                    this.SendPropertyChanging();
                    this._Onvan = value;
                    this.SendPropertyChanged("Onvan");
                    this.OnOnvanChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}