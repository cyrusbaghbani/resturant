﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Price")]
    public partial class Price : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private decimal _Price_;

        private string _DateShoro;

        private string _DatePayan;

        private string _TimeShoro;

        private string _TimePayan;

        private string _DatetimeShoro_Persian;

        private string _DatetimePayan_Persian;

        private bool _IsTakhfifOmomi = false;

        private bool _IsPriceAsli = false;

        private System.Nullable<bool> _IsDeleted=false;

        private System.DateTime _DateSabt;

        private System.Guid _ProductId;

        private System.Nullable<int> _MojodiProduct;

        private bool _IsTakhfifEkhtesasi = false;

        private bool _IsDarhalEngheza = false;

        private string _DatePayanEngheza;

        private string _DateTolid;

        private EntityRef<Product> _Product;

        private EntitySet<SabadKharidItem> _SabadKharidItems;

        private EntitySet<USER_PRICE> _USER_PRICEs;

        private EntitySet<Notification> _Notifications;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnPrice_Changing(decimal value);
        partial void OnPrice_Changed();
        partial void OnDateShoroChanging(string value);
        partial void OnDateShoroChanged();
        partial void OnDatePayanChanging(string value);
        partial void OnDatePayanChanged();
        partial void OnTimeShoroChanging(string value);
        partial void OnTimeShoroChanged();
        partial void OnTimePayanChanging(string value);
        partial void OnTimePayanChanged();
        partial void OnDatetimeShoro_PersianChanging(string value);
        partial void OnDatetimeShoro_PersianChanged();
        partial void OnDatetimePayan_PersianChanging(string value);
        partial void OnDatetimePayan_PersianChanged();
        partial void OnIsTakhfifOmomiChanging(bool value);
        partial void OnIsTakhfifOmomiChanged();
        partial void OnIsPriceAsliChanging(bool value);
        partial void OnIsPriceAsliChanged();
        partial void OnIsDeletedChanging(System.Nullable<bool> value);
        partial void OnIsDeletedChanged();
        partial void OnDateSabtChanging(System.DateTime value);
        partial void OnDateSabtChanged();
        partial void OnProductIdChanging(System.Guid value);
        partial void OnProductIdChanged();
        partial void OnMojodiProductChanging(System.Nullable<int> value);
        partial void OnMojodiProductChanged();
        partial void OnIsTakhfifEkhtesasiChanging(bool value);
        partial void OnIsTakhfifEkhtesasiChanged();
        partial void OnIsDarhalEnghezaChanging(bool value);
        partial void OnIsDarhalEnghezaChanged();
        partial void OnDatePayanEnghezaChanging(string value);
        partial void OnDatePayanEnghezaChanged();
        partial void OnDateTolidChanging(string value);
        partial void OnDateTolidChanged();
        #endregion

        public Price()
        {
            this._Notifications = new EntitySet<Notification>(new Action<Notification>(this.attach_Notifications), new Action<Notification>(this.detach_Notifications));
            this._USER_PRICEs = new EntitySet<USER_PRICE>(new Action<USER_PRICE>(this.attach_USER_PRICEs), new Action<USER_PRICE>(this.detach_USER_PRICEs));
            this._SabadKharidItems = new EntitySet<SabadKharidItem>(new Action<SabadKharidItem>(this.attach_SabadKharidItems), new Action<SabadKharidItem>(this.detach_SabadKharidItems));
            this._Product = default(EntityRef<Product>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Price_", DbType = "Decimal(18,0) NOT NULL")]
        public decimal Price_
        {
            get
            {
                return this._Price_;
            }
            set
            {
                if ((this._Price_ != value))
                {
                    this.OnPrice_Changing(value);
                    this.SendPropertyChanging();
                    this._Price_ = value;
                    this.SendPropertyChanged("Price_");
                    this.OnPrice_Changed();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateShoro", DbType = "NVarChar(50)")]
        public string DateShoro
        {
            get
            {
                return this._DateShoro;
            }
            set
            {
                if ((this._DateShoro != value))
                {
                    this.OnDateShoroChanging(value);
                    this.SendPropertyChanging();
                    this._DateShoro = value;
                    this.SendPropertyChanged("DateShoro");
                    this.OnDateShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePayan", DbType = "NVarChar(50)")]
        public string DatePayan
        {
            get
            {
                return this._DatePayan;
            }
            set
            {
                if ((this._DatePayan != value))
                {
                    this.OnDatePayanChanging(value);
                    this.SendPropertyChanging();
                    this._DatePayan = value;
                    this.SendPropertyChanged("DatePayan");
                    this.OnDatePayanChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeShoro", DbType = "NVarChar(50)")]
        public string TimeShoro
        {
            get
            {
                return this._TimeShoro;
            }
            set
            {
                if ((this._TimeShoro != value))
                {
                    this.OnTimeShoroChanging(value);
                    this.SendPropertyChanging();
                    this._TimeShoro = value;
                    this.SendPropertyChanged("TimeShoro");
                    this.OnTimeShoroChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimePayan", DbType = "NVarChar(50)")]
        public string TimePayan
        {
            get
            {
                return this._TimePayan;
            }
            set
            {
                if ((this._TimePayan != value))
                {
                    this.OnTimePayanChanging(value);
                    this.SendPropertyChanging();
                    this._TimePayan = value;
                    this.SendPropertyChanged("TimePayan");
                    this.OnTimePayanChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatetimeShoro_Persian", DbType = "NVarChar(50)")]
        public string DatetimeShoro_Persian
        {
            get
            {
                return this._DatetimeShoro_Persian;
            }
            set
            {
                if ((this._DatetimeShoro_Persian != value))
                {
                    this.OnDatetimeShoro_PersianChanging(value);
                    this.SendPropertyChanging();
                    this._DatetimeShoro_Persian = value;
                    this.SendPropertyChanged("DatetimeShoro_Persian");
                    this.OnDatetimeShoro_PersianChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatetimePayan_Persian", DbType = "NVarChar(50)")]
        public string DatetimePayan_Persian
        {
            get
            {
                return this._DatetimePayan_Persian;
            }
            set
            {
                if ((this._DatetimePayan_Persian != value))
                {
                    this.OnDatetimePayan_PersianChanging(value);
                    this.SendPropertyChanging();
                    this._DatetimePayan_Persian = value;
                    this.SendPropertyChanged("DatetimePayan_Persian");
                    this.OnDatetimePayan_PersianChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTakhfifOmomi", DbType = "Bit NOT NULL")]
        public bool IsTakhfifOmomi
        {
            get
            {
                return this._IsTakhfifOmomi;
            }
            set
            {
                if ((this._IsTakhfifOmomi != value))
                {
                    this.OnIsTakhfifOmomiChanging(value);
                    this.SendPropertyChanging();
                    this._IsTakhfifOmomi = value;
                    this.SendPropertyChanged("IsTakhfifOmomi");
                    this.OnIsTakhfifOmomiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsPriceAsli", DbType = "Bit NOT NULL")]
        public bool IsPriceAsli
        {
            get
            {
                return this._IsPriceAsli;
            }
            set
            {
                if ((this._IsPriceAsli != value))
                {
                    this.OnIsPriceAsliChanging(value);
                    this.SendPropertyChanging();
                    this._IsPriceAsli = value;
                    this.SendPropertyChanged("IsPriceAsli");
                    this.OnIsPriceAsliChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit")]
        public System.Nullable<bool> IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateSabt
        {
            get
            {
                return this._DateSabt;
            }
            set
            {
                if ((this._DateSabt != value))
                {
                    this.OnDateSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt = value;
                    this.SendPropertyChanged("DateSabt");
                    this.OnDateSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid ProductId
        {
            get
            {
                return this._ProductId;
            }
            set
            {
                if ((this._ProductId != value))
                {
                    if (this._Product.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductIdChanging(value);
                    this.SendPropertyChanging();
                    this._ProductId = value;
                    this.SendPropertyChanged("ProductId");
                    this.OnProductIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MojodiProduct", DbType = "Int")]
        public System.Nullable<int> MojodiProduct
        {
            get
            {
                return this._MojodiProduct;
            }
            set
            {
                if ((this._MojodiProduct != value))
                {
                    this.OnMojodiProductChanging(value);
                    this.SendPropertyChanging();
                    this._MojodiProduct = value;
                    this.SendPropertyChanged("MojodiProduct");
                    this.OnMojodiProductChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTakhfifEkhtesasi", DbType = "Bit NOT NULL")]
        public bool IsTakhfifEkhtesasi
        {
            get
            {
                return this._IsTakhfifEkhtesasi;
            }
            set
            {
                if ((this._IsTakhfifEkhtesasi != value))
                {
                    this.OnIsTakhfifEkhtesasiChanging(value);
                    this.SendPropertyChanging();
                    this._IsTakhfifEkhtesasi = value;
                    this.SendPropertyChanged("IsTakhfifEkhtesasi");
                    this.OnIsTakhfifEkhtesasiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDarhalEngheza", DbType = "Bit NOT NULL")]
        public bool IsDarhalEngheza
        {
            get
            {
                return this._IsDarhalEngheza;
            }
            set
            {
                if ((this._IsDarhalEngheza != value))
                {
                    this.OnIsDarhalEnghezaChanging(value);
                    this.SendPropertyChanging();
                    this._IsDarhalEngheza = value;
                    this.SendPropertyChanged("IsDarhalEngheza");
                    this.OnIsDarhalEnghezaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DatePayanEngheza", DbType = "NVarChar(50)")]
        public string DatePayanEngheza
        {
            get
            {
                return this._DatePayanEngheza;
            }
            set
            {
                if ((this._DatePayanEngheza != value))
                {
                    this.OnDatePayanEnghezaChanging(value);
                    this.SendPropertyChanging();
                    this._DatePayanEngheza = value;
                    this.SendPropertyChanged("DatePayanEngheza");
                    this.OnDatePayanEnghezaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTolid", DbType = "NVarChar(50)")]
        public string DateTolid
        {
            get
            {
                return this._DateTolid;
            }
            set
            {
                if ((this._DateTolid != value))
                {
                    this.OnDateTolidChanging(value);
                    this.SendPropertyChanging();
                    this._DateTolid = value;
                    this.SendPropertyChanged("DateTolid");
                    this.OnDateTolidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Price", Storage = "_Product", ThisKey = "ProductId", OtherKey = "UID", IsForeignKey = true)]
        public Product Product
        {
            get
            {
                return this._Product.Entity;
            }
            set
            {
                Product previousValue = this._Product.Entity;
                if (((previousValue != value)
                            || (this._Product.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Product.Entity = null;
                        previousValue.Prices.Remove(this);
                    }
                    this._Product.Entity = value;
                    if ((value != null))
                    {
                        value.Prices.Add(this);
                        this._ProductId = value.UID;
                    }
                    else
                    {
                        this._ProductId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Product");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_USER_PRICE", Storage = "_USER_PRICEs", ThisKey = "UID", OtherKey = "PriceID")]
        public EntitySet<USER_PRICE> USER_PRICEs
        {
            get
            {
                return this._USER_PRICEs;
            }
            set
            {
                this._USER_PRICEs.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_SabadKharidItem", Storage = "_SabadKharidItems", ThisKey = "UID", OtherKey = "PriceID")]
        public EntitySet<SabadKharidItem> SabadKharidItems
        {
            get
            {
                return this._SabadKharidItems;
            }
            set
            {
                this._SabadKharidItems.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_Notification", Storage = "_Notifications", ThisKey = "UID", OtherKey = "Price_UID")]
        public EntitySet<Notification> Notifications
        {
            get
            {
                return this._Notifications;
            }
            set
            {
                this._Notifications.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.Price = this;
        }

        private void detach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.Price = null;
        }

        private void attach_USER_PRICEs(USER_PRICE entity)
        {
            this.SendPropertyChanging();
            entity.Price = this;
        }

        private void detach_USER_PRICEs(USER_PRICE entity)
        {
            this.SendPropertyChanging();
            entity.Price = null;
        }

        private void attach_Notifications(Notification entity)
        {
            this.SendPropertyChanging();
            entity.Price = this;
        }

        private void detach_Notifications(Notification entity)
        {
            this.SendPropertyChanging();
            entity.Price = null;
        }

    }
}