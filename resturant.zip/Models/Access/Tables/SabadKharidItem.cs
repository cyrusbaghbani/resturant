﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.SabadKharidItem")]
    public partial class SabadKharidItem : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _ProductId;

        private System.Guid _UserAddKonandeID;

        private System.Guid _SabadKharidID;

        private System.Guid _PriceID;

        private System.DateTime _DateTimeSabt;

        private string _DateSabt_Fa;

        private string _TimeSabt_Fa;

        private decimal _Count;

        private decimal _PriceVahed;

        private System.Nullable<bool> _IsTahvilAzAnbar;

        private System.Nullable<System.DateTime> _DateTimeTahvilAzAnbar;

        private string _DateTahvilAzAnbar_Fa;

        private string _TimeTahvilAzAnbar_Fa;

        private System.Nullable<bool> _IsTahvilBeMoshtari;

        private System.Nullable<System.DateTime> _DateTimeTahvilBeMoshtari;

        private string _DateTahvilBeMoshtari_Fa;

        private string _TimeTahvilBeMoshtari_Fa;

        private decimal _DarsadHadie_AllMonth;

        private decimal _DarsadHadie_EndMonth;

        private decimal _MablaghHadie_AllMonth;

        private decimal _MablaghHadie_EndMonth;

        private decimal _MablaghPardakht;

        private EntityRef<user> _user;

        private EntityRef<Price> _Price;

        private EntityRef<Product> _Product;

        private EntityRef<SabadKharid> _SabadKharid;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnProductIdChanging(System.Guid value);
        partial void OnProductIdChanged();
        partial void OnUserAddKonandeIDChanging(System.Guid value);
        partial void OnUserAddKonandeIDChanged();
        partial void OnSabadKharidIDChanging(System.Guid value);
        partial void OnSabadKharidIDChanged();
        partial void OnPriceIDChanging(System.Guid value);
        partial void OnPriceIDChanged();
        partial void OnDateTimeSabtChanging(System.DateTime value);
        partial void OnDateTimeSabtChanged();
        partial void OnDateSabt_FaChanging(string value);
        partial void OnDateSabt_FaChanged();
        partial void OnTimeSabt_FaChanging(string value);
        partial void OnTimeSabt_FaChanged();
        partial void OnCountChanging(decimal value);
        partial void OnCountChanged();
        partial void OnPriceVahedChanging(decimal value);
        partial void OnPriceVahedChanged();
        partial void OnIsTahvilAzAnbarChanging(System.Nullable<bool> value);
        partial void OnIsTahvilAzAnbarChanged();
        partial void OnDateTimeTahvilAzAnbarChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeTahvilAzAnbarChanged();
        partial void OnDateTahvilAzAnbar_FaChanging(string value);
        partial void OnDateTahvilAzAnbar_FaChanged();
        partial void OnTimeTahvilAzAnbar_FaChanging(string value);
        partial void OnTimeTahvilAzAnbar_FaChanged();
        partial void OnIsTahvilBeMoshtariChanging(System.Nullable<bool> value);
        partial void OnIsTahvilBeMoshtariChanged();
        partial void OnDateTimeTahvilBeMoshtariChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeTahvilBeMoshtariChanged();
        partial void OnDateTahvilBeMoshtari_FaChanging(string value);
        partial void OnDateTahvilBeMoshtari_FaChanged();
        partial void OnTimeTahvilBeMoshtari_FaChanging(string value);
        partial void OnTimeTahvilBeMoshtari_FaChanged();
        partial void OnDarsadHadie_AllMonthChanging(decimal value);
        partial void OnDarsadHadie_AllMonthChanged();
        partial void OnDarsadHadie_EndMonthChanging(decimal value);
        partial void OnDarsadHadie_EndMonthChanged();
        partial void OnMablaghHadie_AllMonthChanging(decimal value);
        partial void OnMablaghHadie_AllMonthChanged();
        partial void OnMablaghHadie_EndMonthChanging(decimal value);
        partial void OnMablaghHadie_EndMonthChanged();
        partial void OnMablaghPardakhtChanging(decimal value);
        partial void OnMablaghPardakhtChanged();
        #endregion

        public SabadKharidItem()
        {
            this._user = default(EntityRef<user>);
            this._Price = default(EntityRef<Price>);
            this._Product = default(EntityRef<Product>);
            this._SabadKharid = default(EntityRef<SabadKharid>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductId", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid ProductId
        {
            get
            {
                return this._ProductId;
            }
            set
            {
                if ((this._ProductId != value))
                {
                    if (this._Product.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductIdChanging(value);
                    this.SendPropertyChanging();
                    this._ProductId = value;
                    this.SendPropertyChanged("ProductId");
                    this.OnProductIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserAddKonandeID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserAddKonandeID
        {
            get
            {
                return this._UserAddKonandeID;
            }
            set
            {
                if ((this._UserAddKonandeID != value))
                {
                    if (this._user.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserAddKonandeIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserAddKonandeID = value;
                    this.SendPropertyChanged("UserAddKonandeID");
                    this.OnUserAddKonandeIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SabadKharidID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid SabadKharidID
        {
            get
            {
                return this._SabadKharidID;
            }
            set
            {
                if ((this._SabadKharidID != value))
                {
                    if (this._SabadKharid.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnSabadKharidIDChanging(value);
                    this.SendPropertyChanging();
                    this._SabadKharidID = value;
                    this.SendPropertyChanged("SabadKharidID");
                    this.OnSabadKharidIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PriceID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid PriceID
        {
            get
            {
                return this._PriceID;
            }
            set
            {
                if ((this._PriceID != value))
                {
                    if (this._Price.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnPriceIDChanging(value);
                    this.SendPropertyChanging();
                    this._PriceID = value;
                    this.SendPropertyChanged("PriceID");
                    this.OnPriceIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateTimeSabt
        {
            get
            {
                return this._DateTimeSabt;
            }
            set
            {
                if ((this._DateTimeSabt != value))
                {
                    this.OnDateTimeSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabt = value;
                    this.SendPropertyChanged("DateTimeSabt");
                    this.OnDateTimeSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt_Fa", DbType = "NVarChar(50)")]
        public string DateSabt_Fa
        {
            get
            {
                return this._DateSabt_Fa;
            }
            set
            {
                if ((this._DateSabt_Fa != value))
                {
                    this.OnDateSabt_FaChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt_Fa = value;
                    this.SendPropertyChanged("DateSabt_Fa");
                    this.OnDateSabt_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeSabt_Fa", DbType = "NVarChar(50)")]
        public string TimeSabt_Fa
        {
            get
            {
                return this._TimeSabt_Fa;
            }
            set
            {
                if ((this._TimeSabt_Fa != value))
                {
                    this.OnTimeSabt_FaChanging(value);
                    this.SendPropertyChanging();
                    this._TimeSabt_Fa = value;
                    this.SendPropertyChanged("TimeSabt_Fa");
                    this.OnTimeSabt_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Count", DbType = "Decimal(18,0) NOT NULL")]
        public decimal Count
        {
            get
            {
                return this._Count;
            }
            set
            {
                if ((this._Count != value))
                {
                    this.OnCountChanging(value);
                    this.SendPropertyChanging();
                    this._Count = value;
                    this.SendPropertyChanged("Count");
                    this.OnCountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PriceVahed", DbType = "Decimal(18,0) NOT NULL")]
        public decimal PriceVahed
        {
            get
            {
                return this._PriceVahed;
            }
            set
            {
                if ((this._PriceVahed != value))
                {
                    this.OnPriceVahedChanging(value);
                    this.SendPropertyChanging();
                    this._PriceVahed = value;
                    this.SendPropertyChanged("PriceVahed");
                    this.OnPriceVahedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTahvilAzAnbar", DbType = "Bit")]
        public System.Nullable<bool> IsTahvilAzAnbar
        {
            get
            {
                return this._IsTahvilAzAnbar;
            }
            set
            {
                if ((this._IsTahvilAzAnbar != value))
                {
                    this.OnIsTahvilAzAnbarChanging(value);
                    this.SendPropertyChanging();
                    this._IsTahvilAzAnbar = value;
                    this.SendPropertyChanged("IsTahvilAzAnbar");
                    this.OnIsTahvilAzAnbarChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeTahvilAzAnbar", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeTahvilAzAnbar
        {
            get
            {
                return this._DateTimeTahvilAzAnbar;
            }
            set
            {
                if ((this._DateTimeTahvilAzAnbar != value))
                {
                    this.OnDateTimeTahvilAzAnbarChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeTahvilAzAnbar = value;
                    this.SendPropertyChanged("DateTimeTahvilAzAnbar");
                    this.OnDateTimeTahvilAzAnbarChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTahvilAzAnbar_Fa", DbType = "NVarChar(50)")]
        public string DateTahvilAzAnbar_Fa
        {
            get
            {
                return this._DateTahvilAzAnbar_Fa;
            }
            set
            {
                if ((this._DateTahvilAzAnbar_Fa != value))
                {
                    this.OnDateTahvilAzAnbar_FaChanging(value);
                    this.SendPropertyChanging();
                    this._DateTahvilAzAnbar_Fa = value;
                    this.SendPropertyChanged("DateTahvilAzAnbar_Fa");
                    this.OnDateTahvilAzAnbar_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeTahvilAzAnbar_Fa", DbType = "NVarChar(50)")]
        public string TimeTahvilAzAnbar_Fa
        {
            get
            {
                return this._TimeTahvilAzAnbar_Fa;
            }
            set
            {
                if ((this._TimeTahvilAzAnbar_Fa != value))
                {
                    this.OnTimeTahvilAzAnbar_FaChanging(value);
                    this.SendPropertyChanging();
                    this._TimeTahvilAzAnbar_Fa = value;
                    this.SendPropertyChanged("TimeTahvilAzAnbar_Fa");
                    this.OnTimeTahvilAzAnbar_FaChanged();
                }
            }
        }


        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DarsadHadie_AllMonth", DbType = "Decimal(18,1) NOT NULL")]
        public decimal DarsadHadie_AllMonth
        {
            get
            {
                return this._DarsadHadie_AllMonth;
            }
            set
            {
                if ((this._DarsadHadie_AllMonth != value))
                {
                    this.OnDarsadHadie_AllMonthChanging(value);
                    this.SendPropertyChanging();
                    this._DarsadHadie_AllMonth = value;
                    this.SendPropertyChanged("DarsadHadie_AllMonth");
                    this.OnDarsadHadie_AllMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DarsadHadie_EndMonth", DbType = "Decimal(18,1) NOT NULL")]
        public decimal DarsadHadie_EndMonth
        {
            get
            {
                return this._DarsadHadie_EndMonth;
            }
            set
            {
                if ((this._DarsadHadie_EndMonth != value))
                {
                    this.OnDarsadHadie_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._DarsadHadie_EndMonth = value;
                    this.SendPropertyChanged("DarsadHadie_EndMonth");
                    this.OnDarsadHadie_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghHadie_AllMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghHadie_AllMonth
        {
            get
            {
                return this._MablaghHadie_AllMonth;
            }
            set
            {
                if ((this._MablaghHadie_AllMonth != value))
                {
                    this.OnMablaghHadie_AllMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghHadie_AllMonth = value;
                    this.SendPropertyChanged("MablaghHadie_AllMonth");
                    this.OnMablaghHadie_AllMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghHadie_EndMonth", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghHadie_EndMonth
        {
            get
            {
                return this._MablaghHadie_EndMonth;
            }
            set
            {
                if ((this._MablaghHadie_EndMonth != value))
                {
                    this.OnMablaghHadie_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghHadie_EndMonth = value;
                    this.SendPropertyChanged("MablaghHadie_EndMonth");
                    this.OnMablaghHadie_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MablaghPardakht", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MablaghPardakht
        {
            get
            {
                return this._MablaghPardakht;
            }
            set
            {
                if ((this._MablaghPardakht != value))
                {
                    this.OnMablaghPardakhtChanging(value);
                    this.SendPropertyChanging();
                    this._MablaghPardakht = value;
                    this.SendPropertyChanged("MablaghPardakht");
                    this.OnMablaghPardakhtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsTahvilBeMoshtari", DbType = "Bit")]
        public System.Nullable<bool> IsTahvilBeMoshtari
        {
            get
            {
                return this._IsTahvilBeMoshtari;
            }
            set
            {
                if ((this._IsTahvilBeMoshtari != value))
                {
                    this.OnIsTahvilBeMoshtariChanging(value);
                    this.SendPropertyChanging();
                    this._IsTahvilBeMoshtari = value;
                    this.SendPropertyChanged("IsTahvilBeMoshtari");
                    this.OnIsTahvilBeMoshtariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeTahvilBeMoshtari", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeTahvilBeMoshtari
        {
            get
            {
                return this._DateTimeTahvilBeMoshtari;
            }
            set
            {
                if ((this._DateTimeTahvilBeMoshtari != value))
                {
                    this.OnDateTimeTahvilBeMoshtariChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeTahvilBeMoshtari = value;
                    this.SendPropertyChanged("DateTimeTahvilBeMoshtari");
                    this.OnDateTimeTahvilBeMoshtariChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTahvilBeMoshtari_Fa", DbType = "NVarChar(50)")]
        public string DateTahvilBeMoshtari_Fa
        {
            get
            {
                return this._DateTahvilBeMoshtari_Fa;
            }
            set
            {
                if ((this._DateTahvilBeMoshtari_Fa != value))
                {
                    this.OnDateTahvilBeMoshtari_FaChanging(value);
                    this.SendPropertyChanging();
                    this._DateTahvilBeMoshtari_Fa = value;
                    this.SendPropertyChanged("DateTahvilBeMoshtari_Fa");
                    this.OnDateTahvilBeMoshtari_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeTahvilBeMoshtari_Fa", DbType = "NVarChar(50)")]
        public string TimeTahvilBeMoshtari_Fa
        {
            get
            {
                return this._TimeTahvilBeMoshtari_Fa;
            }
            set
            {
                if ((this._TimeTahvilBeMoshtari_Fa != value))
                {
                    this.OnTimeTahvilBeMoshtari_FaChanging(value);
                    this.SendPropertyChanging();
                    this._TimeTahvilBeMoshtari_Fa = value;
                    this.SendPropertyChanged("TimeTahvilBeMoshtari_Fa");
                    this.OnTimeTahvilBeMoshtari_FaChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_SabadKharidItem", Storage = "_user", ThisKey = "UserAddKonandeID", OtherKey = "UID", IsForeignKey = true)]
        public user user
        {
            get
            {
                return this._user.Entity;
            }
            set
            {
                user previousValue = this._user.Entity;
                if (((previousValue != value)
                            || (this._user.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._user.Entity = null;
                        previousValue.SabadKharidItems.Remove(this);
                    }
                    this._user.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidItems.Add(this);
                        this._UserAddKonandeID = value.UID;
                    }
                    else
                    {
                        this._UserAddKonandeID = default(System.Guid);
                    }
                    this.SendPropertyChanged("user");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_SabadKharidItem", Storage = "_Price", ThisKey = "PriceID", OtherKey = "UID", IsForeignKey = true)]
        public Price Price
        {
            get
            {
                return this._Price.Entity;
            }
            set
            {
                Price previousValue = this._Price.Entity;
                if (((previousValue != value)
                            || (this._Price.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Price.Entity = null;
                        previousValue.SabadKharidItems.Remove(this);
                    }
                    this._Price.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidItems.Add(this);
                        this._PriceID = value.UID;
                    }
                    else
                    {
                        this._PriceID = default(System.Guid);
                    }
                    this.SendPropertyChanged("Price");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_SabadKharidItem", Storage = "_Product", ThisKey = "ProductId", OtherKey = "UID", IsForeignKey = true)]
        public Product Product
        {
            get
            {
                return this._Product.Entity;
            }
            set
            {
                Product previousValue = this._Product.Entity;
                if (((previousValue != value)
                            || (this._Product.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Product.Entity = null;
                        previousValue.SabadKharidItems.Remove(this);
                    }
                    this._Product.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidItems.Add(this);
                        this._ProductId = value.UID;
                    }
                    else
                    {
                        this._ProductId = default(System.Guid);
                    }
                    this.SendPropertyChanged("Product");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "SabadKharid_SabadKharidItem", Storage = "_SabadKharid", ThisKey = "SabadKharidID", OtherKey = "UID", IsForeignKey = true)]
        public SabadKharid SabadKharid
        {
            get
            {
                return this._SabadKharid.Entity;
            }
            set
            {
                SabadKharid previousValue = this._SabadKharid.Entity;
                if (((previousValue != value)
                            || (this._SabadKharid.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._SabadKharid.Entity = null;
                        previousValue.SabadKharidItems.Remove(this);
                    }
                    this._SabadKharid.Entity = value;
                    if ((value != null))
                    {
                        value.SabadKharidItems.Add(this);
                        this._SabadKharidID = value.UID;
                    }
                    else
                    {
                        this._SabadKharidID = default(System.Guid);
                    }
                    this.SendPropertyChanged("SabadKharid");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }



}