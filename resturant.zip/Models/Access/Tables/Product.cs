﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Product")]
    public partial class Product : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Nullable<int> _BrandId;

        private System.Nullable<int> _ProductTypeId;

        private string _Information;

        private string _ImageUrl;

        private bool _IsDeleted;

        private System.Nullable<int> _UnitId;

        private string _Dsc;

        private System.DateTime _DateSabt;

        private bool _IsShowInSite;

        private string _Code;

        private decimal _MojodiCount;

        private System.Nullable<decimal> _Point_Fake;

        private decimal _MaxMojodi;

        private decimal _MinMojodi;

        private decimal _DarsadTakhfif_For_AllMonth;

        private decimal _DarsadTakhfif_For_EndMonth;

        private EntitySet<Mojodi> _Mojodis;

        private EntitySet<Price> _Prices;

        private EntityRef<Brand> _Brand;

        private EntityRef<ProductType> _ProductType;

        private EntityRef<Unit> _Unit;

        private EntitySet<SabadKharidItem> _SabadKharidItems;

        private EntitySet<Point> _Points;

        private EntitySet<NotificationMojodi> _NotificationMojodis;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnBrandIdChanging(System.Nullable<int> value);
        partial void OnBrandIdChanged();
        partial void OnPoint_FakeChanging(System.Nullable<decimal> value);
        partial void OnPoint_FakeChanged();
        partial void OnProductTypeIdChanging(System.Nullable<int> value);
        partial void OnProductTypeIdChanged();
        partial void OnInformationChanging(string value);
        partial void OnInformationChanged();
        partial void OnImageUrlChanging(string value);
        partial void OnImageUrlChanged();
        partial void OnIsDeletedChanging(bool value);
        partial void OnIsDeletedChanged();
        partial void OnUnitIdChanging(System.Nullable<int> value);
        partial void OnUnitIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnDateSabtChanging(System.DateTime value);
        partial void OnDateSabtChanged();
        partial void OnIsShowInSiteChanging(bool value);
        partial void OnIsShowInSiteChanged();
        partial void OnCodeChanging(string value);
        partial void OnCodeChanged();
        partial void OnMojodiCountChanging(decimal value);
        partial void OnMojodiCountChanged();
        partial void OnMaxMojodiChanging(decimal value);
        partial void OnMaxMojodiChanged();
        partial void OnMinMojodiChanging(decimal value);
        partial void OnMinMojodiChanged();
        partial void OnDarsadTakhfif_For_AllMonthChanging(decimal value);
        partial void OnDarsadTakhfif_For_AllMonthChanged();
        partial void OnDarsadTakhfif_For_EndMonthChanging(decimal value);
        partial void OnDarsadTakhfif_For_EndMonthChanged();
        #endregion

        public Product()
        {
            this._NotificationMojodis = new EntitySet<NotificationMojodi>(new Action<NotificationMojodi>(this.attach_NotificationMojodis), new Action<NotificationMojodi>(this.detach_NotificationMojodis));
            this._Points = new EntitySet<Point>(new Action<Point>(this.attach_Points), new Action<Point>(this.detach_Points));
            this._Mojodis = new EntitySet<Mojodi>(new Action<Mojodi>(this.attach_Mojodis), new Action<Mojodi>(this.detach_Mojodis));
            this._Prices = new EntitySet<Price>(new Action<Price>(this.attach_Prices), new Action<Price>(this.detach_Prices));
            this._Brand = default(EntityRef<Brand>);
            this._ProductType = default(EntityRef<ProductType>);
            this._Unit = default(EntityRef<Unit>);
            this._SabadKharidItems = new EntitySet<SabadKharidItem>(new Action<SabadKharidItem>(this.attach_SabadKharidItems), new Action<SabadKharidItem>(this.detach_SabadKharidItems));

            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BrandId", DbType = "Int")]
        public System.Nullable<int> BrandId
        {
            get
            {
                return this._BrandId;
            }
            set
            {
                if ((this._BrandId != value))
                {
                    if (this._Brand.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnBrandIdChanging(value);
                    this.SendPropertyChanging();
                    this._BrandId = value;
                    this.SendPropertyChanged("BrandId");
                    this.OnBrandIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProductTypeId", DbType = "Int")]
        public System.Nullable<int> ProductTypeId
        {
            get
            {
                return this._ProductTypeId;
            }
            set
            {
                if ((this._ProductTypeId != value))
                {
                    if (this._ProductType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnProductTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._ProductTypeId = value;
                    this.SendPropertyChanged("ProductTypeId");
                    this.OnProductTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Information", DbType = "NVarChar(MAX)")]
        public string Information
        {
            get
            {
                return this._Information;
            }
            set
            {
                if ((this._Information != value))
                {
                    this.OnInformationChanging(value);
                    this.SendPropertyChanging();
                    this._Information = value;
                    this.SendPropertyChanged("Information");
                    this.OnInformationChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ImageUrl", DbType = "NVarChar(MAX)")]
        public string ImageUrl
        {
            get
            {
                return this._ImageUrl;
            }
            set
            {
                if ((this._ImageUrl != value))
                {
                    this.OnImageUrlChanging(value);
                    this.SendPropertyChanging();
                    this._ImageUrl = value;
                    this.SendPropertyChanged("ImageUrl");
                    this.OnImageUrlChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted", DbType = "Bit NOT NULL")]
        public bool IsDeleted
        {
            get
            {
                return this._IsDeleted;
            }
            set
            {
                if ((this._IsDeleted != value))
                {
                    this.OnIsDeletedChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted = value;
                    this.SendPropertyChanged("IsDeleted");
                    this.OnIsDeletedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UnitId", DbType = "Int")]
        public System.Nullable<int> UnitId
        {
            get
            {
                return this._UnitId;
            }
            set
            {
                if ((this._UnitId != value))
                {
                    if (this._Unit.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUnitIdChanging(value);
                    this.SendPropertyChanging();
                    this._UnitId = value;
                    this.SendPropertyChanged("UnitId");
                    this.OnUnitIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateSabt", DbType = "DateTime NOT NULL")]
        public System.DateTime DateSabt
        {
            get
            {
                return this._DateSabt;
            }
            set
            {
                if ((this._DateSabt != value))
                {
                    this.OnDateSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateSabt = value;
                    this.SendPropertyChanged("DateSabt");
                    this.OnDateSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsShowInSite", DbType = "Bit NOT NULL")]
        public bool IsShowInSite
        {
            get
            {
                return this._IsShowInSite;
            }
            set
            {
                if ((this._IsShowInSite != value))
                {
                    this.OnIsShowInSiteChanging(value);
                    this.SendPropertyChanging();
                    this._IsShowInSite = value;
                    this.SendPropertyChanged("IsShowInSite");
                    this.OnIsShowInSiteChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Code", DbType = "NVarChar(MAX)")]
        public string Code
        {
            get
            {
                return this._Code;
            }
            set
            {
                if ((this._Code != value))
                {
                    this.OnCodeChanging(value);
                    this.SendPropertyChanging();
                    this._Code = value;
                    this.SendPropertyChanged("Code");
                    this.OnCodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MojodiCount", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MojodiCount
        {
            get
            {
                return this._MojodiCount;
            }
            set
            {
                if ((this._MojodiCount != value))
                {
                    this.OnMojodiCountChanging(value);
                    this.SendPropertyChanging();
                    this._MojodiCount = value;
                    this.SendPropertyChanged("MojodiCount");
                    this.OnMojodiCountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Point_Fake", DbType = "Decimal(18,2)")]
        public System.Nullable<decimal>  Point_Fake
        {
            get
            {
                return this._Point_Fake;
            }
            set
            {
                if ((this._Point_Fake != value))
                {
                    this.OnPoint_FakeChanging(value);
                    this.SendPropertyChanging();
                    this._Point_Fake = value;
                    this.SendPropertyChanged("Point_Fake");
                    this.OnPoint_FakeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MaxMojodi", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MaxMojodi
        {
            get
            {
                return this._MaxMojodi;
            }
            set
            {
                if ((this._MaxMojodi != value))
                {
                    this.OnMaxMojodiChanging(value);
                    this.SendPropertyChanging();
                    this._MaxMojodi = value;
                    this.SendPropertyChanged("MaxMojodi");
                    this.OnMaxMojodiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MinMojodi", DbType = "Decimal(18,0) NOT NULL")]
        public decimal MinMojodi
        {
            get
            {
                return this._MinMojodi;
            }
            set
            {
                if ((this._MinMojodi != value))
                {
                    this.OnMinMojodiChanging(value);
                    this.SendPropertyChanging();
                    this._MinMojodi = value;
                    this.SendPropertyChanged("MinMojodi");
                    this.OnMinMojodiChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DarsadTakhfif_For_AllMonth", DbType = "Decimal(18,1) NOT NULL")]
        public decimal DarsadTakhfif_For_AllMonth
        {
            get
            {
                return this._DarsadTakhfif_For_AllMonth;
            }
            set
            {
                if ((this._DarsadTakhfif_For_AllMonth != value))
                {
                    this.OnDarsadTakhfif_For_AllMonthChanging(value);
                    this.SendPropertyChanging();
                    this._DarsadTakhfif_For_AllMonth = value;
                    this.SendPropertyChanged("DarsadTakhfif_For_AllMonth");
                    this.OnDarsadTakhfif_For_AllMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_NotificationMojodi", Storage = "_NotificationMojodis", ThisKey = "UID", OtherKey = "ProductID")]
        public EntitySet<NotificationMojodi> NotificationMojodis
        {
            get
            {
                return this._NotificationMojodis;
            }
            set
            {
                this._NotificationMojodis.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DarsadTakhfif_For_EndMonth", DbType = "Decimal(18,1) NOT NULL")]
        public decimal DarsadTakhfif_For_EndMonth
        {
            get
            {
                return this._DarsadTakhfif_For_EndMonth;
            }
            set
            {
                if ((this._DarsadTakhfif_For_EndMonth != value))
                {
                    this.OnDarsadTakhfif_For_EndMonthChanging(value);
                    this.SendPropertyChanging();
                    this._DarsadTakhfif_For_EndMonth = value;
                    this.SendPropertyChanged("DarsadTakhfif_For_EndMonth");
                    this.OnDarsadTakhfif_For_EndMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Mojodi", Storage = "_Mojodis", ThisKey = "UID", OtherKey = "ProductId")]
        public EntitySet<Mojodi> Mojodis
        {
            get
            {
                return this._Mojodis;
            }
            set
            {
                this._Mojodis.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Price", Storage = "_Prices", ThisKey = "UID", OtherKey = "ProductId")]
        public EntitySet<Price> Prices
        {
            get
            {
                return this._Prices;
            }
            set
            {
                this._Prices.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Brand_Product", Storage = "_Brand", ThisKey = "BrandId", OtherKey = "Id", IsForeignKey = true)]
        public Brand Brand
        {
            get
            {
                return this._Brand.Entity;
            }
            set
            {
                Brand previousValue = this._Brand.Entity;
                if (((previousValue != value)
                            || (this._Brand.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Brand.Entity = null;
                        previousValue.Products.Remove(this);
                    }
                    this._Brand.Entity = value;
                    if ((value != null))
                    {
                        value.Products.Add(this);
                        this._BrandId = value.Id;
                    }
                    else
                    {
                        this._BrandId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Brand");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "ProductType_Product", Storage = "_ProductType", ThisKey = "ProductTypeId", OtherKey = "Id", IsForeignKey = true)]
        public ProductType ProductType
        {
            get
            {
                return this._ProductType.Entity;
            }
            set
            {
                ProductType previousValue = this._ProductType.Entity;
                if (((previousValue != value)
                            || (this._ProductType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._ProductType.Entity = null;
                        previousValue.Products.Remove(this);
                    }
                    this._ProductType.Entity = value;
                    if ((value != null))
                    {
                        value.Products.Add(this);
                        this._ProductTypeId = value.Id;
                    }
                    else
                    {
                        this._ProductTypeId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("ProductType");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Unit_Product", Storage = "_Unit", ThisKey = "UnitId", OtherKey = "Id", IsForeignKey = true)]
        public Unit Unit
        {
            get
            {
                return this._Unit.Entity;
            }
            set
            {
                Unit previousValue = this._Unit.Entity;
                if (((previousValue != value)
                            || (this._Unit.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Unit.Entity = null;
                        previousValue.Products.Remove(this);
                    }
                    this._Unit.Entity = value;
                    if ((value != null))
                    {
                        value.Products.Add(this);
                        this._UnitId = value.Id;
                    }
                    else
                    {
                        this._UnitId = default(Nullable<int>);
                    }
                    this.SendPropertyChanged("Unit");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_Point", Storage = "_Points", ThisKey = "UID", OtherKey = "ProductID")]
        public EntitySet<Point> Points
        {
            get
            {
                return this._Points;
            }
            set
            {
                this._Points.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Product_SabadKharidItem", Storage = "_SabadKharidItems", ThisKey = "UID", OtherKey = "ProductId")]
        public EntitySet<SabadKharidItem> SabadKharidItems
        {
            get
            {
                return this._SabadKharidItems;
            }
            set
            {
                this._SabadKharidItems.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Mojodis(Mojodi entity)
        {
            this.SendPropertyChanging();
            entity.Product = this;
        }

        private void detach_Mojodis(Mojodi entity)
        {
            this.SendPropertyChanging();
            entity.Product = null;
        }

        private void attach_Prices(Price entity)
        {
            this.SendPropertyChanging();
            entity.Product = this;
        }

        private void detach_Prices(Price entity)
        {
            this.SendPropertyChanging();
            entity.Product = null;
        }

        private void attach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.Product = this;
        }

        private void detach_SabadKharidItems(SabadKharidItem entity)
        {
            this.SendPropertyChanging();
            entity.Product = null;
        }

        private void attach_Points(Point entity)
        {
            this.SendPropertyChanging();
            entity.Product = this;
        }

        private void detach_Points(Point entity)
        {
            this.SendPropertyChanging();
            entity.Product = null;
        }

        private void attach_NotificationMojodis(NotificationMojodi entity)
        {
            this.SendPropertyChanging();
            entity.Product = this;
        }

        private void detach_NotificationMojodis(NotificationMojodi entity)
        {
            this.SendPropertyChanging();
            entity.Product = null;
        }
    }
}