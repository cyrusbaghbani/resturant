﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Notification")]
    public partial class Notification : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _GruopIDs;

        private int _NotificationTypeId;

        private string _Dsc;

        private System.Nullable<System.Guid> _UserId;

        private bool _IsRead;

        private bool _IsDeleted_Customer;

        private bool _IsDeleted_Creater;

        private string _DateRead;

        private string _TimeRead;

        private string _DateCreate;

        private string _TimeCreate;

        private string _Subject;

        private System.Nullable<System.Guid> _Price_UID;

        private EntityRef<Price> _Price;

        private System.Nullable<System.Guid> _UserRead_Id;

        private System.Nullable<System.Guid> _SenderID;

        private EntityRef<user> _SenderNotification;

        private EntityRef<user> _userNotificationsMalek;

        private EntityRef<user> _userReadNotification;

        private EntityRef<NotificationType> _NotificationType;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnGruopIDsChanging(System.Guid value);
        partial void OnGruopIDsChanged();
   
        partial void OnNotificationTypeIdChanging(int value);
        partial void OnNotificationTypeIdChanged();
        partial void OnDscChanging(string value);
        partial void OnDscChanged();
        partial void OnUserIdChanging(System.Nullable<System.Guid> value);
        partial void OnUserIdChanged();
        partial void OnIsReadChanging(bool value);
        partial void OnIsReadChanged();
        partial void OnIsDeleted_CustomerChanging(bool value);
        partial void OnIsDeleted_CustomerChanged();
        partial void OnIsDeleted_CreaterChanging(bool value);
        partial void OnIsDeleted_CreaterChanged();    
        partial void OnDateReadChanging(string value);
        partial void OnDateReadChanged();
        partial void OnTimeReadChanging(string value);
        partial void OnTimeReadChanged();
        partial void OnDateCreateChanging(string value);
        partial void OnDateCreateChanged();
        partial void OnTimeCreateChanging(string value);
        partial void OnTimeCreateChanged();
        partial void OnUserRead_IdChanging(System.Nullable<System.Guid> value);
        partial void OnUserRead_IdChanged();
        partial void OnPrice_UIDChanging(System.Nullable<System.Guid> value);
        partial void OnPrice_UIDChanged();
        partial void OnSubjectChanging(string value);
        partial void OnSubjectChanged();
        partial void OnSenderIDChanging(System.Nullable<System.Guid> value);
        partial void OnSenderIDChanged();
        #endregion

        public Notification()
        {
            this._SenderNotification = default(EntityRef<user>);
            this._Price = default(EntityRef<Price>);
            this._userNotificationsMalek = default(EntityRef<user>);
            this._userReadNotification = default(EntityRef<user>);
            this._NotificationType = default(EntityRef<NotificationType>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_GruopIDs", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid GruopIDs
        {
            get
            {
                return this._GruopIDs;
            }
            set
            {
                if ((this._GruopIDs != value))
                {
                    this.OnGruopIDsChanging(value);
                    this.SendPropertyChanging();
                    this._GruopIDs = value;
                    this.SendPropertyChanged("GruopIDs");
                    this.OnGruopIDsChanged();
                }
            }
        }
        
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NotificationTypeId", DbType = "Int NOT NULL")]
        public int NotificationTypeId
        {
            get
            {
                return this._NotificationTypeId;
            }
            set
            {
                if ((this._NotificationTypeId != value))
                {
                    if (this._NotificationType.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnNotificationTypeIdChanging(value);
                    this.SendPropertyChanging();
                    this._NotificationTypeId = value;
                    this.SendPropertyChanged("NotificationTypeId");
                    this.OnNotificationTypeIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Dsc", DbType = "NVarChar(MAX)")]
        public string Dsc
        {
            get
            {
                return this._Dsc;
            }
            set
            {
                if ((this._Dsc != value))
                {
                    this.OnDscChanging(value);
                    this.SendPropertyChanging();
                    this._Dsc = value;
                    this.SendPropertyChanged("Dsc");
                    this.OnDscChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this._userNotificationsMalek.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }
        
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsRead", DbType = "Bit NOT NULL")]
        public bool IsRead
        {
            get
            {
                return this._IsRead;
            }
            set
            {
                if ((this._IsRead != value))
                {
                    this.OnIsReadChanging(value);
                    this.SendPropertyChanging();
                    this._IsRead = value;
                    this.SendPropertyChanged("IsRead");
                    this.OnIsReadChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted_Customer", DbType = "Bit NOT NULL")]
        public bool IsDeleted_Customer
        {
            get
            {
                return this._IsDeleted_Customer;
            }
            set
            {
                if ((this._IsDeleted_Customer != value))
                {
                    this.OnIsDeleted_CustomerChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted_Customer = value;
                    this.SendPropertyChanged("IsDeleted_Customer");
                    this.OnIsDeleted_CustomerChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsDeleted_Customer", DbType = "Bit NOT NULL")]
        public bool IsDeleted_Creater
        {
            get
            {
                return this._IsDeleted_Creater;
            }
            set
            {
                if ((this._IsDeleted_Creater != value))
                {
                    this.OnIsDeleted_CreaterChanging(value);
                    this.SendPropertyChanging();
                    this._IsDeleted_Creater = value;
                    this.SendPropertyChanged("IsDeleted_Create");
                    this.OnIsDeleted_CreaterChanged();
                }
            }
        }
        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateRead", DbType = "NVarChar(50)")]
        public string DateRead
        {
            get
            {
                return this._DateRead;
            }
            set
            {
                if ((this._DateRead != value))
                {
                    this.OnDateReadChanging(value);
                    this.SendPropertyChanging();
                    this._DateRead = value;
                    this.SendPropertyChanged("DateRead");
                    this.OnDateReadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeRead", DbType = "NVarChar(50)")]
        public string TimeRead
        {
            get
            {
                return this._TimeRead;
            }
            set
            {
                if ((this._TimeRead != value))
                {
                    this.OnTimeReadChanging(value);
                    this.SendPropertyChanging();
                    this._TimeRead = value;
                    this.SendPropertyChanged("TimeRead");
                    this.OnTimeReadChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateCreate", DbType = "NVarChar(50)")]
        public string DateCreate
        {
            get
            {
                return this._DateCreate;
            }
            set
            {
                if ((this._DateCreate != value))
                {
                    this.OnDateCreateChanging(value);
                    this.SendPropertyChanging();
                    this._DateCreate = value;
                    this.SendPropertyChanged("DateCreate");
                    this.OnDateCreateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TimeCreate", DbType = "NVarChar(50)")]
        public string TimeCreate
        {
            get
            {
                return this._TimeCreate;
            }
            set
            {
                if ((this._TimeCreate != value))
                {
                    this.OnTimeCreateChanging(value);
                    this.SendPropertyChanging();
                    this._TimeCreate = value;
                    this.SendPropertyChanged("TimeCreate");
                    this.OnTimeCreateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserRead_Id", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UserRead_Id
        {
            get
            {
                return this._UserRead_Id;
            }
            set
            {
                if ((this._UserRead_Id != value))
                {
                    if (this._userReadNotification.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserRead_IdChanging(value);
                    this.SendPropertyChanging();
                    this._UserRead_Id = value;
                    this.SendPropertyChanged("UserRead_Id");
                    this.OnUserRead_IdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Price_UID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> Price_UID
        {
            get
            {
                return this._Price_UID;
            }
            set
            {
                if ((this._Price_UID != value))
                {
                    if (this._Price.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnPrice_UIDChanging(value);
                    this.SendPropertyChanging();
                    this._Price_UID = value;
                    this.SendPropertyChanged("Price_UID");
                    this.OnPrice_UIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification", Storage = "_userNotificationsMalek", ThisKey = "UserId", OtherKey = "UID", IsForeignKey = true)]
        public user userNotificationsMalek
        {
            get
            {
                return this._userNotificationsMalek.Entity;
            }
            set
            {
                user previousValue = this._userNotificationsMalek.Entity;
                if (((previousValue != value)
                            || (this._userNotificationsMalek.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userNotificationsMalek.Entity = null;
                        previousValue.NotificationsUserMalek.Remove(this);
                    }
                    this._userNotificationsMalek.Entity = value;
                    if ((value != null))
                    {
                        value.NotificationsUserMalek.Add(this);
                        this._UserId = value.UID;
                    }
                    else
                    {
                        this._UserId = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("userNotificationsMalek");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification1", Storage = "_userReadNotification", ThisKey = "UserRead_Id", OtherKey = "UID", IsForeignKey = true)]
        public user userReadNotification
        {
            get
            {
                return this._userReadNotification.Entity;
            }
            set
            {
                user previousValue = this._userReadNotification.Entity;
                if (((previousValue != value)
                            || (this._userReadNotification.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._userReadNotification.Entity = null;
                        previousValue.NotificationsReaduser.Remove(this);
                    }
                    this._userReadNotification.Entity = value;
                    if ((value != null))
                    {
                        value.NotificationsReaduser.Add(this);
                        this._UserRead_Id = value.UID;
                    }
                    else
                    {
                        this._UserRead_Id = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("userReadNotification");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Price_Notification", Storage = "_Price", ThisKey = "Price_UID", OtherKey = "UID", IsForeignKey = true)]
        public Price Price
        {
            get
            {
                return this._Price.Entity;
            }
            set
            {
                Price previousValue = this._Price.Entity;
                if (((previousValue != value)
                            || (this._Price.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Price.Entity = null;
                        previousValue.Notifications.Remove(this);
                    }
                    this._Price.Entity = value;
                    if ((value != null))
                    {
                        value.Notifications.Add(this);
                        this._Price_UID = value.UID;
                    }
                    else
                    {
                        this._Price_UID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("Price");
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Subject", DbType = "NVarChar(MAX)")]
        public string Subject
        {
            get
            {
                return this._Subject;
            }
            set
            {
                if ((this._Subject != value))
                {
                    this.OnSubjectChanging(value);
                    this.SendPropertyChanging();
                    this._Subject = value;
                    this.SendPropertyChanged("Subject");
                    this.OnSubjectChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SenderID", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> SenderID
        {
            get
            {
                return this._SenderID;
            }
            set
            {
                if ((this._SenderID != value))
                {
                    if (this._SenderNotification.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnSenderIDChanging(value);
                    this.SendPropertyChanging();
                    this._SenderID = value;
                    this.SendPropertyChanged("SenderID");
                    this.OnSenderIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Notification1", Storage = "_SenderNotification", ThisKey = "SenderID", OtherKey = "UID", IsForeignKey = true)]
        public user SenderNotification
        {
            get
            {
                return this._SenderNotification.Entity;
            }
            set
            {
                user previousValue = this._SenderNotification.Entity;
                if (((previousValue != value)
                            || (this._SenderNotification.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._SenderNotification.Entity = null;
                        previousValue.NotificationSender.Remove(this);
                    }
                    this._SenderNotification.Entity = value;
                    if ((value != null))
                    {
                        value.NotificationSender.Add(this);
                        this._SenderID = value.UID;
                    }
                    else
                    {
                        this._SenderID = default(Nullable<System.Guid>);
                    }
                    this.SendPropertyChanged("SenderNotification");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "NotificationType_Notification", Storage = "_NotificationType", ThisKey = "NotificationTypeId", OtherKey = "Id", IsForeignKey = true)]
        public NotificationType NotificationType
        {
            get
            {
                return this._NotificationType.Entity;
            }
            set
            {
                NotificationType previousValue = this._NotificationType.Entity;
                if (((previousValue != value)
                            || (this._NotificationType.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._NotificationType.Entity = null;
                        previousValue.Notifications.Remove(this);
                    }
                    this._NotificationType.Entity = value;
                    if ((value != null))
                    {
                        value.Notifications.Add(this);
                        this._NotificationTypeId = value.Id;
                    }
                    else
                    {
                        this._NotificationTypeId = default(int);
                    }
                    this.SendPropertyChanged("NotificationType");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

}