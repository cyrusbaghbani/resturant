﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{
    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Temp")]
    public partial class Temp : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private System.Guid _UID;

        private System.Guid _UserID;

        private string _PAGENAME;

        private System.Nullable<System.Guid> _UIDItems;

        private System.Nullable<int> _IDItems;

        private System.Nullable<System.DateTime> _DateTimeSabt;

        private string _src;

        private string _SessionID;

        private EntityRef<user> _user;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUIDChanging(System.Guid value);
        partial void OnUIDChanged();
        partial void OnUserIDChanging(System.Guid value);
        partial void OnUserIDChanged();
        partial void OnPAGENAMEChanging(string value);
        partial void OnPAGENAMEChanged();
        partial void OnUIDItemsChanging(System.Nullable<System.Guid> value);
        partial void OnUIDItemsChanged();
        partial void OnIDItemsChanging(System.Nullable<int> value);
        partial void OnIDItemsChanged();
        partial void OnDateTimeSabtChanging(System.Nullable<System.DateTime> value);
        partial void OnDateTimeSabtChanged();
        partial void OnsrcChanging(string value);
        partial void OnsrcChanged();     
        partial void OnSessionIDChanging(string value);
        partial void OnSessionIDChanged();
        #endregion

        public Temp()
        {
            this._user = default(EntityRef<user>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UID", DbType = "UniqueIdentifier NOT NULL", IsPrimaryKey = true)]
        public System.Guid UID
        {
            get
            {
                return this._UID;
            }
            set
            {
                if ((this._UID != value))
                {
                    this.OnUIDChanging(value);
                    this.SendPropertyChanging();
                    this._UID = value;
                    this.SendPropertyChanged("UID");
                    this.OnUIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserID", DbType = "UniqueIdentifier NOT NULL")]
        public System.Guid UserID
        {
            get
            {
                return this._UserID;
            }
            set
            {
                if ((this._UserID != value))
                {
                    if (this._user.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIDChanging(value);
                    this.SendPropertyChanging();
                    this._UserID = value;
                    this.SendPropertyChanged("UserID");
                    this.OnUserIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PAGENAME", DbType = "NVarChar(MAX)")]
        public string PAGENAME
        {
            get
            {
                return this._PAGENAME;
            }
            set
            {
                if ((this._PAGENAME != value))
                {
                    this.OnPAGENAMEChanging(value);
                    this.SendPropertyChanging();
                    this._PAGENAME = value;
                    this.SendPropertyChanged("PAGENAME");
                    this.OnPAGENAMEChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UIDItems", DbType = "UniqueIdentifier")]
        public System.Nullable<System.Guid> UIDItems
        {
            get
            {
                return this._UIDItems;
            }
            set
            {
                if ((this._UIDItems != value))
                {
                    this.OnUIDItemsChanging(value);
                    this.SendPropertyChanging();
                    this._UIDItems = value;
                    this.SendPropertyChanged("UIDItems");
                    this.OnUIDItemsChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IDItems", DbType = "Int")]
        public System.Nullable<int> IDItems
        {
            get
            {
                return this._IDItems;
            }
            set
            {
                if ((this._IDItems != value))
                {
                    this.OnIDItemsChanging(value);
                    this.SendPropertyChanging();
                    this._IDItems = value;
                    this.SendPropertyChanged("IDItems");
                    this.OnIDItemsChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_DateTimeSabt", DbType = "DateTime")]
        public System.Nullable<System.DateTime> DateTimeSabt
        {
            get
            {
                return this._DateTimeSabt;
            }
            set
            {
                if ((this._DateTimeSabt != value))
                {
                    this.OnDateTimeSabtChanging(value);
                    this.SendPropertyChanging();
                    this._DateTimeSabt = value;
                    this.SendPropertyChanged("DateTimeSabt");
                    this.OnDateTimeSabtChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_src", DbType = "NVarChar(MAX)")]
        public string src
        {
            get
            {
                return this._src;
            }
            set
            {
                if ((this._src != value))
                {
                    this.OnsrcChanging(value);
                    this.SendPropertyChanging();
                    this._src = value;
                    this.SendPropertyChanged("src");
                    this.OnsrcChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SessionID", DbType = "NVarChar(MAX)")]
        public string SessionID
        {
            get
            {
                return this._SessionID;
            }
            set
            {
                if ((this._SessionID != value))
                {
                    this.OnSessionIDChanging(value);
                    this.SendPropertyChanging();
                    this._SessionID = value;
                    this.SendPropertyChanged("SessionID");
                    this.OnSessionIDChanged();
                }
            }
        }
        

       [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "user_Temp", Storage = "_user", ThisKey = "UserID", OtherKey = "UID", IsForeignKey = true)]
        public user user
        {
            get
            {
                return this._user.Entity;
            }
            set
            {
                user previousValue = this._user.Entity;
                if (((previousValue != value)
                            || (this._user.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._user.Entity = null;
                        previousValue.Temps.Remove(this);
                    }
                    this._user.Entity = value;
                    if ((value != null))
                    {
                        value.Temps.Add(this);
                        this._UserID = value.UID;
                    }
                    else
                    {
                        this._UserID = default(System.Guid);
                    }
                    this.SendPropertyChanged("user");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}