﻿using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System;

namespace restauran.Models.Access.Tables
{

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.ASPStateTempSessions")]
    public partial class ASPStateTempSession : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _SessionId;

        private System.DateTime _Created;

        private System.DateTime _Expires;

        private System.DateTime _LockDate;

        private System.DateTime _LockDateLocal;

        private int _LockCookie;

        private int _Timeout;

        private bool _Locked;

        private System.Data.Linq.Binary _SessionItemShort;

        private System.Data.Linq.Binary _SessionItemLong;

        private int _Flags;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnSessionIdChanging(string value);
        partial void OnSessionIdChanged();
        partial void OnCreatedChanging(System.DateTime value);
        partial void OnCreatedChanged();
        partial void OnExpiresChanging(System.DateTime value);
        partial void OnExpiresChanged();
        partial void OnLockDateChanging(System.DateTime value);
        partial void OnLockDateChanged();
        partial void OnLockDateLocalChanging(System.DateTime value);
        partial void OnLockDateLocalChanged();
        partial void OnLockCookieChanging(int value);
        partial void OnLockCookieChanged();
        partial void OnTimeoutChanging(int value);
        partial void OnTimeoutChanged();
        partial void OnLockedChanging(bool value);
        partial void OnLockedChanged();
        partial void OnSessionItemShortChanging(System.Data.Linq.Binary value);
        partial void OnSessionItemShortChanged();
        partial void OnSessionItemLongChanging(System.Data.Linq.Binary value);
        partial void OnSessionItemLongChanged();
        partial void OnFlagsChanging(int value);
        partial void OnFlagsChanged();
        #endregion

        public ASPStateTempSession()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SessionId", DbType = "NVarChar(88) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string SessionId
        {
            get
            {
                return this._SessionId;
            }
            set
            {
                if ((this._SessionId != value))
                {
                    this.OnSessionIdChanging(value);
                    this.SendPropertyChanging();
                    this._SessionId = value;
                    this.SendPropertyChanged("SessionId");
                    this.OnSessionIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Created", DbType = "DateTime NOT NULL")]
        public System.DateTime Created
        {
            get
            {
                return this._Created;
            }
            set
            {
                if ((this._Created != value))
                {
                    this.OnCreatedChanging(value);
                    this.SendPropertyChanging();
                    this._Created = value;
                    this.SendPropertyChanged("Created");
                    this.OnCreatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Expires", DbType = "DateTime NOT NULL")]
        public System.DateTime Expires
        {
            get
            {
                return this._Expires;
            }
            set
            {
                if ((this._Expires != value))
                {
                    this.OnExpiresChanging(value);
                    this.SendPropertyChanging();
                    this._Expires = value;
                    this.SendPropertyChanged("Expires");
                    this.OnExpiresChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LockDate", DbType = "DateTime NOT NULL")]
        public System.DateTime LockDate
        {
            get
            {
                return this._LockDate;
            }
            set
            {
                if ((this._LockDate != value))
                {
                    this.OnLockDateChanging(value);
                    this.SendPropertyChanging();
                    this._LockDate = value;
                    this.SendPropertyChanged("LockDate");
                    this.OnLockDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LockDateLocal", DbType = "DateTime NOT NULL")]
        public System.DateTime LockDateLocal
        {
            get
            {
                return this._LockDateLocal;
            }
            set
            {
                if ((this._LockDateLocal != value))
                {
                    this.OnLockDateLocalChanging(value);
                    this.SendPropertyChanging();
                    this._LockDateLocal = value;
                    this.SendPropertyChanged("LockDateLocal");
                    this.OnLockDateLocalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LockCookie", DbType = "Int NOT NULL")]
        public int LockCookie
        {
            get
            {
                return this._LockCookie;
            }
            set
            {
                if ((this._LockCookie != value))
                {
                    this.OnLockCookieChanging(value);
                    this.SendPropertyChanging();
                    this._LockCookie = value;
                    this.SendPropertyChanged("LockCookie");
                    this.OnLockCookieChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Timeout", DbType = "Int NOT NULL")]
        public int Timeout
        {
            get
            {
                return this._Timeout;
            }
            set
            {
                if ((this._Timeout != value))
                {
                    this.OnTimeoutChanging(value);
                    this.SendPropertyChanging();
                    this._Timeout = value;
                    this.SendPropertyChanged("Timeout");
                    this.OnTimeoutChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Locked", DbType = "Bit NOT NULL")]
        public bool Locked
        {
            get
            {
                return this._Locked;
            }
            set
            {
                if ((this._Locked != value))
                {
                    this.OnLockedChanging(value);
                    this.SendPropertyChanging();
                    this._Locked = value;
                    this.SendPropertyChanged("Locked");
                    this.OnLockedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SessionItemShort", DbType = "VarBinary(7000)", UpdateCheck = UpdateCheck.Never)]
        public System.Data.Linq.Binary SessionItemShort
        {
            get
            {
                return this._SessionItemShort;
            }
            set
            {
                if ((this._SessionItemShort != value))
                {
                    this.OnSessionItemShortChanging(value);
                    this.SendPropertyChanging();
                    this._SessionItemShort = value;
                    this.SendPropertyChanged("SessionItemShort");
                    this.OnSessionItemShortChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SessionItemLong", DbType = "Image", UpdateCheck = UpdateCheck.Never)]
        public System.Data.Linq.Binary SessionItemLong
        {
            get
            {
                return this._SessionItemLong;
            }
            set
            {
                if ((this._SessionItemLong != value))
                {
                    this.OnSessionItemLongChanging(value);
                    this.SendPropertyChanging();
                    this._SessionItemLong = value;
                    this.SendPropertyChanged("SessionItemLong");
                    this.OnSessionItemLongChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Flags", DbType = "Int NOT NULL")]
        public int Flags
        {
            get
            {
                return this._Flags;
            }
            set
            {
                if ((this._Flags != value))
                {
                    this.OnFlagsChanging(value);
                    this.SendPropertyChanging();
                    this._Flags = value;
                    this.SendPropertyChanged("Flags");
                    this.OnFlagsChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}