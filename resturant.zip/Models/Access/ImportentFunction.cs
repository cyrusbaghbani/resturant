﻿using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace restauran.Models.Access
{
    public static class ImportentFunction
    {
        static List<string> Alphba_Number = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
        public static string GetCodeMoarefi()
        {
            DBDataContext dc = new DBDataContext();
            string Code = "";
            do
            {
                var random = new Random(DateTime.Now.Millisecond);
                Code = "";
                while (Code.Length != 8)
                {
                    int index = random.Next(0, (Alphba_Number.Count() - 1));
                    Code += Alphba_Number[index];
                }
            } while (dc.users.Any(s => s.CODE_MOAREFI != null && s.CODE_MOAREFI == Code));

            return Code;
        }

        public static bool IsDependencyUser(user obj)
        {
            bool result = false;
            if (obj.NotificationsReaduser.Any()
                ||
                obj.NotificationsUserMalek.Any()
                ||
                obj.Child.Any()
                ||
                obj.PaymentsPardakhtKonande.Any()
                ||
                obj.PaymentsAccunt.Any()
                )
                result = true;

            return result;
        }
    }
}