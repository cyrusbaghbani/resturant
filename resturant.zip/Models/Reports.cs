﻿using restauran.Models.Access;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace restauran.Models
{
    public struct STRUCT_REPORT
    {
        public System.IO.MemoryStream MS;
        public string ONVAN;
    }
    public static class Reports
    {

        public static STRUCT_REPORT Factor(string imageurl, HttpServerUtilityBase Server)
        {
            var SabadKharidID_ = Utility.EncryptedQueryString.Decrypt(imageurl);
            DBDataContext dc = new Models.Access.DBDataContext();

            string RptName = "\\FactorA4.mrt";

            var query = from p in dc.SabadKharidItems
                        where
                        p.SabadKharidID.ToString() == SabadKharidID_
                        &&
                        p.SabadKharid.IsDeleted == false
                        &&
                        p.SabadKharid.IsKharid == true
                        select new
                        {
                            onvan = (p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name,
                            count = p.Count + " " + p.Product.Unit.Name,
                            PriceVahed = p.PriceVahed,
                            PriceKol = p.Count * p.PriceVahed,

                        };



            string DatePrint = DateShamsi.GetCurrentDate();
            string TimePrint = DateShamsi.GetCurrentHour();

            Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
            rpt.Load(Server.MapPath("~\\Reports" + RptName));


            var sabad = dc.SabadKharids.FirstOrDefault(s => s.UID.ToString() == SabadKharidID_);
            rpt.Dictionary.Variables["DatePrint"].Value = DatePrint;
            rpt.Dictionary.Variables["TimePrint"].Value = TimePrint;
            rpt.Dictionary.Variables["SabtDate"].Value = sabad == null ? "" : sabad.DateSabtSefareshKharid_Fa;
            rpt.Dictionary.Variables["SabtTime"].Value = sabad == null ? "" : sabad.TimeSabtSefareshKharid_Fa;
            rpt.Dictionary.Variables["CodeRahgiri"].Value = sabad == null ? "" : sabad.CodeRahgiri;
            rpt.Dictionary.Variables["PayGift"].Value = sabad == null ? "0" : (sabad.MablaghPardakhtShodeHadie_AllMonth + sabad.MablaghPardakhtShodeHadie_EndMonth).ToString();
            rpt.Dictionary.Variables["PayPardakhti"].Value = sabad == null ? "0" : (sabad.MablaghGhabelPardakht + sabad.MablaghPardakhtShodeHadieAzKifPolAsli).ToString();
            rpt.Dictionary.Variables["PriceTax"].Value = sabad == null ? "0" : (sabad.MablaghPardakhtMaliat).ToString();
            rpt.Dictionary.Variables["PriceTransport"].Value = sabad == null ? "0" : (sabad.MablaghPardakhtTransport).ToString();


            rpt.RegData("ds", query.ToList());

            rpt.Render();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
            return (new STRUCT_REPORT() { MS = ms, ONVAN = ("Factor" + (sabad == null ? "" : (sabad.CodeRahgiri + "_" + sabad.DateSabtSefareshKharid_Fa)).Replace("/", "") + ".pdf") });
            //rpt.Print(true);
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = "application/pdf";
            //HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
            //HttpContext.Current.Response.BinaryWrite(ms.ToArray());
            //HttpContext.Current.Response.End();
        }

        public static STRUCT_REPORT REPORT_KOL_SEFARESHAT(string datestart, string timestart, string dateend, string timeend, HttpServerUtilityBase Server)
        {

            datestart = DateShamsi.GetShamsiDateString(datestart);
            dateend = DateShamsi.GetShamsiDateString(dateend);
            timestart = DateShamsi.GetShamsiTimeString(timestart + ":00");
            timeend = DateShamsi.GetShamsiTimeString(timeend + ":00");


            DBDataContext dc = new Models.Access.DBDataContext();

            string RptName = "\\Tozie\\Sefaresh.mrt";

            var query = from p in dc.SabadKharidItems
                        join t in dc.SabadKharids on p.SabadKharidID equals t.UID
                        where
                        t.IsDeleted == false
                        &&
                        t.IsKharid == true
                        &&
                        t.DateSabtSefareshKharid_Fa != null
                        &&
                        (
                            datestart == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) > 0
                               ||
                               (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) == 0
                               &&
                                   (
                                    timestart == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timestart) >= 0
                                   )
                               )
                               
                            )
                        )
                         &&
                        (
                            dateend == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(dateend) < 0
                               ||
                               (
                                t.DateSabtSefareshKharid_Fa.CompareTo(dateend) == 0
                                &&
                                   (
                                    timeend == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timeend) < 0                               
                               
                                    )
                                )
                            )
                        )
                        group p by new { p.Price.ProductId, Unit=p.Price.Product.Unit.Name,name= ((p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name) } into g
                        select new
                        {
                            subTitle="کل سفارشات",
                            ID="-",
                            Unit=g.Key.Unit,
                            onvan=g.Key.name.Trim(),
                            count=g.Sum(s=>s.Count),
                        };



            string DatePrint = DateShamsi.GetCurrentDate();
            string TimePrint = DateShamsi.GetCurrentHour();

            Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
            rpt.Load(Server.MapPath("~\\Reports" + RptName));



            rpt.Dictionary.Variables["DatePrint"].Value = DatePrint;
            rpt.Dictionary.Variables["TimePrint"].Value = TimePrint;
            rpt.Dictionary.Variables["Title"].Value = "گزارش کل سفارشات";
            rpt.Dictionary.Variables["StartReportDate"].Value = datestart == "" ? "-" : (datestart+" "+(timestart == "" ? "" : ("["+timestart.Substring(0, 5)+"]")));
            rpt.Dictionary.Variables["EndReportDate"].Value = dateend == "" ? "-" : (dateend+" "+(timeend == "" ? "" : ("[" + timeend.Substring(0, 5) + "]")));  
            
            rpt.RegData("ds", query.OrderBy(s => s.onvan.Trim()).ToList());

            rpt.Render();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
            return (new STRUCT_REPORT() { MS = ms, ONVAN = ("Report" + DateShamsi.GetCurrentDate("-") +"-"+DateShamsi.GetCurrentHour("-") + ".pdf") });
            //rpt.Print(true);
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = "application/pdf";
            //HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
            //HttpContext.Current.Response.BinaryWrite(ms.ToArray());
            //HttpContext.Current.Response.End();
        }

        public static STRUCT_REPORT REPORT_SEFARESHAT_HAR_VISITOR(string datestart, string timestart, string dateend, string timeend, HttpServerUtilityBase Server)
        {
            datestart = DateShamsi.GetShamsiDateString(datestart);
            dateend = DateShamsi.GetShamsiDateString(dateend);
            timestart = DateShamsi.GetShamsiTimeString(timestart + ":00");
            timeend = DateShamsi.GetShamsiTimeString(timeend + ":00");


            DBDataContext dc = new Models.Access.DBDataContext();

            string RptName = "\\Tozie\\Sefaresh.mrt";

            var query = from p in dc.SabadKharidItems
                        join t in dc.SabadKharids on p.SabadKharidID equals t.UID
                        where
                        t.IsDeleted == false
                        &&
                        t.IsKharid == true
                        &&
                        t.DateSabtSefareshKharid_Fa != null
                        &&
                        (
                            datestart == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) > 0
                               ||
                               (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) == 0
                               &&
                                   (
                                    timestart == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timestart) >= 0
                                   )
                               )

                            )
                        )
                         &&
                        (
                            dateend == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(dateend) < 0
                               ||
                               (
                                t.DateSabtSefareshKharid_Fa.CompareTo(dateend) == 0
                                &&
                                   (
                                    timeend == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timeend) < 0

                                    )
                                )
                            )
                        )
                        group p by new { p.Price.ProductId,visitorID=(t.userMoshtari.VisitorUserID==null?Guid.Empty: t.userMoshtari.VisitorUserID),subTitle= (t.userMoshtari.VisitorUserID==null?"بدون ویزیتور": t.userMoshtari.VisitorUser.FullName), Unit = p.Price.Product.Unit.Name, name = ((p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name) } into g
                        select new
                        {
                            subTitle = g.Key.subTitle,
                            ID = g.Key.visitorID.ToString(),
                            Unit = g.Key.Unit,
                            onvan = g.Key.name.Trim(),
                            count = g.Sum(s => s.Count),
                        };



            string DatePrint = DateShamsi.GetCurrentDate();
            string TimePrint = DateShamsi.GetCurrentHour();

            Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
            rpt.Load(Server.MapPath("~\\Reports" + RptName));



            rpt.Dictionary.Variables["DatePrint"].Value = DatePrint;
            rpt.Dictionary.Variables["TimePrint"].Value = TimePrint;
            rpt.Dictionary.Variables["Title"].Value = "گزارش سفارشات هر وزیتور";
            rpt.Dictionary.Variables["StartReportDate"].Value = datestart == "" ? "-" : (datestart + " " + (timestart == "" ? "" : ("[" + timestart.Substring(0, 5) + "]")));
            rpt.Dictionary.Variables["EndReportDate"].Value = dateend == "" ? "-" : (dateend + " " + (timeend == "" ? "" : ("[" + timeend.Substring(0, 5) + "]")));

            rpt.RegData("ds", query.OrderBy(s => s.ID.Trim()==Guid.Empty.ToString()?"-":s.subTitle).ToList());

            rpt.Render();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
            return (new STRUCT_REPORT() { MS = ms, ONVAN = ("Report" + DateShamsi.GetCurrentDate("-") + "-" + DateShamsi.GetCurrentHour("-") + ".pdf") });
            //rpt.Print(true);
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = "application/pdf";
            //HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
            //HttpContext.Current.Response.BinaryWrite(ms.ToArray());
            //HttpContext.Current.Response.End();
        }

        public static STRUCT_REPORT REPORT_SEFARESHAT_HAR_TOZIEKONANDE(string datestart, string timestart, string dateend, string timeend, HttpServerUtilityBase Server)
        {
            datestart = DateShamsi.GetShamsiDateString(datestart);
            dateend = DateShamsi.GetShamsiDateString(dateend);
            timestart = DateShamsi.GetShamsiTimeString(timestart + ":00");
            timeend = DateShamsi.GetShamsiTimeString(timeend + ":00");


            DBDataContext dc = new Models.Access.DBDataContext();

            string RptName = "\\Tozie\\Sefaresh.mrt";

            var query = from p in dc.SabadKharidItems
                        join t in dc.SabadKharids on p.SabadKharidID equals t.UID
                        where
                        t.IsDeleted == false
                        &&
                        t.IsKharid == true
                        &&
                        t.DateSabtSefareshKharid_Fa != null
                        &&
                        (
                            datestart == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) > 0
                               ||
                               (
                               t.DateSabtSefareshKharid_Fa.CompareTo(datestart) == 0
                               &&
                                   (
                                    timestart == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timestart) >= 0
                                   )
                               )

                            )
                        )
                         &&
                        (
                            dateend == ""
                            ||
                            (
                               t.DateSabtSefareshKharid_Fa.CompareTo(dateend) < 0
                               ||
                               (
                                t.DateSabtSefareshKharid_Fa.CompareTo(dateend) == 0
                                &&
                                   (
                                    timeend == ""
                                    ||
                                    t.TimeSabtSefareshKharid_Fa.CompareTo(timeend) < 0

                                    )
                                )
                            )
                        )
                        group p by new { p.Price.ProductId, TahvilDahandeID = (t.UserTahvilDahandeID == null ? Guid.Empty : t.UserTahvilDahandeID), subTitle = (t.UserTahvilDahandeID == null ? "بدون توزیع کننده" : t.userTahvilDahande.FullName), Unit = p.Price.Product.Unit.Name, name = ((p.Product.ProductType.Parent.IsShowName ? p.Product.ProductType.Parent.Name : "") + " " + p.Product.ProductType.Name + " " + p.Product.Brand.Name) } into g
                        select new
                        {
                            subTitle = g.Key.subTitle,
                            ID = g.Key.TahvilDahandeID.ToString(),
                            Unit = g.Key.Unit,
                            onvan = g.Key.name.Trim(),
                            count = g.Sum(s => s.Count),
                        };



            string DatePrint = DateShamsi.GetCurrentDate();
            string TimePrint = DateShamsi.GetCurrentHour();

            Stimulsoft.Report.StiReport rpt = new Stimulsoft.Report.StiReport();
            rpt.Load(Server.MapPath("~\\Reports" + RptName));



            rpt.Dictionary.Variables["DatePrint"].Value = DatePrint;
            rpt.Dictionary.Variables["TimePrint"].Value = TimePrint;
            rpt.Dictionary.Variables["Title"].Value = "گزارش سفارشات هر توزیع کننده";
            rpt.Dictionary.Variables["StartReportDate"].Value = datestart == "" ? "-" : (datestart + " " + (timestart == "" ? "" : ("[" + timestart.Substring(0, 5) + "]")));
            rpt.Dictionary.Variables["EndReportDate"].Value = dateend == "" ? "-" : (dateend + " " + (timeend == "" ? "" : ("[" + timeend.Substring(0, 5) + "]")));

            rpt.RegData("ds", query.OrderBy(s =>  s.subTitle).ToList());

            rpt.Render();
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            rpt.ExportDocument(Stimulsoft.Report.StiExportFormat.Pdf, ms);
            return (new STRUCT_REPORT() { MS = ms, ONVAN = ("Report" + DateShamsi.GetCurrentDate("-") + "-" + DateShamsi.GetCurrentHour("-") + ".pdf") });
            //rpt.Print(true);
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = "application/pdf";
            //HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=Report." + "pdf");
            //HttpContext.Current.Response.BinaryWrite(ms.ToArray());
            //HttpContext.Current.Response.End();
        }
    }
}