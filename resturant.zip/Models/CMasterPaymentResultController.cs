﻿using App_Start.Utility;
using Models.Controll;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.IO;
using Utility;


public class CMasterPaymentResultController : Controller
{
    protected DBDataContext dc = new DBDataContext();
    protected user CurrentUser;
    protected string CurrentDate
    {
        get
        {
            return DateShamsi.GetCurrentDate();
        }
    }
    protected Guid? USERID
    {
        get
        {
            try
            {
                return Session["USERID"] == null ? (Guid?)null : (Guid)Session["USERID"];
            }
            catch { return null; }
        }
    }

    protected string LotteryPath = "/Attachment/Lottary/";
    protected string AdvertisingPath = "/Attachment/Advertising/";

    protected Guid CurrentSabadKharidID
    {
        get
        {
            try
            {
                return Session["CurrentSabadKharidID"] == null ? Guid.Empty : (Guid)Session["CurrentSabadKharidID"];
            }
            catch { return Guid.Empty; }
        }
        set
        {
            Session["CurrentSabadKharidID"] = value;
        }
    }

    protected SabadKharid CurrentSabadKharid
    {
        get
        {
            try
            {
                return dc.SabadKharids.FirstOrDefault(s => s.UID == CurrentSabadKharidID);
            }
            catch { return null; }
        }

    }

    protected string OldPageIndex
    {
        get
        {
            if (Request.Cookies["Searchuasers"] != null && Request.Cookies["Searchuasers"]["PageIndex"] != null)
            {

                return Request.Cookies["Searchuasers"]["PageIndex"];
            }

            return "";
        }
        set
        {
            Response.Cookies["Searchuasers"]["PageIndex"] = value.ToString();
        }
    }
    protected string FieldCboProductType
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["FieldCboProductType"] != null)
            {

                return Request.Cookies["SearchCookie"]["FieldCboProductType"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["FieldCboProductType"] = value.ToString();
        }
    }
    protected string FieldCboBrandValue
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["FieldCboBrandValue"] != null)
            {

                return Request.Cookies["SearchCookie"]["FieldCboBrandValue"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["FieldCboBrandValue"] = value.ToString();
        }
    }
    protected string FieldFullName
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["FieldFullName"] != null)
            {

                return Request.Cookies["SearchCookie"]["FieldFullName"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["FieldFullName"] = value.ToString();
        }
    }
    protected string FieldMobileNumber
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["FieldMobileNumber"] != null)
            {

                return Request.Cookies["SearchCookie"]["FieldMobileNumber"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["FieldMobileNumber"] = value.ToString();
        }
    }
    protected string FieldtxtOnvan
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["FieldtxtOnvan"] != null)
            {

                return Request.Cookies["SearchCookie"]["FieldtxtOnvan"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["FieldtxtOnvan"] = value.ToString();
        }
    }
    protected string FieldDATETA
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["DATETA"] != null)
            {

                return Request.Cookies["SearchCookie"]["DATETA"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["DATETA"] = value.ToString();
        }
    }
    protected string FieldDATEAZ
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["DATEAZ"] != null)
            {

                return Request.Cookies["SearchCookie"]["DATEAZ"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["DATEAZ"] = value.ToString();
        }
    }
    protected string Fieldhfvalue
    {
        get
        {
            if (Request.Cookies["SearchCookie"] != null && Request.Cookies["SearchCookie"]["hfvalue"] != null)
            {

                return Request.Cookies["SearchCookie"]["hfvalue"];
            }

            return "";
        }
        set
        {
            Response.Cookies["SearchCookie"]["hfvalue"] = value.ToString();
        }
    }



    private bool Security()
    {
        try
        {
            CurrentUser = dc.users.SingleOrDefault(s => s.UID == USERID && s.IsActive == true && s.IsDeleted == false);
        }
        catch
        {
            CurrentUser = null;
        }
        if (CurrentUser == null || CurrentUser.Role.IsMenagment)
        {
            Response.Redirect("~/Login/Login");
            return false;
        }
        return true;
    }
    private void LoadMaster()
    {
        ViewBag.FullName_User = CurrentUser.FullName;
    }
    public ActionResult GoToPage(string Action, string Controller, string Parametr = "")
    {
        return RedirectToAction(EmoNetUtility.GetEncodedQueryString(Action, Parametr), Controller);
    }
    public ActionResult GOLOGIN()
    {
        return RedirectToAction("Login", "Login");
    }

    // GET: Security
    protected override void OnActionExecuting(ActionExecutingContext filterContext)
    {
        if (!Security())
        {
            return;
        }
        LoadMaster();
        // Do whatever here...
    }
    public ActionResult EXIT()
    {
        EventLog.Loging(" خروج کاربر از سامانه", EventTypeIds.khorojAzSystem, "CMANEGMENT", CurrentUser.UID);
        Session.Remove("USERID");
        return RedirectToAction("Login", "Login");
    }
    //[HttpPost]
    //public JsonResult SearchCustomers(string Value, string PageIndex)
    //{


    //    DBDataContext dc = new DBDataContext();

    //    var q = (from p in dc.Costomers
    //             where
    //             p.IsDelete == false
    //             &&
    //            (
    //            Value == ""
    //            ||
    //            p.FullName.Contains(Value)
    //            ||
    //            ("0" + p.Mobile).Contains(Value)

    //            )
    //             select new
    //             {
    //                 p.Id,
    //                 p.FullName,
    //                 p.Mobile
    //             }).OrderBy(s => s.FullName).ToList();



    //    GridPageNumber GridPaging = new Models.Controll.GridPageNumber();
    //    GridPaging.lst_headerName.Add("نام و نام خانوادگی");
    //    GridPaging.lst_headerName.Add("شماره همراه");
    //    GridPaging.lst_headerName.Add("انتخاب");

    //    GridPaging.Columns = 4;
    //    GridPaging.RowRecord = 7;
    //    GridPaging.CountAllRecord = q.Count();
    //    GridPaging.currentPage = GridPaging.SetcountGrid(int.Parse("0" + PageIndex));
    //    GridPaging.IsShowPageNumbering = GridPaging.CountAllRecord > GridPaging.RowRecord;
    //    GridPaging.maxPageNumber = GridPaging.CountAllRecord % GridPaging.RowRecord == 0 ? ((GridPaging.CountAllRecord / GridPaging.RowRecord)) : ((GridPaging.CountAllRecord / GridPaging.RowRecord) + 1);
    //    GridPaging.RowRecord = GridPaging.IsShowPageNumbering ? GridPaging.RowRecord : 0;
    //    var list = GridPaging.IsShowPageNumbering ? q.Skip(GridPaging.currentPage * GridPaging.RowRecord).Take(GridPaging.RowRecord).ToList() : q.ToList();

    //    string str = GridPaging.GetHtmlHeader() + " <tbody> <tr> <td data-title=\"\" style=\"font-size:20px\"  colspan=\"" + GridPaging.Columns + "\" > هیچ رکوردی یافت نشد. </td>  </tr> </tbody> ";

    //    if (list.Any())
    //    {
    //        str = GridPaging.GetHtmlHeader() + " <tbody> ";
    //        int linnumbere = GridPaging.StartLineNumber - 1;
    //        foreach (var p in list)
    //        {
    //            str += " <tr> "
    //                + " <td data-title=\"ردیف\" align=\"center\"> " + (++linnumbere).ToString() + " </td> "
    //                     + " <td data-title=\"نام و نام خانوادگی\"> " + p.FullName + " </td> "
    //                     + " <td class=\"numeric\" data-title=\"شماره همراه\"> " + "0" + (p.Mobile) + " </td> "

    //                     + " <td data-title=\"\"  > "
    //                     + "     <div onclick=\"Select_customer('" + EncryptedQueryString.Encrypt(p.Id.ToString()) + "','" + p.FullName + "'); return false;\" class=\"fa fa-square-o \" style=\"font-size: 20px; font-weight: bold; color: red; cursor: pointer;\"> "
    //                     + "         <span class=\"Farsi_\" style=\"font-size: 18px; font-weight: bold; color: red; cursor: pointer;\">انتخاب</span> "
    //                     + "     </div> "
    //                     + " </td>     </tr> ";
    //        }
    //        str += " </tbody> ";
    //        str += GetTableSearchCustomerFooter(GridPaging);
    //    }

    //    return Json(str);
    //}
    //private string GetTableSearchCustomerFooter(GridPageNumber GridPaging)
    //{
    //    string strhtml = "";
    //    if (GridPaging.IsShowPageNumbering)
    //    {
    //        strhtml += " <tr style=\"background-color: #cbd1c2; border: 1px solid #a9a9a9\"> ";

    //        strhtml += "  <td style=\"right:0;padding-right:5px;font-size:16px\" colspan=\"" + GridPaging.Columns.ToString() + "\" > ";
    //        if (GridPaging.currentPage >= GridPaging.PageNumber)
    //        {

    //            strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
    //            strhtml += " name=\"pageIndex\" type=\"submit\"  onclick=\"Search('" + (GridPaging.StartPageNumber - 1) + "');return false;\" value =\"" + (GridPaging.StartPageNumber - 1) + "\" > ";
    //            strhtml += " " + GridPaging.Prview + " ";
    //            strhtml += " </button> ";
    //        }

    //        for (int i = GridPaging.StartPageNumber; i < (GridPaging.EndPageNumber); i++)
    //        {
    //            if (i == GridPaging.currentPage)
    //            {

    //                strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
    //                strhtml += "name= \"pageIndex\"  onclick=\"Search('" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
    //                strhtml += " " + (i + 1) + " ";
    //                strhtml += " </button> ";
    //            }
    //            else
    //            {
    //                strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
    //                strhtml += " name=\"pageIndex\"  onclick=\"Search('" + (i) + "');return false;\"  type=\"submit\" value=" + (i) + " > ";
    //                strhtml += " " + (i + 1) + " ";
    //                strhtml += " </button> ";
    //            }
    //        }

    //        if (((GridPaging.maxPageNumber - 1) / GridPaging.PageNumber) > ((GridPaging.currentPage) / GridPaging.PageNumber))
    //        {
    //            strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex\" ";
    //            strhtml += " type=\"submit\" onclick=\"Search('" + GridPaging.EndPageNumber + "');return false;\" value=\"" + GridPaging.EndPageNumber + "\" > ";
    //            strhtml += " " + GridPaging.Next + " ";
    //            strhtml += " </button> ";

    //        }

    //        strhtml += "  </td> ";

    //        strhtml += " </tr> ";

    //    }

    //    return strhtml;
    //}

    ///// <summary>
    ///// برای انتخاب مشتری ها از طریق اس ام اس
    ///// مشتری ها بر اساس خدماتی که انجام می دهنده دسته بندی شده و در لیست ما نمایش داده می شوند
    ///// هر خدمت می تواند بیش از یک مشتری داشته باشد
    ///// </summary>
    ///// <param name="Value"></param>
    ///// <returns></returns>
    //[HttpPost]
    //public JsonResult SearchRecivers(string Value)
    //{
    //    string str = "";
    //    dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
    //    List<CheckboxListItems> list_checkbox = new List<CheckboxListItems>();
    //    var q = (from p in dc.NobatTypes
    //             where
    //             p.IsDeleted == false
    //             &&
    //             p.Nobat.IsDeleted == false
    //             &&
    //             p.Nobat.Costomer.IsDelete == false
    //             &&
    //            (
    //            Value == ""
    //            ||
    //            p.Nobat.Costomer.FullName.Contains(Value)
    //            ||
    //            ("0" + p.Nobat.Costomer.Mobile).Contains(Value)

    //            )
    //             select new
    //             {
    //                 p.Nobat.Costomer.Id,
    //                 fullname = p.Nobat.Costomer.FullName,
    //                 ServiceTypeId = p.ServiceTypeId,
    //                 ServiceTypeName = p.ServiceType.Name,
    //                 p.ServiceType.ParentId,
    //                 parentname = p.ServiceType.ParentId == null ? "-" : p.ServiceType.ServiceTypeParent.Name,
    //                 p.ServiceType.ServiceTypeParent.Name,
    //             }).OrderBy(s => s.fullname).ToList();



    //    var list_ParentName = q.Select(s => new { s.ParentId, s.parentname }).Distinct().OrderBy(s => s.parentname).ToList();
    //    foreach (var item in list_ParentName)
    //    {
    //        CheckboxListItems root = new CheckboxListItems() { id = item.parentname, label = item.parentname, checked_ = false };
    //        root.children.AddRange(q.Where(s => s.ParentId == item.ParentId).Select(s => new item_CheckboxListItems { id = (EncryptedQueryString.Encrypt(s.Id.ToString())), label = s.fullname, checked_ = false }).Distinct().OrderBy(s => s.label));
    //        list_checkbox.Add(root);
    //    }


    //    //str = "  {item: {id: 'id1', abel: 'Lorem ipsum dolor 1', checked: false},       "
    //    //+ "          children: [{                                       "
    //    //+ "              item: {                                        "
    //    //+ "                  id: 'id11',                                "
    //    //+ "                  label: 'Lorem ipsum dolor 11',             "
    //    //+ "                  checked: false                             "
    //    //+ "              }                                              "
    //    //+ "          }, {                                               "
    //    //+ "              item: {                                        "
    //    //+ "                  id: 'id12',                                "
    //    //+ "                  label: 'Lorem ipsum dolor 12',             "
    //    //+ "                  checked: false                             "
    //    //+ "              }                                              "
    //    //+ "          }, {                                               "
    //    //+ "              item: {                                        "
    //    //+ "                  id: 'id13',                                "
    //    //+ "                  label: 'Lorem ipsum dolor 13',             "
    //    //+ "                  checked: false                             "
    //    //+ "              }                                              "
    //    //+ "          }]                                                 "
    //    //+ "      }                                                      ";

    //    return Json(list_checkbox);
    //}


    #region Delete TEMP FILES

    public void DeleteTempFiles(Guid? UserUID, Guid? ItemUID, int? ItemID, string PageName, string sessenID)
    {
        DBDataContext dc = new DBDataContext();
        var q = from p in dc.Temps
                where
                (UserUID == null || p.UserID == USERID)
                &&
                (ItemID == null || p.UIDItems == ItemUID)
                &&
                (ItemID == null || p.IDItems == ItemID)
                &&
                (PageName == null || PageName.Trim() == "" || p.PAGENAME == PageName)
                &&
                (sessenID == null || sessenID.Trim() == "" || p.SessionID == sessenID)
                select p;

        foreach (var p in q)
        {
            try
            {
                string path = Server.MapPath(p.src);
                if (System.IO.File.Exists(path))
                {
                    System.IO.File.Delete(path);
                }
                dc.Temps.DeleteOnSubmit(p);
            }
            catch { }
        }
        dc.SubmitChanges();
    }

    #endregion


}
