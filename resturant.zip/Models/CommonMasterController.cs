﻿using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;

public class CommonMasterController : Controller
{
    // GET: CommonMaster
    protected DBDataContext dc = new DBDataContext();
    protected user CurrentUser;
    protected string CurrentDate
    {
        get
        {
            return DateShamsi.GetCurrentDate();
        }
    }
    protected Guid? USERID
    {
        get
        {
            try
            {
                return Session["USERID"] == null ? (Guid?)null : (Guid)Session["USERID"];
            }
            catch { return null; }
        }
    }

    protected string LotteryPath = "/Attachment/Lottary/";
    protected string AdvertisingPath = "/Attachment/Advertising/";


    protected bool Security_IsUser()
    {
        try
        {
            CurrentUser = dc.users.SingleOrDefault(s => s.UID == USERID && s.IsActive == true && s.IsDeleted == false);
        }
        catch
        {
            CurrentUser = null;
        }
        if (CurrentUser == null)
        {

            return false;
        }
        return true;
    }
    protected bool Security_IsManagment()
    {
        try
        {
            CurrentUser = dc.users.SingleOrDefault(s => s.UID == USERID && s.IsActive == true && s.IsDeleted == false);
        }
        catch
        {
            CurrentUser = null;
        }
        if (CurrentUser == null || CurrentUser.Role.IsMenagment == false)
        {

            return false;
        }
        return true;
    }



}

