﻿using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace restauran.Models
{
    public class MasterPageModel
    {
        protected DBDataContext dc;
        protected user CurrentUser;
        public Messaging DisplayMessage;
        public Security security;
        public string FullName_Master;
        public string TodayDate_Master;
        public string LotteryPath = "/Attachment/Lottary/";
        protected string AdvertisingPath = "/Attachment/Advertising/";


        public int SabadKharidDarHalTozihCount = 0;
        public int SabadKharidBarrasiNashodeCount = 0;
        public int BirthDayCustomerTodayCount = 0;
        public int CountMinProduct = 0;

        public void Intialize(user currentUser, string pageNum)
        {
            security = new Security(currentUser, pageNum);
            DisplayMessage = new Messaging();
            CurrentUser = currentUser;
            LoadValueOfMaster(currentUser);
        }

        private void LoadValueOfMaster(user currentUser)
        {
            dc = new DBDataContext();
            if (currentUser != null)
                FullName_Master = currentUser.FullName;
            TodayDate_Master = DateShamsi.GetCurrentDate();

            CalculateSabadKharid();
            CalculateBirthdayOfCustomers();
            CountMinProducts();
        }

        private void CalculateBirthdayOfCustomers()
        {
            string birthdate = "/" + TodayDate_Master.Split('/')[1] + "/" + TodayDate_Master.Split('/')[2];
            BirthDayCustomerTodayCount = dc.users.Count(s => s.IsDeleted == false && s.Role.IsMenagment == false && s.Role.IsShow == true && s.BirthDate != null && s.BirthDate != "" && s.BirthDate.Contains(birthdate));
        }

        private void CalculateSabadKharid()
        {
            SabadKharidDarHalTozihCount = (from p in dc.SabadKharids
                                           where
                                           p.IsDeleted == false
                                           &&
                                           p.IsKharid == true
                                           &&
                                           p.IsTahvilBeMoshtari == false
                                           &&
                                           p.IsTaiedBarrasi == true
                                           &&
                                           p.UserTahvilDahandeID != null
                                           &&
                                           p.UserTahvilDahandeID != Guid.Empty
                                           &&
                                           (
                                               (CurrentUser.RoleId != RoleIds.M_ToziKonande && CurrentUser.RoleId != RoleIds.M_Visitor)
                                               ||
                                               (CurrentUser.RoleId == RoleIds.M_ToziKonande && p.UserTahvilDahandeID == CurrentUser.UID)
                                               ||
                                               (CurrentUser.RoleId == RoleIds.M_Visitor && p.userMoshtari.VisitorUserID == CurrentUser.UID)
                                           )
                                           select p.UID).Count();


            SabadKharidBarrasiNashodeCount = (from p in dc.SabadKharids
                                              where
                                              p.IsDeleted == false
                                              &&
                                              p.IsKharid == true
                                              &&
                                              p.IsTahvilBeMoshtari == false
                                              &&
                                              p.IsTaiedBarrasi == false

                                              &&
                                              (
                                                  (CurrentUser.RoleId != RoleIds.M_ToziKonande && CurrentUser.RoleId != RoleIds.M_Visitor)
                                                  ||
                                                  (CurrentUser.RoleId == RoleIds.M_Visitor && p.userMoshtari.VisitorUserID == CurrentUser.UID)
                                              )
                                              select p.UID).Count();
        }

        private void CountMinProducts()
        {
            CountMinProduct = (from p in dc.Products
                               where
                               p.IsDeleted == false
                               &&
                               p.IsShowInSite == true
                               &&
                               (
                               p.MojodiCount <= p.MinMojodi
                               ||
                               (p.MojodiCount - (p.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)) ? p.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)).Sum(s => s.Count) : 0
                               )) <= p.MinMojodi
                               )
                               select p.UID).Distinct().Count();
        }
    }
}