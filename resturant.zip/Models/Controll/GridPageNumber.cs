﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models.Controll
{
    public class GridPageNumber
    {
        public int Columns = 0;
        public int currentPage = 0;
        public int maxPageNumber = 0;
        public bool IsShowPageNumbering;
        public int CountAllRecord;
        public int RowRecord = 20;
        public string Next = ">>";
        public string Prview = "<<";
        public int PageNumber = 7;
        public string pageIndex = "0";
        public string name = "";
        public GridPageNumber(string Name)
        {
            name = Name;
        }
        public GridPageNumber()
        {

        }
        public List<string> lst_headerName = new List<string>();

        public int StartLineNumber
        {
            get
            {
                return (currentPage * RowRecord) + 1;
            }
        }
        public int StartPageNumber
        {
            get
            {
                return currentPage % PageNumber == 0 ? currentPage : ((currentPage / PageNumber) * PageNumber);
            }
        }
        public int EndPageNumber
        {
            get
            {
                return StartPageNumber + PageNumber > maxPageNumber ? (maxPageNumber) : (StartPageNumber + PageNumber);
            }
        }
        public int SetcountGrid(int currentPageIndex)
        {
            if (currentPageIndex == 0 || ((currentPageIndex * RowRecord) < CountAllRecord))
            {
                return currentPageIndex;
            }

            else if ((currentPageIndex * RowRecord) > CountAllRecord)
            {
                return CountAllRecord / RowRecord;
            }
            else if ((currentPageIndex * RowRecord) == CountAllRecord)
            {
                int tmp = (CountAllRecord / RowRecord) - 1;
                return tmp > 0 ? tmp : 0;
            }

            return currentPageIndex;
        }

        public int SkypeItem()
        {
            return currentPage * RowRecord;
        }

        public void GridLoad()
        {
            currentPage = SetcountGrid((int.TryParse("0" + pageIndex, out currentPage) ? currentPage : 0));
            IsShowPageNumbering = CountAllRecord > RowRecord;
            maxPageNumber = CountAllRecord % RowRecord == 0 ? ((CountAllRecord / RowRecord)) : ((CountAllRecord / RowRecord) + 1);
            RowRecord = IsShowPageNumbering ? RowRecord : 0;
        }

        public string GetHtmlFooter(string UseJavascriptFunctionName="")
        {
            string strhtml = "";
            if (IsShowPageNumbering)
            {
                strhtml += " <tr style=\"background-color: #cbd1c2; border: 1px solid #a9a9a9;direction:rtl\"> ";

                strhtml += "  <td style=\"text-align: right;right:0;padding-right:5px;font-size:16px\" colspan=\"" + Columns.ToString() + "\" > ";
                if (currentPage >= PageNumber)
                {
                    if (UseJavascriptFunctionName != "")
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
                        strhtml += " name=\"pageIndex" + name + "\" onclick=\""+ UseJavascriptFunctionName + "('"+ (StartPageNumber - 1) + "')" + "; return false;\" type=\"submit\" value =\"" + (StartPageNumber - 1) + "\" > ";
                        strhtml += " " + Prview + " ";
                        strhtml += " </button> ";
                    }
                    else
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\"";
                        strhtml += " name=\"pageIndex" + name + "\" onclick=\"ShowProgress();\" type=\"submit\" value =\"" + (StartPageNumber - 1) + "\" > ";
                        strhtml += " " + Prview + " ";
                        strhtml += " </button> ";
                    }
                }

                for (int i = StartPageNumber; i < (EndPageNumber); i++)
                {
                   
                   if (i == currentPage)
                    {
                        if (UseJavascriptFunctionName != "")
                        {
                            strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
                            strhtml += "name= \"pageIndex" + name + "\" onclick=\"" + UseJavascriptFunctionName + "('" + (i) + "')" + "; return false;\"  type=\"submit\" value=" + (i) + " > ";
                            strhtml += " " + (i + 1) + " ";
                            strhtml += " </button> ";
                        }
                        else
                        {
                            strhtml += " <button style=\"font -size:18px;font-weight:bold;cursor:pointer;border:0px;background-color:transparent\" ";
                            strhtml += "name= \"pageIndex" + name + "\" onclick=\"ShowProgress();\"  type=\"submit\" value=" + (i) + " > ";
                            strhtml += " " + (i + 1) + " ";
                            strhtml += " </button> ";
                        }
                    }
                    else
                    {
                        if (UseJavascriptFunctionName != "")
                        {
                            strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
                            strhtml += " name=\"pageIndex" + name + "\" onclick=\"" + UseJavascriptFunctionName + "('" + (i) + "')" + "; return false;\"  type=\"submit\" value=" + (i) + " > ";
                            strhtml += " " + (i + 1) + " ";
                            strhtml += " </button> ";
                        }
                        else
                        {
                            strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" ";
                            strhtml += " name=\"pageIndex" + name + "\" onclick=\"ShowProgress();\"  type=\"submit\" value=" + (i) + " > ";
                            strhtml += " " + (i + 1) + " ";
                            strhtml += " </button> ";
                        }
                    }
                }

                if (((maxPageNumber - 1) / PageNumber) > ((currentPage) / PageNumber))
                {
                    if (UseJavascriptFunctionName != "")
                    {

                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex" + name + "\" ";
                        strhtml += " type=\"submit\" onclick=\"" + UseJavascriptFunctionName + "('" + (EndPageNumber) + "')" + "; return false;\"  value=\"" + EndPageNumber + "\" > ";
                        strhtml += " " + Next + " ";
                        strhtml += " </button> ";
                    }
                    else
                    {
                        strhtml += " <button style=\"cursor:pointer;border:0px;background-color:transparent\" name=\"pageIndex" + name + "\" ";
                        strhtml += " type=\"submit\" onclick=\"ShowProgress();\"  value=\"" + EndPageNumber + "\" > ";
                        strhtml += " " + Next + " ";
                        strhtml += " </button> ";
                    }

                }

                strhtml += "  </td> ";

                strhtml += " </tr> ";

            }
            strhtml += " <input type = \"hidden\" name=\"hfCurrentPageIndex" + name + "\" value=\"" + currentPage + "\" /> ";
            return strhtml;
        }
        public string GetHtmlHeader(bool HasRadif = true)
        {
            string html = " <thead class=\"cf\" style=\"background-color: #B01624; border: 1px solid #a9a9a9;color:white;\"> ";

            html += " <tr> ";
            if (HasRadif)
                html += " <th style=\"text-align: center\">ردیف</th> ";
            foreach (var str in lst_headerName)
                html += " <th style=\"text-align: center\">" + str + "</th> ";

            html += " </tr> ";
            html += " </thead> ";

            return html;

        }
    }
}