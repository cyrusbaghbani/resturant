﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace restauran.Models.Controll
{
    public class BackupControll
    {
        public string Date="";
        public string Time = "";
        public string Length = "";
        public string link = "";
        public string Type = "";
        public string Name = "";
    }
}