﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models.Controll
{
    public class NotificationItem
    {
        public Guid UID;
        public List<string> recivename ;
        public string subject = "";
        public string DSC = "";
        public bool IsAnyRead = false;
        public string DateCreate = "";
        public string TimeCreate = "";
        public bool IsReciveMsg = false;
    }
}