﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models.Controll
{
    public class item_CheckboxListItems
    {
        public string id = "";
        public string label = "";
        public bool checked_;
        public string parentID = "";
    }
    public class CheckboxListItems
    {
        public string id = "";
        public string label = "";
        public bool checked_;
        public string parentID = "";
        public List<item_CheckboxListItems> children = new List<item_CheckboxListItems>();
    }
}