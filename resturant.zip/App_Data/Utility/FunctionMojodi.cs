﻿using Models;
using restauran.Models.Access;
using restauran.Models.Access.Tables;
//using SmsIrRestful;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using Utility;

/// <summary>
/// Summary description for SmsUtility
/// </summary>
/// 

public static class FunctionMojodi
{
    /// <summary>
    /// تعداد کل منقضی حذف شده را بدست اورده
    /// از کل موجودی کم می کند
    /// همچنین تمام جنس های فروخته شده را نیز از کل موجودی کم می کند به جز جنس های فروخته شده ی منقضی 
    /// </summary>
    /// <param name="productID"></param>
    public static void SETMOJODI(string productID)
    {
        DBDataContext dc = new DBDataContext();
        var obj = dc.Products.FirstOrDefault(s => s.UID.ToString() == productID);
        if (obj != null)
        {
            //تعداد کل منقضی ها
            decimal MojodiMonghazi = (decimal)(dc.Prices.Any(s => s.IsDeleted == false && s.IsDarhalEngheza == true && s.ProductId == obj.UID) ? dc.Prices.Where(s => s.IsDeleted == false && s.IsDarhalEngheza == true && s.ProductId == obj.UID).Sum(s => s.MojodiProduct) : 0);
            //تعداد فروخته شده ها به جز منقضی ها
            var sabadkharidList = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == true && s.ProductId == obj.UID && (s.PriceID == null || (s.Price.IsDarhalEngheza == false)));
            decimal sabadKharidCount = sabadkharidList.Any() ? sabadkharidList.Sum(s => s.Count) : 0;
            decimal sum = ((dc.Mojodis.Any(s => obj.UID == s.ProductId && s.IsDeleted == false) ? dc.Mojodis.Where(s => obj.UID == s.ProductId && s.IsDeleted == false).Sum(s => s.Count) : 0));

            obj.MojodiCount = sum - sabadKharidCount - MojodiMonghazi;
            dc.SubmitChanges();
        }
    }
    public static decimal? TedadReserveProduct_BdoneMonghaziHa(Guid uID)
    {
        DBDataContext dc = new DBDataContext();
        var objs_ReserveSabadKala = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false
           && s.ProductId == uID
           && s.SabadKharid.IsKharid == false
           && (s.PriceID == null || (s.Price.IsDarhalEngheza == false)));
        return objs_ReserveSabadKala.Any() ? objs_ReserveSabadKala.Sum(s => s.Count) : (decimal?)null;
    }

    public static decimal MojodiTedadDarHaleEngheza(Guid uID)
    {
        DBDataContext dc = new DBDataContext();

        string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
        var price_objs = dc.Prices.Where(s => s.ProductId == uID && s.IsDeleted == false && s.IsDarhalEngheza == true
          && s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
          && (s.DatetimePayan_Persian != null && s.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0));

        List<Guid> lstuid = price_objs.Select(s => s.UID).ToList();

        var objs_ForokhteShodeSabadKala = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false
       && s.SabadKharid.IsKharid == true
       && (s.PriceID != null && lstuid.Contains(s.PriceID)));


        decimal tedad_Monghazi = (decimal)(price_objs.Any() ? (price_objs.Sum(s => s.MojodiProduct) - (objs_ForokhteShodeSabadKala.Any() ? objs_ForokhteShodeSabadKala.Sum(s => s.Count) : 0)) : 0);
        return tedad_Monghazi;
    }

    public static decimal? MojodiReservHay_TedadDarHaleEngheza(Guid uID)
    {
        DBDataContext dc = new DBDataContext();

        string currentDatetime = DateShamsi.GetMixShamsiDateTimeString(DateShamsi.GetCurrentDate(), DateShamsi.GetCurrentHour().Substring(0, 5));
        var price_objs = dc.Prices.Where(s => s.ProductId == uID && s.IsDeleted == false && s.IsDarhalEngheza == true
          && s.DatetimeShoro_Persian != null && s.DatetimeShoro_Persian.CompareTo(currentDatetime) <= 0
          && (s.DatetimePayan_Persian != null && s.DatetimePayan_Persian.CompareTo(currentDatetime) >= 0)).Select(s => (Guid?)s.UID).ToList();

        var objs_ReserveShodeSabadKala = dc.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false
             && s.SabadKharid.IsKharid == false
             && (s.PriceID != null && price_objs.Contains(s.PriceID)));
        return (decimal?)(objs_ReserveShodeSabadKala.Any() ? objs_ReserveShodeSabadKala.Sum(s => s.Count) : (decimal?)null);
    }


    public static void NOtificationToMinProd(Guid? prodID, string Dsc)
    {
        try
        {
            DBDataContext dc = new DBDataContext();
            var q_prods = (from p in dc.Products
                           where
                           (prodID == null || p.UID == prodID)
                           &&
                           p.IsDeleted == false
                           &&
                           p.IsShowInSite == true
                           &&
                           (
                           p.MojodiCount <= p.MinMojodi
                           ||
                           (p.MojodiCount - (p.SabadKharidItems.Any(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)) ? p.SabadKharidItems.Where(s => s.SabadKharid.IsDeleted == false && s.SabadKharid.IsKharid == false && (s.Price.IsPriceAsli || s.Price.IsTakhfifEkhtesasi || s.Price.IsTakhfifOmomi)).Sum(s => s.Count) : 0
                           )) <= p.MinMojodi
                           )
                           select p);

            var q_notMooj = dc.NotificationMojodis.Where(s => (prodID == null || s.ProductID == prodID) && s.IsAfzayesh == false);

            var lstAfzayeshYafte = from p in q_notMooj
                                   join t in q_prods on p.ProductID equals t.UID into rows
                                   from r in rows.DefaultIfEmpty()
                                   where r == null


                                   select p;
            foreach (var q in lstAfzayeshYafte)
                q.IsAfzayesh = true;
            dc.SubmitChanges();

            var q_users = dc.users.Where(s => s.IsDeleted == false && s.Role.IsMenagment == true && (s.RoleId == RoleIds.M_Administrator || s.RoleId == RoleIds.M_AdminWebSiteIds));
            string currentDate = DateShamsi.GetCurrentDate();
            int cnt = 0;
            foreach (var p in q_prods)
            {

                if (p.NotificationMojodis.Count(s => s.Date.CompareTo(currentDate) == 0 && s.IsAfzayesh == false) < 3)
                {
                    var nots = dc.NotificationMojodis.Where(s => s.ProductID == p.UID && s.IsAfzayesh == false).OrderByDescending(s => s.DateTime).FirstOrDefault();

                    if (nots == null || DateTime.Now.Subtract(nots.DateTime.Value).TotalHours > 5)
                    {
                        cnt++;
                        var n = new NotificationMojodi();
                        n.Date = DateShamsi.GetCurrentDate();
                        n.Time = DateShamsi.GetCurrentHour();
                        n.DateTime = DateTime.Now;
                        n.IsAfzayesh = false;
                        n.MojodiJari = p.MojodiCount;
                        n.Product = p;
                        n.UID = Guid.NewGuid();
                        dc.NotificationMojodis.InsertOnSubmit(n);

                        foreach (var user in q_users)
                        {

                            var not = new Notification();
                            not.DateCreate = DateShamsi.GetCurrentDate();
                            not.Dsc = "موجودی کالای " + (p.ProductType.Parent.IsShowName ? p.ProductType.Parent.Name : "") + " " + p.ProductType.Name + " " + p.Brand.Name + " از حداقل ثبت شده کمتر شده است.(" + p.MojodiCount + ")";
                            not.GruopIDs = Guid.NewGuid();
                            not.NotificationTypeId = NotificationTypeIDs.MojodiAnbar;
                            not.UID = Guid.NewGuid();
                            not.userNotificationsMalek = user;
                            not.TimeCreate = DateShamsi.GetCurrentHour();
                            not.SenderID = null;
                            dc.Notifications.InsertOnSubmit(not);
                        }
                    }


                }
                if (cnt >= 15)
                {
                    cnt = 0;
                    dc.SubmitChanges();
                }
            }

            dc.SubmitChanges();
        }
        catch { }

    }

    public static Payment CreatePayment(Guid UserID, decimal mablagh, bool IsAsli, bool IsGift_allMont, bool IsGift_EndMont, bool IsVariz, decimal mablaghKolMojodi, string dsc = "")
    {
        var obj = new Payment();
        obj.DatePersianSabt = DateShamsi.GetCurrentDate();
        obj.TimePersianSabt = DateShamsi.GetCurrentHour();
        obj.DateTimeSabt = DateTime.Now;
        obj.IsGift = IsGift_allMont;
        obj.IsGift_EndMonth = IsGift_EndMont;
        obj.IsVariz = IsVariz;
        obj.UID = Guid.NewGuid();
        obj.MablaghKol = mablaghKolMojodi + (IsVariz ? mablagh : (-1 * mablagh));
        obj.UserAccountId = UserID;
        obj.DSC = dsc;
        obj.UserPardakhKonandeID = UserID;
        obj.MablaghVariziYaBardashti = mablagh;
        return obj;

    }
}