﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;





/// <summary>
/// Summary description for Data_Db
/// </summary>
/// 
public static class NotificationTypeIDs
{
    public static int TakhfifEkhtesasi = 1;
    public static int MojodiAnbar = 2;
    public static int KhoshamadGoie_custmers = 3;
    public static int TahvilSabadKharid = 4;
    public static int Customid = 5;
}
public static class AdditionalFee_Type
{
    public static string TAX = "TAX";
    public static string TRANSPORT = "TRANSPORT";
}
    public static class RoleIds
{

    /// <summary>
    /// 1	مدیر سیستم بخش مدیریت
    /// Emonet
    /// </summary>
    public static int M_Administrator = 1;//faghat Sherkat Emonet
    /// <summary>
    /// 2	مدیر سیستم بخش مشتری
    /// Emonet
    /// </summary>
    public static int C_Administrator = 2;//faghat Sherkat Emonet
    /// <summary>
    /// 3	مدیر سیستم
    /// </summary>
    public static int M_AdminWebSiteIds = 3;
    /// <summary>
    /// 4	مشتری
    /// </summary>
    public static int C_MoshtariIds = 4;
    /// <summary>
    /// 5	اپراتور1
    /// </summary>
    public static int M_OPERATOR_1 = 5;
    /// <summary>
    /// 6	اپراتور2
    /// </summary>
    public static int M_OPERATOR_2 = 6;
    /// <summary>
    /// 8	توزیع کننده
    /// </summary>
    public static int M_ToziKonande = 8;
    /// <summary>
    /// 9	ویزیتور
    /// </summary>
    public static int M_Visitor = 9;
}
